@import "common.js"
@import "IautoLib/iautolib.js"
@import "IautoLib/filelib.js"
@import "IautoLib/metaparse.js"
@import "IautoLib/metaparsenew.js"
@import "IautoLib/logJS.js"
@import "IautoSketchLibManager/iautoLibraryControlor.js"

const SW_OPERATION_PATTERNS = [
  'Select SW Operation',
  'Tap',
  'Long Press',
  'Scroll',
  'Timeout',
  'Outside Input'
]

const BEEP_TYPES = [
  'Select Beep Type',
  'Decision',
  'Failure',
  'Notice',
  'None'
]


function setMetadataPanelStopFlag(flag)
{
    var mocha = Mocha.sharedRuntime();
    var MetadataPanelStopFlag = "MetadataPanelStopFlag";
    mocha.setValue_forKey_(flag, MetadataPanelStopFlag);
}
function checkMetadataPanelStopFlag()
{
    var mocha = Mocha.sharedRuntime();
    var MetadataPanelStopFlag = "MetadataPanelStopFlag";
    return mocha.valueForKey(MetadataPanelStopFlag);
}
function restartSetupPanelNew(context)
{
    setupPanelNew(context, context.command, true);
}

SInherit = function(className, BaseClass, selectorHandlerDict) {
    var uniqueClassName = className + NSUUID.UUID().UUIDString();
    var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, BaseClass);
    for (var selectorString in selectorHandlerDict) {
        // LogJS.error("importexport","SInherit selectorString = "+selectorString)
        delegateClassDesc.addInstanceMethodWithSelector_function_(selectorString, selectorHandlerDict[selectorString]);
        //log(selectorString + "->" + selectorHandlerDict[selectorString].toString())
    }
    delegateClassDesc.registerClass();
    return NSClassFromString(uniqueClassName);
};

function ExportHMISpecOwn(context) {
    if (fileExists("/usr/bin/java") == false) {
        showAlert("No java command. Please install java first!");
        return -2;
    }

    coscript.setShouldKeepAround(true);
    //var myWorkSpace = WORK_SPACE;
    var script_full_filename = context.scriptPath;
    var sketchPluginPath = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    sketchPluginPath = sketchPluginPath.substr(0, sketchPluginPath.lastIndexOf('/'));
    var frameworkpath = sketchPluginPath + "/Resources/";
    console.log("frameworkpath "+frameworkpath)
    // var frameworkpath = NSString.stringWithFormat_(context.scriptPath).stringByDeletingLastPathComponent().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent()
    // frameworkpath = "/Users/wuyuchi/Library/Developer/Xcode/DerivedData/TestTMNAFrameworkApp-elzslrzkwsiyqtavcueeihnujnws/Build/Products/Debug/";
    //var frameworkpath = "/Users/nb/sketch19/sketchplugin/bundle_xcode/sketchPluginFramework"
    var frameworkname = "TMNAFramework"
    var mocha = [Mocha sharedRuntime]
    var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]


    var command = context.command;
    var document = context.document;
    var scriptPath = context.scriptPath;
    var scriptURL = context.scriptURL;
    var selection = context.selection;
    SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
    var sketchObjects = [
        MSLayer.new(),
        MSLayerGroup.new(),
        MSFlowConnection.new(),
        MSSymbolCreator.new(),
        MSLayerArray.new(),
        MSTextLayer.new(),
        MSArtboardGroup.new(),
        MSShapeGroup.new(),
        MSExportRequest.new(),
        MSStyle.new(),
        MSStyleFill.new(),
        MSColor.new(),
        MSCurvePoint.new(),
        MSShapePathLayer.new(),
        MSRectangleShape.new(),
        MSTriangleShape.new(),
        MSOvalShape.new(),
        MSStarShape.new(),
        MSPolygonShape.new(),
        MSAbsoluteRect.new()
    ];
    SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);
    // generatePartID_temp(context)
    var pageSelectViewObj = pageSelectView.alloc().init();
    pageSelectViewObj.startShowPageInfo()
    setDelegateForScreenOverView(pageSelectViewObj,context);
    // var ExportHMISpecObj = ExportHMISpec.alloc().init();
    // ExportHMISpecObj.startExportHMISpec();
}

var selectedPagesActions = {
    "setContext:":function(context) {
        // console.log("setContext")
        // LogJS.error("importexport","setContext")
        this.context = context
    },
    "onOKBtn:":function(param) {
        // var exportHMISpecObj = new ExportHMISpecManager(this.context,param);
        // exportHMISpecObj.exportHMISpecStrart(this.context);

        var result_full_path = param["path"];
        ConvertJson2Excel(this.context,result_full_path);
    }
}

function ConvertJson2Excel(context,result_full_path)
{
    var script_full_filename = context.scriptPath;
    let work_result_dir = ""+result_full_path + "/___exportspecs___";
    let script_full_path = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    let params = []
    params.push("-jar");
    params.push(""+script_full_path+"/IautoScripts/GenScreenSpec.jar");
    params.push(work_result_dir+"/");
    params.push(result_full_path+"/");
    let retCmdStr = runCommand("/usr/bin/java", params);

    if (retCmdStr.length > 0) {
        LogJS.error("importexport", "Java Params:"+params);
        LogJS.error("importexport", "Java Console:"+retCmdStr);
    }
    //deleteFile(work_result_dir);
    showAlert("Export Finished!");
}

function generatePartID_temp(context){
    let pages = context.document.pages();
    for (let ii=0; ii < pages.count(); ii++) {
        var curPage = pages[ii];
        if (isPageIgnored(curPage)==true) {
            continue;
        }
        for (let jj = 0; jj < curPage.artboards().count(); jj++) {
            var nowArtBoard = curPage.artboards()[jj];
            var nowArtBoardObjectID = nowArtBoard.objectID();
            if(isArtboardIgnored(nowArtBoard)){
                continue
            }
            generatePartID(context, nowArtBoard);
        }
    }
}

function setDelegateForScreenOverView(selectPagesPanel,context) {
    // add delegate for screen & parts
    var pageSelectViewDelegatejs = SInherit("pageSelectViewDelegatejs", pageSelectViewDelegate,selectedPagesActions);

    var pageSelectViewDelegatejs = pageSelectViewDelegatejs.alloc().init()
    pageSelectViewDelegatejs.setContext(context)
    //LogJS.error("importexport",pageSelectViewDelegateobj.onOKBtn)
    selectPagesPanel.setDelegage(pageSelectViewDelegatejs);
}

function ExportHMISpecManager(context,config)
{
    this.context = context;
    this.pageConfig = config;
}

ExportHMISpecManager.prototype.exportHMISpecStrart = function(context)
{
    var openPanel = NSOpenPanel.openPanel();
    [openPanel setCanChooseDirectories:true]; //Can open the directory
    [openPanel setCanChooseFiles:0]; //Can only select directory and can not select file
    [openPanel setDirectory:NSHomeDirectory()]; //The default directory is $home

    [openPanel setPrompt: @"Export"];

    if (openPanel.runModal() != NSOKButton) {
        return false;
    }

    var result_full_path = openPanel.URL().path();

    // // 0 init
    var script_full_filename = context.scriptPath;
    var sketchPluginPath = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    this.symbolExpandConfilePath = sketchPluginPath + "/IautoConfig/symbolexpand.json";
    this.symbolExpandConfileContent = nil;
    this.symbolexpandConfig = nil;

    if (fileExists(this.symbolExpandConfilePath)) {
        this.symbolExpandConfileContent = readJson(this.symbolExpandConfilePath);
    }
    this.initExpandSymbolsConfig();

    //Create temperory work path
    let work_result_dir = ""+result_full_path + "/___exportspecs___";
    // console.log(work_result_dir)
    if (fileExists(work_result_dir) == true) {
        deleteFile(work_result_dir);
    }

    createDirectory(work_result_dir);
    createDirectory(work_result_dir+"/images");

    let pages = context.document.pages();
    for (let ii=0; ii < pages.count(); ii++) {
        var curPage = pages[ii];
        var curPageName = ""+curPage.name();
        if (isPageIgnored(curPage)==true) {
            continue;
        }
        var flag = this.pageConfig[curPageName]
        if([flag boolValue]){
            this.ExportOnePageToExcel(context, curPage, work_result_dir, result_full_path);
        }
    }

    // 3.generate excel
    let script_full_path = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    let params = []
    params.push("-jar");
    // params.push("-Xms1g");
    // params.push("-Xmx4g");
    params.push(""+script_full_path+"/IautoScripts/GenScreenSpec.jar");
    params.push(work_result_dir+"/");
    params.push(result_full_path+"/");
    let retCmdStr = runCommand("/usr/bin/java", params);

    if (retCmdStr.length > 0) {
        LogJS.error("importexport", "Java Params:"+params);
        LogJS.error("importexport", "Java Console:"+retCmdStr);
    }

    deleteFile(work_result_dir);

    showAlert("Export Finished!");
}

ExportHMISpecManager.prototype.initExpandSymbolsConfig = function()
{
    if(this.symbolExpandConfileContent){
        this.symbolexpandConfig = {};
        for(var pageKey in this.symbolExpandConfileContent){
            var artboardsInfo = this.symbolExpandConfileContent[pageKey]["layers"];
            if(!artboardsInfo){
                continue
            }
            for(var artboardKey in artboardsInfo) {
                var allNodeInfo = artboardsInfo[artboardKey]["layers"];
                if(!allNodeInfo){
                    continue
                }
                for(var nodeKey in allNodeInfo){
                    var curKey = ""+pageKey+"_"+artboardKey+"_"+nodeKey
                    log("initExpandSymbolsConfig curKey "+ allNodeInfo[nodeKey]["isExpaned"])
                    this.symbolexpandConfig[curKey] = {}
                    this.symbolexpandConfig[curKey]["isExpaned"] = allNodeInfo[nodeKey]["isExpaned"];
                    this.symbolexpandConfig[curKey]["expandLevel"] = allNodeInfo[nodeKey]["expandLevel"];
                }
            }
        }
    }
}

ExportHMISpecManager.prototype.ExportOnePageToExcel = function(context, onePage, work_dir_url, result_dir_url){
    let onePageSlugName = toSlug(onePage.name())
    createDirectory(result_dir_url+"/"+onePageSlugName)
    let cap_img_path = work_dir_url+"/images";
    let page_result_list = {}
    for (let jj = 0; jj < onePage.artboards().count(); jj++) {
        var nowArtBoard = onePage.artboards()[jj];
        var nowArtBoardObjectID = nowArtBoard.objectID();
        if(isArtboardIgnored(nowArtBoard)){
            continue
        }
        var nowartboardName = nowArtBoard.name()+"";
        let one_artboard_dict = {}
        let artbord_metadata = context.command.valueForKey_onLayer_forPluginIdentifier(
            'metadata',
            nowArtBoard,
            'tmnaMM'
        );
        let artboard_destgrade_jsonstr = context.command.valueForKey_onLayer_forPluginIdentifier(
            "ScreenAdoptionInfo",
            nowArtBoard,
            "tmnaMM"
        );
        let artboard_screenID = context.command.valueForKey_onLayer_forPluginIdentifier(
            "ScreenID",
            nowArtBoard,
            "tmnaMM");
        if (artboard_screenID == null) {
            artboard_screenID = ""
        }

        generatePartID(context, nowArtBoard)

        var ScreenID = ""
        var tempIndex = nowartboardName.indexOf("-")
        if(tempIndex != -1){
            ScreenID = removeBlankspace(nowartboardName.substr(0, tempIndex));
        }
        one_artboard_dict["ScreenInfo"] = {}
        one_artboard_dict["ScreenInfo"]["excelInfo"] = {}
        one_artboard_dict["ScreenInfo"]["excelInfo"]["Screen ID"] = "" + ScreenID//artboard_screenID;
        one_artboard_dict["ScreenInfo"]["excelInfo"]["Basic Screen ID"] = ""+nowArtBoardObjectID
        one_artboard_dict["ScreenInfo"]["excelInfo"]["Screen Name"] = ""+nowartboardName
        one_artboard_dict["ScreenInfo"]["excelInfo"]["Note"] = getMetaRemarks(artbord_metadata)
        one_artboard_dict["ScreenInfo"]["sketchInfo"] = {}
        one_artboard_dict["ScreenInfo"]["sketchInfo"]["uuid"] = ""+nowArtBoardObjectID

        one_artboard_dict["ScreenInfo"]["sketchInfo"]["Rect"] = {}
        one_artboard_dict["ScreenInfo"]["sketchInfo"]["Rect"]["x"] = "0"
        one_artboard_dict["ScreenInfo"]["sketchInfo"]["Rect"]["y"] = "0"
        one_artboard_dict["ScreenInfo"]["sketchInfo"]["Rect"]["w"] = ""+Math.round(nowArtBoard.frame().width())
        one_artboard_dict["ScreenInfo"]["sketchInfo"]["Rect"]["h"] = ""+Math.round(nowArtBoard.frame().height())

        exportLayerTofile(context, nowArtBoard, cap_img_path, nowArtBoardObjectID);
        one_artboard_dict["ScreenInfo"]["sketchInfo"]["imgPath"] = cap_img_path+"/"+nowArtBoardObjectID+".png"

        // save destgrade information
        one_artboard_dict["DestGradeInfo"] = {}
        dest_region_list = ["Japan","Europe/Russia","China","Oceania","South Africa","HongKong / Macao","South East Asia",
                            "India","Taiwan","Middle East","South and Central (Brazil & Argentina)","South and Central","Korea"]

        for (let one_region_index in dest_region_list) {
            let one_region = dest_region_list[one_region_index]
            one_artboard_dict["DestGradeInfo"][one_region] = {}
            //Lexus information
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"] = {}
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Unavailable"]={}
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Unavailable"]["L1"] =""
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Unavailable"]["L1.5"] =""
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Unavailable"]["L2"] =""
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Available"]={}
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Available"]["L1"] =""
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Available"]["L1.5"] =""
            one_artboard_dict["DestGradeInfo"][one_region]["Lexus"]["Available"]["L2"] =""
            //toyota information
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"] = {}
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Unavailable"]={}
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Unavailable"]["Entry DA"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Unavailable"]["T1"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Unavailable"]["T2"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Unavailable"]["T-EMVN"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Available"]={}
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Available"]["Entry DA"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Available"]["T1"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Available"]["T2"]=""
            one_artboard_dict["DestGradeInfo"][one_region]["Toyota"]["Available"]["T-EMVN"]=""
        }
        if (artboard_destgrade_jsonstr != null) {
            let artboard_destgrade = JSON.parse(artboard_destgrade_jsonstr);

            for(let idestregion in artboard_destgrade) {
                if (!(idestregion in one_artboard_dict["DestGradeInfo"])) {
                    continue
                }
                for (let icartype in artboard_destgrade[idestregion]) {
                    for (let icartype_enable in artboard_destgrade[idestregion][icartype]) {
                        for (let icartype_machine in artboard_destgrade[idestregion][icartype][icartype_enable]) {
                            one_artboard_dict["DestGradeInfo"][idestregion][icartype][icartype_enable][icartype_machine] = artboard_destgrade[idestregion][icartype][icartype_enable][icartype_machine]
                        }
                    }
                }
            }
        }

        var subLayers = [];
        getAllSubLayers(nowArtBoard,subLayers);
        one_artboard_dict["PartsList"] = {}
        var prefixKey = ""+onePage.objectID()+"_"+nowArtBoardObjectID;
        for (let ilayer = 0; ilayer < subLayers.length; ilayer++) {
            var curLayer = subLayers[ilayer];
            var curLayerObjectID = curLayer.objectID();
            if (isLayerIgnored(curLayer, 'redline')==true) {
                continue;
            }
            if ((curLayer.absoluteRect().x()+curLayer.absoluteRect().width()) > (nowArtBoard.absoluteRect().x()+nowArtBoard.absoluteRect().width())) {
                continue;
            }
            if ((curLayer.absoluteRect().y()+curLayer.absoluteRect().height()) > (nowArtBoard.absoluteRect().y()+nowArtBoard.absoluteRect().height())) {
                continue;
            }

            var curLayerMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
                'metadata',
                curLayer,
                'tmnaMM'
            );
            let curLayerConditionData = context.command.valueForKey_onLayer_forPluginIdentifier(
                'screenSpecConditions',
                curLayer,
                'tmnaMM'
            );
            let curLayerPartIDInfo = context.command.valueForKey_onLayer_forPluginIdentifier(
                'PartID',
                curLayer,
                'tmnaMM'
            );
            var curLayerPartID = ""
            if (curLayerPartIDInfo) {
                curLayerPartID = curLayerPartIDInfo[curLayerObjectID];
            }
            var onePartObj = this.makeDetailInfo4Layer(curLayer,curLayerPartID,curLayerMetadata,curLayerConditionData,cap_img_path,0,0)

            var partType = getPartsType(curLayerMetadata)
            if(!partType || partType == "" || partType == "Select Part Type"){
                if(curLayer.className() == "MSSymbolInstance") {
                    var curMasterID = curLayer.symbolMaster().objectID();
                    var iautoLibraryControlorObj = new iautoLibraryControlor(context);
                    var correspond_master = iautoLibraryControlorObj.getSymbolFromLib(curMasterID);
                    if(correspond_master){
                        var curMasterMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
                            'metadata',
                            correspond_master,
                            'tmnaMM'
                        );
                        partType = getPartsType(curMasterMetadata)
                        if(partType){
                            onePartObj["Parts Type"] = partType;
                        }
                    }
                }
            }

            if(checkIsTextInstance(curLayer)){
                var curstringValue = getTextInstanceValue(curLayer);
                onePartObj["sketchInfo"]["imgPath"] = ""+curstringValue;
            }
            else{
                exportLayerTofile(this.context, curLayer, cap_img_path, curLayerObjectID);
                onePartObj["sketchInfo"]["imgPath"] = cap_img_path+"/"+curLayerObjectID+".png"
                if(isSymbolWithMaster(curLayer)){
                    onePartObj["subsymbols"] = {}
                    this.generateSublayerInfo(context,curLayer,onePartObj["subsymbols"],cap_img_path,prefixKey)
                }
            }

            one_artboard_dict["PartsList"][curLayerObjectID] = onePartObj
        }

        page_result_list[nowArtBoardObjectID]=one_artboard_dict
    }

    let pageDicStr = jsonFomat(JSON.stringify(page_result_list));
    writeTextToFile(pageDicStr, work_dir_url+"/"+onePageSlugName+".json");

    return true;
}

function generatePartID(context, artboard_info) {
    // set group letter
    let group_list = []
    getAllArtboardGroup(artboard_info, group_list)
    generateGroupLayerPartID(context, artboard_info, "", artboard_info)

    var maxIndexForNode = getMaxIndexForGroup(context,artboard_info);
    var partIDTextNum = maxIndexForNode+1
    for (let igroup = 0; igroup < group_list.length; igroup++) {
        let curGroup = group_list[igroup];
        var curgroupobjectID = curGroup.objectID();
        let curPartIDMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
            'PartID',
            curGroup,
            'tmnaMM'
        );
        var curgrouppartID = "";
        if (curPartIDMetadata && curPartIDMetadata[curgroupobjectID]) {
            curgrouppartID = curPartIDMetadata[curgroupobjectID]
        }
        else{
            var curgroupobjectInfo = {}
            curgrouppartID = convertNumToStr(partIDTextNum)
            curgroupobjectInfo[curgroupobjectID] = curgrouppartID;
            context.command.setValue_forKey_onLayer_forPluginIdentifier(
                curgroupobjectInfo,
                "PartID",
                curGroup,
                "tmnaMM");
            partIDTextNum = partIDTextNum + 1;
        }
        //LogJS.error("importexport","generateGroupLayerPartID "+curGroup.name()+"")
        generateGroupLayerPartID(context, curGroup, curgrouppartID, artboard_info)
    }
}

function generateGroupLayerPartID(context, group_layer, prefix_str, artboard_info) {
    let subLayers = group_layer.layers()
    var maxIndexForNode = getMaxIndexForInstance(context,group_layer,subLayers);
    let partIDTextNum = maxIndexForNode+1
    for(let idxSub=0; idxSub<subLayers.count(); idxSub++)
    {
        let sublayer = subLayers[idxSub];
        if (sublayer.class() == MSArtboardGroup || sublayer.class() == MSLayerGroup) {
            continue;
        }
        if (isLayerIgnored(sublayer, 'redline')==true) {
            continue;
        }
        // if ((sublayer.absoluteRect().x()+sublayer.absoluteRect().width()) > (artboard_info.absoluteRect().x()+artboard_info.absoluteRect().width())) {
        //     continue;
        // }
        // if ((sublayer.absoluteRect().y()+sublayer.absoluteRect().height()) > (artboard_info.absoluteRect().y()+artboard_info.absoluteRect().height())) {
        //     continue;
        // }
        var newPartIDInfo = {};
        let curPartIDMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
            'PartID',
            sublayer,
            'tmnaMM'
        );
        var sublayerobjectID = sublayer.objectID();
        var newpartID = prefix_str+partIDTextNum
        if (curPartIDMetadata && curPartIDMetadata[sublayerobjectID]) {
            newPartIDInfo[sublayerobjectID] = curPartIDMetadata[sublayerobjectID];
        }
        else{
            newPartIDInfo[sublayerobjectID] = newpartID;
            partIDTextNum = partIDTextNum + 1
        }

        var selectedLayerSubSymbols = []
        allSymbolLayersWithParents(sublayer, selectedLayerSubSymbols)
        if(selectedLayerSubSymbols.length > 1){
            selectedLayerSubSymbols.reverse()
            selectedLayerSubSymbols.pop()
            var maxIndexForSub = getMaxIndexForInstance(context,sublayer,selectedLayerSubSymbols);
            var subLayerIndex = maxIndexForSub+1;
            for(var num=0;num<selectedLayerSubSymbols.length;num++){
                var childLayer = selectedLayerSubSymbols[num];
                var childLayerObjectID = childLayer.objectID();

                if (curPartIDMetadata && curPartIDMetadata[childLayerObjectID]) {
                    newPartIDInfo[childLayerObjectID] = curPartIDMetadata[childLayerObjectID];
                }
                else{
                    var subLayerpartID = newpartID +"_"+ subLayerIndex;
                    newPartIDInfo[childLayerObjectID] = subLayerpartID;
                    subLayerIndex = subLayerIndex + 1;
                }
            }
        }
        context.command.setValue_forKey_onLayer_forPluginIdentifier(
                    newPartIDInfo,
                    "PartID",
                    sublayer,
                    "tmnaMM");
    }
}
function getAllSubLayersForImport(layer, list, context)
{
    if (nil == layer) {
        return;
    };

    if(layer.class() == MSArtboardGroup || layer.class() == MSLayerGroup)
    {
        var subLayers = layer.layers()
        for(var idxSub=0; idxSub<subLayers.count(); idxSub++)
        {
            var sublayer = subLayers[idxSub];
            getAllSubLayersForImport(sublayer, list, context)
        }
    }
    else if(layer.class() == MSSymbolInstance){
        clearMetaAndConditData(layer, context);
        list.push(layer)
    }
    else {
      //Do nothing
    }
}
function clearMetaAndConditData(layer, context){
    var nullMetadata = [];
    context.command.setValue_forKey_onLayer_forPluginIdentifier(
            nullMetadata, 'metadata', layer, 'tmnaMM');
    var nullCondiData = {};
    context.command.setValue_forKey_onLayer_forPluginIdentifier(
            nullCondiData, 'screenSpecConditions', layer, 'tmnaMM');
}


function getAllSubLayers(layer, list)
{
    if (nil == layer) {
        return;
    };

    if(layer.class() == MSArtboardGroup || layer.class() == MSLayerGroup)
    {
        var subLayers = layer.layers()
        for(var idxSub=0; idxSub<subLayers.count(); idxSub++)
        {
            var sublayer = subLayers[idxSub];
            getAllSubLayers(sublayer, list)
        }
    }
    else if(layer.class() == MSSymbolInstance){
        list.push(layer)
    }
    else {
      //Do nothing
    }
}

function getPython3CmdPath() {
    var python36Path = "/Library/Frameworks/Python.framework/Versions/3.6/bin/python3";
    var python37Path = "/Library/Frameworks/Python.framework/Versions/3.7/bin/python3";
    var python3Path = "";

    if(fileExists(python37Path)){
        python3Path = python37Path;
        return python3Path;
    }
    else if(fileExists(python36Path)){
        python3Path = python36Path;
        return python3Path;
    }

    return null;
}

function ImportHMISpec(context)
{
    setMetadataPanelStopFlag(true);

    var ctx = context;

    delayRun(0.3, () => {
            tryLoadFramework(ctx);

            ImportHMISpecDo(ctx);

            restartSetupPanelNew(ctx);
    })
}

function ImportHMISpecDo(context) {

    LogJS.error("importexport", "ImportHMISpec :");
    console.log("ImportHMISpec==");
//   var frameworkpath = "/Users/godfatherlaw/Desktop/sketch_pro/Plugins/demo_tmna_1113/sketchplugin/NewTmnaSpecTool/xcode_project/TMNAFramework"
// var frameworkname = "TMNAFramework"
// var mocha = [Mocha sharedRuntime]
// var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
//
// SketchEventHandler.onSetWorkspace("/Users/godfatherlaw/Desktop/sketch_pro/sketchplugin/iWorkSpace");
// var command = context.command;
// var document = context.document;
// var scriptPath = context.scriptPath;
// var scriptURL = context.scriptURL;
// var selection = context.selection;
// SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
// var sketchObjects = [MSLayer.new(),MSLayerGroup.new(),MSFlowConnection.new(),MSSymbolCreator.new(),MSLayerArray.new(),MSTextLayer.new(),MSArtboardGroup.new(),MSShapeGroup.new(),MSExportRequest.new(),MSStyle.new(),MSStyleFill.new(),MSColor.new(),MSCurvePoint.new(),MSShapePathLayer.new(),MSRectangleShape.new(),MSTriangleShape.new(),MSOvalShape.new(),MSStarShape.new(),MSPolygonShape.new(),MSAbsoluteRect.new()];
// SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);

    tryLoadFramework(context);
    //1、关闭tmna的窗口
    const mainSplitView = context.document.splitViewController().splitView()
    let mainSplitSubviews = mainSplitView.arrangedSubviews()
    // Remove any and all existing panels
    for (let iii=mainSplitSubviews.length-1; iii>=0; iii--) {
        if (String(mainSplitSubviews[iii].class()) == "TCSidebarPane") {
            mainSplitView.removeArrangedSubview(mainSplitSubviews[iii])
        }
        if (String(mainSplitSubviews[iii].class()) == "pluginSplitView") {
            mainSplitView.removeArrangedSubview(mainSplitSubviews[iii])
        }
    }

    //2、打开选择目录对话框，只允许选择文件。
    //选择的目标目录中应该包括hmispec目录和sketchsymbols目录
    //hmispec目录中存放了导入需要用到的hmi式样书
    //sketchsymbols目录中存放了symbolID与PartsID的绑定关系
    var openPanel = NSOpenPanel.openPanel();

    [openPanel setCanChooseDirectories:true]; //可以打开目录
    //[openPanel setCanChooseFiles:0]; //不能打开文件(我需要处理一个目录内的所有文件)
    [openPanel setDirectory:NSHomeDirectory()]; //起始目录为Home
    // [openPanel setAllowsMultipleSelection:true]; //可选多个文件
    [openPanel setPrompt: @"Import"];

    if (openPanel.runModal() != NSOKButton) {
        return false;
    }
    let import_full_path = openPanel.URL().path();

    let binding_json_path = import_full_path
    if (import_full_path.substr(import_full_path.lastIndexOf('.')) ==".xlsx") {
        binding_json_path = import_full_path.substr(0, import_full_path.lastIndexOf('/'));
    }

    // 检测是否安装了python3
    python3Cmd = getPython3CmdPath();
    if (python3Cmd == null) {
        showAlert("Python3 is not installed, please install it!");
        return -2;
    }

    //导入式样书
    let script_full_filename = context.scriptPath;
    let script_full_path = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    let excel2jsonret = runCommand(python3Cmd,
                [script_full_path+"/IautoScripts/TmnaExcel2Json.py", import_full_path, binding_json_path+"/spec_result.json"],
                {"LC_ALL":"en_us.UTF-8"});
    if (excel2jsonret.length > 0) {
        LogJS.error("importexport", "Python Command:"+python3Cmd);
        LogJS.error("importexport", "Python Params:"+import_full_path);
        LogJS.error("importexport", "Python Script TmnaExcel2Json Return Console:"+excel2jsonret);
        showAlert("Import Error! Please see the logfile($home/iauto_tmnaplugin/log/iautoplugin.log) for the detail information!");
        return -2;
    }
    LogJS.info("importexport", "Run TmnaExcel2Json.py Finished.");

    bindingInfo_json = readJson(binding_json_path+"/spec_result.json")

    let pages = context.document.pages();
    for (let ii=0; ii < pages.count(); ii++) {
        if (isPageIgnored(pages[ii])==true) {
            continue;
        }

        let onePage = pages[ii];
        for (let jj = 0; jj < onePage.artboards().count(); jj++) {
            let nowArtBoard = onePage.artboards()[jj];
            var nowArtBoardID = nowArtBoard.objectID();
            if (!bindingInfo_json[nowArtBoardID]) {
                continue;
            }
            let screen_dest_grade_info = getDestGradeInfo(nowArtBoardID, bindingInfo_json)
            if (screen_dest_grade_info == null) {
                continue;
            }
            //LogJS.info("importexport", "DestGrade data for object："+JSON.stringify(screen_dest_grade_info));

            screen_dest_grade_info["Region"] = {
                "Current":"Japan",
                "List":["Japan","Europe/Russia","China","Oceania","South Africa","HongKong / Macao","South East Asia",
                "India","Taiwan","Middle East","South and Central (Brazil & Argentina)","South and Central","Korea","North America"]
            }
            // console.log(""+nowArtBoard.objectID())
            // console.log(screen_dest_grade_info)
            context.command.setValue_forKey_onLayer_forPluginIdentifier(
                JSON.stringify(screen_dest_grade_info), 'ScreenAdoptionInfo', nowArtBoard, 'tmnaMM');
            //set artboard metadata
            getArtBoardMetadata(bindingInfo_json,nowArtBoard,context);

            var subLayers = [];
            getAllSubLayersForImport(nowArtBoard,subLayers,context);

            var partsList = getAllPartsFromJson(bindingInfo_json,nowArtBoardID);
            if(partsList){
                for (let ilayer = 0; ilayer < subLayers.length; ilayer++) {
                    let curLayer = subLayers[ilayer];
                    // if (isLayerIgnored(curLayer, 'redline')==true) {
                    //     continue;
                    // }
                    var subLayerInfo = getSubLayerInfodata(partsList, curLayer, nowArtBoardID)
                    if(subLayerInfo){
                        // var partIDInfo = subLayerInfo["Parts ID"];
                        // context.command.setValue_forKey_onLayer_forPluginIdentifier(
                        //         partIDInfo, 'PartID', curLayer, 'tmnaMM');
                        //meta data
                        var metadata = subLayerInfo["metadata"];
                        context.command.setValue_forKey_onLayer_forPluginIdentifier(
                                metadata, 'metadata', curLayer, 'tmnaMM');

                        //conditionsData
                        var conditionsData = subLayerInfo["conditionsData"];
                        context.command.setValue_forKey_onLayer_forPluginIdentifier(
                                conditionsData, 'screenSpecConditions', curLayer, 'tmnaMM');

                    }
                }
            }
        }
    }

    // deleteFile(binding_json_path+"/spec_result.json");

    showAlert("Import Finished!");
}

function getArtBoardMetadata(bindingInfo_json,nowArtBoard,context){
  var artBoardMeta = [];
  //claer
  context.command.setValue_forKey_onLayer_forPluginIdentifier(
          artBoardMeta, 'metadata', nowArtBoard, 'tmnaMM');

  var artBoardMetaInfo = {};
  artBoardMetaInfo["type"] = "Remarks";
  artBoardMetaInfo["content"] = bindingInfo_json[nowArtBoard.objectID()]["ScreenInfo"]["excelInfo"]["Note"];
  artBoardMeta.push(artBoardMetaInfo);

  context.command.setValue_forKey_onLayer_forPluginIdentifier(
          artBoardMeta, 'metadata', nowArtBoard, 'tmnaMM');
}

function getAllPartsFromJson(JsonInfo,artboardID)
{
    if(!JsonInfo || !JsonInfo[artboardID]){
        return nil;
    }
    var partsList = {};
    var partsListFromJson = JsonInfo[artboardID]["PartsList"];

    if(!partsListFromJson){
        return nil;
    }

    for(var partId in partsListFromJson){
        var curNodeInfo = partsListFromJson[partId];
        console.log("getAllPartsFromJson=="+partId);
        partsList[partId] = curNodeInfo;
        if(curNodeInfo["subsymbols"]){
            var subSymbolsList = curNodeInfo["subsymbols"];
            for(var subSymbolId in subSymbolsList){
                partsList[subSymbolId] = subSymbolsList[subSymbolId];
            }
        }
    }
    return partsList;
}

ExportHMISpecManager.prototype.generateSublayerInfo = function(context,targetLayer,indoData,cap_img_path,prefixKey)
{
    // var curNodeKey = ""+prefixKey+"_"+targetLayer.objectID();
    // var isNeedExpandFlag = 0
    // var curNodeExpandLevel = 0
    // if(this.symbolexpandConfig[curNodeKey]){
    //     isNeedExpandFlag = this.symbolexpandConfig[curNodeKey]["isExpaned"];
    //     curNodeExpandLevel = this.symbolexpandConfig[curNodeKey]["expandLevel"];
    // }
    // if(isNeedExpandFlag == 0 || curNodeExpandLevel <= 0 || targetLayer.className() != "MSSymbolInstance"){
    //     return;
    // }
    // var curMaster = targetLayer.symbolMaster();
    // if(curMaster){
    //     for(var childNum = 0;childNum < curMaster.layers().length;childNum++){
    //         var childLayer = curMaster.layers()[childNum];
    //         var level = curNodeExpandLevel -1;
    //         this.makeSublayerInfo(context,targetLayer,childLayer,indoData,cap_img_path,level)
    //     }
    // }
    this.makeSublayerInfo(context,targetLayer,indoData,cap_img_path);
}

ExportHMISpecManager.prototype.makeSublayerInfo = function(context,targetLayer,indoData,cap_img_path)
{
    if(!isSymbolWithMaster(targetLayer)){
        return;
    }

    //get all sublayers
    var parentRoot = targetLayer.parentRoot();
    var realtive_x = targetLayer.absoluteRect().x() - parentRoot.absoluteRect().x()
    var realtive_y = targetLayer.absoluteRect().x() - parentRoot.absoluteRect().x()
    var selectedLayerSubSymbols = []
    allSymbolLayersWithParents(targetLayer, selectedLayerSubSymbols)
    selectedLayerSubSymbols.reverse()
    selectedLayerSubSymbols.pop()

    //
    var targetLayerOverrides = targetLayer.overrides()
    var targetLayerOverrideValues = targetLayer.overrideValues().reverse();
    for(var num=0;num<selectedLayerSubSymbols.length;num++){
        var curLayer = selectedLayerSubSymbols[num];
        var curLayerObjectID = curLayer.objectID();
        if (isLayerIgnored(curLayer, 'redline')==true) {
            continue;
        }
        if(checkOverridesIsNone(targetLayerOverrideValues,curLayerObjectID)){
            continue;
        }

        let curLayerMetadata = nil;
        let curLayerConditionData = context.command.valueForKey_onLayer_forPluginIdentifier(
            'screenSpecConditions',
            targetLayer,
            'tmnaMM'
        );
        var curLayerPartID = nil;
        curLayerMetadata = getSubLayerMetadata(context,targetLayer,curLayerObjectID)
        var curLayerPartInfo = context.command.valueForKey_onLayer_forPluginIdentifier(
            'PartID',
            targetLayer,
            'tmnaMM'
        );
        if(curLayerPartInfo){
            curLayerPartID = curLayerPartInfo[curLayerObjectID]
        }
        var onePartObj = this.makeDetailInfo4Layer(curLayer,curLayerPartID,curLayerMetadata,curLayerConditionData,cap_img_path,realtive_x,realtive_y)
        if(curLayer.className() == "MSTextLayer"){
            var curstringValue = "";
            if(targetLayerOverrides[curLayerObjectID]){
                curstringValue = targetLayerOverrides[curLayerObjectID];
            }
            else{
                curstringValue = curLayer.stringValue();
            }
            onePartObj["sketchInfo"]["imgPath"] = ""+curstringValue;
        }
        else if(checkIsTextInstance(curLayer)){
            var curstringValue = getTextInstanceValueByOverrideValues(targetLayerOverrideValues,curLayer);
            onePartObj["sketchInfo"]["imgPath"] = ""+curstringValue;
        }
        else{
            exportLayerTofile(context, curLayer, cap_img_path, curLayerObjectID);
            onePartObj["sketchInfo"]["imgPath"] = cap_img_path+"/"+curLayerObjectID+".png"
        }

        indoData[curLayerObjectID] = onePartObj;
    }
}

ExportHMISpecManager.prototype.makeDetailInfo4Layer = function(curLayer,curLayerPartID,curLayerMetadata,curLayerConditionData,cap_img_path,realtive_x = 0,realtive_y = 0)
{
    var curLayerObjectID = curLayer.objectID();
    var onePartObj = {}
    var curJsonMetadata = makeJsonMetadata(curLayerMetadata);
    onePartObj["Parts ID"] = ""+curLayerPartID;
    onePartObj["Display image"] = ""+curLayer.name();

    onePartObj["Parts Type"] = getPartsTypeforJson(curJsonMetadata)
    onePartObj["Parts Name"] = ""+curLayer.name();
    onePartObj["choose target"] = ""+getTargetIDformMetaforJson(curJsonMetadata)

    onePartObj["sketchInfo"] = {}
    onePartObj["sketchInfo"]["uuid"] = ""+curLayerObjectID

    onePartObj["sketchInfo"]["Rect"] = {}
    var parentRoot = curLayer.parentRoot();
    if(parentRoot){
        onePartObj["sketchInfo"]["Rect"]["x"] = ""+Math.round(realtive_x + curLayer.absoluteRect().x() - parentRoot.absoluteRect().x());
        onePartObj["sketchInfo"]["Rect"]["y"] = ""+Math.round(realtive_y + curLayer.absoluteRect().y() - parentRoot.absoluteRect().y());
    }
    else{
        onePartObj["sketchInfo"]["Rect"]["x"] = ""+realtive_x;
        onePartObj["sketchInfo"]["Rect"]["y"] = ""+realtive_y;
    }

    onePartObj["sketchInfo"]["Rect"]["w"] = ""+Math.round(curLayer.frame().width())
    onePartObj["sketchInfo"]["Rect"]["h"] = ""+Math.round(curLayer.frame().height())
    // exportLayerTofile(this.context, curLayer, cap_img_path, curLayerObjectID);
    // onePartObj["sketchInfo"]["imgPath"] = cap_img_path+"/"+curLayerObjectID+".png"

    onePartObj["Display Condition"] = getConditionDict(curLayerConditionData, curLayer, "displayCondition")

    onePartObj["Text or Image information"] = {}
    onePartObj["Text or Image information"]["Japanese"] = {}
    onePartObj["Text or Image information"]["Japanese"]["Japanese"] = ""
    onePartObj["Text or Image information"]["Japanese"]["Fixed words"] = ""
    onePartObj["Text or Image information"]["U.S.English"] = {}
    onePartObj["Text or Image information"]["U.S.English"]["U.S.English"] = ""
    onePartObj["Text or Image information"]["U.S.English"]["Fixed words"] = ""
    onePartObj["Text or Image information"]["U.K.English"] = {}
    onePartObj["Text or Image information"]["U.K.English"]["U.K.English"] = ""
    onePartObj["Text or Image information"]["U.K.English"]["Fixed words"] = ""
    onePartObj["Text or Image information"]["Fixed Image"] = ""
    onePartObj["Text or Image information"]["Delete condition in motion"] = getConditionDict(curLayerConditionData, curLayer, "textImageDeleteInMotion")
    onePartObj["Text or Image information"]["Outside Input"] = {}
    onePartObj["Text or Image information"]["Outside Input"]["Display contents"] = getTextImgDispContentforJson(curJsonMetadata)
    onePartObj["Text or Image information"]["Outside Input"]["Format"] = getTextImgFormatforJson(curJsonMetadata)
    onePartObj["Text or Image information"]["Outside Input"]["Range"] = getTextImgRangeforJson(curJsonMetadata)
    onePartObj["Text or Image information"]["Validation"] = getTextImgValidationforJson(curJsonMetadata)

    onePartObj["SW Information"] = {}
    onePartObj["SW Information"]["Tonedown condition in motion"] = getConditionDict(curLayerConditionData, curLayer, "sWTonedownMotion")
    onePartObj["SW Information"]["Tonedown condition except in motion"] = getConditionDict(curLayerConditionData, curLayer, "sWTonedownExceptInMotion")
    onePartObj["SW Information"]["Selected condition"] = getConditionDict(curLayerConditionData, curLayer, "sWSelected")
    onePartObj["SW Information"]["SW operation Pattern"] = getSWOpePatternforJson(curJsonMetadata)
    onePartObj["SW Information"]["Operation result"] = {}
    onePartObj["SW Information"]["Operation result"]["Screen Transion"] = getOpeResultScreenTransforJson(curJsonMetadata)
    onePartObj["SW Information"]["Operation result"]["Start Function"] = getOpeResultStartFuncforJson(curJsonMetadata)
    onePartObj["SW Information"]["Operation result"]["Setting Value Change"] = getOpeResultSettingValueChangeforJson(curJsonMetadata)
    onePartObj["SW Information"]["Operation result"]["Other"] = getOpeResultOtherforJson(curJsonMetadata)
    onePartObj["SW Information"]["BEEP"] = getBeepInfoforJson(curJsonMetadata)
    return onePartObj;
}

function getMaxIndexForGroup(context,targetLayer) {
    if(targetLayer.className() != "MSArtboardGroup" && targetLayer.className() != "MSLayerGroup"){
        return 0
    }
    var group_list = []
    var maxGroupIndex = 0;
    getAllArtboardGroup(targetLayer, group_list);
    for(var groupNum=0;groupNum<group_list.length;groupNum++){
        var curgroup = group_list[groupNum];
        var curgroupobjectID = curgroup.objectID();
        var curPartIDMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
            'PartID',
            curgroup,
            'tmnaMM'
        );
        if (curPartIDMetadata && curPartIDMetadata[curgroupobjectID]) {
            var curGroupIndex = convertStrToNum(curPartIDMetadata[curgroupobjectID])
            if(maxGroupIndex < curGroupIndex){
                maxGroupIndex = curGroupIndex;
            }
        }
    }
    return maxGroupIndex
}

function getMaxIndexForInstance(context,targetLayer,subLayers) {
    var prefix_str = context.command.valueForKey_onLayer_forPluginIdentifier(
            'PartID',
            targetLayer,
            'tmnaMM'
        );
    if (!prefix_str) {
        prefix_str = ""
    }
    var maxInstanceIndex = 0;
    for(var idxSub=0; idxSub<subLayers.length; idxSub++)
    {
        var sublayer = subLayers[idxSub];
        var sublayerObjectID = sublayer.objectID();
        var curPartIDMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
            'PartID',
            sublayer,
            'tmnaMM'
        );
        if (curPartIDMetadata && curPartIDMetadata[sublayerObjectID]) {
            var curNodePartID = curPartIDMetadata[sublayerObjectID]
            var strartNum = curNodePartID.indexOf(prefix_str)+prefix_str.length
            var curIndex = curNodePartID.substring(strartNum);
            if(curIndex > maxInstanceIndex){
                maxInstanceIndex = curIndex;
            }
        }
    }
    return maxInstanceIndex;
}

function getAllSubLayerIDBymetaData(metadata)
{
    var index = 0;
    var SubLayerIDs = [];
    if(metadata){
        for(index=0;index<metadata.length;index++){
            if(metadata[index].type == "child"){
                if(metadata[index].content){
                    var subLayerID = metadata[index].content.id;
                    SubLayerIDs.push(subLayerID)
                }
            }
        }
    }
    return SubLayerIDs;
}

function getSubLayerMetadata(context,targetLayer,sublayerObjectID)
{
    var curLayerMetadata =context.command.valueForKey_onLayer_forPluginIdentifier(
        'metadata',
        targetLayer,
        'tmnaMM'
    );
    if(curLayerMetadata){
        for(index=0;index<curLayerMetadata.length;index++){
            if(curLayerMetadata[index].type == "child"){
                if(curLayerMetadata[index].content && curLayerMetadata[index].content.metadata){
                    var res = curLayerMetadata[index].content.metadata;
                    return res;
                }
            }
        }
    }
    return nil;
}

function getSubLayerInfodata(partsList, targetLayer, artboardID)
{

    console.log("getSubLayerInfodata==");
    if(!targetLayer || !artboardID || !partsList){
        return nil;
    }

    //get targetLayer's choose targets
    var subSymbolsFromChooseTarget = MetadataUtils.getSymbolInstanceSubPartsLayersHMISpec(targetLayer);

    // var partsListFromJson = JsonInfo[artboardID]["PartsList"];
    var targetLayerID = targetLayer.objectID();

    var resInfo = {};
    var metadataInfo = [];

    var conditionsInfo = {};

    for ( var i = 0; i <subSymbolsFromChooseTarget.length; i++){
        var subSymbol = subSymbolsFromChooseTarget[i];
        var absoluteObjectID = subSymbol["absoluteObjectID"]
        for(var idFromJson in partsList){
            //get symbol data
            if(targetLayerID == idFromJson){
                  var curNodeInfo = partsList[idFromJson];
                  getSubLayermetaInfo(curNodeInfo, metadataInfo);
            }
            //get multi state meta data
            var idArr = idFromJson.split("_");
            if(idArr.length > 2){
              var lastStr = idArr[idArr.length - 2];
              if(lastStr.substring(0,5) == "state"){
                  //delete last str
                  idArr.splice(-2,2);
                  var idStr = idArr.join("_");
                  //is layer or subLayer's multi state
                  if(targetLayerID == idStr || absoluteObjectID == idStr){
                      getMultiStateInfo(lastStr, idFromJson, partsList[idFromJson],metadataInfo, conditionsInfo);
                  }
              }
            }

            //get subsymbol data
            if( absoluteObjectID == idFromJson)){
              // var idArr = idFromJson.split("_");
              // var childID = idArr[idArr.length - 1];

              var subLayerInfo = partsList[idFromJson];
              var submetaInfo = {};
              var conditionsData = {};

              submetaInfo["type"] = "child";
              submetaInfo["content"] = {};
              submetaInfo["content"]["id"] = "" + idFromJson;
              submetaInfo["content"]["metadata"] = [];

              // getSubLayermetaInfo(subLayerInfo,metadataInfo);

              getSubLayermetaInfoTemp(subLayerInfo,submetaInfo["content"]["metadata"], idFromJson);
              metadataInfo.push(submetaInfo);
              // condition data
              getSubLayerconditionInfo(subLayerInfo,conditionsInfo,idFromJson);

              // conditionsInfo.push(conditionsData);
              //
              // break;
            }
        }
   }

    resInfo["metadata"] = metadataInfo;

    resInfo["conditionsData"] = conditionsInfo;

    return resInfo;
}

function getMultiStateInfo(typeName, idFromJson, layer, metadataInfo, conditionsInfo){
                    console.log("getMultiStateInfo==== typeName: "+typeName);
  var submetaInfo = {};
  var conditionsData = {};

  submetaInfo["type"] = "child";
  submetaInfo["content"] = {};
  submetaInfo["content"]["id"] = "" + idFromJson;
  submetaInfo["content"]["metadata"] = [];
  // meta data
  getSubLayermetaInfoTemp(layer, submetaInfo["content"]["metadata"], idFromJson);
  metadataInfo.push(submetaInfo);
  console.log("getMultiStateInfo====metadataInfo length:"+metadataInfo.length);
  for(var i=0 ; i<metadataInfo.length ; i++ ){
      console.log("getMultiStateInfo====metadataInfo[i]:"+metadataInfo[i]);
  }
  // condition data
  getSubLayerconditionInfo(layer, conditionsInfo,idFromJson);
}

function getSubLayermetaInfo(curNodeInfo,metaDataConArr){
    if(curNodeInfo["Text or Image information"]){
        var curNodeInfoImageInfo = curNodeInfo["Text or Image information"];
        if(curNodeInfoImageInfo["Validation"] && curNodeInfoImageInfo["Validation"] != "") {
            var metadaValidationtaInfo = {}
            metadaValidationtaInfo["type"] = "text-image-validation";
            metadaValidationtaInfo["content"] = curNodeInfoImageInfo["Validation"];
            metaDataConArr.push(metadaValidationtaInfo);
        }
        if(curNodeInfoImageInfo["Outside Input"]){
            var curNodeOutsizeInfo = curNodeInfoImageInfo["Outside Input"]
            if(curNodeOutsizeInfo["Display contents"] && curNodeOutsizeInfo["Display contents"] != ""){
                var metadataDisplayInfo = {}
                metadataDisplayInfo["type"] = "text-image-outside-input";
                metadataDisplayInfo["content"] = {};
                metadataDisplayInfo["content"]["type"] = "display-contents";
                metadataDisplayInfo["content"]["value"] = ""+curNodeOutsizeInfo["Display contents"];
                metaDataConArr.push(metadataDisplayInfo);
            }
            if(curNodeOutsizeInfo["Format"] && curNodeOutsizeInfo["Format"] != ""){
                var metadataformatInfo = {}
                metadataformatInfo["type"] = "text-image-outside-input";
                metadataformatInfo["content"] = {};
                metadataformatInfo["content"]["type"] = "format";
                metadataformatInfo["content"]["value"] = ""+curNodeOutsizeInfo["Format"];
                metaDataConArr.push(metadataformatInfo);
            }
            if(curNodeOutsizeInfo["Range"] && curNodeOutsizeInfo["Range"] != ""){
                var metadataRangeInfo = {}
                metadataRangeInfo["type"] = "text-image-outside-input";
                metadataRangeInfo["content"] = {};
                metadataRangeInfo["content"]["type"] = "range";
                metadataRangeInfo["content"]["value"] = ""+curNodeOutsizeInfo["Range"];
                metaDataConArr.push(metadataRangeInfo);
            }
        }
        //Fixed Image
        if(curNodeInfoImageInfo["Fixed Image"] && curNodeInfoImageInfo["Fixed Image"] != "") {
            var metadaFixedImageInfo = {}
            metadaFixedImageInfo["type"] = "fixed-image";
            metadaFixedImageInfo["content"] = curNodeInfoImageInfo["Fixed Image"];
            metaDataConArr.push(metadaFixedImageInfo);
        }
        //Japanese
        if(curNodeInfoImageInfo["Japanese"] && curNodeInfoImageInfo["Japanese"] != "") {
          var curNodeJapaneseInfo = curNodeInfoImageInfo["Japanese"];
          if(curNodeJapaneseInfo["Japanese"] && curNodeJapaneseInfo["Japanese"] != ""){
              var metadataJapaneseInfo = {}
              metadataJapaneseInfo["type"] = "Japanese";
              metadataJapaneseInfo["content"] = {};
              metadataJapaneseInfo["content"]["type"] = "Japanese";
              metadataJapaneseInfo["content"]["value"] = ""+curNodeJapaneseInfo["Japanese"];
              metaDataConArr.push(metadataJapaneseInfo);
          }

          if(curNodeJapaneseInfo["Fixed words"] && curNodeJapaneseInfo["Fixed words"] != ""){
              var metadataJapaneseInfo = {}
              metadataJapaneseInfo["type"] = "Japanese";
              metadataJapaneseInfo["content"] = {};
              metadataJapaneseInfo["content"]["type"] = "Fixed words";
              metadataJapaneseInfo["content"]["value"] = ""+curNodeJapaneseInfo["Fixed words"];
              metaDataConArr.push(metadataJapaneseInfo);
          }
        }
        //U.S.English
        if(curNodeInfoImageInfo["U.S.English"] && curNodeInfoImageInfo["U.S.English"] != "") {
          var curNodeUSInfo = curNodeInfoImageInfo["U.S.English"];
          if(curNodeUSInfo["U.S.English"] && curNodeUSInfo["U.S.English"] != ""){
              var metadataUSInfo = {}
              metadataUSInfo["type"] = "U.S.English";
              metadataUSInfo["content"] = {};
              metadataUSInfo["content"]["type"] = "U.S.English";
              metadataUSInfo["content"]["value"] = ""+curNodeUSInfo["U.S.English"];
              metaDataConArr.push(metadataUSInfo);
          }

          if(curNodeUSInfo["Fixed words"] && curNodeUSInfo["Fixed words"] != ""){
              var metadataUSInfo = {}
              metadataUSInfo["type"] = "U.S.English";
              metadataUSInfo["content"] = {};
              metadataUSInfo["content"]["type"] = "Fixed words";
              metadataUSInfo["content"]["value"] = ""+curNodeUSInfo["Fixed words"];
              metaDataConArr.push(metadataUSInfo);
          }
        }
        //U.K.English
        if(curNodeInfoImageInfo["U.K.English"] && curNodeInfoImageInfo["U.K.English"] != "") {
          var curNodeUKInfo = curNodeInfoImageInfo["U.K.English"];
          if(curNodeUKInfo["U.K.English"] && curNodeUKInfo["U.K.English"] != ""){
              var metadataUKInfo = {}
              metadataUKInfo["type"] = "U.K.English";
              metadataUKInfo["content"] = {};
              metadataUKInfo["content"]["type"] = "U.K.English";
              metadataUKInfo["content"]["value"] = ""+curNodeUKInfo["U.K.English"];
              metaDataConArr.push(metadataUKInfo);
          }

          if(curNodeUKInfo["Fixed words"] && curNodeUKInfo["Fixed words"] != ""){
              var metadataUKInfo = {}
              metadataUKInfo["type"] = "U.K.English";
              metadataUKInfo["content"] = {};
              metadataUKInfo["content"]["type"] = "Fixed words";
              metadataUKInfo["content"]["value"] = ""+curNodeUKInfo["Fixed words"];
              metaDataConArr.push(metadataUKInfo);
          }
        }

    }
    if(curNodeInfo["SW Information"]){
        var curNodeSWInfo = curNodeInfo["SW Information"];
        if(curNodeSWInfo["SW operation Pattern"] && curNodeSWInfo["SW operation Pattern"] != ""){
            var SWoperationPatternid = curNodeSWInfo["SW operation Pattern"];
            var metadaSWOperationInfo = {}
            metadaSWOperationInfo["type"] = "sw-operation-pattern";
            metadaSWOperationInfo["content"] = {};
            // metadaSWOperationInfo["content"]["id"] = SWoperationPatternid;
            // metadaSWOperationInfo["content"]["swOperationPattern"] = ""+SW_OPERATION_PATTERNS[SWoperationPatternid];
            var index = SW_OPERATION_PATTERNS.indexOf(SWoperationPatternid);
            if(index != -1){
                metadaSWOperationInfo["content"]["id"] = index;
            }
            metadaSWOperationInfo["content"]["swOperationPattern"] = ""+SWoperationPatternid;
            metaDataConArr.push(metadaSWOperationInfo);
        }
        if(curNodeSWInfo["Operation result"]){
            var curNodeSWResInfo = curNodeSWInfo["Operation result"];
            if(curNodeSWResInfo["Screen Transion"] && curNodeSWResInfo["Screen Transion"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "screen-transition";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Screen Transion"];
                metaDataConArr.push(metadataSWTransion);
            }
            if(curNodeSWResInfo["Start Function"] && curNodeSWResInfo["Start Function"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "start-function";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Start Function"];
                metaDataConArr.push(metadataSWTransion);
            }
            if(curNodeSWResInfo["Setting Value Change"] && curNodeSWResInfo["Setting Value Change"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "setting-value-change";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Setting Value Change"];
                metaDataConArr.push(metadataSWTransion);
            }
            if(curNodeSWResInfo["Other"] && curNodeSWResInfo["Other"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "other";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Other"];
                metaDataConArr.push(metadataSWTransion);
            }
        }
    }
    if(curNodeInfo["Parts Type"]){

        var metadataParttypeInfo = {};
        metadataParttypeInfo["type"] = "Parts Type";
        metadataParttypeInfo["content"] ={};
        if(curNodeInfo["Parts Type"] == ""){
            metadataParttypeInfo["content"]["part"] = "Select Part Type";
            metadataParttypeInfo["content"]["id"] = "11";
        }
        else{
            var curPartType = curNodeInfo["Parts Type"];

                                console.log("getMultiStateInfo==== Parts Type"+curPartType);
            // console.log("getSubLayermetaInfo== indexOf curPartType: "+ PART_TYPES.indexOf(curPartType));
            metadataParttypeInfo["content"]["part"] = curPartType
            // console.log("getSubLayermetaInfo== curPartType: "+ curPartType);
            metadataParttypeInfo["content"]["id"] = ""+PART_TYPES.indexOf(curPartType);
        }
        metaDataConArr.push(metadataParttypeInfo);
    }
    if(curNodeInfo["choose target"]){
        var metadatachooseInfo = {};
        metadatachooseInfo["type"] = "Target";
        if(curNodeInfo["choose target"] == ""){
            metadatachooseInfo["content"] = ""+targetLayerID;
        }
        else{
            metadatachooseInfo["content"] = curNodeInfo["choose target"];
        }
        metaDataConArr.push(metadatachooseInfo);
    }
    if(curNodeInfo["SW Information"] && curNodeInfo["SW Information"]["BEEP"]) {
        var metadatabeepInfo = {};
        metadatabeepInfo["type"] = "beep";
        metadatabeepInfo["content"] = {};
        var curBeepStr = curNodeInfo["SW Information"]["BEEP"];
        metadatabeepInfo["content"]["beep"] = curBeepStr;
        metadatabeepInfo["content"]["id"] = ""+BEEP_TYPES.indexOf("curBeepStr");
        metaDataConArr.push(metadatabeepInfo);
    }
}
function getSubLayermetaInfoTemp(curNodeInfo,metaDataConArr,targetLayerID){
    if(curNodeInfo["Display Condition"]){

        if(curNodeInfo["Display Condition"]["else"] && curNodeInfo["Display Condition"]["else"] != ""){
          var metadaElseInfo = {}
          metadaElseInfo["type"] = "else";
          metadaElseInfo["content"] = curNodeInfo["Display Condition"]["else"];
          metaDataConArr.push(metadaElseInfo);
        }
    }
    if(curNodeInfo["Text or Image information"]){
        var curNodeInfoImageInfo = curNodeInfo["Text or Image information"];
        if(curNodeInfoImageInfo["Validation"] && curNodeInfoImageInfo["Validation"] != "") {
            var metadaValidationtaInfo = {}
            metadaValidationtaInfo["type"] = "text-image-validation";
            metadaValidationtaInfo["content"] = curNodeInfoImageInfo["Validation"];
            metaDataConArr.push(metadaValidationtaInfo);
        }
        if(curNodeInfoImageInfo["Outside Input"]){
            var curNodeOutsizeInfo = curNodeInfoImageInfo["Outside Input"]
            if(curNodeOutsizeInfo["Display contents"] && curNodeOutsizeInfo["Display contents"] != ""){
                var metadataDisplayInfo = {}
                metadataDisplayInfo["type"] = "text-image-outside-input";
                metadataDisplayInfo["content"] = {};
                metadataDisplayInfo["content"]["type"] = "display-contents";
                metadataDisplayInfo["content"]["value"] = ""+curNodeOutsizeInfo["Display contents"];
                metaDataConArr.push(metadataDisplayInfo);
            }
            if(curNodeOutsizeInfo["Format"] && curNodeOutsizeInfo["Format"] != ""){
                var metadataformatInfo = {}
                metadataformatInfo["type"] = "text-image-outside-input";
                metadataformatInfo["content"] = {};
                metadataformatInfo["content"]["type"] = "format";
                metadataformatInfo["content"]["value"] = ""+curNodeOutsizeInfo["Format"];
                metaDataConArr.push(metadataformatInfo);
            }
            if(curNodeOutsizeInfo["Range"] && curNodeOutsizeInfo["Range"] != ""){
                var metadataRangeInfo = {}
                metadataRangeInfo["type"] = "text-image-outside-input";
                metadataRangeInfo["content"] = {};
                metadataRangeInfo["content"]["type"] = "range";
                metadataRangeInfo["content"]["value"] = ""+curNodeOutsizeInfo["Range"];
                metaDataConArr.push(metadataRangeInfo);
            }
        }
        //Fixed Image
        if(curNodeInfoImageInfo["Fixed Image"] && curNodeInfoImageInfo["Fixed Image"] != "") {
            var metadaFixedImageInfo = {}
            metadaFixedImageInfo["type"] = "fixed-image";
            metadaFixedImageInfo["content"] = curNodeInfoImageInfo["Fixed Image"];
            metaDataConArr.push(metadaFixedImageInfo);
        }
        //Japanese
        if(curNodeInfoImageInfo["Japanese"] && curNodeInfoImageInfo["Japanese"] != "") {
          var curNodeJapaneseInfo = curNodeInfoImageInfo["Japanese"];
          if(curNodeJapaneseInfo["Japanese"] && curNodeJapaneseInfo["Japanese"] != ""){
              var metadataJapaneseInfo = {}
              metadataJapaneseInfo["type"] = "Japanese";
              metadataJapaneseInfo["content"] = {};
              metadataJapaneseInfo["content"]["type"] = "Japanese";
              metadataJapaneseInfo["content"]["value"] = ""+curNodeJapaneseInfo["Japanese"];
              metaDataConArr.push(metadataJapaneseInfo);
          }

          if(curNodeJapaneseInfo["Fixed words"] && curNodeJapaneseInfo["Fixed words"] != ""){
              var metadataJapaneseInfo = {}
              metadataJapaneseInfo["type"] = "Japanese";
              metadataJapaneseInfo["content"] = {};
              metadataJapaneseInfo["content"]["type"] = "Fixed words";
              metadataJapaneseInfo["content"]["value"] = ""+curNodeJapaneseInfo["Fixed words"];
              metaDataConArr.push(metadataJapaneseInfo);
          }
        }
        //U.S.English
        if(curNodeInfoImageInfo["U.S.English"] && curNodeInfoImageInfo["U.S.English"] != "") {
          var curNodeUSInfo = curNodeInfoImageInfo["U.S.English"];
          if(curNodeUSInfo["U.S.English"] && curNodeUSInfo["U.S.English"] != ""){
              var metadataUSInfo = {}
              metadataUSInfo["type"] = "U.S.English";
              metadataUSInfo["content"] = {};
              metadataUSInfo["content"]["type"] = "U.S.English";
              metadataUSInfo["content"]["value"] = ""+curNodeUSInfo["U.S.English"];
              metaDataConArr.push(metadataUSInfo);
          }

          if(curNodeUSInfo["Fixed words"] && curNodeUSInfo["Fixed words"] != ""){
              var metadataUSInfo = {}
              metadataUSInfo["type"] = "U.S.English";
              metadataUSInfo["content"] = {};
              metadataUSInfo["content"]["type"] = "Fixed words";
              metadataUSInfo["content"]["value"] = ""+curNodeUSInfo["Fixed words"];
              metaDataConArr.push(metadataUSInfo);
          }
        }
        //U.K.English
        if(curNodeInfoImageInfo["U.K.English"] && curNodeInfoImageInfo["U.K.English"] != "") {
          var curNodeUKInfo = curNodeInfoImageInfo["U.K.English"];
          if(curNodeUKInfo["U.K.English"] && curNodeUKInfo["U.K.English"] != ""){
              var metadataUKInfo = {}
              metadataUKInfo["type"] = "U.K.English";
              metadataUKInfo["content"] = {};
              metadataUKInfo["content"]["type"] = "U.K.English";
              metadataUKInfo["content"]["value"] = ""+curNodeUKInfo["U.K.English"];
              metaDataConArr.push(metadataUKInfo);
          }

          if(curNodeUKInfo["Fixed words"] && curNodeUKInfo["Fixed words"] != ""){
              var metadataUKInfo = {}
              metadataUKInfo["type"] = "U.K.English";
              metadataUKInfo["content"] = {};
              metadataUKInfo["content"]["type"] = "Fixed words";
              metadataUKInfo["content"]["value"] = ""+curNodeUKInfo["Fixed words"];
              metaDataConArr.push(metadataUKInfo);
          }
        }

    }
    if(curNodeInfo["SW Information"]){
        var curNodeSWInfo = curNodeInfo["SW Information"];
        if(curNodeSWInfo["SW operation Pattern"] && curNodeSWInfo["SW operation Pattern"] != ""){
            var SWoperationPatternid = curNodeSWInfo["SW operation Pattern"];
            var metadaSWOperationInfo = {}
            metadaSWOperationInfo["type"] = "sw-operation-pattern";
            metadaSWOperationInfo["content"] = {};
            metadaSWOperationInfo["content"]["id"] = 0;
            var index = SW_OPERATION_PATTERNS.indexOf(SWoperationPatternid);
            if(index != -1){
                metadaSWOperationInfo["content"]["id"] = index;
            }
            metadaSWOperationInfo["content"]["swOperationPattern"] = ""+SWoperationPatternid;
            metaDataConArr.push(metadaSWOperationInfo);
        }
        if(curNodeSWInfo["Operation result"]){
            var curNodeSWResInfo = curNodeSWInfo["Operation result"];
            if(curNodeSWResInfo["Screen Transion"] && curNodeSWResInfo["Screen Transion"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "screen-transition";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Screen Transion"];
                metaDataConArr.push(metadataSWTransion);
            }
            if(curNodeSWResInfo["Start Function"] && curNodeSWResInfo["Start Function"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "start-function";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Start Function"];
                metaDataConArr.push(metadataSWTransion);
            }
            if(curNodeSWResInfo["Setting Value Change"] && curNodeSWResInfo["Setting Value Change"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "setting-value-change";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Setting Value Change"];
                metaDataConArr.push(metadataSWTransion);
            }
            if(curNodeSWResInfo["Other"] && curNodeSWResInfo["Other"] != ""){
                var metadataSWTransion = {};
                metadataSWTransion["type"] = "sw-operation-result";
                metadataSWTransion["content"] = {};
                metadataSWTransion["content"]["type"] = "other";
                metadataSWTransion["content"]["value"] = curNodeSWResInfo["Other"];
                metaDataConArr.push(metadataSWTransion);
            }
        }
    }
    if(curNodeInfo["Parts Type"]){

        var metadataParttypeInfo = {};
        metadataParttypeInfo["type"] = "Parts Type";
        metadataParttypeInfo["content"] ={};
        if(curNodeInfo["Parts Type"] == ""){
            metadataParttypeInfo["content"]["part"] = "Select Part Type";
            metadataParttypeInfo["content"]["id"] = "11";
        }
        else{
            var curPartType = curNodeInfo["Parts Type"];

                                console.log("getMultiStateInfo==== Parts Type"+curPartType);
            // console.log("getSubLayermetaInfo== indexOf curPartType: "+ PART_TYPES.indexOf(curPartType));
            metadataParttypeInfo["content"]["part"] = curPartType
            // console.log("getSubLayermetaInfo== curPartType: "+ curPartType);
            metadataParttypeInfo["content"]["id"] = ""+PART_TYPES.indexOf(curPartType);
        }
        metaDataConArr.push(metadataParttypeInfo);
    }
    if(curNodeInfo["choose target"]){
        var metadatachooseInfo = {};
        metadatachooseInfo["type"] = "Target";
        if(curNodeInfo["choose target"] == ""){
            metadatachooseInfo["content"] = ""+targetLayerID;
        }
        else{
            metadatachooseInfo["content"] = curNodeInfo["choose target"];
        }
        metaDataConArr.push(metadatachooseInfo);
    }
    if(curNodeInfo["SW Information"] && curNodeInfo["SW Information"]["BEEP"]) {
        var metadatabeepInfo = {};
        metadatabeepInfo["type"] = "beep";
        metadatabeepInfo["content"] = {};
        var curBeepStr = curNodeInfo["SW Information"]["BEEP"];
        metadatabeepInfo["content"]["beep"] = curBeepStr;
        metadatabeepInfo["content"]["id"] = ""+BEEP_TYPES.indexOf("curBeepStr");
        metaDataConArr.push(metadatabeepInfo);
    }
}
function getSubLayerconditionInfo(curNodeInfo,conditionsData,targetLayerID){
    if(curNodeInfo["Display Condition"]){
        var conditionkey = "displayCondition__"+targetLayerID;
        var conditionvalue = getConditionData(curNodeInfo["Display Condition"])

          console.log("getMultiStateInfo====conditionvalue else:"+ conditionvalue["else"]);
        conditionsData[conditionkey] = conditionvalue;
    }
    if(curNodeInfo["Text or Image information"] && curNodeInfo["Text or Image information"]["Delete condition in motion"]){
        var conditionkey = "textImageDeleteInMotion__"+targetLayerID;
        var conditionvalue = getConditionData(curNodeInfo["Text or Image information"]["Delete condition in motion"])
        conditionsData[conditionkey] = conditionvalue;
    }
    if(curNodeInfo["SW Information"]){
        var curNodeSWInfo = curNodeInfo["SW Information"]
        if(curNodeSWInfo["Tonedown condition in motion"]){
            var conditionkey = "sWTonedownMotion__"+targetLayerID;
            var conditionvalue = getConditionData(curNodeSWInfo["Tonedown condition in motion"])
            conditionsData[conditionkey] = conditionvalue;
        }
        if(curNodeSWInfo["Tonedown condition except in motion"]){
            var conditionkey = "sWTonedownExceptInMotion__"+targetLayerID;
            var conditionvalue = getConditionData(curNodeSWInfo["Tonedown condition except in motion"])
            conditionsData[conditionkey] = conditionvalue;
        }
        if(curNodeSWInfo["Selected condition"]){
            var conditionkey = "sWSelected__"+targetLayerID;
            var conditionvalue = getConditionData(curNodeSWInfo["Selected condition"])
            conditionsData[conditionkey] = conditionvalue;
        }
    }
}

function makeJsonMetadata(oriMetadata){
    if(!oriMetadata){
        return nil;
    }
    var jsonMetadata = {};
    for(var num=0;num<oriMetadata.length;num++){
        var curOriginMetadata = oriMetadata[num];
        var key = ""+curOriginMetadata.type
        var value = curOriginMetadata.content
        jsonMetadata[key] = value;
    }
    return jsonMetadata;
}

function checkIsTextInstance(layer)
{
    if(isSymbolWithMaster(layer)){
        var curoverridePoints = layer.overridePoints()
        if(curoverridePoints.length == 1)
        {
            var curoverridePointsStr = ""+curoverridePoints[0];
            if(curoverridePointsStr.indexOf("_stringValue") != -1){
                if(curoverridePointsStr.length == 48){
                    return true;
                }
            }
        }
    }
    return false;
}

function getTextInstanceValue(layer)
{
    if(isSymbolWithMaster(layer)){
        var curoverrides = layer.overrides();
        if(curoverrides.count() == 1){
            for(var key in curoverrides){
                return curoverrides[key];
            }
        }
    }
    return "";
}

function checkOverridesIsNone(targetLayerOverrideValues,curLayerObjectID)
{
    if(targetLayerOverrideValues){
        for(var num=0;num<targetLayerOverrideValues.length;num++){
            var curInfo = ""+targetLayerOverrideValues[num].overrideName();
            if(curInfo.indexOf(curLayerObjectID+"_symbolID") != -1){
                if(targetLayerOverrideValues[num].value() == ""){
                    return true;
                }
            }
        }
    }
    return false
}
function getTextInstanceValueByOverrideValues(targetLayerOverrideValues,layer)
{
    var resStr = ""
    var flag = true;
    var curLayerObjectID = layer.objectID();
    if(targetLayerOverrideValues){
        for(var num=0;num<targetLayerOverrideValues.length;num++){
            var curInfo = ""+targetLayerOverrideValues[num].overrideName();
            if(curInfo.indexOf(curLayerObjectID) != -1 && curInfo.indexOf("_stringValue") != -1){
                resStr = targetLayerOverrideValues[num].value();
                flag = false;
                break;
            }
        }
    }
    if(flag){
        resStr = ""+getTextInstanceValue(layer)
    }
    return resStr;
}

// check if a layer is a valid symbol with a valid master
const isSymbolWithMaster = layer => layer.className() == "MSSymbolInstance" && layer.symbolMaster()

// Push layer into array only if it doesn't already contain given layer
const pushIfNotContains = (layer, layers) => {
  let contains = false
  layers.forEach(l => {
    if (String(l.objectID()) === String(layer.objectID())) {
      contains = true
    }
  })
  if (!contains) { layers.push(layer) }
}

// gather symbols in parent a few levels deep
const allSymbolLayersWithParents = (layer, layers, level) => {

  if (isLayerIgnored(layer,'redline')) { return layers }

  // Don't recurse deeply.
  if (!level && level !== 0) {
    level = 0
  } else {
    level = level + 1
  }

  if (level > 2) { return layers }

  if (isSymbolWithMaster(layer)) {
    pushIfNotContains(layer, layers)
    layer.symbolMaster().layers().forEach(l => { allSymbolLayersWithParents(l, layers, level) })
  } else {
    layer.layers && layer.layers().forEach(l => { allSymbolLayersWithParents(l, layers, level) })
  }

  return layers
}

function tryLoadFramework(context)
{
    var frameworkName = "TMNAFramework"
    var mocha = Mocha.sharedRuntime();
    if (mocha.valueForKey(frameworkName)) {
      // alreadyLoad
      return;
    }
    coscript.setShouldKeepAround(true);
    var FrameworkPath =  COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent()+"/Resources";
    CLogToFile("test", FrameworkPath)
    CLogToFile("test", frameworkName)
    var mocha = [Mocha sharedRuntime]
    var loadflg = [mocha loadFrameworkWithName:frameworkName inDirectory:FrameworkPath]
    CLogToFile("test", loadflg.toString())
    mocha.setValue_forKey_(true, frameworkName);

    var command = context.command;
    var document = context.document;
    var scriptPath = context.scriptPath;
    var scriptURL = context.scriptURL;
    var selection = context.selection;
    SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
    var sketchObjects = [MSLayer.new(),MSLayerGroup.new(),MSFlowConnection.new(),MSSymbolCreator.new(),MSLayerArray.new(),MSTextLayer.new(),MSArtboardGroup.new(),MSShapeGroup.new(),MSExportRequest.new(),MSStyle.new(),MSStyleFill.new(),MSColor.new(),MSCurvePoint.new(),MSShapePathLayer.new(),MSRectangleShape.new(),MSTriangleShape.new(),MSOvalShape.new(),MSStarShape.new(),MSPolygonShape.new(),MSAbsoluteRect.new()];
    SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);
}
