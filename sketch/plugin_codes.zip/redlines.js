@import 'common.js';

// put unique symbol info into allSymbols dict based on lowest Y coord of frames
const putIfLowerY = (allSymbols, layerAndParent) => {

  let symbol = layerAndParent.layer
  let symbolParent = layerAndParent.parent
  let rootLayer = layerAndParent.rootLayer
  let symbolMasterName = symbol.symbolMaster().name()
  let symbolFrameY = rootLayer ? rootLayer.frame().y() : symbol.frame().y()
  let existing = allSymbols[symbolMasterName]

  if (!existing || existing.symbolFrameY > symbolFrameY) {
    if (existing) {
      partId = existing.partId
    } else {
      if (true) { // ONLY USE ALPHA CHARACTERS FOR NOW
        var highestPid = 999
        for (prop in allSymbols) {
          let pid = allSymbols[prop].partId
          if (pid && pid > highestPid && pid >= 1000) highestPid = pid
        }
        partId = highestPid + 1
      } else {
        var highestPid = 0
        for (prop in allSymbols) {
          let pid = allSymbols[prop].partId
          if (pid && pid > highestPid && pid < 1000) highestPid = pid
        }
        partId = highestPid + 1
      }
    }
    allSymbols[symbolMasterName] = { symbolFrameY, symbol, symbolParent, partId, rootLayer, text: layerAndParent.text }
  }
}

// check if a layer is a valid symbol with a valid master
const isSymbolWithMaster = layer => layer.className() == "MSSymbolInstance" && layer.symbolMaster()

const hasTextOverride = layer => {
  var hasOverride = false
  layer.overrideValues().forEach(val => {
    let isStringValue = val.overrideName().includes('stringValue');
    if (isStringValue) {
      hasOverride = true
    }
  });
  return hasOverride
}

const isIgnoredSublayer = (layer, all) => {
  var isNone = false
  all.forEach(val => {
    if (val.indexOf(layer.objectID()) !== -1) {
      isNone = true
    }
  });
  return isNone
}

// recursively gather all symbol layers in a parent
const allSymbolLayersWithParents = (parent, layers) => {
  parent.layers().forEach(layer => {
    // We don't care about labeling rectangles. Should come up with a system for ignoring symbols
    if (isLayerIgnored(layer, 'redlines')) return

    let hasSublayers = !!layer.layers
    if (isSymbolWithMaster(layer)) {
      var containsSymbolMaster = false
      var ignoredSubLayers = [];

      // If our symbol instance has an override set to `None`, add it to an array to exclude from our redline

      layer.overrideValues().forEach(val => {
        if(val.value().length() == 0) {
          ignoredSubLayers.push(val.overrideName());
        }
      });

      layer.symbolMaster().layers().forEach((l) => {
        if (isIgnoredSublayer(l, ignoredSubLayers)) {
          return
        }
        if (isSymbolWithMaster(l)) {
          containsSymbolMaster = true
          layers.push({ layer: l, parent, rootLayer: layer, text: hasTextOverride(l)})
        }
      })
      if (!containsSymbolMaster) {
        layers.push({ layer, parent, text: hasTextOverride(layer) })
      }
    } else if (hasSublayers) {
      allSymbolLayersWithParents(layer, layers)
    }
  })
  return layers
}

var onRun = function(context) {
  let sketch = context.api();
  let doc = context.document;
  let sketchDoc = sketch.selectedDocument;
  let filePath = `red-lines/${removeFileExtension(sketchDoc.sketchObject.displayName())}/${formatDate(new Date)}/`;

  let allArtboards = []

  doc.pages().forEach(page => {
    if (isPageIgnored(page)) return
    page.artboards().forEach(artboard => {
      var layers = allSymbolLayersWithParents(artboard, [])

      // Sketch orders layers descending, so we need to reverse
      layers.reverse();

      let allSymbols = { }
      // add layers in Y-axis order to map of { 'symbol master name': { symbol, partId } }
      layers.forEach(layerAndParent => { putIfLowerY(allSymbols, layerAndParent) })
      // push tuple of symbol map and artboard onto list
      allArtboards.push({ allSymbols,  artboard })

      // Reset layers to original order
      layers.reverse();
    })

  })

  let apiApp = new sketch.Application(context)
  let apiDoc = new sketch.Document(doc, new sketch.Application(context))
  let tempText = [];
  let tempTextBg = [];
  let tempShape = [];

  specFolder = `${NSHomeDirectory()}/rfq-specs/`
  if (!specFolder) return;

  // var exportedOnce = false
  allArtboards.forEach(allSymbolsAndArtboard => {
    let allSymbols = allSymbolsAndArtboard.allSymbols
    let artboard = allSymbolsAndArtboard.artboard

    const underscoredArtboardName = artboard.name()
      .split("/").map(str => str.trim()).join("_")

    const exportOpts = {
      'use-id-for-name': true,
      formats: 'png',
      overwriting: true,
      scales: '1',
      output: specFolder + filePath + underscoredArtboardName
    }

    let cols = 'Parts ID, Display Image, Parts Type, Fixed Image';

    for (s in allSymbols) {
      let sym = allSymbols[s]
      const symbolId = String(sym.symbol.objectID())
      sym.textValues = [];
      let symParent = sym.symbolParent
      let partId = sym.partId
      let frame = sym.rootLayer ? sym.rootLayer.frame() : sym.symbol.frame()
      let addX = sym.rootLayer ? sym.symbol.frame().x() : 0
      let addY = sym.rootLayer ? sym.symbol.frame().y() : 0
      let apiGroup = new sketch.Group(symParent, apiDoc);

      // ---- Text
      let bg = new sketch.Rectangle(
        frame.x() + addX,
        frame.y() + addY,
        24,
        24);
      let textBg = apiGroup.newShape({ frame: bg });
      let textBgBorders = textBg.sketchObject.style().setBorders([]);

      var fill = MSStyleFill.new();
      fill.setColor_(MSColor.rgbColorRed_green_blue(255, 0, 0));
      fill.setFillType_(0);
      fill.enabled = true;
      textBg.sketchObject.style().setFills([fill]);

      tempTextBg.push(textBg);

      if (sym.partId >= 1000) {
        partId = letters[partId - 1000]
      }

      let text = apiGroup.newText({
        text: `${partId}`,
        alignment: 2,
        fixedWidth: true
      });

      text.frame = bg;

      let textStyle = text.sketchObject.style().textStyle();
      // textstyle consists of a dictionary of attributes, take a mutable copy of that dictionary
      let mutableTextAttributes = NSMutableDictionary.dictionaryWithDictionary(textStyle.attributes());
      // set the NSColor key for the attributes dictionary
      mutableTextAttributes.setObject_forKey(NSColor.colorWithRed_green_blue_alpha(1, 1, 1, 1), 'NSColor');
      mutableTextAttributes.setObject_forKey(NSFont.systemFontOfSize(18.0), 'NSFont');

      // write the attributes dictionary back onto the textstyle (and we're done)
      textStyle.setValue_forKey_(mutableTextAttributes, 'attributes');

      tempText.push(text);

      MSLayerMovement.moveToFront([text._object]);
      // ---- Text


      // ---- Shape
      let shapeFrame = new sketch.Rectangle(
        frame.x() + addX,
        frame.y() + addY,
        sym.symbol.frame().width(),
        sym.symbol.frame().height());
      let shape = apiGroup.newShape({ frame: shapeFrame });
      let shapeFills = shape.sketchObject.style().setFills([]);

      var border = MSStyleBorder.new()
      border.setColor_(MSColor.rgbColorRed_green_blue(255, 0, 0))
      border.setFillType_(0)
      border.enabled = true
      shape.sketchObject.style().setBorders([border])

      tempShape.push(shape);
      // ---- Shape


      // ---- Create Array of Text Override Values
        let overrideValues = sym.symbol.overrideValues();

        overrideValues.forEach(val => {
          let isStringValue = val.overrideName().includes('stringValue');

          if (isStringValue) {
            sym.textValues.push(val.value());
          }
        });


    }

    new sketch.Artboard(artboard, apiDoc).export(exportOpts)
  });

  tempText.forEach(text => text.remove());
  tempTextBg.forEach(textBg => textBg.remove());
  tempShape.forEach(shape => shape.remove());

  // alert('Screen Spec Generated!', 'Good Job!');
}
