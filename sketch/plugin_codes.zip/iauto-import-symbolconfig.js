@import "IautoLib/iautolib.js"
@import "IautoLib/filelib.js"

function ImportSymbolConfig(context) {
    var openPanel = NSOpenPanel.openPanel();
    
    [openPanel setCanChooseDirectories:true]; //可以打开目录
    [openPanel setCanChooseFiles:1]; //不能打开文件(我需要处理一个目录内的所有文件)
    [openPanel setDirectory:NSHomeDirectory()]; //起始目录为Home
    [openPanel setPrompt: @"Import"];

    if (openPanel.runModal() != NSOKButton) {
        return false;
    }
    let import_full_path = openPanel.URL().path();

    let script_full_filename = context.scriptPath;
    let script_full_path = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    let config_json_filepath = ""+script_full_path+"/IautoConfig/symbolexpand.json"
    let config_python_script = ""+script_full_path+"/IautoScripts/SymbolConfig2Json.py"

    python3Cmd = getPython3CmdPath();
    if (python3Cmd == null) {
        showAlert("Python3 is not installed, please install it!");
        return -2;
    }
    
    runCommand(python3Cmd, 
        [config_python_script, config_json_filepath, import_full_path], 
        {"LC_ALL":"en_us.UTF-8"});

    showAlert("Import Finished!");
}

function getPython3CmdPath() {
    var python36Path = "/Library/Frameworks/Python.framework/Versions/3.6/bin/python3";
    var python37Path = "/Library/Frameworks/Python.framework/Versions/3.7/bin/python3";
    var python3Path = "";
    
    if(fileExists(python37Path)){
        python3Path = python37Path;
        return python3Path;
    }
    else if(fileExists(python36Path)){
        python3Path = python36Path;
        return python3Path;
    }

    return null;
}