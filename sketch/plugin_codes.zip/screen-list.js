@import 'common.js';

var onRun = function(context) {
  var cols = 'Section, Screen Image, Screen ID, Screen Name, Remarks';

  var sketch = context.api();

  var doc = context.document;
  let apiDoc = new sketch.Document(doc, new sketch.Application(context));

  var pages = doc.pages();

  let sketchDoc = sketch.selectedDocument;
  let rawDocName = removeFileExtension(sketchDoc.sketchObject.displayName());
  let docSplit = rawDocName.indexOf('(');
  let docName = rawDocName.substring(0, docSplit != -1 ? docSplit : rawDocName.lenth).replace(/\s/g,'')

  specFolder = `${NSHomeDirectory()}/rfq-specs/`;
  let filePath = `screen-list/${docName}/${formatDate(new Date)}/`;

  exportFolder = specFolder + filePath;

  let exportOpts = {
    'use-id-for-name': true,
    formats: 'png',
    overwriting: true,
    scales: '1',
    output: exportFolder + '_export'
  }


  for (var i = 0; i < pages.count(); i++) {
    var page = pages[i];
    var pageName = page.name();
    var artboards = page.artboards();

    if (!isPageIgnored(page)) {
      for (var z = 0; z < artboards.count(); z++) {
        let artboard = artboards[z];
        let artboardName = artboard.name();
        let artboardId = String(new sketch.Artboard(artboard, doc).id);
        let artboardRemark;

        let userInfo = artboard.userInfo();

        if (userInfo) {
          if (userInfo.tmnaMM && userInfo.tmnaMM.metadata) {
            userInfo.tmnaMM.metadata.forEach(data => {
              if (data.type == 'Remarks') {
                artboardRemark = `"${String(data.content)}"`;
              }
            });
          }
        }

        // Export artboard
        new sketch.Artboard(artboard, apiDoc).export(exportOpts);

        cols += `\n ${pageName},${exportFolder}_export/${artboardId}.png,${artboardId},${artboardName},${artboardRemark ? artboardRemark : ' '}`
      }
    }
  }

  writeTextToFile(cols, exportFolder + `${docName}--screen-list.csv`)

  // alert('Screen List Generated!', 'Good Job!');
}
