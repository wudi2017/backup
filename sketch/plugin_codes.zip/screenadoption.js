@import "IautoLib/logJS.js"

function DBLOG(logstr, logtag="libbase")
{
    LogJS.info(logtag, logstr);
    // var nsStrLog = NSString.alloc().initWithString(logstr);
    // nsStrLog = nsStrLog.stringByAppendingFormat("\n");

    // var homeDir = NSHomeDirectory();
    // var logFileFullName = homeDir + "/" + logtag + ".log"
    // //log(logFileFullName)

    // var filehandle = NSFileHandle.fileHandleForWritingAtPath(logFileFullName)
    // if(filehandle)
    // {
    //     filehandle.truncateFileAtOffset(filehandle.seekToEndOfFile());
    //     var nsdata = nsStrLog.dataUsingEncoding(NSUTF8StringEncoding);
    //     filehandle.writeData(nsdata)
    //     [filehandle closeFile];
    // }
    // else
    // {
    //     nsStrLog.writeToFile_atomically(logFileFullName, true);
    // }
}

SInherit = function(className, BaseClass, selectorHandlerDict) {
    var uniqueClassName = className + NSUUID.UUID().UUIDString();
    var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, BaseClass);
    for (var selectorString in selectorHandlerDict) {
        delegateClassDesc.addInstanceMethodWithSelector_function_(selectorString, selectorHandlerDict[selectorString]);
        //log(selectorString + "->" + selectorHandlerDict[selectorString].toString())
    }
    delegateClassDesc.registerClass();
    return NSClassFromString(uniqueClassName);
};

function CocoaDictArrToJsonObj(xObj)
{
    var jsonObj = "Unknown";
    // DBLOG("className:"+xObj.className());
    // DBLOG("value:"+xObj.toString());
    if(xObj.className().indexOf("String")>0)
    {
        jsonObj = xObj.toString()+"";
    }
    else if(xObj.className().indexOf("Dictionary")>0)
    {
        jsonObj = {}
        for(key in xObj)
        {
            var localkey = key
            var xSubObj = xObj[key];
            var jsonSub = CocoaDictArrToJsonObj(xSubObj)
            jsonObj[localkey]= jsonSub
        }
    }
    else if(xObj.className().indexOf("Array")>0)
    {
        jsonObj = []
        for(iArr=0;iArr<xObj.count();iArr++)
        {
            var xSubObj = xObj[iArr]
            var jsonSub = CocoaDictArrToJsonObj(xSubObj)
            jsonObj.push(jsonSub)
        }
    }
    return jsonObj
}

function JsonObjToCocoaDictArr(jObj)
{
    var xObj = @"Unknown";
    if(typeof(jObj) == "string") // ""
    {
        xObj = [NSString stringWithString:jObj];
    }
    else if((jObj instanceof Object) && !(jObj instanceof Array)) // {}
    {
        xObj = [NSMutableDictionary dictionary];
        for(key in jObj)
        {
            var localkey = key
            var jSubObj = jObj[key];
            var xSub = JsonObjToCocoaDictArr(jSubObj)
            [xObj setObject:xSub forKey:localkey];
        }
    }
    else if((jObj instanceof Object) && (jObj instanceof Array)) // []
    {
        xObj = [NSMutableArray array];
        for(iArr=0;iArr<jObj.length;iArr++)
        {
            var jSubObj = jObj[iArr]
            var xSub = JsonObjToCocoaDictArr(jSubObj)
            xObj.addObject(xSub);
        }
    }
    return xObj;
}

function loadArtboardScreenAdoption(context,artboard)
{
	var currentArtboard = artboard;
	DBLOG("loadArtboardScreenAdoption="+currentArtboard.objectID())

	// get layerScreenAdoptionInfo
	var layerScreenAdoptionInfo = context.command.valueForKey_onLayer_forPluginIdentifier("ScreenAdoptionInfo",currentArtboard,"tmnaMM");
	DBLOG("get layerScreenAdoptionInfo="+layerScreenAdoptionInfo)

	// init jsonScreenAdoptionInfo
	DBLOG("init jsonScreenAdoptionInfo")
	var jsonScreenAdoptionInfo = nil;
	var defaultRegionCurrent = "Japan";
	var defaultRegionList = ['Japan','Europe/Russia','China','Oceania','South Africa','HongKong / Macao','South East Asia','India','Taiwan','Middle East','South and Central (Brazil & Argentina)','South and Central','Korea','North America'];
	if(layerScreenAdoptionInfo)
	{
		jsonScreenAdoptionInfo = JSON.parse(layerScreenAdoptionInfo);
		if (jsonScreenAdoptionInfo) {
			if (!jsonScreenAdoptionInfo['Region']) {
	    		jsonScreenAdoptionInfo['Region'] = {}
	    		jsonScreenAdoptionInfo['Region']['Current'] = defaultRegionCurrent;
	    	};
	    	jsonScreenAdoptionInfo['Region']['List'] = defaultRegionList;
		};
	}
    if (!jsonScreenAdoptionInfo)
    {
    	jsonScreenAdoptionInfo = {'Region':{'Current':defaultRegionCurrent,'List':defaultRegionList}};
    }
    DBLOG(JSON.stringify(jsonScreenAdoptionInfo));

    // ConvertToCocoaObject
    ScreenAdoptionInfoModelData=JsonObjToCocoaDictArr(jsonScreenAdoptionInfo);
    DBLOG("ConvertToCocoaObject")
    DBLOG(ScreenAdoptionInfoModelData.toString())

	var localContext = context;
	coscript.setShouldKeepAround(true);

	var frameworkpath = COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent();
	//var frameworkpath = "/Users/nb/Library/Developer/Xcode/DerivedData/TestTMNAFrameworkApp-filajsceaccxavhaycqzhvqspbja/Build/Products/Debug"
	var frameworkname = "TMNAFramework"
	var mocha = [Mocha sharedRuntime]
	var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
	DBLOG("sketchPluginFramework loadflg="+loadflg)

	var Toolbar = NSPanel.alloc().init();
	//Toolbar.setBackgroundColor(NSColor.colorWithRed_green_blue_alpha(0.95, 0.95, 0.95, 1));
	Toolbar.setTitle("Screen Adoption")
	Toolbar.setTitlebarAppearsTransparent(true);
	Toolbar.setFrame_display(NSMakeRect(0, 0, 550, 370), false);
	Toolbar.setMovableByWindowBackground(true);
	Toolbar.becomeKeyWindow();
	Toolbar.setLevel(NSFloatingWindowLevel);
	var contentView = Toolbar.contentView()
	Toolbar.center();

	var JSScreenAdoptionViewDelegate = SInherit("JSScreenAdoptionViewDelegate", ScreenAdoptionViewDelegate, {
    	"onSaveButtonClick":function(){ 
    		DBLOG("JSScreenAdoptionViewDelegate.onSaveButtonClick");

    		var saView = ScreenAdoptionView.instance()
    		var modelData = saView.getModelData();
    		DBLOG("saView.getModelData()");
    		DBLOG(modelData.toString());

    		DBLOG("ConvertToJsonObjectString");
    		var jsonObj = CocoaDictArrToJsonObj(modelData);
    		var layerScreenAdoptionInfo = JSON.stringify(jsonObj);
    		DBLOG(layerScreenAdoptionInfo);

    		DBLOG("RemoveRegionList");
    		if (layerScreenAdoptionInfo["Region"]) {
    			delete(layerScreenAdoptionInfo["Region"]["List"])
    		};

    		DBLOG("localContext.command.setValue_forKey_onLayer currentArtboard="+currentArtboard.objectID());
    		localContext.command.setValue_forKey_onLayer_forPluginIdentifier(layerScreenAdoptionInfo,"ScreenAdoptionInfo",currentArtboard,"tmnaMM");

            Toolbar.close();
        },
        "onCancelButtonClick":function(){ 
        	DBLOG("JSScreenAdoptionViewDelegate.onCancelButtonClick");
        	var saView = ScreenAdoptionView.instance()
        	Toolbar.close();
        }
    });

    var saView = ScreenAdoptionView.instance()
    var delegate = JSScreenAdoptionViewDelegate.alloc().init()
    DBLOG("saView.setDelegage(delegate);");
    saView.setDelegage(delegate); 
    DBLOG("saView.clearModelData();");
    saView.clearModelData();
    DBLOG("saView.setModelData(ScreenAdoptionInfoModelData);");
    saView.setModelData(ScreenAdoptionInfoModelData);
    
	contentView.addSubview(saView)
	saView.setFrame(NSMakeRect(0, 0, 600,350))
	Toolbar.makeKeyAndOrderFront(nil);
	DBLOG("show ScreenAdoptionView");

	/*
	data={"Region":{"Current":"X","List":["Y","X"]},
        "X":{
            "Toyota":{
                "Available":{"Entry DA":"1", "T1":"2", "T2":"3", "T-EMVN":"4"},
                "Unavailable":{"Entry DA":"5", "T1":"6", "T2":"7", "T-EMVN":"8"}
            },
            "Lexus":{
                "Available":{"L1":"2", "L1.5":"3", "L2":"4"},
                "Unavailable":{"L1":"6", "L1.5":"7", "L2":"8"}
            }
        },
        "T":{
            "Toyota":{
                "Available":{"Entry DA":"1", "T1":"2", "T2":"3", "T-EMVN":"4"},
                "Unavailable":{"Entry DA":"5", "T1":"6", "T2":"7", "T-EMVN":"8"}
            },
            "Lexus":{
                "Available":{"L1":"2", "L1.5":"3", "L2":"4"},
                "Unavailable":{"L1":"6", "L1.5":"7", "L2":"8"}
            }
        }
	}
	*/

}
function showAlert()
{
    var alert = [NSAlert new];
    [alert addButtonWithTitle:"OK"];
    [alert setMessageText:"information:"];
    [alert setInformativeText:"cannot show the adoption information for the artboard, you must select one artboard!"];
    [alert setAlertStyle:NSWarningAlertStyle];
    [alert runModal];
}
function startScreenAdoption(context)
{
	DBLOG("startScreenAdoption");

	if (context.selection.count()!=1) {
		DBLOG("context.selection.count=" + context.selection.count());
        showAlert();
		return;
	};
	if (context.selection[0].className() != "MSArtboardGroup") {
		DBLOG("context.selection[0].className()=" + context.selection[0].className());
        showAlert();
		return;
	};

	var selectArtboard = context.selection[0];
	loadArtboardScreenAdoption(context, selectArtboard)
}