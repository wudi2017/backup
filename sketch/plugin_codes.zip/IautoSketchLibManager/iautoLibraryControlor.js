function iautoLibraryControlor(context) {
    //this.libraryMarkInfosDic = [];
    //this.cachelibraryMarkInfosDic = [];
    this.iautoLibraries = [];
    this.libraryNames =[];
    //this.documentName = getSketchDocumentName(context)
    var templibraries = NSApp.delegate().librariesController().libraries();
    for (num = 0; num < templibraries .count(); num++) {
        if(templibraries[num].enabled() && templibraries[num].document() && templibraries[num].class() == 'MSUserAssetLibrary'){
            this.iautoLibraries.push(templibraries[num]) 
        }
    }
}

iautoLibraryControlor.prototype.getSymbolFromLib = function(layerID)
{
    for (var libNum = 0; libNum < this.iautoLibraries.length ; libNum++) {
        var curLib = this.iautoLibraries[libNum];
        var curLibDoc = curLib.document()
        var symbolObj =curLibDoc.layerWithID(layerID);
        if(symbolObj){
            return symbolObj;
        }
    }
    return nil;
}