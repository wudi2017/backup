@import "IautoLib/logJS.js"
@import "IautoLib/iautolib.js"

var PERMANENT_USELESS_SCREEN_ID = "30000uselessuselessuseless300000"

function DBLOG(logstr, logtag="libbase")
{
    LogJS.info(logtag, logstr);
    // var nsStrLog = NSString.alloc().initWithString(logstr);
    // nsStrLog = nsStrLog.stringByAppendingFormat("\n");

    // var homeDir = NSHomeDirectory();
    // var logFileFullName = homeDir + "/" + logtag + ".log"
    // //log(logFileFullName)

    // var filehandle = NSFileHandle.fileHandleForWritingAtPath(logFileFullName)
    // if(filehandle)
    // {
    //     filehandle.truncateFileAtOffset(filehandle.seekToEndOfFile());
    //     var nsdata = nsStrLog.dataUsingEncoding(NSUTF8StringEncoding);
    //     filehandle.writeData(nsdata)
    //     [filehandle closeFile];
    // }
    // else
    // {
    //     nsStrLog.writeToFile_atomically(logFileFullName, true);
    // }
}

SInherit = function(className, BaseClass, selectorHandlerDict) {
    var uniqueClassName = className + NSUUID.UUID().UUIDString();
    var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, BaseClass);
    for (var selectorString in selectorHandlerDict) {
        delegateClassDesc.addInstanceMethodWithSelector_function_(selectorString, selectorHandlerDict[selectorString]);
        //log(selectorString + "->" + selectorHandlerDict[selectorString].toString())
    }
    delegateClassDesc.registerClass();
    return NSClassFromString(uniqueClassName);
};

function CocoaDictArrToJsonObj(xObj)
{
    var jsonObj = "UnknownObject";
    if(xObj.className().indexOf("String")>0)
    {
        jsonObj = xObj.toString()+"";
    }
    else if(xObj.className().indexOf("Number")>0)
    {
        jsonObj = Number(xObj);
    }
    else if(xObj.className().indexOf("Dictionary")>0)
    {
        jsonObj = {}
        for(key in xObj)
        {
            var localkey = key
            var xSubObj = xObj[key];
            var jsonSub = CocoaDictArrToJsonObj(xSubObj)
            jsonObj[localkey]= jsonSub
        }
    }
    else if(xObj.className().indexOf("Array")>0)
    {
        jsonObj = []
        for(iArr=0;iArr<xObj.count();iArr++)
        {
            var xSubObj = xObj[iArr]
            var jsonSub = CocoaDictArrToJsonObj(xSubObj)
            jsonObj.push(jsonSub)
        }
    }
    return jsonObj
}

function JsonObjToCocoaDictArr(jObj)
{
    var xObj = @"UnknownObject";
    if(typeof(jObj) == "string") // ""
    {
        xObj = [NSString stringWithString:jObj];
    }
    else if(typeof(jObj) == "number") // number
    {
        xObj = jObj;
    }
    else if((jObj instanceof Object) && !(jObj instanceof Array)) // {}
    {
        xObj = [NSMutableDictionary dictionary];
        for(key in jObj)
        {
            var localkey = key
            var jSubObj = jObj[key];
            var xSub = JsonObjToCocoaDictArr(jSubObj)
            [xObj setObject:xSub forKey:localkey];
        }
    }
    else if((jObj instanceof Object) && (jObj instanceof Array)) // []
    {
        xObj = [NSMutableArray array];
        for(iArr=0;iArr<jObj.length;iArr++)
        {
            var jSubObj = jObj[iArr]
            var xSub = JsonObjToCocoaDictArr(jSubObj)
            xObj.addObject(xSub);
        }
    }
    return xObj;
}

/*******************************************/
function getDefaultFunc(artboard)
{
    return 'ADvanced safety (ADas)';
}
function getFuncList()
{
    var funcList = [
        'Android Auto',
        'Air Conditioning (Climate)',
        'Automatic Drive',
        'AGent client',
        'AM radio',
        'Advancement Optical system',
        'Audio Visual (Audio Common))',
        'APp media',
        'ADvanced safety (ADas)',
        'AUdio common',
        'Bluetooth Audio',
        'Blu-Ray',
        'Bluetooth setting',
        'CD media',
        'CharGe',
        'Car Life',
        'Car Sharing',
        'Car Play',
        'DAB media',
        'Disc',
        'Drive Mode select',
        'DVD VR',
        'DVD video',
        'Emargency Call',
        'ETC/DSRC',
        'Energy Flow',
        'EV function',
        'Fuel Consumption',
        'FM radio',
        'First Time onboarding',
        'Four Wheel drive',
        'G-Book (CH)',
        'Hnadsfree, phone, message',
        'HDMI media',
        'IP Apps',
        'iOS ipod',
        'KeyBoard',
        'MiraCast',
        'MessaGes',
        'My Room mode',
        'Memory Service (JP)',
        'NaVigation',
        'Operator Service',
        'OTA update',
        'Privacy Protection',
        'RaDio common',
        'Rear seat Entertainment',
        'Remote Services',
        'Solar Charging System',
        'SDL',
        'Sound Library',
        'Sd Media',
        'SeaT',
        'System',
        'T-Connect / G-Link',
        'Telematics',
        'Tire Pressure Monitor',
        'Digital TV media',
        'USB audio',
        'User Profile',
        'Universal Search',
        'USB video',
        'Vehicle Customization',
        'Valet Mode',
        'Voice Recognition',
        'Vehicle setting',
        'Vehicle Integration',
        'Web Browser',
        'WiFi setting',
        'We Link',
        'XM radio media',
        ];

    return funcList;
}
function getFuncCodeMap()
{
    var funcCodeMap = {
        'Android Auto':'AA',
        'Air Conditioning (Climate)':'AC',
        'Automatic Drive':'AD',
        'AGent client':'AG',
        'AM radio':'AM',
        'Advancement Optical system':'AO',
        'Audio Visual (Audio Common))':'AV',
        'APp media':'AP',
        'ADvanced safety (ADas)':'AD',
        'AUdio common':'AU',
        'Bluetooth Audio':'BA',
        'Blu-Ray':'BR',
        'Bluetooth setting':'BT',
        'CD media':'CD',
        'CharGe':'CG',
        'Car Life':'CL',
        'Car Sharing':'CS',
        'Car Play':'CP',
        'DAB media':'DB',
        'Disc':'DC',
        'Drive Mode select':'DM',
        'DVD VR':'DR',
        'DVD video':'DV',
        'Emargency Call':'EC',
        'ETC/DSRC':'ED',
        'Energy Flow':'EF',
        'EV function':'EV',
        'Fuel Consumption':'FC',
        'FM radio':'FM',
        'First Time onboarding':'FT',
        'Four Wheel drive':'FW',
        'G-Book (CH)':'GB',
        'Hnadsfree, phone, message':'HF',
        'HDMI media':'HI',
        'IP Apps':'IA',
        'iOS ipod':'IP',
        'KeyBoard':'KB',
        'MiraCast':'MC',
        'MessaGes ':'MG',
        'My Room mode ':'MR',
        'Memory Service (JP) ':'MS',
        'NaVigation':'NV',
        'Operator Service':'OS',
        'OTA update':'OT',
        'Privacy Protection':'PP',
        'RaDio common':'RD',
        'Rear seat Entertainment':'RE',
        'Remote Services':'RS',
        'Solar Charging System':'SC',
        'SDL':'SD',
        'Sound Library':'SL',
        'Sd Media':'SM',
        'SeaT':'ST',
        'System':'SY',
        'T-Connect / G-Link':'TC',
        'Telematics':'TL',
        'Tire Pressure Monitor':'TP',
        'Digital TV media':'TV',
        'USB audio':'UA',
        'User Profile':'UP',
        'Universal Search':'US',
        'USB video':'UV',
        'Vehicle Customization':'VC',
        'Valet Mode':'VM',
        'Voice Recognition':'VR',
        'Vehicle setting':'VS',
        'Vehicle Integration':'VI',
        'Web Browser':'WB',
        'WiFi setting':'WF',
        'We Link':'WL',
        'XM radio media':'XM'
    };

    return funcCodeMap;
}
function findFuncCodeByStr(str)
{
    var funcMap = getFuncCodeMap();
    return funcMap[str];
}
/*******************************************/
function getDefaultRegion(pageinfo)
{
    return getPageRegionInfo(pageinfo);
}
function getRegionList()
{
    var regionList = [
        'Global',
        'JP',
        'EU',
        'OTHER'
        ];
    return regionList;
}
function getRegionCodeMap()
{
    var regionCodeMap = {
        'Global':0,
        'JP':1,
        'EU':2,
        'OTHER':3
    };
    return regionCodeMap;
}
function findRegionStrByCode(code)
{
    var regionMap = getRegionCodeMap();
    for (key in regionMap) {
        if (regionMap[key] == code) {
            return key;
        };
    };
    return "UnknownRegion"
}
function findRegionCodeByStr(str)
{
    var regionMap = getRegionCodeMap();
    return regionMap[str];
}

g_artboardExitValList = nil
function loadAllExistArtboadsVal(context)
{
  var doc = context.document;
  var pages = doc.pages();
  for(var iPage=0; iPage<pages.length; iPage++)
  {
    var pageObj = pages[iPage];
    var artboards = pageObj.artboards();
    for(var iArtboard=0; iArtboard <artboards.length; iArtboard ++)
    {
      var artboardObj = artboards[iArtboard];
      var layerScreenID = context.command.valueForKey_onLayer_forPluginIdentifier("ScreenID",artboardObj,"tmnaMM");
      if(nil != layerScreenID)
      {
        var idarr = layerScreenID.split(".")
        if(idarr.length > 2)
        {
          var artboardVal = idarr[2]
          g_artboardExitValList.push(artboardVal)
        }
      }
    }
  }
}
function getArtboardVal(context, artboard)
{
    if(nil == g_artboardExitValList)
    {
        g_artboardExitValList = []
        loadAllExistArtboadsVal(context)
    }
    var objectID = artboard.objectID();
    var idarr = objectID.split("-")
    var artboardVal = idarr[0][0] + idarr[1][0] + idarr[2][0] + idarr[3][0];

    if(-1 == g_artboardExitValList.indexOf(artboardVal))
    {
        //log("not exist")
    }
    else
    {
        //log("exist & regenerate")
        artboardVal = idarr[0][1] + idarr[1][1] + idarr[2][1] + idarr[3][1];
        if(-1 == g_artboardExitValList.indexOf(artboardVal))
        {
        }
        else
        {
            //log("already exist artboard value,  fatal err")
        }
    }

    g_artboardExitValList.push(artboardVal)
    //log("artboadVal:"+artboardVal)
    return artboardVal;
}


function loadArtboardScreenIDEdit(context,page,artboard)
{
    var currentPage = page;
    var currentArtboard = artboard;
    DBLOG("loadArtboardScreenIDEdit currentPage:"+currentPage.name())
    DBLOG("loadArtboardScreenIDEdit currentArtboard:"+currentArtboard.name())

    // get layerScreenID
    var layerScreenID = context.command.valueForKey_onLayer_forPluginIdentifier("ScreenID",currentArtboard,"tmnaMM");
    DBLOG("get layerScreenID="+layerScreenID)

    // init jsonScreenID
    DBLOG("init jsonScreenIDEditData")
    var jsonScreenIDEditData = {}
    jsonScreenIDEditData['Region'] = {}
    jsonScreenIDEditData['Region']['Current'] = ""
    jsonScreenIDEditData['Region']['List'] = getRegionList()
    jsonScreenIDEditData['RegionMap'] = getRegionCodeMap()
    jsonScreenIDEditData['Func'] = {}
    jsonScreenIDEditData['Func']['Current'] = ""
    jsonScreenIDEditData['Func']['List'] = getFuncList()
    jsonScreenIDEditData['FuncMap'] = getFuncCodeMap()
    jsonScreenIDEditData['ArtboardVal'] = getArtboardVal(artboard)
    
    if(layerScreenID)
    {
        var regionStr = "UnknownRegion";
        var funcStr = "UnknownRegion";

        var arrScrID = layerScreenID.split(".");
        if (arrScrID.length == 3) {
            var codeStr = arrScrID[1];
            var code = parseInt(codeStr);
            regionStr = findRegionStrByCode(code);
            funcStr = arrScrID[0];
        };
        
        jsonScreenIDEditData['Region']['Current'] = regionStr;
        jsonScreenIDEditData['Func']['Current'] = funcStr;
        //jsonScreenIDEditData['EditAble'] = "disable";
    }
    else
    {
        jsonScreenIDEditData['Region']['Current'] = getDefaultRegion(currentPage)
        jsonScreenIDEditData['Func']['Current'] = getDefaultFunc(artboard)
    }

    // reset to default
    jsonScreenIDEditData['Region']['Current'] = getDefaultRegion(currentPage)
    jsonScreenIDEditData['Func']['Current'] = getDefaultFunc(artboard)

    DBLOG(JSON.stringify(jsonScreenIDEditData));

    // ConvertToCocoaObject
    xScreenIDEditData=JsonObjToCocoaDictArr(jsonScreenIDEditData);
    DBLOG("ConvertToCocoaObject")
    DBLOG(xScreenIDEditData.toString())

    var localContext = context;
    coscript.setShouldKeepAround(true);

    var frameworkpath = COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent();
    //var frameworkpath = "/Users/nb/Library/Developer/Xcode/DerivedData/TestTMNAFrameworkApp-filajsceaccxavhaycqzhvqspbja/Build/Products/Debug"
    var frameworkname = "TMNAFramework"
    var mocha = [Mocha sharedRuntime]
    var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
    DBLOG("sketchPluginFramework loadflg="+loadflg)

    var Toolbar = NSPanel.alloc().init();
    //Toolbar.setBackgroundColor(NSColor.colorWithRed_green_blue_alpha(0.95, 0.95, 0.95, 1));
    Toolbar.setTitle("Screen ID Edit")
    Toolbar.setTitlebarAppearsTransparent(true);
    Toolbar.setFrame_display(NSMakeRect(0, 0, 540, 200), false);
    Toolbar.setMovableByWindowBackground(true);
    Toolbar.becomeKeyWindow();
    Toolbar.setLevel(NSFloatingWindowLevel);
    var contentView = Toolbar.contentView()
    Toolbar.center();

    var JSScreenIDEditViewDelegate = SInherit("JSScreenIDEditViewDelegate", ScreenIDEditViewDelegate, {
        "onSaveButtonClick":function(){ 
            DBLOG("JSScreenIDEditViewDelegate.onSaveButtonClick");

            // var sideView = ScreenIDEditView.instance()
            // var modelData = sideView.getModelData();
            // DBLOG("sideView.getModelData()");
            // DBLOG(modelData.toString());

            // DBLOG("ConvertToJsonObjectString");
            // var jsonObj = CocoaDictArrToJsonObj(modelData);
            // var jsonScreenIDEditData = JSON.stringify(jsonObj);
            // DBLOG(jsonScreenIDEditData);

      //       DBLOG("PreviewScreenID:");
      //       var previewScreenID = jsonObj["PreviewScreenID"]
      //       DBLOG(previewScreenID);

      //       DBLOG("localContext.command.setValue_forKey_onLayer currentArtboard="+currentArtboard.objectID());
      //       localContext.command.setValue_forKey_onLayer_forPluginIdentifier(previewScreenID,"ScreenID",currentArtboard,"tmnaMM");

      //       var newArtboardName = previewScreenID + " - " + currentArtboard.name();
      //       DBLOG("reset currentArtboard name ="+newArtboardName);
      //       currentArtboard.setName(newArtboardName);

            var sideView = ScreenIDEditView.instance()
            var modelData = sideView.getModelData();
            DBLOG("sideView.getModelData()");
            DBLOG(modelData.toString());

            DBLOG("ConvertToJsonObjectString");
            var jsonObj = CocoaDictArrToJsonObj(modelData);
            var layerScreenAdoptionInfo = JSON.stringify(jsonObj);
            DBLOG(layerScreenAdoptionInfo);
            var curFunc = nil;
            if (jsonObj['Func']) {
                curFunc = jsonObj['Func']['Current']
            };
            var curFuncCode = nil;
            if (curFunc) {
                curFuncCode = findFuncCodeByStr(curFunc);
            };
            var curRegion = nil;
            if (jsonObj['Region']) {
                curRegion = jsonObj['Region']['Current']
            };
            var curRegionCode = nil;
            if (curRegion) {
                curRegionCode = findRegionCodeByStr(curRegion);
            };
            DBLOG("Func:"+curFunc);
            DBLOG("Region:"+curRegion);
            DBLOG("RegionCode:"+curRegionCode);

            var doc = localContext.document;
            var pages = doc.pages();
            DBLOG(pages.toString());
            for(var iPage=0; iPage<pages.length; iPage++)
            {
                var page = pages[iPage];
                if (page.name().indexOf("Symbol")>=0) {
                    continue;
                };

                if (page.objectID() == currentPage.objectID()) {
                    var artboards = page.artboards();
                    for(var iArtboard=0; iArtboard <artboards.length; iArtboard ++)
                    {
                        var curArtboard = artboards[iArtboard];

                        if (isConditionArtboard(curArtboard)) {
                            continue;
                        };
                        
                        var layerScreenID = localContext.command.valueForKey_onLayer_forPluginIdentifier("ScreenID",curArtboard,"tmnaMM");
                        if (layerScreenID) {

                        }
                        else
                        {
                            if (curFunc && curRegion) {
                                var curArtboardVal = getArtboardVal(curArtboard)
                                var screenID = curFuncCode + "." + curRegionCode + "." + curArtboardVal;
                                DBLOG("curArtboardVal screenID:" + screenID + " (" + curArtboard.name() + ")");

                                DBLOG("localContext.command.setValue_forKey_onLayer currentArtboard="+currentArtboard.objectID());
                                localContext.command.setValue_forKey_onLayer_forPluginIdentifier(screenID,"ScreenID",curArtboard,"tmnaMM");

                                var newArtboardName = screenID + " - " + curArtboard.name();
                                DBLOG("reset currentArtboard name ="+newArtboardName);
                                curArtboard.setName(newArtboardName);
                            };
                        }
                    }
                };
            }

            Toolbar.close();
        },
        "onCancelButtonClick":function(){ 
            DBLOG("JSScreenIDEditViewDelegate.onCancelButtonClick");
            Toolbar.close();
        }
    });

    var sideView = ScreenIDEditView.instance()
    var delegate = JSScreenIDEditViewDelegate.alloc().init()
    DBLOG("sideView.setDelegage(delegate);");
    sideView.setDelegage(delegate); 
    DBLOG("sideView.clearModelData();");
    sideView.clearModelData();
    DBLOG("sideView.setModelData(xScreenIDEditData);");
    sideView.setModelData(xScreenIDEditData);
    
    contentView.addSubview(sideView)
    sideView.setFrame(NSMakeRect(0, 0, 600,350))
    Toolbar.makeKeyAndOrderFront(nil);
    DBLOG("show ScreenIDEditView");

    /*
     data={
        "Func":{"Current":"X","List":["Y","X"]},
        "Region":{"Current":"X","List":["Y","X"]},
        "RegionMap":{"Y":21},
        "ArtboardVal":{"Current":"X","List":["Y","X"]}
     }
    */

}

function NewLoadArtboardScreenIDEdit(context,page,artboard)
{
    var currentPage = page;
    var currentArtboards = artboard;
    DBLOG("loadArtboardScreenIDEdit currentPage:"+currentPage.name())
    //LogJS.error("libbase","loadArtboardScreenIDEdit currentArtboard:"+currentArtboards)

    // get layerScreenID
    var layerScreenID = context.command.valueForKey_onLayer_forPluginIdentifier("ScreenID",currentArtboards[0],"tmnaMM");
    DBLOG("get layerScreenID="+layerScreenID)

    // init jsonScreenID
    DBLOG("init jsonScreenIDEditData")
    var jsonScreenIDEditData = {}
    jsonScreenIDEditData['Region'] = {}
    jsonScreenIDEditData['Region']['Current'] = ""
    jsonScreenIDEditData['Region']['List'] = getRegionList()
    jsonScreenIDEditData['RegionMap'] = getRegionCodeMap()
    jsonScreenIDEditData['Func'] = {}
    jsonScreenIDEditData['Func']['Current'] = ""
    jsonScreenIDEditData['Func']['List'] = getFuncList()
    jsonScreenIDEditData['FuncMap'] = getFuncCodeMap()
    jsonScreenIDEditData['ArtboardVal'] = "****"
    
    if(layerScreenID)
    {
        var regionStr = "UnknownRegion";
        var funcStr = "UnknownRegion";

        var arrScrID = layerScreenID.split(".");
        if (arrScrID.length == 3) {
            var codeStr = arrScrID[1];
            var code = parseInt(codeStr);
            regionStr = findRegionStrByCode(code);
            funcStr = arrScrID[0];
        };
        
        jsonScreenIDEditData['Region']['Current'] = regionStr;
        jsonScreenIDEditData['Func']['Current'] = funcStr;
        //jsonScreenIDEditData['EditAble'] = "disable";
    }
    else
    {
        jsonScreenIDEditData['Region']['Current'] = getDefaultRegion(currentPage)
        jsonScreenIDEditData['Func']['Current'] = getDefaultFunc(currentArtboards[0])
    }

    // reset to default
    jsonScreenIDEditData['Region']['Current'] = getDefaultRegion(currentPage)
    jsonScreenIDEditData['Func']['Current'] = getDefaultFunc(currentArtboards[0])

    DBLOG(JSON.stringify(jsonScreenIDEditData));

    // ConvertToCocoaObject
    xScreenIDEditData=JsonObjToCocoaDictArr(jsonScreenIDEditData);
    DBLOG("ConvertToCocoaObject")
    DBLOG(xScreenIDEditData.toString())

    var localContext = context;
    coscript.setShouldKeepAround(true);

    var frameworkpath = COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent();
    //var frameworkpath = "/Users/nb/Library/Developer/Xcode/DerivedData/TestTMNAFrameworkApp-filajsceaccxavhaycqzhvqspbja/Build/Products/Debug"
    var frameworkname = "TMNAFramework"
    var mocha = [Mocha sharedRuntime]
    var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
    DBLOG("sketchPluginFramework loadflg="+loadflg)

    var Toolbar = NSPanel.alloc().init();
    //Toolbar.setBackgroundColor(NSColor.colorWithRed_green_blue_alpha(0.95, 0.95, 0.95, 1));
    Toolbar.setTitle("Screen ID Edit")
    Toolbar.setTitlebarAppearsTransparent(true);
    Toolbar.setFrame_display(NSMakeRect(0, 0, 540, 200), false);
    Toolbar.setMovableByWindowBackground(true);
    Toolbar.becomeKeyWindow();
    Toolbar.setLevel(NSFloatingWindowLevel);
    var contentView = Toolbar.contentView()
    Toolbar.center();

    var JSScreenIDEditViewDelegate = SInherit("JSScreenIDEditViewDelegate", ScreenIDEditViewDelegate, {
        "onSaveButtonClick":function(){ 
            DBLOG("JSScreenIDEditViewDelegate.onSaveButtonClick");
            var sideView = ScreenIDEditView.instance()
            var modelData = sideView.getModelData();
            DBLOG("sideView.getModelData()");
            DBLOG(modelData.toString());

            DBLOG("ConvertToJsonObjectString");
            var jsonObj = CocoaDictArrToJsonObj(modelData);
            var layerScreenAdoptionInfo = JSON.stringify(jsonObj);
            DBLOG(layerScreenAdoptionInfo);
            var curFunc = nil;
            if (jsonObj['Func']) {
                curFunc = jsonObj['Func']['Current']
            };
            var curFuncCode = nil;
            if (curFunc) {
                curFuncCode = findFuncCodeByStr(curFunc);
            };
            var curRegion = nil;
            if (jsonObj['Region']) {
                curRegion = jsonObj['Region']['Current']
            };
            var curRegionCode = nil;
            if (curRegion) {
                curRegionCode = findRegionCodeByStr(curRegion);
            };
            DBLOG("Func:"+curFunc);
            DBLOG("Region:"+curRegion);
            DBLOG("RegionCode:"+curRegionCode);

            var doc = localContext.document;
            var pages = doc.pages();
            DBLOG(pages.toString());

            var artboards = page.artboards();
            for(var iArtboard=0; iArtboard <currentArtboards.length; iArtboard ++)
            {
                var curArtboard = currentArtboards[iArtboard];

                if (isConditionArtboard(curArtboard)) {
                    continue;
                };
                
                var layerScreenID = localContext.command.valueForKey_onLayer_forPluginIdentifier("ScreenID",curArtboard,"tmnaMM");
                var permantScreenID = localContext.command.valueForKey_onLayer_forPluginIdentifier("PermanentScreenID",curArtboard,"tmnaMM");
                if (permantScreenID&&permantScreenID!=PERMANENT_USELESS_SCREEN_ID) {
                    if (curArtboard.name() != permantScreenID) {
                        curArtboard.setName(permantScreenID);
                    }
                }
                else
                {
                    if (curFunc && curRegion) {
                        var curArtboardVal = getArtboardVal(localContext,curArtboard)
                        var screenID = curFuncCode + "." + curRegionCode + "." + curArtboardVal;
                        DBLOG("curArtboardVal screenID:" + screenID + " (" + curArtboard.name() + ")");

                        DBLOG("localContext.command.setValue_forKey_onLayer currentArtboard="+curArtboard.objectID());
                        localContext.command.setValue_forKey_onLayer_forPluginIdentifier(screenID,"ScreenID",curArtboard,"tmnaMM");
                        originArtBoardName = localContext.command.valueForKey_onLayer_forPluginIdentifier("OriginArtBoardName",curArtboard,"tmnaMM");
                        if (!originArtBoardName){
                            originArtBoardName = curArtboard.name();
                        }
                        var newArtboardName = screenID + " - " + originArtBoardName;
                        DBLOG("reset curArtboard name ="+newArtboardName);
                        curArtboard.setName(newArtboardName);
                        localContext.command.setValue_forKey_onLayer_forPluginIdentifier(newArtboardName,"PermanentScreenID",curArtboard,"tmnaMM");
                        localContext.command.setValue_forKey_onLayer_forPluginIdentifier(originArtBoardName,"OriginArtBoardName",curArtboard,"tmnaMM");
                    };
                }
            }
            Toolbar.close();
        },
        "onCancelButtonClick":function(){ 
            DBLOG("JSScreenIDEditViewDelegate.onCancelButtonClick");
            Toolbar.close();
        }
    });

    var sideView = ScreenIDEditView.instance()
    var delegate = JSScreenIDEditViewDelegate.alloc().init()
    DBLOG("sideView.setDelegage(delegate);");
    sideView.setDelegage(delegate); 
    DBLOG("sideView.clearModelData();");
    sideView.clearModelData();
    DBLOG("sideView.setModelData(xScreenIDEditData);");
    sideView.setModelData(xScreenIDEditData);
    
    contentView.addSubview(sideView)
    sideView.setFrame(NSMakeRect(0, 0, 600,350))
    Toolbar.makeKeyAndOrderFront(nil);
    DBLOG("show ScreenIDEditView");

    /*
     data={
        "Func":{"Current":"X","List":["Y","X"]},
        "Region":{"Current":"X","List":["Y","X"]},
        "RegionMap":{"Y":21},
        "ArtboardVal":{"Current":"X","List":["Y","X"]}
     }
    */

}

function showAlert(str)
{
    var alert = [NSAlert new];
    [alert addButtonWithTitle:"OK"];
    [alert setMessageText:@"Alert"];
    [alert setInformativeText:str];
    [alert setAlertStyle:NSWarningAlertStyle];
    [alert runModal];
}

function getFirstPage(context)
{
    var doc = context.document;
    var pages = doc.pages();
    for(var iPage=0; iPage<pages.length; iPage++)
    {
        return pages[iPage];
    }
    return nil; 
}
function getFirstArtboardInPage(pageObj)
{
    var artboards = pageObj.artboards();
    for(var iArtboard=0; iArtboard <artboards.length; iArtboard ++)
    {
        return artboards[iArtboard];
    }
    return nil; 
}
function getFirstArtboard(context)
{
    var firstPage = getFirstPage(context);
    return getFirstArtboardInPage(firstPage); 
}

function startScreenIDEdit(context)
{
	DBLOG("startScreenIDEdit");
    var currentPage = context.document.currentPage();
    if (!currentPage) {
        showAlert("There is no selection page, please choose one page!");
        return;
    };

    var artboards = [];
    var selections = context.selection;
    if (selections) {
        for (var i = 0; i < selections.length; i++) {
            var selection = selections[i]
            if (selection.className() == "MSArtboardGroup") {
                artboards.push(selection)
            };
        };
    };

    var selectArtboards = artboards;
    var length = artboards.length;
    if (length <= 0) {
        selectArtboards = context.document.artboards();
        length = context.document.artboards().length;
        if (length <= 0) {
            showAlert("There is no artboards in current page!");
            return;
        };
    };
    NewLoadArtboardScreenIDEdit(context,currentPage,selectArtboards);
}

var createField = function(value, size) 
{
    var size = (size) ? size : NSMakeRect(0,0,100,20);
    var field = [[NSTextField alloc] initWithFrame:size];
    [field setStringValue:value];

    return field;
}

function DrawWindowAndResetScreenID(context,page,artboard) 
{
    var alertWindow = COSAlertWindow.new();
    alertWindow.setMessageText('Reset ScreenID');
    alertWindow.addTextLabelWithValue("Password:");
    alertWindow.addAccessoryView(createField("", NSMakeRect(0,0,200,20)));
    alertWindow.addButtonWithTitle('OK');
    alertWindow.addButtonWithTitle('Cancel');
    var responseCode = alertWindow.runModal();
    if (responseCode == 1000) {
        let content = String([[alertWindow viewAtIndex:1] stringValue]);
        if (content == "111111Aa") {
            var artboards = page.artboards();
            var currentArtboards = artboard;
            for(var iArtboard=0; iArtboard < currentArtboards.length; iArtboard ++)
            {
                var curArtboard = currentArtboards[iArtboard];

                if (isConditionArtboard(curArtboard)) {
                    continue;
                };
                var permantScreenID = context.command.valueForKey_onLayer_forPluginIdentifier("PermanentScreenID",curArtboard,"tmnaMM");
                if (permantScreenID && permantScreenID != PERMANENT_USELESS_SCREEN_ID) {
                   context.command.setValue_forKey_onLayer_forPluginIdentifier(PERMANENT_USELESS_SCREEN_ID,"PermanentScreenID",curArtboard,"tmnaMM");
                }
            }  
        }
        else {
            showAlert("Password is wrong!");
            return;
        }
    }
    else {
        return;
    }
}

function resetScreenID(context)
{
    DBLOG("resetScreenID");
    var currentPage = context.document.currentPage();
    if (!currentPage) {
        showAlert("There is no selection page, please choose one page!");
        return;
    };

    var artboards = [];
    var selections = context.selection;
    if (selections) {
        for (var i = 0; i < selections.length; i++) {
            var selection = selections[i]
            if (selection.className() == "MSArtboardGroup") {
                artboards.push(selection)
            };
        };
    };
    
    var selectArtboards = artboards;
    var length = artboards.length;
    if (length <= 0) {
        selectArtboards = context.document.artboards();
        length = context.document.artboards().length;
        if (length <= 0) {
            showAlert("There is no artboards in current page!");
            return;
        }
    };

    var selectionNum = artboards;
    var recordnum = 0;
    if (selectionNum >= 1) {
        var artboardNum = 0;
        for(var i = 0; i < selectionNum; i++) {
            if (artboards[i].className() == "MSArtboardGroup") {
                artboardNum ++;
            }
        }
        if (artboardNum != selectionNum) {
            showAlert("Please only select one or more Artboards, no select other targets like symbols!");
            return;
        }
        selectArtboards = artboards;
    }
    DrawWindowAndResetScreenID(context,currentPage,selectArtboards);
}
