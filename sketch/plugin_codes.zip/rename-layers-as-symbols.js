@import 'common.js';

var onRun = function(context) {
  var allSymbols = getAllSymbolsInDocument(context.document);

  for (var i = 0; i < allSymbols.length; i++) {
    var symbol = allSymbols[i];

    if (symbol.symbolMaster()) {
      var masterName = symbol.symbolMaster().name();

      if (symbol.name() != masterName) {
        symbol.setName(masterName);
      }
    }
  }

  // alert('Symbol Layer Names Reset!', 'Good Job!');
}
