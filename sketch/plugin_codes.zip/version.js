@import "iautolib/Alert.js"
@import "iautolib/filelib.js"

function showVersion(context)
{
	var pluginRoot =  COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent();
	var versionFile = pluginRoot + "/" + "version.txt";
	//versionFile = "/Users/nb/sketch19/sketchplugin-other/NewTmnaSpecTool/new_tmna-multimedia-iauto.sketchplugin/Contents/Sketch/version.txt";
	var versionFileContent = readFileContent(versionFile);
	var copyright = "Copyright @2018 iAuto (Shanghai) Co., Ltd. All right reserved.";
	copyright =  "";
	showMessageButton1(NSWarningAlertStyle, versionFileContent, copyright, "OK")
}