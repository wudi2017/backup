@import "metadata-panel-listener.js"
@import "IautoLib/iautolib.js"

function resetHMIExportConfig(context)
{
    var currentPage = context.document.currentPage();
    var count = context.selection.count();
    if (!currentPage || count <= 0) {
        showAlert("There is no selection, please choose at least one layer!");
        return;
    };
    DrawWindowAndResetExportConfig(context);
}

function DrawWindowAndResetExportConfig(context) 
{
    // var alertWindow = COSAlertWindow.new();
    // alertWindow.setMessageText('Reset HMIExportConfig');
    // alertWindow.addTextLabelWithValue("Password:");
    // alertWindow.addAccessoryView(createField("", NSMakeRect(0,0,200,20)));
    // alertWindow.addButtonWithTitle('OK');
    // alertWindow.addButtonWithTitle('Cancel');
    // var responseCode = alertWindow.runModal();
    // if (responseCode == 1000) {
    //     let content = String([[alertWindow viewAtIndex:1] stringValue]);
    //     if (content == "111111Aa") {
            setMetadataPanelStopFlag(true);
            var ctx = context;
            delayRun(0.3, () => {
                  initFramework(context);
                  SketchEventHandler.resetExportMarkConfig();
                  context.document.showMessage("reset mark info finish");
                  showAlert("Reset mark info finish!");
                  restartSetupPanelNew(ctx);
            })
    //     }
    //     else {
    //         showAlert("Password is wrong!");
    //         return;
    //     }
    // }
    // else {
    //     return;
    // }
}

function initFramework(context)
{
  coscript.setShouldKeepAround(true);
  var frameworkname = "TMNAFramework"
    var mocha = Mocha.sharedRuntime();
    if (!mocha.valueForKey(frameworkname)) {
       var script_full_filename = context.scriptPath;
    var sketchPluginPath = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    sketchPluginPath = sketchPluginPath.substr(0, sketchPluginPath.lastIndexOf('/'));
    var frameworkpath = sketchPluginPath + "/Resources/";
    var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
    mocha.setValue_forKey_(true, frameworkname);
        //return;
    }
    
    var command = context.command;
    var document = context.document;
    var scriptPath = context.scriptPath;
    var scriptURL = context.scriptURL;
    var selection = context.selection;
    SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
    var sketchObjects = [
        MSLayer.new(),
        MSLayerGroup.new(),
        MSFlowConnection.new(),
        MSSymbolCreator.new(),
        MSLayerArray.new(),
        MSTextLayer.new(),
        MSArtboardGroup.new(),
        MSShapeGroup.new(),
        MSExportRequest.new(),
        MSStyle.new(),
        MSStyleFill.new(),
        MSColor.new(),
        MSCurvePoint.new(),
        MSShapePathLayer.new(),
        MSRectangleShape.new(),
        MSTriangleShape.new(),
        MSOvalShape.new(),
        MSStarShape.new(),
        MSPolygonShape.new(),
        MSAbsoluteRect.new()
    ];
    SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);
}

var createField = function(value, size) 
{
    var size = (size) ? size : NSMakeRect(0,0,100,20);
    var field = [[NSTextField alloc] initWithFrame:size];
    [field setStringValue:value];

    return field;
}