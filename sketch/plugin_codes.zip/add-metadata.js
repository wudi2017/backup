@import 'common.js';

let META_MENU_ITEMS = ['Summary', 'Remarks', 'Parts Type', 'Screen Mode'];
// PART_TYPES is imported from common.js
let SCREEN_MODES = ['TODO1', 'TODO2', 'TODO3']; // Waiting for TMC list

// Frankensteined together. Don't really understand
var createField = function(value, size) {
	var size = (size) ? size : NSMakeRect(0,0,100,20);
	var field = [[NSTextField alloc] initWithFrame:size];
	[field setStringValue:value];

	return field;
}

// Frankensteined together. Don't really understand
var buildMenu = function(items, initialSelection, size, selectedCallback) {
  var size = (size) ? size : NSMakeRect(0,0,100,20);
  var popUpButton = [[NSPopUpButton alloc] initWithFrame:size];

  let index = 0
  for (i in items) {
    var item = [[NSMenuItem alloc] init];
    item.setTitle(items[i]);
    item.setCOSJSTargetFunction(function(sender) {
      const title = [sender title]
      selectedCallback && selectedCallback(String(title))
    })
    [[popUpButton menu] addItem: item]
    if (index === initialSelection) [popUpButton selectItem: item]
    index++
  }

  return popUpButton;
}

// Frankensteined together. Don't really understand
function metaObject(selectedLayerName, layerMessage) {
  var alertWindow = COSAlertWindow.new();

  const relayout = (subItems, mainMenuSelection) => {

    const index = mainMenuSelection || 0

    alertWindow.setMessageText('Add/Edit Metadata');

    alertWindow.addTextLabelWithValue('For ' + selectedLayerName + ':');

    alertWindow.addAccessoryView(buildMenu(META_MENU_ITEMS, index, NSMakeRect(0,0,300,20), (selection) => {
      log(`selected ${selection}`)
      [alertWindow views].forEach((sv) => sv.removeFromSuperview())
      [[alertWindow views] removeAllObjects]
      if (selection == 'Parts Type') {
        relayout(PART_TYPES, META_MENU_ITEMS.indexOf(selection))
      } else if (selection == 'Screen Mode') {
        relayout(SCREEN_MODES, META_MENU_ITEMS.indexOf(selection))
      } else {
        relayout(null, META_MENU_ITEMS.indexOf(selection))
      }
      [alertWindow layout]
      [[alertWindow alert] layout]
    }));

    if (subItems) {
      log('relayout with subitems')
      alertWindow.addAccessoryView(buildMenu(subItems, 0, NSMakeRect(0,0,300,20), (selection) => {
        log(`subItem selected ${selection}`)
      }));
    } else {
      log('relayout without subitems')
      alertWindow.addAccessoryView(createField(layerMessage, NSMakeRect(0,0,300,120)));
    }
  }

  relayout()

  alertWindow.addButtonWithTitle('OK');
  alertWindow.addButtonWithTitle('Cancel');
  alertWindow.addButtonWithTitle('CLEAR ALL META');
  alertWindow.addButtonWithTitle('SHOW ALL META');

  var fieldOne = alertWindow.viewAtIndex(1);
  alertWindow.alert().window().setInitialFirstResponder(fieldOne);

  var responseCode = alertWindow.runModal();

  if (responseCode == 1000) {
    let type = String([[alertWindow viewAtIndex:1] titleOfSelectedItem])
    let content;
    if (type == 'Parts Type') {
      const part = String([[alertWindow viewAtIndex:2] titleOfSelectedItem])
      const idd = PART_TYPES.indexOf(part)
      content = { 'id': idd, part }
    } else if (type == 'Screen Mode') {
      const mode = String([[alertWindow viewAtIndex:2] titleOfSelectedItem])
      const idd = SCREEN_MODES.indexOf(mode)
      content = { 'id': idd, mode }
    } else {
      content = String([[alertWindow viewAtIndex:2] stringValue])
    }

    return { type, content };
  } else if (responseCode == 1002) {
    // clear all meta
    return null;
  } else if (responseCode == 1003) {
    // show all meta
    return 1;
  } else {
    // cancel
    return false;
  }
}


var onRun = function(context) {
  let sketch = context.api();

  let document = sketch.selectedDocument;
  let selection = document.selectedLayers;

  let command = context.command;

  // Get selected layer. Only allows for 1 selected layer at a time
  // Selected layer may be artboard or layer
  let selectedLayer = context.document.selectedLayers().firstLayer();

  if (selectedLayer) {
    // start with empty array to set/replace on metadata key
    var newMeta = [];

    // get current metadata array
    var currentMeta = command.valueForKey_onLayer_forPluginIdentifier(
      'metadata',
      selectedLayer,
      'tmnaMM'
    );

    // If currentMeta, add to newMeta array
    if (currentMeta) {
      currentMeta.forEach((m) => { newMeta.push(m) })
    }

    // return on cancel
    const enteredMeta = metaObject(selectedLayer.name(), '')
    if (enteredMeta === false) {
      log('Cancelled')
      return
    }

    if (enteredMeta === null) {
      // clear all meta
      alert('Meta cleared', '');
      newMeta = []
    } else if (enteredMeta === 1) {
      alert('Meta', `${newMeta}`)
      return
    } else {
      // remove any existing meta of same type
      for (let i=newMeta.length-1; i>=0; i--) {
        if (newMeta[i].type == enteredMeta.type) {
          newMeta.splice(i, 1);
        }
      }
      // add object returned by metaObject method
      newMeta.push(enteredMeta);
    }

    // set/replace metadata key on tmnaMM key
    command.setValue_forKey_onLayer_forPluginIdentifier(
      newMeta,
      'metadata',
      selectedLayer,
      'tmnaMM'
    );
  } else {
    alert('No layer selected', 'Please select a layer and try again.');
    return;
  }

  log(selectedLayer.userInfo());
}
