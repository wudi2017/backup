@import 'common.js';

var onRun = function(context) {
  var cols = 'No, Branch, Part Type, Template Name, Parts Image, Summary, Remarks';

  var sketch = context.api();
  var doc = context.document;

  let apiDoc = new sketch.Document(doc, new sketch.Application(context));

  // ---- Automated Export Data
  let sketchDoc = sketch.selectedDocument;
  let rawDocName = removeFileExtension(sketchDoc.sketchObject.displayName());

  specFolder = `${NSHomeDirectory()}/rfq-specs/`;
  let filePath = `common-parts/${formatDate(new Date)}/`;

  var exportFolder = specFolder + filePath;

  var exportOpts = {
    'use-id-for-name': true,
    formats: 'png',
    overwriting: true,
    scales: '1',
    output: exportFolder + '_export'
  }

  // ---- Automated Export Data

  var pages = doc.pages();

  var populateCSV = function(collection) {
    for (i in collection) {
      let part = collection[i].symbol;
      let partId = String(new sketch.Artboard(part, doc).id);
      let partNumber = collection[i].partNumber;
      let partType = collection[i].partType;
      let partSummary = collection[i].summary;
      let partRemarks = collection[i].remarks;

      // Export part
      new sketch.Artboard(part, apiDoc).export(exportOpts);

      // Add part to CSV
      cols += `\n ${partNumber},${partNumber}-${i},${partType},${part.name()},${exportFolder}_export/${partId}.png,"${partSummary ? partSummary : ''}","${partRemarks ? partRemarks : ''}"`;
    }
  }

  // Fill partsArrays with empty arrays for each part type
  var partsArrays = [];
  UNDERSCORE_PARTS.forEach(p => partsArrays.push([]));

  for (var i = 0; i < pages.count(); i++) {
    var page = pages[i];
    var pageName = page.name();
    var symbols = page.artboards();


    if (pageName == 'Symbols') {
      for (var i = 0; i < symbols.count(); i++) {
        let symbol = symbols[i];
        let userInfo = symbol.userInfo();

        if (userInfo) {
          if (userInfo.tmnaMM && userInfo.tmnaMM.metadata) {
            let partTypeId;
            let partSummary;
            let partRemarks;

            userInfo.tmnaMM.metadata.forEach(data => {
              if (data.type == 'Parts Type') {
                partTypeId = Number(data.content.id);
                partType = String(data.content.part);
              }

              if (data.type == 'Summary') {
                partSummary = String(data.content);
              }

              if (data.type == 'Remarks') {
                partRemarks = String(data.content);
              }
            });

            let part = {
              symbol: symbol,
              partNumber: partTypeId,
              partType: partType,
              summary: partSummary,
              remarks: partRemarks
            }

            partsArrays[partTypeId].push(part);
          }
        }
      }

      // Build the CSV
      partsArrays.forEach(partArray => {
        populateCSV(partArray);
      });

      writeTextToFile(cols, exportFolder + 'common-parts.csv')
      doc.showMessage('Common Parts Spec Generated');

      return;
    }
  }


}
