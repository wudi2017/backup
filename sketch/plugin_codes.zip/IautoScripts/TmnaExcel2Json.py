# coding=utf-8
import copy
import json
import os
import sys
import logging
import xlrd

subCondition = {'A':'-'}
sameCondition = {'Parts ID':'','Screen ID':''}
condition = {'Formula':'-','Condition':subCondition, 'Same Condition':sameCondition}
jpMenuText = {'Japanese':'-','Fixed words':'-'}
usMenuText = {'U.S.English':'-','Fixed words':'-'}
ukMenuText = {'U.K.English':'-','Fixed words':'-'}
outsideInput = {'Display contents':''}
textImageInfo = {'Japanese':jpMenuText,'U.S.English':usMenuText,'U.K.English':ukMenuText}
operationResult = {'Screen Transion':'','Start Function':'','Setting Value Change':'','Other':''}
swInfo = {}
screenInfo = {'Screen ID':'','Basic Screen ID':'','Screen Name':'','Note':''}
partsDefine = {'Parts ID':'','Display image':'','Parts Type':'','Parts Name':''}
LogInitConfig = {"LogSize" :50,\
                "LogSizeUnit" :"mb",\
                "LogEnabled" : 1,\
                "LogLevelDefault":"error",\
                "LogInfo" :{\
                            "baselog" : "error",\
                            "importexport" : "error",\
                            "datacenter" : "error",\
                            "sketchparser" : "error",\
                            "hmi" : "error"}\
                }
logger = logging.getLogger("importexport")

def loggerConfig(workdir):
    LogConfig = LogInitConfig.copy()
    # 指定logger输出格式
    log_formater = "%(asctime)s [%(levelname)s] [importexport] : %(message)s"
    formatter = logging.Formatter(log_formater)

    log_path  = os.path.expanduser('~') + os.sep + 'sketchplugin_iauto'+os.sep+'log'+os.sep
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    log_file = log_path + "iautoplugin.log"
    #日志文件Size大于2MB（1024*1024*2）时删除
    log_size = LogConfig.get('LogSize')
    if log_size != None:
        log_size = int(log_size) * 1024 * 1024
    else:
        log_size = 2 * 1024 * 1024

    if os.path.exists(log_file):
        if os.path.getsize(log_file) > int(log_size):
            os.remove(log_file)
    # 文件日志
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(formatter) # 可以通过setFormatter指定输出格式
    logger.addHandler(file_handler)
    
    # 控制台日志
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.formatter = formatter # 也可以直接给formatter赋值
    # 为logger添加的日志处理器，可以自定义日志处理器让其输出到其他地方
    logger.addHandler(console_handler)
    log_info = LogConfig.get("LogInfo")
    log_level = None
    if log_info != None and 'importexport' in log_info:
        log_level = log_info.get('importexport')
    else:
        log_level = LogConfig.get('LogLevelDefault')
    
    if log_level == None:
        return
    log_level = log_level.lower()
    if log_level == 'info':
        # 指定日志的最低输出级别，默认为WARN级别
        logger.setLevel(logging.INFO)
    elif log_level == 'debug':
        logger.setLevel(logging.DEBUG)
    elif log_level == 'warn':
        logger.setLevel(logging.WARNING)
    elif log_level == 'error':
        logger.setLevel(logging.ERROR)
    else:
        logger.setLevel(logging.WARNING)
    return

def GetWorkBook(fileName):
    if(fileName != None):
        try:
            book = xlrd.open_workbook(fileName)
            return book
        except Exception as e:
            logger.warning(e.__str__())
            return None
    else:
        return None

def getCellStrByIndex(sheet, cellCow,cellRow):
    ret = sheet.cell_value(cellRow-1, cellCow-1)
    if isinstance(ret,float):
        return str(int(ret))
    return str(ret)
        
def GetPartsDefineRow(worksheet):
    tmpLineCount = 1
    strCell = getCellStrByIndex(worksheet,1,tmpLineCount)
    #找出Partes定义位置
    while strCell != 'Parts ID':
        tmpLineCount = tmpLineCount + 1
        strCell = getCellStrByIndex(worksheet,1,tmpLineCount)
    else:
        return (tmpLineCount + 4)#Parts Define部分的表题部分所占行数为4

def GetNextPartsRow(worksheet,curLineCount,MaxRowNum):
    nextPartsLineCount = curLineCount + 1
    value =  getCellStrByIndex(worksheet,1,nextPartsLineCount)
    #print(value+'A')
    while (value == '') and (nextPartsLineCount < MaxRowNum):
        #print(value)
        nextPartsLineCount = nextPartsLineCount + 1
        value = getCellStrByIndex(worksheet,1,nextPartsLineCount)
    else:
        if nextPartsLineCount == MaxRowNum:#最后一个Parts时的处理
            nextPartsLineCount = MaxRowNum + 1
        return nextPartsLineCount
#Display dic define

def GetDisplayCondition(worksheet,curLineCount,nextPartsLineCount, dispCondition):
    #Display Condition Start
    tmpStr = ''
    subDispCondition = subCondition
    tmpStr = getCellStrByIndex(worksheet,6,curLineCount)
    if tmpStr == '':    #共通Parts
        return False
    #strDispCondition = 'Display Condition: { \n'
    tmpStr = getCellStrByIndex(worksheet,5,curLineCount)
    if True:#tmpStr != '-': #判断Condition的公式部分是否有效，无效的话，就不用读取了
        tmpStr = ''
        dispCondition['Formula'] = getCellStrByIndex(worksheet,5,curLineCount)
        tmpLineCount = curLineCount
        #Condition
        subDispCondition = subCondition.copy()
        while tmpLineCount < nextPartsLineCount:
            tmpStr = getCellStrByIndex(worksheet,7,tmpLineCount)
            subDispCondition.update({getCellStrByIndex(worksheet,6,tmpLineCount):tmpStr})
            tmpLineCount = tmpLineCount + 1

        dispCondition['Condition'] = subDispCondition
    else:
        #公式无效时，删除字典中dispCondition的信息
        del dispCondition['Condition']
        del dispCondition['Formula']

    #Same Condition
    dispSameCondition = sameCondition.copy()
    dispSameCondition['Parts ID'] =  getCellStrByIndex(worksheet,8,curLineCount)
    dispSameCondition['Screen ID'] = getCellStrByIndex(worksheet,9,curLineCount)
    dispCondition['Same Condition'] = dispSameCondition

    #else
    dispCondition.update({'else':getCellStrByIndex(worksheet,10,curLineCount)})
    #DispCondition end
    return True

def GetTextImageInfo(worksheet,curLineCount,partsDefineRow, nextPartsLineCount,textImageInfo):
    #Text or Image information  Start
    columnPos = 11 # K列

    tmpJPMenuText = jpMenuText.copy()
    tmpJPMenuText['Japanese'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    tmp = jpMenuText['Japanese']
    columnPos +=1
    tmpJPMenuText['Fixed words'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos +=1

    tmpStr = getCellStrByIndex(worksheet,columnPos,partsDefineRow-1)
    hasVUICommand = tmpStr == 'VUI recognition word'
    #print(tmpStr)
    if hasVUICommand:
        tmpJPMenuText.update({'VUI recognition word':getCellStrByIndex(worksheet,columnPos, curLineCount)})
        columnPos +=1
    else:
        pass
    textImageInfo['Japanese'] = tmpJPMenuText

    #U.S English
    tmpUSMenuText = usMenuText.copy()
    tmpUSMenuText['U.S.English'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos +=1
    tmpUSMenuText['Fixed words'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos +=1

    tmpStr = getCellStrByIndex(worksheet,columnPos,partsDefineRow-1)
    hasVUICommand = tmpStr == 'VUI recognition word'

    if hasVUICommand:
        tmpUSMenuText.update({'VUI recognition word':getCellStrByIndex(worksheet,columnPos, curLineCount)})
        columnPos +=1
    else:
        pass
    textImageInfo['U.S.English'] = tmpUSMenuText;

    #U.K English
    tmpUKMenuText = ukMenuText.copy()
    tmpUKMenuText['U.K.English'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos +=1
    tmpUKMenuText['Fixed words'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos +=1

    tmpStr = getCellStrByIndex(worksheet,columnPos,partsDefineRow-1)
    hasVUICommand = tmpStr == 'VUI recognition word'
    #print(tmpStr)
    if hasVUICommand:
        tmpUKMenuText.update({'VUI recognition word':getCellStrByIndex(worksheet,columnPos, curLineCount)})
        columnPos +=1
    else:
        pass
    textImageInfo['U.K.English'] = tmpUKMenuText;
    
    #Fixed Image
    textImageInfo.update({'Fixed Image':getCellStrByIndex(worksheet,columnPos, curLineCount)})
    columnPos +=1

    #Delete condition in motion
    deleteCondition = condition.copy()
    tmpStr = getCellStrByIndex(worksheet, columnPos, curLineCount)
    columnPos += 1
    if True:#((tmpStr != '-') and (tmpStr != '')):  # 判断Condition部分是否有效，无效的话，就不用读取了
        deleteCondition['Formula'] = tmpStr;
        tmpLineCount = curLineCount
        # Condition
        subDeleteCondition = subCondition.copy()
        while tmpLineCount < nextPartsLineCount:
            tmpStr = getCellStrByIndex(worksheet, (columnPos + 1), tmpLineCount)
            subDeleteCondition.update({getCellStrByIndex(worksheet, columnPos, tmpLineCount): tmpStr})
            tmpLineCount = tmpLineCount + 1
        deleteCondition['Condition'] = subDeleteCondition
    else:
        # 公式无效时，删除字典中Condition的信息
        del deleteCondition['Condition']
        del deleteCondition['Formula']
    columnPos += 2

    # Same Condition
    deleteSameCondition = sameCondition.copy()
    deleteSameCondition['Parts ID'] = getCellStrByIndex(worksheet, columnPos, curLineCount)
    columnPos += 1
    deleteSameCondition['Screen ID'] = getCellStrByIndex(worksheet, columnPos, curLineCount)
    columnPos += 1
    deleteCondition['Same Condition'] = deleteSameCondition

    textImageInfo.update({'Delete condition in motion':deleteCondition})
    
    #Outside Input
    tmpOutsideInput = outsideInput.copy()
    tmpOutsideInput.update({'Display contents':getCellStrByIndex(worksheet,columnPos, curLineCount)})
    columnPos +=1
    tmpOutsideInput.update({'Format':getCellStrByIndex(worksheet,columnPos, curLineCount)})
    columnPos +=1
    tmpOutsideInput.update({'Range':getCellStrByIndex(worksheet,columnPos, curLineCount)})
    columnPos +=1
    textImageInfo.update({'Outside Input':tmpOutsideInput})
    
    textImageInfo.update({'Validation':getCellStrByIndex(worksheet,columnPos, curLineCount)})
    columnPos +=1
    
    #TextImageInfo end
    return columnPos
    
def isValidScreenSpeck(worksheet):
    if '<Delete>' in worksheet.name: #Sheet名中含<Delete>的Sheet为不需要的Sheet
        return False
    tmpLineCnt = 1
    while tmpLineCnt < 4:
        value = getCellStrByIndex(worksheet,1,tmpLineCnt)
        #print(value)
        if(value.lower().find('screen id') >= 0):#如果前4行，没有Screen ID的内容，这个Sheet不是Screen Spec
            return True
        else:
            tmpLineCnt +=1
    else:
        return False
    

def GetSWInfo(worksheet,curLineCount,columnPos,nextPartsLineCount,swInfo):
    tonedownInMotionCondition = condition.copy()
    tmpStr = getCellStrByIndex(worksheet, columnPos, curLineCount)
    columnPos += 1
    if True:#((tmpStr != '-') and (tmpStr != '')):  # 判断Condition部分是否有效，无效的话，就不用读取了
        tonedownInMotionCondition['Formula'] = tmpStr;
        tmpLineCount = curLineCount
        # Condition
        subTonedownCondition = subCondition.copy()
        while tmpLineCount < nextPartsLineCount:
            tmpStr = getCellStrByIndex(worksheet, (columnPos + 1), tmpLineCount)
            subTonedownCondition.update({getCellStrByIndex(worksheet, columnPos, tmpLineCount): tmpStr})
            tmpLineCount = tmpLineCount + 1

        tonedownInMotionCondition['Condition'] = subTonedownCondition
    else:
        # 公式无效时，删除字典中Condition的信息
        del tonedownInMotionCondition['Condition']
        del tonedownInMotionCondition['Formula']
    columnPos += 2

    # Same Condition
    tonedownInMotionSameCondition = sameCondition.copy()
    tonedownInMotionSameCondition['Parts ID'] = getCellStrByIndex(worksheet, columnPos, curLineCount)
    columnPos += 1
    tonedownInMotionSameCondition['Screen ID'] = getCellStrByIndex(worksheet, columnPos, curLineCount)
    columnPos += 1
    tonedownInMotionCondition['Same Condition'] = tonedownInMotionSameCondition

    swInfo['Tonedown condition in motion'] = tonedownInMotionCondition

    tonedownNotMotionCondition = condition.copy()
    tmpStr = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    if True:#((tmpStr != '-') and (tmpStr != '')): #判断Condition部分是否有效，无效的话，就不用读取了
        tonedownNotMotionCondition['Formula'] = tmpStr;
        tmpLineCount = curLineCount
        #Condition
        subTonedownCondition = subCondition.copy()
        while tmpLineCount < nextPartsLineCount:
            tmpStr = getCellStrByIndex(worksheet,(columnPos+1), tmpLineCount)
            subTonedownCondition.update({getCellStrByIndex(worksheet,columnPos, tmpLineCount):tmpStr})
            tmpLineCount = tmpLineCount + 1
        tonedownNotMotionCondition['Condition'] = subTonedownCondition
    else:
        # 公式无效时，删除字典中Condition的信息
        del tonedownNotMotionCondition['Condition']
        del tonedownNotMotionCondition['Formula']
    columnPos += 2
    
    #Same Condition
    tonedownNotMotionSameCondition = sameCondition.copy()
    tonedownNotMotionSameCondition['Parts ID'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    tonedownNotMotionSameCondition['Screen ID'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    tonedownNotMotionCondition['Same Condition'] = tonedownNotMotionSameCondition

    swInfo['Tonedown condition except in motion'] = tonedownNotMotionCondition

    #Selected condition
    selectedCondition = condition.copy()
    tmpStr = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    if True:#((tmpStr != '-') and  (tmpStr != '')): #判断Condition部分是否有效，无效的话，就不用读取了
        #tmpStr = ''
        selectedCondition['Formula'] = tmpStr;
        tmpLineCount = curLineCount
        #Condition
        subSelectedCondition = subCondition.copy()
        while tmpLineCount < nextPartsLineCount:
            tmpStr = getCellStrByIndex(worksheet,(columnPos+1), tmpLineCount)
            subSelectedCondition.update({getCellStrByIndex(worksheet,columnPos, tmpLineCount):tmpStr})
            tmpLineCount = tmpLineCount + 1
        selectedCondition['Condition'] = subSelectedCondition
    else:
        # 公式无效时，删除字典中Condition的信息
        del selectedCondition['Condition']
        del selectedCondition['Formula']
    columnPos += 2
    
    #Same Condition
    selectedSameCondition = sameCondition.copy()
    selectedSameCondition['Parts ID'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    selectedSameCondition['Screen ID'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    
    selectedCondition['Same Condition'] = selectedSameCondition
    swInfo['Selected condition'] = selectedCondition
    
    #SW operation Pattern
    swInfo['SW operation Pattern'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    
    #Operation result
    tmpOperationResult = operationResult.copy()
    tmpOperationResult['Screen Transion'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    tmpOperationResult['Start Function'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    tmpOperationResult['Setting Value Change'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    tmpOperationResult['Other'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1
    swInfo['Operation result'] = tmpOperationResult;
    
    #SW operation Pattern
    
    swInfo['BEEP'] = getCellStrByIndex(worksheet,columnPos, curLineCount)
    columnPos += 1

    return columnPos


def GetOneScreenInfo(worksheet):
    sheetName = worksheet.name
    ret_onesheet_dict = {}

    #global json
    logger.info('The sheet of [' + sheetName+'] Start!')
    lineCount = 1
    #取得PartsList的位置
    partsDefineRow = GetPartsDefineRow(worksheet)
    lineCount = partsDefineRow
    #lineCount = lineCount + 4
    maxLineCount = worksheet.nrows
    if partsDefineRow > maxLineCount:
        logger.warning('The sheet of [' + sheetName + '] is invalid Screen Specification!')
        return
    tmpScreenInfo = screenInfo.copy()
    tmpScreenInfo.clear()
    tmpScreenInfo['Screen ID'] =  getCellStrByIndex(worksheet,3,2)
    tmpScreenInfo['Basic Screen ID'] = getCellStrByIndex(worksheet,3,3)
    tmpScreenInfo['Screen Name'] = getCellStrByIndex(worksheet,3,4)
    if 'Note:' == getCellStrByIndex(worksheet,1,5) :
        tmpScreenInfo['Note'] = getCellStrByIndex(worksheet,2,5)
    else:
        tmpScreenInfo['VUI prompt'] =  getCellStrByIndex(worksheet,3,5)
        tmpScreenInfo['Note'] =  getCellStrByIndex(worksheet,2,6)

    ret_onesheet_dict["ScreenInfo"] = {}
    ret_onesheet_dict["ScreenInfo"]["excelInfo"] = tmpScreenInfo
    ret_onesheet_dict["ScreenInfo"]["sketchInfo"] = {
        "uuid" : tmpScreenInfo['Basic Screen ID'],
        "Rect" : {},
        "imgPath":""
    }

    ret_onesheet_dict["DestGradeInfo"] = GetDestGradeInfo(worksheet)
    ret_onesheet_dict["PartsList"] = {}

    while(lineCount <= maxLineCount):
        #找出下一个Partes定义位置
        nextPartsRow = GetNextPartsRow(worksheet,lineCount,maxLineCount)
    
        #取得各个Parts的信息
        tmpPartsDefine = partsDefine.copy()
        strPartsID = getCellStrByIndex(worksheet,1,lineCount)
        tmpPartsDefine['Parts ID'] = strPartsID
        # tmpPartsDefine['Parts UUID'] = getCellStrByIndex(worksheet, 48, lineCount)
        tmpPartsDefine['Display image'] = getCellStrByIndex(worksheet,2,lineCount)
        strPartType = getCellStrByIndex(worksheet,3,lineCount)
        tmpPartsDefine['Parts Type'] = strPartType
        tmpPartsDefine['Parts Name'] = getCellStrByIndex(worksheet, 4,lineCount)
        tmpPartsDefine['sketchInfo'] = {
            "uuid" : getCellStrByIndex(worksheet, 48, lineCount),
            "Rect" : {},
            "imgPath":""
        }

        tmpDispCondition = condition.copy()
        if False == GetDisplayCondition(worksheet,lineCount,nextPartsRow,tmpDispCondition):
            #当前Parts为无效Parts时，调到下一个Parts所在的行
            pass
        else:
            tmpPartsDefine.update({'Display Condition':tmpDispCondition})
            tmpTextImageInfo = textImageInfo.copy()
            columnPos = GetTextImageInfo(worksheet,lineCount,partsDefineRow,nextPartsRow,tmpTextImageInfo)
            tmpPartsDefine.update({'Text or Image information':tmpTextImageInfo})
            if True:#ord(strPartsID[0]) >= ord('A') and ord(strPartsID[0]) <= ord('Z'):
                tmpSWInfo = swInfo.copy()
                GetSWInfo(worksheet,lineCount,columnPos,nextPartsRow,tmpSWInfo)
                tmpPartsDefine.update({'SW Information':tmpSWInfo})
            else:
                pass
        lineCount = nextPartsRow

        if strPartsID == '':
            pass
        elif strPartsID.find("_") > 0:
            for i_k, i_v in ret_onesheet_dict["PartsList"].items():
                if i_v['Parts ID'].strip() == strPartsID.split("_")[0].strip():
                    i_v['subsymbols'][tmpPartsDefine['sketchInfo']['uuid']]=tmpPartsDefine
                    break
        else:
            tmpPartsDefine['subsymbols'] = {}
            
            ret_onesheet_dict["PartsList"].update({tmpPartsDefine['sketchInfo']['uuid']:tmpPartsDefine})


    return ret_onesheet_dict


def GetDestGradeInfo(worksheet):
    retDictInfo = {}

    region_list = ["Japan","Europe/Russia","China","Oceania","South Africa","HongKong / Macao","South East Asia",
                    "India","Taiwan","Middle East","South and Central (Brazil & Argentina)","South and Central","Korea"]
    ais_list = ["Available","Unavailable"]
    machine_type_dict = {
        "Toyota":["Entry DA","T1","T2","T-EMVN"],
        "Lexus":["L1","L1.5","L2"]
    }

    line_no = 10;

    for i_region in region_list:
        retDictInfo[i_region] = {}
        retDictInfo[i_region]["Toyota"] = {}
        retDictInfo[i_region]["Lexus"] = {}
        for i_ais in ais_list:
            col_no = 11
            retDictInfo[i_region]["Toyota"][i_ais] = {}
            for i_toyota_machinetype in machine_type_dict["Toyota"]:
                retDictInfo[i_region]["Toyota"][i_ais][i_toyota_machinetype] = getCellStrByIndex(worksheet, col_no, line_no)
                col_no = col_no+1

            retDictInfo[i_region]["Lexus"][i_ais] = {}
            for i_lexus_machinetype in machine_type_dict["Lexus"]:
                retDictInfo[i_region]["Lexus"][i_ais][i_lexus_machinetype] = getCellStrByIndex(worksheet, col_no, line_no)
                col_no = col_no+1
            line_no = line_no+1

    return retDictInfo
    
#打开excel
def GetExcelInfo(xls_fileName):
    workbook = GetWorkBook(xls_fileName)
    hasValidSheet = False
    if workbook == None:
        logger.warning(xls_fileName + 'can not be opened!')
        return

    retfilejson = {}
    try:
        for sheet in workbook.sheets():
            if (isValidScreenSpeck(sheet)):  # 排除掉非Screen Spec的Excel文档
                hasValidSheet = True
                ret_sheet_dict = GetOneScreenInfo(sheet)
                if "ScreenInfo" in ret_sheet_dict:
                    retfilejson[ret_sheet_dict["ScreenInfo"]["sketchInfo"]["uuid"]] = ret_sheet_dict
            else:
                logger.warning('The sheet of ['+ sheet.name + '] is not Screen Specification!')
        if not hasValidSheet:
            logger.error('The file you choose is not screen specification, Please check it!')

    except Exception as e:
        logger.warning(e.__str__())

    return retfilejson

#打开excel
def GetOneExcelInfo(fileName, result_json_file):
    retfilejson_onefile = GetExcelInfo(fileName)

    with open(result_json_file, "w") as output_json_file:
        json.dump(retfilejson_onefile, output_json_file, indent=2)


def Excel2JsonInDir(dirPath, result_json_file):
    retfilejson_dirs = {}

    for mainDirPath,subDirnPath,fileNames in os.walk(dirPath):
        for fileName in fileNames:
            if '$' not in fileName:#过滤掉因打开Excel生成的临时文件
                if isExcelFile(fileName):#过滤掉非Excel的文件
                    fileName = os.path.join(mainDirPath, fileName)
                    onefilejson = GetExcelInfo(fileName)
                    if onefilejson:
                        retfilejson_dirs.update(onefilejson)

    with open(result_json_file, "w") as output_json_file:
        json.dump(retfilejson_dirs, output_json_file, indent=2)

    
def isExcelFile(fileName):
    fileExt = os.path.splitext(fileName)[1]
    fileExt = fileExt.lower()
    if fileExt == '.xlsx' or fileExt == '.xls':
        return True
    else:
        return False

if __name__ == "__main__":
    loggerConfig("./")
    # Excel2JsonInDir("/Users/huangyp/workspace/temp/01_radio/", "/Users/huangyp/workspace/temp/test.json")

    try:
        import xlrd
    except Exception as e:
        logger.error("xlrd is not installed, please install it!")
        exit(1)

    if not os.path.exists(sys.argv[1]):
        logger.error('The file or directory you choose does not exist!')

    if isExcelFile(sys.argv[1]):
        GetOneExcelInfo(sys.argv[1], sys.argv[2])
    elif os.path.isdir(sys.argv[1]):
        Excel2JsonInDir(sys.argv[1], sys.argv[2])
    else:
        logger.error('The path you choose is not an Excel file or a directory, Please check it!')
    