# coding=utf-8
import xlrd
import json
import sys

if __name__ == "__main__":
    # config_json_filename = "/Users/huangyp/workspace/sketchplugin_iauto_tmna/tmna-multimedia-iauto.sketchplugin/Contents/Sketch/IautoConfig/symbolexpand.json"
    # xls_config_file = "/Users/huangyp/workspace/temp/symbollist.xlsx"
    config_json_filename = sys.argv[1]
    xls_config_file = sys.argv[2]

    config_json = {}
    with open(config_json_filename, "r") as config_json_file:
        config_json = json.load(config_json_file)

    config_workbook = xlrd.open_workbook(xls_config_file)
    config_sheet = config_workbook.sheet_by_name("SymbolList")

    if not config_sheet:
        exit(0)

    max_row_count = config_sheet.nrows

    for i_row in range(1, max_row_count):
        page_uuid = config_sheet.cell_value(i_row,0)
        artboard_uuid = config_sheet.cell_value(i_row,1)
        symbol_uuid = config_sheet.cell_value(i_row,2)
        page_name = config_sheet.cell_value(i_row,3)
        artboard_name = config_sheet.cell_value(i_row,4)
        symbol_name = config_sheet.cell_value(i_row,5)
        is_need_expand = config_sheet.cell_value(i_row,7)
        expand_level_str = config_sheet.cell_value(i_row,8)

        page_dict = {
            "name":"",
            "layers":{}
        }
        if page_uuid in config_json:
            page_dict = config_json[page_uuid]

        page_dict["name"] = page_name

        artboard_dict = {
            "name":"",
            "layers":{}
        }
        if artboard_uuid in page_dict["layers"]:
            artboard_dict = page_dict["layers"][artboard_uuid]
        artboard_dict["name"] = artboard_name

        symbol_dict = {
            "name":symbol_name,
            "isExpaned":0,
            "expandLevel":0
        }
        if is_need_expand and is_need_expand=="Y":
            symbol_dict["isExpaned"] = 1

        try:
            expand_level_int = int(expand_level_str)
        except:
            expand_level_int = 0
        if expand_level_int > 0:
            symbol_dict["expandLevel"] = expand_level_int

        artboard_dict["layers"][symbol_uuid] = symbol_dict
        page_dict["layers"][artboard_uuid] = artboard_dict
        config_json[page_uuid] = page_dict


    with open(config_json_filename, "w") as config_json_file:
        json.dump(config_json,config_json_file, indent=2)
