// Handle alerts
function alert(title, message){
  var app = [NSApplication sharedApplication];
  [app displayDialog:message withTitle:title];
}

let letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

function isPageIgnored(page) {
  var name = page.name();

  return name == 'Symbols' ||
    name == 'symbols' ||
    name == 'Config' ||
    name == 'Sandbox' ||
    name == '_sandbox' ||
    name == '_archive' ||
    name == '_reference';
}

function isLayerIgnored(layer, type) {
  var name = layer.name().toLowerCase();

  var redlineLayers = [
    'ignore redline',
    'ignore redlines',
    'ingore redline',
    'ingore redlines',
    'guide'
  ];

  var genericLayers = [
    'spec/tap area',
    'shapes/rectangle',
    'color'
  ]

  if (type == 'redline') {
    return redlineLayers.indexOf(name) > -1 ||
            genericLayers.indexOf(name) > -1 ||
            name.indexOf('~Shapes/') > -1 ||
            name.indexOf('�/Fill/') > -1;
  }

  if (type == 'transition') {
    return redlineLayers.indexOf(name) > -1;
  }

  if (type == 'metadatapanel') {
    return redlineLayers.indexOf(name) > -1;
  }

  return false;
}

// function isLayerIgnored(layer) {
//   var name = layer.name();
//   if(name == "Ignore Redline" || name == 'guide' || name == "Shapes/Rectangle" || name == "color" || name == "Spec/Tap Area"
//     || name =="Ignore redlines" || name =="Ignore Redlines" || name == "Ignore redline") {
//     return true;
//   }
//   if(name.indexOf("~Shapes/") != -1){
//     return true;
//   }
//   if(name.indexOf("🎨/Fill/") != -1){
//     return true;
//   }
//   return false;
// }

function isArtboardIgnored(artboard) {
    if (isConditionArtboard(artboard) == true) {
        return true;
    }
    var nowartboardName = artboard.name()+"";
    if (nowartboardName.toLowerCase().search("\\[ref.+")>=0) {
        return true;
    }
    return false;
}

// iauto
function isLayerIgnored_iauto(layer) {
  var name = layer.name();

  return name == 'Ignore Redline' ||
    name == 'Shapes/Rectangle' ||
    name == '~Shapes/BG~' ||
    name == '~Shapes/BG LEFT~' ||
    name == '~Shapes/BG RIGHT~' ||
    name == 'guide';
}

var writeTextToFile = function(text, fileName) {
  // log("writeTextToFile: " + text)
  var t = [NSString stringWithFormat:@"%@", text],
  f = [NSString stringWithFormat:@"%@", fileName];
  return [t writeToFile:f atomically:true encoding:NSUTF8StringEncoding error:nil];
}

function formatDate(date) {
  const day = date.getDate();
  const month = date.getMonth() + 1;
  const year = date.getFullYear();

  const paddedDay = ('0' + day).slice(-2);
  const paddedMonth = ('0' + month).slice(-2);

  return `${year}-${paddedMonth}-${paddedDay}`;
}

function removeFileExtension(layerName){
	if([layerName containsString:@"."]){
		var nameArray = [layerName componentsSeparatedByString:@"."];
		var name = nameArray[0];
		return name;
	}else{
		return layerName;
	}
}


function fileSaver() {
  var openPanel = [NSOpenPanel openPanel]

  [openPanel setTitle: 'Choose a location…']
  [openPanel setMessage: 'Select the export location…'];
  [openPanel setPrompt: 'Export'];

  [openPanel setCanCreateDirectories: true]
  [openPanel setCanChooseFiles: false]
  [openPanel setCanChooseDirectories: true]
  [openPanel setAllowsMultipleSelection: false]
  [openPanel setShowsHiddenFiles: false]
  [openPanel setExtensionHidden: false]

  var openPanelButtonPressed = [openPanel runModal]
  if (openPanelButtonPressed == NSFileHandlingPanelOKButton) {
      var filePath = String(openPanel.URL().absoluteString())
      if (0 === filePath.indexOf('file://')) {
        filePath = filePath.substring(7);
      }
      return filePath
  }
}

 // this function lifted from https://github.com/zeroheight/library-symbol-replacer/blob/master/library-symbol-replacer.sketchplugin/Contents/Sketch/script.js#L116
 var getAllSymbolsInDocument = function(document) {
  var predicate = NSPredicate.predicateWithFormat("className == %@", "MSSymbolInstance");
  var filteredArray = NSArray.array()
  var loopPages = document.pages().objectEnumerator()
  var page = null;
  var scope = null;

  while (page = loopPages.nextObject()) {
    scope = page.children();
    filteredArray = filteredArray.arrayByAddingObjectsFromArray(
      scope.filteredArrayUsingPredicate(predicate))
  }

  return filteredArray;
}


// Exporting Layers

const DEFAULT_EXPORT_OPTIONS = {
  compact: false,
  'include-namespaces': false,
  compression: 1.0,
  'group-contents-only': false,
  overwriting: false,
  progressive: false,
  'save-for-web': false,
  'use-id-for-name': false,
  trimmed: false,
  output: '~/Documents/Sketch Exports',
}

function exportLayer(object, options) {
  let merged = {}
  for (prop in DEFAULT_EXPORT_OPTIONS) {
    merged[prop] = DEFAULT_EXPORT_OPTIONS[prop]
  }
  for (prop in options) {
    merged[prop] = options[prop]
  }
  const exporter = MSSelfContainedHighLevelExporter.alloc().initWithOptions(
    merged
  )

  function exportNativeLayers(layers) {
    exporter.exportLayers(layers)
  }

  exportNativeLayers([object])
}

function delayRun(seconds, func) {
  coscript.setShouldKeepAround(true); // Setting session as a long running.

  // First argument is a delay in seconds.
  coscript.scheduleWithInterval_jsFunction(seconds, function() {
      func()

      // TODO:
      // Figure out a better solution for this... don't want to leak scripts.
      // For now, it's the responsibility of any script that uses this to use
      // the commented out line below when it's finished running code to avoid
      // leaking scripts. We can't just call it automatically here, or it will
      // break functionality such as setCOSJSTargetFunction.

      // coscript.setShouldKeepAround(false); // Tearing down the session.
  });
}

// METADATA PART TYPES
let PART_TYPES = [
  'Adjuster',
  'Balloon',
  'Banner',
  'Breadcrumbs',
  'Button',
  'Card - Apps',
  'Card - ETC/DSRC',
  'Card - Media',
  'Card - Navigation',
  'Card - Phone',
  'Card - Record service',
  'Card - User Profile',
  'Card - VR',
  'Check box',
  'Controls',
  'Dial pad',
  'DTV channnel pad',
  'Global Menu',
  'Graph',
  'Icon',
  'Image',
  'Index jump list',
  'Keyboard',
  'Label',
  'List',
  'Mini Player',
  'Misc',
  'Orb',
  'Overlays',
  'Progress Bar',
  'Status Bar',
  'Switch',
  'Video',
  'Video Controls',
  'Select Part Type'
];

let UNDERSCORE_PARTS = PART_TYPES.map((item) => item.toLowerCase().replace(/ /g, '_'));

function strToJS(str) {
  let s = str || '';
  if (s.class() == 'NSNull') { s = ''}
  return String(s);
}

function getMeta(metaType, userInfo) {
  if (userInfo) {
    if (userInfo.tmnaMM && userInfo.tmnaMM.metadata) {
      let metaObject = userInfo.tmnaMM.metadata.find((data) => data.type == metaType);

      return metaObject.content;
    }
  }
}

function getChildsMetadata(rootInfo, symbolId) {
  if (rootInfo) {
    if (rootInfo.tmnaMM && rootInfo.tmnaMM.metadata) {
      var children = filter(rootInfo.tmnaMM.metadata, (info) => info.type == 'child');

      return children.find((child) => child.content.id == symbolId);
    }
  }

  return null;
}

function getScreenSpecCondition(rootInfo, symbolId, conditionType) {
  if (rootInfo) {
    if (rootInfo.tmnaMM && rootInfo.tmnaMM.screenSpecConditions) {
      var key = Object.keys(rootInfo.tmnaMM.screenSpecConditions).find((data) => data == `${conditionType}__${symbolId}`);
      return rootInfo.tmnaMM.screenSpecConditions[key];
    }
  }
}

function getNestedMetaFromArray(metaType, arr) {
  let val = arr.find((data) => data.content.type == metaType);

  return val ? val.content.value : '-';
}

function buildConditionalJSON(rootInfo, symbolId, type, obj) {
  var data = getScreenSpecCondition(rootInfo, symbolId, type);

  if (data) {
    var conditionArr = map(data.conditions, (condition, i) => {
      if (condition.class() == 'NSNull') { return };

      return {
        id: letters[i],
        condition: String(condition)
      }
    });

    if (conditionArr.length > 0) {
      let conditionObj = {
        partId: symbolId,
        formula: String(data.formula),
        conditions: conditionArr,
        sameCondition: {
          partsId: String(data.sameCondition.partsID),
          screenId: String(data.sameCondition.screenID),
        }
      }

      if (type == 'displayCondition') {
        conditionObj.else = strToJS(data.else)
      }

      obj.push(conditionObj);
    }
  }
}

function getPartsType(userInfo) {
  if (userInfo) {
    if (userInfo.tmnaMM && userInfo.tmnaMM.metadata) {
      let partType = userInfo.tmnaMM.metadata.find((data) => data.type == 'Parts Type');

      return partType.content.part;
    }
  }
}

function getSummary(userInfo) {
  if (userInfo) {
    if (userInfo.tmnaMM && userInfo.tmnaMM.metadata) {
      let summary = userInfo.tmnaMM.metadata.find((data) => data.type == 'Summary');

      if (summary) {
        return summary.content;
      }
    }
  }
}


// lodash filter
function filter(collection, callback) {
  var result = [];

  var index = -1,
      length = collection.length;

  while (++index < length) {
    var value = collection[index];
    if (callback(value, index, collection)) {
      result.push(value);
    }
  }

  return result;
}

function map(collection, callback) {
  var result = [];

  var index = -1,
      length = collection.length;

  while (++index < length) {
    var value = collection[index];
    result.push(callback(value, index, collection));
  }

  return result;
}
