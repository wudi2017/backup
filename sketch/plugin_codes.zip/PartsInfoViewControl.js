@import "common.js"

function PVLOG(logstr)
{
    TLOG(logstr,"partsinfoview");
}

function loadPartsInfoViewData(screenID, partsID, context)
{
    PVLOG("initPartsInfoViewControl");

    // save partsInScreenID
    if (screenID) {
        PVLOG("    setMemProperty SelectPartsInfo-screenID:" + screenID);
        setMemProperty("SelectPartsInfo-screenID", screenID);
    };
    
    var partsView = SIAUTOMainView.instance().getPartsInfoView();
    SIAUTOMainView.instance().showParts();

    // add delegate for parts
    var PartsDelegate = SInherit("PartsDelegate", SPartsInfoViewDelegate, {
        "setContext:":function(context) { 
            SVLOG("SInherit::setContext:" + context);
            this.context = context
        },
        "onSaveButtonClick":function(){ 
            PVLOG("PartsDelegate::onSaveButtonClick");

            var view = pluginMainView.shared();
            var partsView = view.getPartsView();
            var screenInfoView = view.getScreenInfoView();
            var modelData = partsView.getModelData();

            savePartsInfo(modelData);


            var partsID = modelData["PartsID"]+"";
            var activatePartsInfoView_screenID = getMemProperty("activatePartsInfoView_screenID")+"";
            var activatePartsInfoView_partsID = getMemProperty("activatePartsInfoView_partsID")+"";
            PVLOG("    partsID:" + partsID);
            PVLOG("    activatePartsInfoView_screenID:" + activatePartsInfoView_screenID);
            PVLOG("    activatePartsInfoView_partsID:" + activatePartsInfoView_partsID);

            // save slice info
            if(this.context) {
                PVLOG("PartsDelegate::setContext:" + this.context);
                //ready to export slice info to db
                PVLOG("PartsDelegate::screenid:" + activatePartsInfoView_screenID);
                var inScreenID = activatePartsInfoView_screenID;
                if(inScreenID) {

                    var bindartboardID = getArtboardIDByScreenID(inScreenID)
                    
                    for (var i = 0; i < bindartboardID.length; i++ ) {
                        var obj = new PartTreeSyncControl(bindartboardID[i],this.context)
                        obj.setScreenId(inScreenID, false);
                        var sliceinfo = obj.syncToDB(bindartboardID[i],this.context)
                        if(sliceinfo != -1) {
                            sliceinfo.screenid = inScreenID
                            updatePartsSketchInfo(sliceinfo)
                        }
                    }
                    this.context.document.showMessage("screen "+inScreenID+" save success");
                }
            } else {
                PVLOG("PartsDelegate save ::Context: is not set");
            }

            // if parts ID changed, rename it
            if (partsID != activatePartsInfoView_partsID) {
                PVLOG("    callIF: renamePart");
                renamePart(activatePartsInfoView_screenID, activatePartsInfoView_partsID , partsID);
                update4ChangePartName(activatePartsInfoView_screenID, activatePartsInfoView_partsID , partsID);
            };

            PVLOG("PartsDelegate::onSaveButtonClick OVER");
        }
    });

    partsView.clearModelData();

    var FindPartsObj = nil;

    if (FindPartsObj) {

        var sPartsID = ""
        var sPartsType = ""
        var sPartsName = ""

        // conds
        var sDisplayConA =""
        var sDisplayConB =""
        var sDisplayConC =""
        var sDisplayConFormula =""
        var sDisplayConSamePartsID =""
        var sDisplayConSameScreenID =""
        var sDisplayConElse =""

        var sTextOrImageDeleteInMotionConA =""
        var sTextOrImageDeleteInMotionConB =""
        var sTextOrImageDeleteInMotionConC =""
        var sTextOrImageDeleteInMotionConFormula =""
        var sTextOrImageDeleteInMotionConSamePartsID =""
        var sTextOrImageDeleteInMotionConSameScreenID =""
        var sTextOrImageDeleteInMotionConElse =""

        var sSWToneDownMotionConA =""
        var sSWToneDownMotionConB =""
        var sSWToneDownMotionConC =""
        var sSWToneDownMotionConFormula =""
        var sSWToneDownMotionConSamePartsID =""
        var sSWToneDownMotionConSameScreenID =""
        var sSWToneDownMotionConElse =""

        var sSWToneDownExceptInMotionConA =""
        var sSWToneDownExceptInMotionConB =""
        var sSWToneDownExceptInMotionConC =""
        var sSWToneDownExceptInMotionConFormula =""
        var sSWToneDownExceptInMotionConSamePartsID =""
        var sSWToneDownExceptInMotionConSameScreenID =""
        var sSWToneDownExceptInMotionConElse =""

        var sSWSelectConA =""
        var sSWSelectConB =""
        var sSWSelectConC =""
        var sSWSelectConFormula =""
        var sSWSelectConSamePartsID =""
        var sSWSelectConSameScreenID =""
        var sSWSelectConElse =""

        // words
        var sJPWords = ""
        var sJPFixedWords = ""
        var sJPVRWords = ""
        var sUSWords = ""
        var sUSFixedWords = ""
        var sUSVRWords = ""
        var sUKWords = ""
        var sUKFixedWords = ""
        var sUKVRWords = ""

        // sw
        var sDisplayContent = ""
        var sFormat = ""
        var sRange = ""
        var sValidation = ""

        var sSWOpePattern = ""
        var sScreenTransition = ""
        var sStartFuntion = ""
        var sSettingValueChange = ""
        var sOther = ""

        var sBeep = ""

        if(FindPartsObj.hasOwnProperty("Parts ID"))
        {
            sPartsID = FindPartsObj["Parts ID"]
        }
        if(FindPartsObj.hasOwnProperty("Parts Type"))
        {
            sPartsType = FindPartsObj["Parts Type"]
        }
        if(FindPartsObj.hasOwnProperty("Parts Name"))
        {
            sPartsName = FindPartsObj["Parts Name"]
        }
        if(FindPartsObj.hasOwnProperty("Parts Name"))
        {
            sPartsName = FindPartsObj["Parts Name"]
        }
        // conds
        if(FindPartsObj.hasOwnProperty("Display Condition"))
        {
            var cDisplayCond = FindPartsObj["Display Condition"];
            if(cDisplayCond.hasOwnProperty("Condition"))
            {
                var cCond = cDisplayCond["Condition"];
                if(cCond.hasOwnProperty("A"))
                {
                    sDisplayConA  = cCond["A"];
                }
                if(cCond.hasOwnProperty("B"))
                {
                    sDisplayConB  = cCond["B"];
                }
                if(cCond.hasOwnProperty("C"))
                {
                    sDisplayConC  = cCond["C"];
                }
            }
            if(cDisplayCond.hasOwnProperty("Formula"))
            {
                sDisplayConFormula = cDisplayCond["Formula"];
            }
            if(cDisplayCond.hasOwnProperty("Same Condition"))
            {
                var cSameCond = cDisplayCond["Same Condition"];
                if(cSameCond.hasOwnProperty("Parts ID"))
                {
                    sDisplayConSamePartsID  = cSameCond["Parts ID"];
                }
                if(cSameCond.hasOwnProperty("Screen ID"))
                {
                    sDisplayConSameScreenID  = cSameCond["Screen ID"];
                }
            }
            if(cDisplayCond.hasOwnProperty("else"))
            {
                sDisplayConElse = cDisplayCond["else"];
            }
            
        }
        if(FindPartsObj.hasOwnProperty("Text or Image information"))
        {
            var cTIIObj = FindPartsObj["Text or Image information"]
            // cond 
            if(cTIIObj.hasOwnProperty("Delete condition in motion"))
            {
                var cDeleteCond = cTIIObj["Delete condition in motion"];
                if(cDeleteCond.hasOwnProperty("Condition"))
                {
                    var cCond = cDeleteCond["Condition"];
                    if(cCond.hasOwnProperty("A"))
                    {
                        sTextOrImageDeleteInMotionConA  = cCond["A"];
                    }
                    if(cCond.hasOwnProperty("B"))
                    {
                        sTextOrImageDeleteInMotionConB  = cCond["B"];
                    }
                    if(cCond.hasOwnProperty("C"))
                    {
                        sTextOrImageDeleteInMotionConC  = cCond["C"];
                    }
                }
                if(cDeleteCond.hasOwnProperty("Formula"))
                {
                    sTextOrImageDeleteInMotionConFormula = cDeleteCond["Formula"];
                }
                if(cDeleteCond.hasOwnProperty("Same Condition"))
                {
                    var cSameCond = cDeleteCond["Same Condition"];
                    if(cSameCond.hasOwnProperty("Parts ID"))
                    {
                        sTextOrImageDeleteInMotionConSamePartsID  = cSameCond["Parts ID"];
                    }
                    if(cSameCond.hasOwnProperty("Screen ID"))
                    {
                        sTextOrImageDeleteInMotionConSameScreenID  = cSameCond["Screen ID"];
                    }
                }
                if(cDeleteCond.hasOwnProperty("else"))
                {
                    sTextOrImageDeleteInMotionConElse = cDeleteCond["else"];
                }
            }

            if(cTIIObj.hasOwnProperty("Japanese"))
            {
                var cJP = cTIIObj["Japanese"]
                if(cJP.hasOwnProperty("Japanese"))
                {
                    sJPWords = cJP["Japanese"]
                }
                if(cJP.hasOwnProperty("Fixed words"))
                {
                    sJPFixedWords = cJP["Fixed words"]
                }
                if(cJP.hasOwnProperty("VUI recognition word"))
                {
                    sJPVRWords = cJP["VUI recognition word"]
                }
            }
            if(cTIIObj.hasOwnProperty("U.S.English"))
            {
                var cUS = cTIIObj["U.S.English"]
                if(cUS.hasOwnProperty("U.S.English"))
                {
                    sUSWords = cUS["U.S.English"]
                }
                if(cUS.hasOwnProperty("Fixed words"))
                {
                    sUSFixedWords = cUS["Fixed words"]
                }
                if(cUS.hasOwnProperty("VUI recognition word"))
                {
                    sUSVRWords = cUS["VUI recognition word"]
                }
            }
            if(cTIIObj.hasOwnProperty("U.K.English"))
            {
                var cUK = cTIIObj["U.K.English"]
                if(cUK.hasOwnProperty("U.K.English"))
                {
                    sUKWords = cUK["U.K.English"]
                }
                if(cUK.hasOwnProperty("Fixed words"))
                {
                    sUKFixedWords = cUK["Fixed words"]
                }
                if(cUK.hasOwnProperty("VUI recognition word"))
                {
                    sUKVRWords = cUK["VUI recognition word"]
                }
            }
            if(cTIIObj.hasOwnProperty("Outside Input"))
            {
                var cOI = cTIIObj["Outside Input"]
                if(cOI.hasOwnProperty("Display contents"))
                {
                    sDisplayContent = cOI["Display contents"]
                }
                if(cOI.hasOwnProperty("Format"))
                {
                    sFormat = cOI["Format"]
                }
                if(cOI.hasOwnProperty("Range"))
                {
                    sRange = cOI["Range"]
                }
            }
            if(cTIIObj.hasOwnProperty("Validation"))
            {
                sValidation = cTIIObj["Validation"]
            }
        }
        if(FindPartsObj.hasOwnProperty("SW Information"))
        {
            var cSWInfo = FindPartsObj["SW Information"];

            // Tonedown condition in motion
            if(cSWInfo.hasOwnProperty("Tonedown condition in motion"))
            {
                var cTonedown = cSWInfo["Tonedown condition in motion"];
                if(cTonedown.hasOwnProperty("Condition"))
                {
                    var cCond = cTonedown["Condition"];
                    if(cCond.hasOwnProperty("A"))
                    {
                        sSWToneDownMotionConA  = cCond["A"];
                    }
                    if(cCond.hasOwnProperty("B"))
                    {
                        sSWToneDownMotionConB  = cCond["B"];
                    }
                    if(cCond.hasOwnProperty("C"))
                    {
                        sSWToneDownMotionConC  = cCond["C"];
                    }
                }
                if(cTonedown.hasOwnProperty("Formula"))
                {
                    sSWToneDownMotionConFormula = cTonedown["Formula"];
                }
                if(cTonedown.hasOwnProperty("Same Condition"))
                {
                    var cSameCond = cTonedown["Same Condition"];
                    if(cSameCond.hasOwnProperty("Parts ID"))
                    {
                        sSWToneDownMotionConSamePartsID  = cSameCond["Parts ID"];
                    }
                    if(cSameCond.hasOwnProperty("Screen ID"))
                    {
                        sSWToneDownMotionConSameScreenID  = cSameCond["Screen ID"];
                    }
                }
                if(cTonedown.hasOwnProperty("else"))
                {
                    sSWToneDownMotionConElse = cTonedown["else"];
                }
            }
            // Tonedown condition except in motion
            if(cSWInfo.hasOwnProperty("Tonedown condition except in motion"))
            {
                var cTonedownExcept = cSWInfo["Tonedown condition except in motion"];
                if(cTonedownExcept.hasOwnProperty("Condition"))
                {
                    var cCond = cTonedownExcept["Condition"];
                    if(cCond.hasOwnProperty("A"))
                    {
                        sSWToneDownExceptInMotionConA  = cCond["A"];
                    }
                    if(cCond.hasOwnProperty("B"))
                    {
                        sSWToneDownExceptInMotionConB  = cCond["B"];
                    }
                    if(cCond.hasOwnProperty("C"))
                    {
                        sSWToneDownExceptInMotionConC  = cCond["C"];
                    }
                }
                if(cTonedownExcept.hasOwnProperty("Formula"))
                {
                    sSWToneDownExceptInMotionConFormula = cTonedownExcept["Formula"];
                }
                if(cTonedownExcept.hasOwnProperty("Same Condition"))
                {
                    var cSameCond = cTonedownExcept["Same Condition"];
                    if(cSameCond.hasOwnProperty("Parts ID"))
                    {
                        sSWToneDownExceptInMotionConSamePartsID  = cSameCond["Parts ID"];
                    }
                    if(cSameCond.hasOwnProperty("Screen ID"))
                    {
                        sSWToneDownExceptInMotionConSameScreenID  = cSameCond["Screen ID"];
                    }
                }
                if(cTonedownExcept.hasOwnProperty("else"))
                {
                    sSWToneDownExceptInMotionConElse = cTonedownExcept["else"];
                }
            }
            // Selected condition
            if(cSWInfo.hasOwnProperty("Selected condition"))
            {
                var cSelected = cSWInfo["Selected condition"];
                if(cSelected.hasOwnProperty("Condition"))
                {
                    var cCond = cSelected["Condition"];
                    if(cCond.hasOwnProperty("A"))
                    {
                        sSWSelectConA  = cCond["A"];
                    }
                    if(cCond.hasOwnProperty("B"))
                    {
                        sSWSelectConB  = cCond["B"];
                    }
                    if(cCond.hasOwnProperty("C"))
                    {
                        sSWSelectConC  = cCond["C"];
                    }
                }
                if(cSelected.hasOwnProperty("Formula"))
                {
                    sSWSelectConFormula = cSelected["Formula"];
                }
                if(cSelected.hasOwnProperty("Same Condition"))
                {
                    var cSameCond = cSelected["Same Condition"];
                    if(cSameCond.hasOwnProperty("Parts ID"))
                    {
                        sSWSelectConSamePartsID  = cSameCond["Parts ID"];
                    }
                    if(cSameCond.hasOwnProperty("Screen ID"))
                    {
                        sSWSelectConSameScreenID  = cSameCond["Screen ID"];
                    }
                }
                if(cSelected.hasOwnProperty("else"))
                {
                    sSWSelectConElse = cSelected["else"];
                }
            }
            
            // pattern
            if (cSWInfo.hasOwnProperty("SW operation Pattern")) {
                sSWOpePattern = cSWInfo["SW operation Pattern"];
            };
            if(cSWInfo.hasOwnProperty("Operation result"))
            {
                var cOpResult = cSWInfo["Operation result"];
                if (cOpResult.hasOwnProperty("Screen Transion")) {
                    sScreenTransition = cOpResult["Screen Transion"];
                };
                if (cOpResult.hasOwnProperty("Start Function")) {
                    sStartFuntion = cOpResult["Start Function"];
                };
                if (cOpResult.hasOwnProperty("Setting Value Change")) {
                    sSettingValueChange = cOpResult["Setting Value Change"];
                };
                if (cOpResult.hasOwnProperty("Other")) {
                    sOther = cOpResult["Other"];
                };
            }
            if (cSWInfo.hasOwnProperty("BEEP")) {
                sBeep = cSWInfo["BEEP"];
            };
        }

        PVLOG("    sPartsID:" + sPartsID.toString());
        PVLOG("    sPartsType:" + sPartsType.toString());
        PVLOG("    sPartsName:" + sPartsName.toString());

        PVLOG("    sDisplayConA:" + sDisplayConA.toString());
        PVLOG("    sDisplayConB:" + sDisplayConB.toString());
        PVLOG("    sDisplayConC:" + sDisplayConC.toString());
        PVLOG("    sDisplayConFormula:" + sDisplayConFormula.toString());
        PVLOG("    sDisplayConSamePartsID:" + sDisplayConSamePartsID.toString());
        PVLOG("    sDisplayConSameScreenID:" + sDisplayConSameScreenID.toString());
        PVLOG("    sDisplayConElse:" + sDisplayConElse.toString());

        PVLOG("    sTextOrImageDeleteInMotionConA:" + sTextOrImageDeleteInMotionConA.toString());
        PVLOG("    sTextOrImageDeleteInMotionConB:" + sTextOrImageDeleteInMotionConB.toString());
        PVLOG("    sTextOrImageDeleteInMotionConC:" + sTextOrImageDeleteInMotionConC.toString());
        PVLOG("    sTextOrImageDeleteInMotionConFormula:" + sTextOrImageDeleteInMotionConFormula.toString());
        PVLOG("    sTextOrImageDeleteInMotionConSamePartsID:" + sTextOrImageDeleteInMotionConSamePartsID.toString());
        PVLOG("    sTextOrImageDeleteInMotionConSameScreenID:" + sTextOrImageDeleteInMotionConSameScreenID.toString());
        PVLOG("    sTextOrImageDeleteInMotionConElse:" + sTextOrImageDeleteInMotionConElse.toString());

        PVLOG("    sSWToneDownMotionConA:" + sSWToneDownMotionConA.toString());
        PVLOG("    sSWToneDownMotionConB:" + sSWToneDownMotionConB.toString());
        PVLOG("    sSWToneDownMotionConC:" + sSWToneDownMotionConC.toString());
        PVLOG("    sSWToneDownMotionConFormula:" + sSWToneDownMotionConFormula.toString());
        PVLOG("    sSWToneDownMotionConSamePartsID:" + sSWToneDownMotionConSamePartsID.toString());
        PVLOG("    sSWToneDownMotionConSameScreenID:" + sSWToneDownMotionConSameScreenID.toString());
        PVLOG("    sSWToneDownMotionConElse:" + sSWToneDownMotionConElse.toString());

        PVLOG("    sJPWords:" + sJPWords.toString());
        PVLOG("    sJPFixedWords:" + sJPFixedWords.toString());
        PVLOG("    sJPVRWords:" + sJPVRWords.toString());
        PVLOG("    sUSWords:" + sUSWords.toString());
        PVLOG("    sUSFixedWords:" + sUSFixedWords.toString());
        PVLOG("    sUSVRWords:" + sUSVRWords.toString());
        PVLOG("    sUKWords:" + sUKWords.toString());
        PVLOG("    sUKFixedWords:" + sUKFixedWords.toString());
        PVLOG("    sUKVRWords:" + sUKVRWords.toString());

        PVLOG("    sDisplayContent:" + sDisplayContent.toString());
        PVLOG("    sFormat:" + sFormat.toString());
        PVLOG("    sRange:" + sRange.toString());
        PVLOG("    sValidation:" + sValidation.toString());

        PVLOG("    sSWOpePattern:" + sSWOpePattern.toString());
        PVLOG("    sScreenTransition:" + sScreenTransition.toString());
        PVLOG("    sStartFuntion:" + sStartFuntion.toString());
        PVLOG("    sSettingValueChange:" + sSettingValueChange.toString());
        PVLOG("    sOther:" + sOther.toString());

        PVLOG("    sBeep:" + sBeep.toString());

        var modelData = partsView.getModelData();
        // parts ID
        [modelData setObject:sPartsID forKey:@"PartsID"];
        // parts type
        var dictPartsType = [NSMutableDictionary dictionary];
        [dictPartsType setObject:sPartsType forKey:@"Current"];
        var arrPartsType = [NSMutableArray array];
        var partsTypeList = getTypeListByTypeName("PartsType");
        if (partsTypeList) {
            for (var iType = 0; iType < partsTypeList.length; iType++) {
                arrPartsType.addObject(partsTypeList[iType]);
            };
        };
        [dictPartsType setObject:arrPartsType forKey:@"List"];
        [modelData setObject:dictPartsType forKey:@"PartsType"];
        // Parts Name
        [modelData setObject:sPartsName forKey:@"PartsName"];
        // Conds
        var dictConds = [NSMutableDictionary dictionary];
        {
            var dictDisplayCond = [NSMutableDictionary dictionary];
            {
                [dictDisplayCond setObject:sDisplayConA forKey:@"A"];
                [dictDisplayCond setObject:sDisplayConB forKey:@"B"];
                [dictDisplayCond setObject:sDisplayConC forKey:@"C"];
                [dictDisplayCond setObject:sDisplayConFormula forKey:@"Formula"];
                [dictDisplayCond setObject:sDisplayConSamePartsID forKey:@"SamePartsID"];
                [dictDisplayCond setObject:sDisplayConSameScreenID forKey:@"SameScreenID"];
                [dictDisplayCond setObject:sDisplayConElse forKey:@"Else"];
            }
            [dictConds setObject:dictDisplayCond forKey:@"Display"];

            var dictTextOrImageDeleteInMotionCond = [NSMutableDictionary dictionary];
            {
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConA forKey:@"A"];
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConB forKey:@"B"];
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConC forKey:@"C"];
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConFormula forKey:@"Formula"];
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConSamePartsID forKey:@"SamePartsID"];
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConSameScreenID forKey:@"SameScreenID"];
                [dictTextOrImageDeleteInMotionCond setObject:sTextOrImageDeleteInMotionConElse forKey:@"Else"];
            }
            [dictConds setObject:dictTextOrImageDeleteInMotionCond forKey:@"TextOrImageDeleteInMotion"];

            var dictSWToneDownMotionCond = [NSMutableDictionary dictionary];
            {
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConA forKey:@"A"];
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConB forKey:@"B"];
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConC forKey:@"C"];
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConFormula forKey:@"Formula"];
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConSamePartsID forKey:@"SamePartsID"];
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConSameScreenID forKey:@"SameScreenID"];
                [dictSWToneDownMotionCond setObject:sSWToneDownMotionConElse forKey:@"Else"];
            }
            [dictConds setObject:dictSWToneDownMotionCond forKey:@"SWToneDownMotion"];

            var dictSWToneDownExceptInMotionCond = [NSMutableDictionary dictionary];
            {
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConA forKey:@"A"];
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConB forKey:@"B"];
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConC forKey:@"C"];
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConFormula forKey:@"Formula"];
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConSamePartsID forKey:@"SamePartsID"];
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConSameScreenID forKey:@"SameScreenID"];
                [dictSWToneDownExceptInMotionCond setObject:sSWToneDownExceptInMotionConElse forKey:@"Else"];
            }
            [dictConds setObject:dictSWToneDownExceptInMotionCond forKey:@"SWToneDownExceptInMotion"];

            var dictSWSelectCond = [NSMutableDictionary dictionary];
            {
                [dictSWSelectCond setObject:sSWSelectConA forKey:@"A"];
                [dictSWSelectCond setObject:sSWSelectConB forKey:@"B"];
                [dictSWSelectCond setObject:sSWSelectConC forKey:@"C"];
                [dictSWSelectCond setObject:sSWSelectConFormula forKey:@"Formula"];
                [dictSWSelectCond setObject:sSWSelectConSamePartsID forKey:@"SamePartsID"];
                [dictSWSelectCond setObject:sSWSelectConSameScreenID forKey:@"SameScreenID"];
                [dictSWSelectCond setObject:sSWSelectConElse forKey:@"Else"];
            }
            [dictConds setObject:dictSWSelectCond forKey:@"SWSelect"];
        }
        [modelData setObject:dictConds forKey:@"Conditions"];
        // Words
        [modelData setObject:sJPWords forKey:@"JPWords"];
        [modelData setObject:sJPFixedWords forKey:@"JPFixedWords"];
        [modelData setObject:sJPVRWords forKey:@"JPVRWords"];
        [modelData setObject:sUSWords forKey:@"USWords"];
        [modelData setObject:sUSFixedWords forKey:@"USFixedWords"];
        [modelData setObject:sUSVRWords forKey:@"USVRWords"];
        [modelData setObject:sUKWords forKey:@"UKWords"];
        [modelData setObject:sUKFixedWords forKey:@"UKFixedWords"];
        [modelData setObject:sUKVRWords forKey:@"UKVRWords"];
        [modelData setObject:sDisplayContent forKey:@"DisplayContent"];
        [modelData setObject:sFormat forKey:@"Format"];
        [modelData setObject:sRange forKey:@"Range"];
        [modelData setObject:sValidation forKey:@"Validation"];

        // sSWOpePattern
        var dictSWOpePattern = [NSMutableDictionary dictionary];
        [dictSWOpePattern setObject:sSWOpePattern forKey:@"Current"];
        var arrSWOpePattern = [NSMutableArray array];
        var swOperationPattern = getTypeListByTypeName("SWOperationPattern");
        if (swOperationPattern) {
            for (var idx = 0; idx < swOperationPattern.length; idx++) {
                arrSWOpePattern.addObject(swOperationPattern[idx]);
            };
        };
        [dictSWOpePattern setObject:arrSWOpePattern forKey:@"List"];
        [modelData setObject:dictSWOpePattern forKey:@"SWOpePattern"];

        [modelData setObject:sScreenTransition forKey:@"SWOpeResScreenTransition"];
        [modelData setObject:sStartFuntion forKey:@"SWOpeResStartFunction"];
        [modelData setObject:sSettingValueChange forKey:@"SWOpeResSetValChange"];
        [modelData setObject:sOther forKey:@"SWOpeResOther"];

        // beep
        var dictBeep = [NSMutableDictionary dictionary];
        [dictBeep setObject:sBeep forKey:@"Current"];
        var arrBeep = [NSMutableArray array];
        var beepList = getTypeListByTypeName("BEEP");
        if (beepList) {
            for (var iBeep = 0; iBeep < beepList.length; iBeep++) {
                arrBeep.addObject(beepList[iBeep]);
            };
        };
        [dictBeep setObject:arrBeep forKey:@"List"];
        [modelData setObject:dictBeep forKey:@"Beep"];

        partsView.setModelData(modelData);
        PVLOG("    partsView.setModelData over");
    }
    else
    {
        PVLOG("Not found PartsObj");
    }
   
    var PartsDelegateobj = PartsDelegate.alloc().init()
    PartsDelegateobj.setContext(context);
    partsView.setDelegage(PartsDelegateobj);
}

function savePartsInfo(modelData)
{
    PVLOG("savePartsInfo");
    //PVLOG(modelData.toString());

    var sScreenID = getMemProperty("SelectPartsInfo-screenID");
    if (!sScreenID) {
        PVLOG("    Invalid screenID!");
        return;
    };
    PVLOG("    sScreenID:"+sScreenID);

    var activatePartsInfoView_partsID = getMemProperty("activatePartsInfoView_partsID")+"";
    var sPartsID = activatePartsInfoView_partsID;//modelData["PartsID"]+"";
    var sPartsType = modelData["PartsType"]["Current"] + "";
    var sPartsName = modelData["PartsName"] + "";

    // cond
    var sCondDisplayA = modelData["Conditions"]["Display"]["A"] + "";
    var sCondDisplayB = modelData["Conditions"]["Display"]["B"] + "";
    var sCondDisplayC = modelData["Conditions"]["Display"]["C"] + "";
    var sCondDisplayElse = modelData["Conditions"]["Display"]["Else"] + "";
    var sCondDisplayFormula = modelData["Conditions"]["Display"]["Formula"] + "";
    var sCondDisplaySamePartsID = modelData["Conditions"]["Display"]["SamePartsID"] + "";
    var sCondDisplaySameScreenID = modelData["Conditions"]["Display"]["SameScreenID"] + "";

    var sCondTextOrImageDeleteInMotionA = modelData["Conditions"]["TextOrImageDeleteInMotion"]["A"] + "";
    var sCondTextOrImageDeleteInMotionB = modelData["Conditions"]["TextOrImageDeleteInMotion"]["B"] + "";
    var sCondTextOrImageDeleteInMotionC = modelData["Conditions"]["TextOrImageDeleteInMotion"]["C"] + "";
    var sCondTextOrImageDeleteInMotionElse = modelData["Conditions"]["TextOrImageDeleteInMotion"]["Else"] + "";
    var sCondTextOrImageDeleteInMotionFormula = modelData["Conditions"]["TextOrImageDeleteInMotion"]["Formula"] + "";
    var sCondTextOrImageDeleteInMotionSamePartsID = modelData["Conditions"]["TextOrImageDeleteInMotion"]["SamePartsID"] + "";
    var sCondTextOrImageDeleteInMotionSameScreenID = modelData["Conditions"]["TextOrImageDeleteInMotion"]["SameScreenID"] + "";

    var sCondSWToneDownMotionA = modelData["Conditions"]["SWToneDownMotion"]["A"] + "";
    var sCondSWToneDownMotionB = modelData["Conditions"]["SWToneDownMotion"]["B"] + "";
    var sCondSWToneDownMotionC = modelData["Conditions"]["SWToneDownMotion"]["C"] + "";
    var sCondSWToneDownMotionElse = modelData["Conditions"]["SWToneDownMotion"]["Else"] + "";
    var sCondSWToneDownMotionFormula = modelData["Conditions"]["SWToneDownMotion"]["Formula"] + "";
    var sCondSWToneDownMotionSamePartsID = modelData["Conditions"]["SWToneDownMotion"]["SamePartsID"] + "";
    var sCondSWToneDownMotionSameScreenID = modelData["Conditions"]["SWToneDownMotion"]["SameScreenID"] + "";

    var sCondSWToneDownExceptInMotionA = modelData["Conditions"]["SWToneDownExceptInMotion"]["A"] + "";
    var sCondSWToneDownExceptInMotionB = modelData["Conditions"]["SWToneDownExceptInMotion"]["B"] + "";
    var sCondSWToneDownExceptInMotionC = modelData["Conditions"]["SWToneDownExceptInMotion"]["C"] + "";
    var sCondSWToneDownExceptInMotionElse = modelData["Conditions"]["SWToneDownExceptInMotion"]["Else"] + "";
    var sCondSWToneDownExceptInMotionFormula = modelData["Conditions"]["SWToneDownExceptInMotion"]["Formula"] + "";
    var sCondSWToneDownExceptInMotionSamePartsID = modelData["Conditions"]["SWToneDownExceptInMotion"]["SamePartsID"] + "";
    var sCondSWToneDownExceptInMotionSameScreenID = modelData["Conditions"]["SWToneDownExceptInMotion"]["SameScreenID"] + "";

    var sCondSWSelectA = modelData["Conditions"]["SWSelect"]["A"] + "";
    var sCondSWSelectB = modelData["Conditions"]["SWSelect"]["B"] + "";
    var sCondSWSelectC = modelData["Conditions"]["SWSelect"]["C"] + "";
    var sCondSWSelectElse = modelData["Conditions"]["SWSelect"]["Else"] + "";
    var sCondSWSelectFormula = modelData["Conditions"]["SWSelect"]["Formula"] + "";
    var sCondSWSelectSamePartsID = modelData["Conditions"]["SWSelect"]["SamePartsID"] + "";
    var sCondSWSelectSameScreenID = modelData["Conditions"]["SWSelect"]["SameScreenID"] + "";

    var sJPWords = modelData["JPWords"] + "";
    var sJPFixedWords = modelData["JPFixedWords"] + "";
    var sJPVRWords = modelData["JPVRWords"] + "";
    var sUSWords = modelData["USWords"] + "";
    var sUSFixedWords = modelData["USFixedWords"] + "";
    var sUSVRWords = modelData["USVRWords"] + "";
    var sUKWords = modelData["UKVRWords"] + "";
    var sUKFixedWords = modelData["UKFixedWords"] + "";
    var sUKVRWords = modelData["UKVRWords"] + "";

    var sDisplayContent = modelData["DisplayContent"] + "";
    var sFormat = modelData["Format"] + "";
    var sRange = modelData["Range"] + "";
    var sValidation = modelData["Validation"] + "";

    var sSWOpePattern = modelData["SWOpePattern"]["Current"] + "";
    
    var sSWOpeResScreenTransition = modelData["SWOpeResScreenTransition"] + "";
    var sSWOpeResStartFunction = modelData["SWOpeResStartFunction"] + "";
    var sSWOpeResSetValChange = modelData["SWOpeResSetValChange"] + "";
    var sSWOpeResOther = modelData["SWOpeResOther"] + "";

    var sBeep = modelData["Beep"]["Current"] + "";

    PVLOG("    sPartsID:" + sScreenID);
    PVLOG("    sPartsType:" + sPartsType);
    PVLOG("    ...");

    // update DB
    var jsFindPartsObj = nil;
    var jObjScreen = readJsonByScreenID(sScreenID);
    if (jObjScreen) {
        if (jObjScreen.hasOwnProperty("ScreenInfo")) {
            if (jObjScreen.hasOwnProperty("PartsInfo")) {
                var jObjPartsInfo = jObjScreen["PartsInfo"];
                for(var pageName in jObjPartsInfo)
                {    
                    var pageParts = jObjPartsInfo[pageName]
                    if (pageParts.hasOwnProperty("parts")) {
                        var partsList = pageParts["parts"]
                        for(var partsName in partsList)
                        {
                            if(partsName+"" == sPartsID+"")
                            {
                                jsFindPartsObj = partsList[partsName]
                            }
                        }
                    }
                }
            }
            else
            {
                PVLOG("    DB ScreenInfo error[PartsInfo]");
            }
        }
        else
        {
            PVLOG("    DB ScreenInfo error[ScreenInfo]");
        }
    }
    else
    {
        PVLOG("    readJsonByScreenID error");
    }

    if (jsFindPartsObj) {
        //var jsonText = JSON.stringify(jsFindPartsObj);
        //PVLOG(jsonText);

        jsFindPartsObj["Parts Type"] = sPartsType;
        jsFindPartsObj["Parts Name"] = sPartsName;

        // conds
        if (!jsFindPartsObj.hasOwnProperty("Display Condition")) {
            jsFindPartsObj["Display Condition"] = {};
        }
        var condDisplay = jsFindPartsObj["Display Condition"];
        if (!condDisplay.hasOwnProperty("Same Condition")) {
            condDisplay["Same Condition"] = {};
        };
        if (!condDisplay.hasOwnProperty("Condition")) {
            condDisplay["Condition"] = {};
        };
        jsFindPartsObj["Display Condition"]["Condition"]["A"] = sCondDisplayA;
        jsFindPartsObj["Display Condition"]["Condition"]["B"] = sCondDisplayB;
        jsFindPartsObj["Display Condition"]["Condition"]["C"] = sCondDisplayC;
        jsFindPartsObj["Display Condition"]["Formula"] = sCondDisplayFormula;
        jsFindPartsObj["Display Condition"]["Same Condition"]["Parts ID"] = sCondDisplaySamePartsID;
        jsFindPartsObj["Display Condition"]["Same Condition"]["Screen ID"] = sCondDisplaySameScreenID;
        jsFindPartsObj["Display Condition"]["else"] = sCondDisplayElse;


        // Text or Image information
        if (!jObjScreen.hasOwnProperty("Text or Image information")) {
            jsFindPartsObj["Text or Image information"] = {};
        }
        var dictTextImageInfo = jsFindPartsObj["Text or Image information"];
            // Delete condition in motion
        if (!dictTextImageInfo.hasOwnProperty("Delete condition in motion")) {
            dictTextImageInfo["Delete condition in motion"] = {};
        }
        var condDelCondInMotion = dictTextImageInfo["Delete condition in motion"];
        if (!condDelCondInMotion.hasOwnProperty("Same Condition")) {
            condDelCondInMotion["Same Condition"] = {};
        };
        if (!condDelCondInMotion.hasOwnProperty("Condition")) {
            condDelCondInMotion["Condition"] = {};
        };
        dictTextImageInfo["Delete condition in motion"]["Condition"]["A"] = sCondTextOrImageDeleteInMotionA;
        dictTextImageInfo["Delete condition in motion"]["Condition"]["B"] = sCondTextOrImageDeleteInMotionB;
        dictTextImageInfo["Delete condition in motion"]["Condition"]["C"] = sCondTextOrImageDeleteInMotionC;
        dictTextImageInfo["Delete condition in motion"]["Formula"] = sCondTextOrImageDeleteInMotionFormula;
        dictTextImageInfo["Delete condition in motion"]["Same Condition"]["Parts ID"] = sCondTextOrImageDeleteInMotionSamePartsID;
        dictTextImageInfo["Delete condition in motion"]["Same Condition"]["Screen ID"] = sCondTextOrImageDeleteInMotionSameScreenID;
        dictTextImageInfo["Delete condition in motion"]["else"] = sCondTextOrImageDeleteInMotionElse;

            // JP
        if (!dictTextImageInfo.hasOwnProperty("Japanese")) {
            dictTextImageInfo["Japanese"] = {};
        }
        dictTextImageInfo["Japanese"]["Japanese"] = sJPWords;
        dictTextImageInfo["Japanese"]["Fixed words"] = sJPFixedWords;
        dictTextImageInfo["Japanese"]["VUI recognition word"] = sJPVRWords;
            //US
        if (!dictTextImageInfo.hasOwnProperty("U.S.English")) {
            dictTextImageInfo["U.S.English"] = {};
        }
        dictTextImageInfo["U.S.English"]["U.S.English"] = sUSWords;
        dictTextImageInfo["U.S.English"]["Fixed words"] = sUSFixedWords;
        dictTextImageInfo["U.S.English"]["VUI recognition word"] = sUSVRWords;
            //UK
        if (!dictTextImageInfo.hasOwnProperty("U.K.English")) {
            dictTextImageInfo["U.K.English"] = {};
        }
        dictTextImageInfo["U.K.English"]["U.K.English"] = sUKWords;
        dictTextImageInfo["U.K.English"]["Fixed words"] = sUKFixedWords;
        dictTextImageInfo["U.K.English"]["VUI recognition word"] = sUKVRWords;
            //OI
        if (!dictTextImageInfo.hasOwnProperty("Outside Input")) {
            dictTextImageInfo["Outside Input"] = {};
        }
        dictTextImageInfo["Outside Input"]["Display contents"] = sDisplayContent;
        dictTextImageInfo["Outside Input"]["Format"] = sFormat;
        dictTextImageInfo["Outside Input"]["Range"] = sRange;
            // validation
        dictTextImageInfo["Validation"] = sValidation;

        // SWInfo
        if (!jsFindPartsObj.hasOwnProperty("SW Information")) {
            jsFindPartsObj["SW Information"] = {};
        }
        var swInfo = jsFindPartsObj["SW Information"];
            // Tonedown condition in motion
        if (!swInfo.hasOwnProperty("Tonedown condition in motion")) {
            swInfo["Tonedown condition in motion"] = {};
        }
        var condTonedownInMotion = swInfo["Tonedown condition in motion"];
        if (!condTonedownInMotion.hasOwnProperty("Same Condition")) {
            condTonedownInMotion["Same Condition"] = {};
        };
        if (!condTonedownInMotion.hasOwnProperty("Condition")) {
            condTonedownInMotion["Condition"] = {};
        };
        condTonedownInMotion["Condition"]["A"] = sCondSWToneDownMotionA;
        condTonedownInMotion["Condition"]["B"] = sCondSWToneDownMotionB;
        condTonedownInMotion["Condition"]["C"] = sCondSWToneDownMotionC;
        condTonedownInMotion["Formula"] = sCondSWToneDownMotionFormula;
        condTonedownInMotion["Same Condition"]["Parts ID"] = sCondSWToneDownMotionSamePartsID;
        condTonedownInMotion["Same Condition"]["Screen ID"] = sCondSWToneDownMotionSameScreenID;
        condTonedownInMotion["else"] = sCondSWToneDownMotionElse;
            // Tonedown condition except in motion
        if (!swInfo.hasOwnProperty("Tonedown condition except in motion")) {
            swInfo["Tonedown condition except in motion"] = {};
        }
        var condTonedownExceptInMotion = swInfo["Tonedown condition except in motion"];
        if (!condTonedownExceptInMotion.hasOwnProperty("Same Condition")) {
            condTonedownExceptInMotion["Same Condition"] = {};
        };
        if (!condTonedownExceptInMotion.hasOwnProperty("Condition")) {
            condTonedownExceptInMotion["Condition"] = {};
        };
        condTonedownExceptInMotion["Condition"]["A"] = sCondSWToneDownExceptInMotionA;
        condTonedownExceptInMotion["Condition"]["B"] = sCondSWToneDownExceptInMotionB;
        condTonedownExceptInMotion["Condition"]["C"] = sCondSWToneDownExceptInMotionC;
        condTonedownExceptInMotion["Formula"] = sCondSWToneDownExceptInMotionFormula;
        condTonedownExceptInMotion["Same Condition"]["Parts ID"] = sCondSWToneDownExceptInMotionSamePartsID;
        condTonedownExceptInMotion["Same Condition"]["Screen ID"] = sCondSWToneDownExceptInMotionSameScreenID;
        condTonedownExceptInMotion["else"] = sCondSWToneDownExceptInMotionElse;
            // Selected condition
        if (!swInfo.hasOwnProperty("Selected condition")) {
            swInfo["Selected condition"] = {};
        }
        var condSelected = swInfo["Selected condition"];
        if (!condSelected.hasOwnProperty("Same Condition")) {
            condSelected["Same Condition"] = {};
        };
        if (!condSelected.hasOwnProperty("Condition")) {
            condSelected["Condition"] = {};
        };
        condSelected["Condition"]["A"] = sCondSWSelectA;
        condSelected["Condition"]["B"] = sCondSWSelectB;
        condSelected["Condition"]["C"] = sCondSWSelectC;
        condSelected["Formula"] = sCondSWSelectFormula;
        condSelected["Same Condition"]["Parts ID"] = sCondSWSelectSamePartsID;
        condSelected["Same Condition"]["Screen ID"] = sCondSWSelectSameScreenID;
        condSelected["else"] = sCondSWSelectElse;
            // pattern
        swInfo["SW operation Pattern"] = sSWOpePattern;
        if (!swInfo.hasOwnProperty("Operation result")) {
            swInfo["Operation result"] = {};
        }
        swInfo["Operation result"]["Screen Transion"] = sSWOpeResScreenTransition;
        swInfo["Operation result"]["Start Function"] = sSWOpeResStartFunction;
        swInfo["Operation result"]["Setting Value Change"] = sSWOpeResSetValChange;
        swInfo["Operation result"]["Other"] = sSWOpeResOther;

        swInfo["BEEP"] = sBeep;

        PVLOG("    writeJsonByScreenID");
        var jsonText = JSON.stringify(jsFindPartsObj);
        PVLOG(jsonText);
        writeJsonByScreenID(sScreenID, jObjScreen);
    }

    PVLOG("    savePartsInfo OVER");
}

function activatePartsInfoViewByScreenIDPartsID(screenID, partsID, context)
{
    PVLOG("activatePartsInfoViewByScreenIDPartsID");
    PVLOG("    screenID:" + screenID);
    PVLOG("    partsID:" + partsID);

    setMemProperty("activatePartsInfoView_screenID", screenID);
    setMemProperty("activatePartsInfoView_partsID", partsID);
    loadPartsInfoViewData(screenID, partsID, context);
}

function activatePartsInfoViewByArtboardIDPartsID(artboardID, partsID, context)
{
    PVLOG("activatePartsInfoViewByArtboardIDPartsID:");
    PVLOG("    " + artboardID + ":" + partsID);

    var artBoardInSPList = getPageInfoByArtBoardID(artboardID)
    if(artBoardInSPList.length > 0)
    {
        var inScreenID = artBoardInSPList[0].ScreenID;
        var inPageID = artBoardInSPList[0].PageID;
        PVLOG("    FindBindInfo Screen:" + inScreenID + " Page:" + inPageID);

        setMemProperty("activatePartsInfoView_screenID", inScreenID);
        setMemProperty("activatePartsInfoView_partsID", partsID);
        loadPartsInfoViewData(inScreenID, partsID, context);
    }
    else
    {
        PVLOG("    NotFindBindInfo, init null info.");
    }
}

