@import "IautoLib/filelib.js"
@import "IautoLib/logJS.js"
@import "metadata-panel-listener.js"
@import "IautoLib/iautolib.js"
function ExportMarkConfigOwn(context)
{
	var openPanel = NSOpenPanel.openPanel();
    [openPanel setCanChooseDirectories:true]; //Can open the directory
    [openPanel setCanChooseFiles:0]; //Can only select directory and can not select file
    [openPanel setDirectory:NSHomeDirectory()]; //The default directory is $home
    [openPanel setPrompt: @"Export"];
    if (openPanel.runModal() != NSOKButton) {
        return false;
    }
    var result_full_path = openPanel.URL().path();
    var jsonFileName = getSketchDocumentName(context) + ".json";
    var jsonFilePath = "" + result_full_path + "/" + jsonFileName;
    var xlsxFilePath = "" + result_full_path + "/" + getSketchDocumentName(context) + ".xlsx";

    initFramework(context);
    SketchEventHandler.startExportMarkConfig(result_full_path);

    context.document.showMessage("screen "+jsonFileName);
    console.log(jsonFileName)

    var script_full_filename = context.scriptPath;
    let script_full_path = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    let params = []
    params.push("-jar");
    params.push(""+script_full_path+"/GenMarkInfoXlsx/ExportMarkInfoXls.jar");
    params.push(jsonFilePath);
    params.push(result_full_path + "/" + getSketchDocumentName(context) + ".xlsx");
    console.log(params[1]);
    let retCmdStr = runCommand("/usr/bin/java", params);
    console.log(retCmdStr);

}

function ImportMarkInfoJs(context)
{
    // 检测是否安装了python3
    python3Cmd = getPython3CmdPath();
    if (python3Cmd == null) {
        showAlert("Python3 is not installed, please install it!");
        return -2;
    }

    var openPanel = NSOpenPanel.openPanel();
    [openPanel setCanChooseDirectories:false]; //Can open the directory
    [openPanel setCanChooseFiles:true]; //Can only select directory and can not select file
    [openPanel setDirectory:NSHomeDirectory()]; //The default directory is $home
    [openPanel setPrompt: @"Import"];
    if (openPanel.runModal() != NSOKButton) {
        return false;
    }
    var import_full_path = openPanel.URL().path();
    var result_path = nil;
    var fileName = nil;
    if (import_full_path.substr(import_full_path.lastIndexOf('.')) != ".xlsx") {
        // binding_json_path = import_full_path.substr(0, import_full_path.lastIndexOf('/'));
    }
    result_path = import_full_path.substr(0, import_full_path.lastIndexOf('/'));
    var startNum = import_full_path.lastIndexOf('/')+1;
    var endNum = import_full_path.lastIndexOf('.');
    fileName = import_full_path.substring(startNum,endNum);
    var jsonFileName = "" + result_path + "/" + fileName +".json";
    // var FileName = getSketchDocumentName(context);
    // var jsonFilePath = "" + result_full_path + "/" + FileName + ".json";
    // var xlsxFilePath = "" + result_full_path + "/" + FileName + ".xlsx";

    initFramework(context);

    var script_full_filename = context.scriptPath;
    var script_full_path = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    var excel2jsonret = runCommand(python3Cmd,
                [script_full_path+"/IautoScripts/TmnaMarkInfoExcel2Json.py", import_full_path, jsonFileName],
                {"LC_ALL":"en_us.UTF-8"});
    if (excel2jsonret.length > 0) {
        LogJS.error("importexport", "Python Command:"+python3Cmd);
        LogJS.error("importexport", "Python Params:"+import_full_path);
        LogJS.error("importexport", "Python Script TmnaExcel2Json Return Console:"+excel2jsonret);
        showAlert("Import Error! Please see the logfile($home/iauto_tmnaplugin/log/iautoplugin.log) for the detail information!");
        return -2;
    }
    setMetadataPanelStopFlag(true);
    var ctx = context;
    delayRun(0.3, () => {
        SketchEventHandler.startImportMarkConfig(jsonFileName);
        restartSetupPanelNew(ctx);
    })
    showAlert("Import ok!");
}

function runCommand(exeCmd, argsList = null, envdict = null) {
    task = [[NSTask alloc] init];
    [task setLaunchPath:exeCmd];
    if (argsList) {
        [task setArguments:argsList];
    }

    if (envdict != null) {
        task.setEnvironment(envdict);
    }

    pipe = [NSPipe pipe];
    [task setStandardOutput:pipe];
    [task setStandardError:pipe];
    [task launch];
    
    file = [pipe fileHandleForReading];
    data = [file readDataToEndOfFile]
    retdata = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]
    // console.log(retdata.trim())

    return retdata.trim()
}

function runJarcmd(cmd, params, workdir)
{
    var cmdlines = params;
    var exec = cmd;
    var pyargs = new Array();
    for (var i=0; i<cmdlines.length; i++)
    {
        pyargs.push(cmdlines[i])
    }

    var launchPath = ""
    {
        var taskFindLaunchPath = [[NSTask alloc] init];
        [taskFindLaunchPath setLaunchPath: "/usr/bin/which"];
        var argumentsInner = Array() 
        argumentsInner.push(exec)
        [taskFindLaunchPath setArguments: argumentsInner];
        var pipeInner = [NSPipe pipe];
        [taskFindLaunchPath setStandardOutput: pipeInner];
        var fileInner = [pipeInner fileHandleForReading]
        [taskFindLaunchPath launch];
        var dataInner = [fileInner readDataToEndOfFile]
        var retdataInner = [[NSString alloc] initWithData: dataInner encoding: NSUTF8StringEncoding]
        var launchPath = retdataInner.trim()
    }

    

    var task = [[NSTask alloc] init];
    [task setCurrentDirectoryPath: workdir];
    [task setLaunchPath: launchPath];
    var envdic = {"LC_ALL":"en_us.UTF-8"};
    // task.environment = envdic;
    task.setEnvironment(envdic);
    [task setArguments: pyargs];
    var pipe = [NSPipe pipe];
    [task setStandardOutput: pipe];
    var file = [pipe fileHandleForReading]
    [task launch];
    var data = [file readDataToEndOfFile]
    var retdata = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding]

    if (retdata.length > 0) {
        LogJS.error("baselog", "Java Path:" + launchPath);
        LogJS.error("baselog", "Java Params:" + pyargs);
        LogJS.error("baselog", "Java Ret Value:" + retdata);    
    }
    
    return retdata;
}
function initFramework(context)
{
	coscript.setShouldKeepAround(true);
	var frameworkname = "TMNAFramework"
    var mocha = Mocha.sharedRuntime();
    if (!mocha.valueForKey(frameworkname)) {
       var script_full_filename = context.scriptPath;
		var sketchPluginPath = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
		sketchPluginPath = sketchPluginPath.substr(0, sketchPluginPath.lastIndexOf('/'));
		var frameworkpath = sketchPluginPath + "/Resources/";
		var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
		mocha.setValue_forKey_(true, frameworkname);
        //return;
    }
    
    var command = context.command;
    var document = context.document;
    var scriptPath = context.scriptPath;
    var scriptURL = context.scriptURL;
    var selection = context.selection;
    SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
    var sketchObjects = [
        MSLayer.new(),
        MSLayerGroup.new(),
        MSFlowConnection.new(),
        MSSymbolCreator.new(),
        MSLayerArray.new(),
        MSTextLayer.new(),
        MSArtboardGroup.new(),
        MSShapeGroup.new(),
        MSExportRequest.new(),
        MSStyle.new(),
        MSStyleFill.new(),
        MSColor.new(),
        MSCurvePoint.new(),
        MSShapePathLayer.new(),
        MSRectangleShape.new(),
        MSTriangleShape.new(),
        MSOvalShape.new(),
        MSStarShape.new(),
        MSPolygonShape.new(),
        MSAbsoluteRect.new()
    ];
    SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);
}

function getSketchDocumentName(context) {
    var sketch_path = context.document.fileURL().path()
    var s = sketch_path.lastIndexOf('/')
    var e = sketch_path.indexOf('(',s)
    if(-1 == e) {
        e = sketch_path.indexOf('.',s)
    }
    var balnk_count = 1;
    while(e>balnk_count &&sketch_path.substr(e-balnk_count,1) == ' '){
        balnk_count++;
    }
    return toSlug(sketch_path.substr(s+1,e-s-balnk_count))
}

function toSlug(str){
    return toJSString(str)
            .toLowerCase()
            .replace(/(<([^>]+)>)/ig, "")
            .replace(/[\/\+\|]/g, " ")
            .replace(new RegExp("[\\!@#$%^&\\*\\(\\)\\?=\\{\\}\\[\\]\\\\\\\,\\.\\:\\;\\']", "gi"),'')
            .replace(/\s+/g,'-')
            .replace(/-/g,'_')
            ;
}

function toJSString(str){
    return new String(str).toString();
}

function getPython3CmdPath() {
    var python36Path = "/Library/Frameworks/Python.framework/Versions/3.6/bin/python3";
    var python37Path = "/Library/Frameworks/Python.framework/Versions/3.7/bin/python3";
    var python3Path = "";

    if(fileExists(python37Path)){
        python3Path = python37Path;
        return python3Path;
    }
    else if(fileExists(python36Path)){
        python3Path = python36Path;
        return python3Path;
    }

    return null;
}