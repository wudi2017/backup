@import 'common.js';
@import 'HelloSketch.framework/HelloSketch.js'

// PART_TYPES is imported from common.js

const SCREEN_MODES = [
  'TODO1',
  'TODO2',
  'TODO3',
  'Select Screen Mode'
]
const MARK_TRUEFALSE = [
  'false',
  'true'
]

const SW_OPERATION_PATTERNS = [
  'Select SW Operation',
  'Tap',
  'Long Press',
  'Scroll',
  'Timeout',
  'Outside Input'
]

const BEEP_TYPES = [
  'Select Beep Type',
  'Decision',
  'Failure',
  'Notice',
  'None'
]

const CONDITIONS = [
  'Display Condition',
  'Text/Image Delete in Motion',
  'SW Tonedown - Motion',
  'SW Tonedown - Except in motion',
  'SW Selected'
]

const CONDITIONS_KEYS = [
  'displayCondition',
  'textImageDeleteInMotion',
  'sWTonedownMotion',
  'sWTonedownExceptInMotion',
  'sWSelected'
]

function CLogToFile(logtag, logstr)
{
    return;
    var nsStrLog = NSString.alloc().initWithString(logstr);
    nsStrLog = nsStrLog.stringByAppendingFormat("\n");

    var homeDir = NSHomeDirectory();
    var logFileFullName = homeDir + "/" + logtag + ".txt"

    var filehandle = NSFileHandle.fileHandleForWritingAtPath(logFileFullName)
    if(filehandle)
    {
        filehandle.truncateFileAtOffset(filehandle.seekToEndOfFile());
        var nsdata = nsStrLog.dataUsingEncoding(NSUTF8StringEncoding);
        filehandle.writeData(nsdata)
        [filehandle closeFile];
    }
    else
    {
        nsStrLog.writeToFile_atomically(logFileFullName, true);
    }
}

function tryLoadFramework(actionContext,actionCommand)
{
    var frameworkName = "TMNAFramework"
    var mocha = Mocha.sharedRuntime();
    if (mocha.valueForKey(frameworkName)) {
      // alreadyLoad
      return;
    }
    coscript.setShouldKeepAround(true);
    var FrameworkPath =  COScript.currentCOScript().env().scriptURL.path().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent()+"/Resources";
    CLogToFile("test", FrameworkPath)
    CLogToFile("test", frameworkName)
    var mocha = [Mocha sharedRuntime]
    var loadflg = [mocha loadFrameworkWithName:frameworkName inDirectory:FrameworkPath]
    CLogToFile("test", loadflg.toString())
    mocha.setValue_forKey_(true, frameworkName);

    var command = actionCommand;
    var document = actionContext.document;
    var scriptPath = actionContext.scriptPath;
    var scriptURL = actionContext.scriptURL;
    var selection = actionContext.selection;
    SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
    var sketchObjects = [MSLayer.new(),MSLayerGroup.new(),MSFlowConnection.new(),MSSymbolCreator.new(),MSLayerArray.new(),MSTextLayer.new(),MSArtboardGroup.new(),MSShapeGroup.new(),MSExportRequest.new(),MSStyle.new(),MSStyleFill.new(),MSColor.new(),MSCurvePoint.new(),MSShapePathLayer.new(),MSRectangleShape.new(),MSTriangleShape.new(),MSOvalShape.new(),MSStarShape.new(),MSPolygonShape.new(),MSAbsoluteRect.new()];
    SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);
}

function setMetadataPanelStopFlag(flag)
{
    var mocha = Mocha.sharedRuntime();
    var MetadataPanelStopFlag = "MetadataPanelStopFlag";
    mocha.setValue_forKey_(flag, MetadataPanelStopFlag);
}
function checkMetadataPanelStopFlag()
{
    var mocha = Mocha.sharedRuntime();
    var MetadataPanelStopFlag = "MetadataPanelStopFlag";
    return mocha.valueForKey(MetadataPanelStopFlag);
}
function restartSetupPanelNew(context)
{
    setupPanelNew(context, context.command, true);
}

function onRun(action) {

  tryLoadFramework(action.actionContext, action.command);
  // We have to delay a little bit because selected layers
  // aren't available immediately for some reason.

  delayRun(0.1, () => {
    setupPanelNew(action.actionContext, action.command, true)
  })
}

function setupPanelNew(context, command, begin) {

  setMetadataPanelStopFlag(false);
  
  // Grab selections

  const selectedLayers = context.document.selectedLayers();
  const selectedLayer = selectedLayers.firstLayer();
  
  // Index into main view hierarchy

  const mainSplitView = context.document.splitViewController().splitView()
  let mainSplitSubviews = mainSplitView.arrangedSubviews()

  // Remove any and all existing panels

  for (let iii=mainSplitSubviews.length-1; iii>=0; iii--) {
    if (String(mainSplitSubviews[iii].class()) == "TCSidebarPane") {
      mainSplitView.removeArrangedSubview(mainSplitSubviews[iii])
    }
  }

  // Abort if nothing (or more than one thing) is selected

  if (!selectedLayer || selectedLayers.containsMultipleLayers()) {
    coscript.setShouldKeepAround(false);
    return;
  }

  // Otherwise, set up the pane and proceed.
  
  mainSplitSubviews = mainSplitView.arrangedSubviews()
  const pane = TCSidebarPane.alloc().init()
  mainSplitView.insertArrangedSubview_atIndex(pane, mainSplitSubviews.length-1)
  pane.setup()

  // Gather existing meta...

  let newMeta = []
  const currentMeta = command.valueForKey_onLayer_forPluginIdentifier(
    'metadata',
    selectedLayer,
    'tmnaMM'
  )
  if (currentMeta) {
    currentMeta.forEach(m => { newMeta.push(m) })
  }

  // Adjust meta target if necessary

  let targetObjectID = String(selectedLayer.objectID())
  newMeta.forEach(m => {
    if (m.type == "Target") {
      targetObjectID = String(m.content || "")
    }
  })

  const oldMeta = []
  newMeta.forEach(m => { oldMeta.push(m) })
  const targetIsParent = targetObjectID === String(selectedLayer.objectID())
  if (!targetIsParent) {
    let matchFound = false
    newMeta.forEach(m => {
      if (matchFound) { return }
      if (m.type == "child") {
        const contentId = String(m.content.id)
        if (contentId === targetObjectID) {
          matchFound = true
          newMeta = []
          const contentMeta = m.content.metadata || []
          contentMeta.forEach(m => { newMeta.push(m) })
        }
      }
    })
    if (!matchFound) {
      newMeta = []
    }
  }

  // Look up saved meta

  let oldSummary = ""
  let oldRemarks = ""
  let oldPartsTypeStr = ""
  let oldScreenModeStr = ""
  let oldTextImageOutsideInputDisplayContents = ""
  let oldTextImageOutsideInputFormat = ""
  let oldTextImageOutsideInputRange = ""
  let oldTextImageValidation = ""
  let oldSwOperationPatternStr = ""
  let oldSwOperationResultScreenTransition = ""
  let oldSwOperationResultStartFunction = ""
  let oldSwOperationResultSettingValueChange = ""
  let oldSwOperationResultOther = ""
  let oldBeepStr = ""

  let oldIsExportStr = command.valueForKey_onLayer_forPluginIdentifier(
    'iauto_export_flag',
    selectedLayer,
    'iautoExportConfig'
  )
  let oldIsExport = -1
  if (oldIsExportStr == "0") {
    oldIsExport = 0;
  } else if (oldIsExportStr == "1") {
    oldIsExport = 1;
  }
  let oldIsExpandStr = command.valueForKey_onLayer_forPluginIdentifier(
    'iauto_expand_flag',
    selectedLayer,
    'iautoExportConfig'
  )
  let oldIsExpand = -1
  if (oldIsExpandStr == "0") {
    oldIsExpand = 0;
  } else if (oldIsExpandStr == "1") {
    oldIsExpand = 1;
  }
  let oldIsCommonSymbolStr = command.valueForKey_onLayer_forPluginIdentifier(
    'iauto_common_symbol_flag',
    selectedLayer,
    'iautoExportConfig'
  )
  let oldIsCommonSymbol = -1
  if (oldIsCommonSymbolStr == "0") {
    oldIsCommonSymbol = 0;
  } else if (oldIsCommonSymbolStr == "1") {
    oldIsCommonSymbol = 1;
  }
  let oldIsTouchableStr = command.valueForKey_onLayer_forPluginIdentifier(
    'iauto_touchable_flag',
    selectedLayer,
    'iautoExportConfig'
  )
  let oldIsTouchable = -1
  if (oldIsTouchableStr == "0") {
    oldIsTouchable = 0;
  } else if (oldIsTouchableStr == "1") {
    oldIsTouchable = 1;
  }

  newMeta.forEach(m => {
    if (m.type == "Summary") {
      oldSummary = m.content || ""
    } else if (m.type == "Remarks") {
      oldRemarks = m.content || ""
    } else if (m.type == "Parts Type") {
      oldPartsTypeStr = m.content.part || ""
    } else if (m.type == "Screen Mode") {
      oldScreenModeStr = m.content.mode || ""
    } else if (m.type == "text-image-outside-input") {
      const contentType = String(m.content.type)
      if (contentType == "display-contents") {
        oldTextImageOutsideInputDisplayContents = m.content.value || ""
      } else if (contentType == "format") {
        oldTextImageOutsideInputFormat = m.content.value || ""
      } else if (contentType == "range") {
        oldTextImageOutsideInputRange = m.content.value || ""
      }
    } else if (m.type == "text-image-validation") {
      oldTextImageValidation = m.content || ""
    } else if (m.type == "sw-operation-pattern") {
      oldSwOperationPatternStr = m.content.swOperationPattern || ""
    } else if (m.type == "sw-operation-result") {
      const contentType = String(m.content.type)
      if (contentType == "screen-transition") {
        oldSwOperationResultScreenTransition = m.content.value || ""
      } else if (contentType == "start-function") {
        oldSwOperationResultStartFunction = m.content.value || ""
      } else if (contentType == "setting-value-change") {
        oldSwOperationResultSettingValueChange = m.content.value || ""
      } else if (contentType == "other") {
        oldSwOperationResultOther = m.content.value || ""
      }
    } else if (m.type == "beep") {
      oldBeepStr = m.content.beep || ""
    } 
  })

  let oldTarget = 0
  //const selectedLayerSubSymbols = allSymbolLayersWithParents(selectedLayer, [selectedLayer])
  var defaultItem = {}
  defaultItem.layer = selectedLayer
  defaultItem.absoluteObjectID = selectedLayer.objectID();
  const selectedLayerSubSymbolsX = allSymbolLayersWithParentsX(selectedLayer,[defaultItem])
  selectedLayerSubSymbolsX.reverse()
  selectedLayerSubSymbolsX.unshift(selectedLayerSubSymbolsX.pop())
  selectedLayerSubSymbolsX.forEach((s, idx) => {
    if (String(s.absoluteObjectID) === String(targetObjectID)) {
      oldTarget = idx
    }
  })

  // log("oldPartsTypeStr :" + oldPartsTypeStr + ":")
  let oldPartsType = PART_TYPES.length - 1
  PART_TYPES.forEach((pt, idx) => {
    if (pt == oldPartsTypeStr) {
      oldPartsType = idx
    }
  })

  // log("oldPartsType :" + oldPartsType + ":")
  let oldScreenMode = SCREEN_MODES.length - 1
  SCREEN_MODES.forEach((pt, idx) => {
    if (pt == oldScreenModeStr) {
      oldScreenMode = idx
    }
  })

  let oldSwOperationPattern = 0
  SW_OPERATION_PATTERNS.forEach((pt, idx) => {
    if (pt == oldSwOperationPatternStr) {
      oldSwOperationPattern = idx
    }
  })
  
  let oldBeep = 0
  BEEP_TYPES.forEach((pt, idx) => {
    if (pt == oldBeepStr) {
      oldBeep = idx
    }
  })

  // Gather existing conditions...

  let currentConds = command.valueForKey_onLayer_forPluginIdentifier(
    'screenSpecConditions',
    selectedLayer,
    'tmnaMM'
  );
  if (!currentConds) { currentConds = {} }
  const newConds = {}
  for (let k in currentConds) {
    newConds[k] = currentConds[k]
  }
  // log("!!! " + JSON.stringify(newConds))

  // Migrate from old condition keys pre-child symbols...
  for (let k in newConds) {
    const kk = String(k)
    if (kk.indexOf('__') === -1) {
      const c = newConds[kk]
      newConds[kk] = undefined
      newConds[`${kk}__${String(selectedLayer.objectID())}`] = c
    }
  }

  // Set up panel Is Export chooser
  const IsExport = TCSidebarChooserSection.alloc().init()
  IsExport.setTitle("Is Exportable")
  pane.addItem(IsExport)
  IsExport.setup()
  // IsExport.setupBelow(space)

  for (let i=0; i<MARK_TRUEFALSE.length; i++) {
    IsExport.addChoice_selected(MARK_TRUEFALSE[i], i === oldIsExport)
  }
  if (-1 == oldIsExport) {
    IsExport.getChooser().selectItemAtIndex(-1);
  }

  // Set up panel Is Expand chooser
  const IsExpand = TCSidebarChooserSection.alloc().init()
  IsExpand.setTitle("Is Expandable")
  pane.addItem(IsExpand)
  IsExpand.setupBelow(IsExport)

  for (let i=0; i<MARK_TRUEFALSE.length; i++) {
    IsExpand.addChoice_selected(MARK_TRUEFALSE[i], i === oldIsExpand)
  }
  if (-1 == oldIsExpand) {
    IsExpand.getChooser().selectItemWithTitle("Please Select");
  }

  // Set up panel Is Common Symbol chooser
  const IsCommonSymbol = TCSidebarChooserSection.alloc().init()
  IsCommonSymbol.setTitle("Is a Common Symbol")
  pane.addItem(IsCommonSymbol)
  IsCommonSymbol.setupBelow(IsExpand)

  for (let i=0; i<MARK_TRUEFALSE.length; i++) {
    IsCommonSymbol.addChoice_selected(MARK_TRUEFALSE[i], i === oldIsCommonSymbol)
  }
  if (-1 == oldIsCommonSymbol) {
    IsCommonSymbol.getChooser().selectItemWithTitle("Please Select");
  }

  // Set up panel Is Touchable chooser
  const IsTouchable = TCSidebarChooserSection.alloc().init()
  IsTouchable.setTitle("Is Touchable")
  pane.addItem(IsTouchable)
  IsTouchable.setupBelow(IsCommonSymbol)

  for (let i=0; i<MARK_TRUEFALSE.length ; i++) {
    IsTouchable.addChoice_selected(MARK_TRUEFALSE[i], i === oldIsTouchable)
  }
  if (-1 == oldIsTouchable) {
    IsTouchable.getChooser().selectItemWithTitle("Please Select");
  }

  // -- Space -- //

  let myspace = TCSidebarSpaceSection.alloc().init()
  pane.addItem(myspace)
  myspace.setupBelow(IsTouchable)

  // Set up panel title

  const title = TCSidebarTitleSection.alloc().init()
  title.setTitle("TMNA Metadata")
  pane.addItem(title)
  title.setupBelow(myspace)

  // Set up panel target symbol chooser

  const subSymbols = TCSidebarLayerChooserSection.alloc().init()
  subSymbols.setTitle("Choose Target")
  pane.addItem(subSymbols)
  subSymbols.setupBelow(title)

  const metaSymNoConditions = (symObjectID) => {
    let hasConds = false
    CONDITIONS_KEYS.forEach((key) => {
      const inner = newConds[`${key}__${symObjectID}`]
      if (!inner) { return }
      hasConds = true
    })
    return !hasConds
  }

  const metaSymEmpty = (symObjectID) => {
    let empty = true
    oldMeta.forEach(m => {
      if (String(m.type) === 'child'
      &&  String(m.content.id) === symObjectID) {
        const mm = []
        if (m.content.metadata) {
          m.content.metadata.forEach(m => { mm.push(m) })
        }
        const lm = loadMeta(mm)
        empty = lm.empty
      }
    })
    return empty
  }

  // let index = 0
  // for (i in selectedLayerSubSymbols) {
  //   const sym = selectedLayerSubSymbols[i]
  //   const symObjectID = String(sym.objectID())
  //   const isSelected = index === oldTarget
  //   if (index === 0) {
  //     const pfx = (loadMeta(oldMeta).empty && metaSymNoConditions(symObjectID)) ? '' : '*'
  //     subSymbols.addChoice_meta_selected(`${pfx}Use Parent Symbol`, symObjectID, isSelected)
  //   } else {
  //     const symName = String(sym.name())
  //     const symMasterName = String(sym.symbolMaster().name())
  //     const pfx = (metaSymEmpty(symObjectID) && metaSymNoConditions(symObjectID)) ? '' : '*'
  //     subSymbols.addChoice_meta_selected(`${pfx}${symName}: ${symMasterName}`, symObjectID, isSelected)
  //   }
  //   index++
  // }

  let index = 0
  for (i in selectedLayerSubSymbolsX) {
    const item = selectedLayerSubSymbolsX[i]
    const sym = item.layer;
    const symObjectID = String(item.absoluteObjectID)
    const isSelected = index === oldTarget
    if (index === 0) {
      const pfx = (loadMeta(oldMeta).empty && metaSymNoConditions(symObjectID)) ? '' : '*'
      subSymbols.addChoice_meta_selected(`${pfx}Use Parent Symbol`, symObjectID, isSelected)
    } else {
      const symName = String(sym.name())
      var symMasterName = ""
      if (sym.className() == "MSSymbolInstance") {
        symMasterName = String(sym.symbolMaster().name())
      }else{
        symMasterName = String(sym.name())
      }
      const pfx = (metaSymEmpty(symObjectID) && metaSymNoConditions(symObjectID)) ? '' : '*'
      subSymbols.addChoice_meta_selected(`${pfx}${symName}: ${symMasterName}`, symObjectID, isSelected)
    }
    index++
  }

  // Set up panel summary entry

  const summary = TCSidebarEntrySection.alloc().init()
  summary.setTitle("Summary")
  summary.setEntryText(oldSummary)
  pane.addItem(summary)
  summary.setupBelow(subSymbols)

  // Set up panel remarks entry

  const remarks = TCSidebarEntrySection.alloc().init()
  remarks.setTitle("Remarks")
  remarks.setEntryText(oldRemarks)
  pane.addItem(remarks)
  remarks.setupBelow(summary)
  summary.setNextTab(remarks.getEntry())

  // -- Space -- //

  let space = TCSidebarSpaceSection.alloc().init()
  pane.addItem(space)
  space.setupBelow(remarks)

  // Set up panel parts type chooser

  const partsType = TCSidebarChooserSection.alloc().init()
  partsType.setTitle("Parts Type")
  pane.addItem(partsType)
  partsType.setupBelow(space)

  partsType.addChoice_selected(PART_TYPES[PART_TYPES.length - 1],
    PART_TYPES.length - 1 === oldPartsType)
  for (let i=0; i<PART_TYPES.length - 1; i++) {
    partsType.addChoice_selected(PART_TYPES[i], i === oldPartsType)
  }

  // Set up panel screen mode chooser

  const screenMode = TCSidebarChooserSection.alloc().init()
  screenMode.setTitle("Screen Mode")
  pane.addItem(screenMode)
  screenMode.setupBelow(partsType)

  screenMode.addChoice_selected(SCREEN_MODES[SCREEN_MODES.length - 1],
    SCREEN_MODES.length - 1 === oldScreenMode)
  for (let i=0; i<SCREEN_MODES.length - 1; i++) {
    screenMode.addChoice_selected(SCREEN_MODES[i], i === oldScreenMode)
  }

  // -- Space -- //

  space = TCSidebarSpaceSection.alloc().init()
  pane.addItem(space)
  space.setupBelow(screenMode)

  // Set up text/image outside input section

  const textImageOutsideInputLabel = TCSidebarTitleSection.alloc().init()
  textImageOutsideInputLabel.setTitle("Text/Image Outside Input")
  pane.addItem(textImageOutsideInputLabel)
  textImageOutsideInputLabel.setupBelow(space)

  const textImageOutsideInputDisplayContents = TCSidebarEntrySection.alloc().init()
  textImageOutsideInputDisplayContents.setTitle("Display Contents")
  textImageOutsideInputDisplayContents.setEntryText(oldTextImageOutsideInputDisplayContents)
  pane.addItem(textImageOutsideInputDisplayContents)
  textImageOutsideInputDisplayContents.setupBelow(textImageOutsideInputLabel)
  textImageOutsideInputDisplayContents.setSub(true)
  remarks.setNextTab(textImageOutsideInputDisplayContents.getEntry())

  const textImageOutsideInputFormat = TCSidebarEntrySection.alloc().init()
  textImageOutsideInputFormat.setTitle("Format")
  textImageOutsideInputFormat.setEntryText(oldTextImageOutsideInputFormat)
  pane.addItem(textImageOutsideInputFormat)
  textImageOutsideInputFormat.setupBelow(textImageOutsideInputDisplayContents)
  textImageOutsideInputFormat.setSub(true)
  textImageOutsideInputDisplayContents.setNextTab(textImageOutsideInputFormat.getEntry())

  const textImageOutsideInputRange = TCSidebarEntrySection.alloc().init()
  textImageOutsideInputRange.setTitle("Range")
  textImageOutsideInputRange.setEntryText(oldTextImageOutsideInputRange)
  pane.addItem(textImageOutsideInputRange)
  textImageOutsideInputRange.setupBelow(textImageOutsideInputFormat)
  textImageOutsideInputRange.setSub(true)
  textImageOutsideInputFormat.setNextTab(textImageOutsideInputRange.getEntry())

  // Set up text/image validation section

  const textImageValidation = TCSidebarEntrySection.alloc().init()
  textImageValidation.setTitle("Text/Image Validation")
  textImageValidation.setEntryText(oldTextImageValidation)
  pane.addItem(textImageValidation)
  textImageValidation.setupBelow(textImageOutsideInputRange)
  textImageValidation.setOneLine(true)
  textImageOutsideInputRange.setNextTab(textImageValidation.getEntry())

  // -- Space -- //

  space = TCSidebarSpaceSection.alloc().init()
  pane.addItem(space)
  space.setupBelow(textImageValidation)

  // Set up SW operation pattern & result section

  const swOperationPattern = TCSidebarChooserSection.alloc().init()
  swOperationPattern.setTitle("SW Operation Pattern")
  pane.addItem(swOperationPattern)
  swOperationPattern.setupBelow(space)

  index = 0
  for (i in SW_OPERATION_PATTERNS) {
    swOperationPattern.addChoice_selected(SW_OPERATION_PATTERNS[i], index === oldSwOperationPattern)
    index++
  }

  const swOperationResultLabel = TCSidebarTitleSection.alloc().init()
  swOperationResultLabel.setTitle("SW Operation Result")
  pane.addItem(swOperationResultLabel)
  swOperationResultLabel.setupBelow(swOperationPattern)

  const swOperationResultScreenTransition = TCSidebarEntrySection.alloc().init()
  swOperationResultScreenTransition.setTitle("Screen Transition")
  swOperationResultScreenTransition.setEntryText(oldSwOperationResultScreenTransition)
  pane.addItem(swOperationResultScreenTransition)
  swOperationResultScreenTransition.setupBelow(swOperationResultLabel)
  swOperationResultScreenTransition.setSub(true)
  textImageValidation.setNextTab(swOperationResultScreenTransition.getEntry())

  const swOperationResultStartFunction = TCSidebarEntrySection.alloc().init()
  swOperationResultStartFunction.setTitle("Start Function")
  swOperationResultStartFunction.setEntryText(oldSwOperationResultStartFunction)
  pane.addItem(swOperationResultStartFunction)
  swOperationResultStartFunction.setupBelow(swOperationResultScreenTransition)
  swOperationResultStartFunction.setSub(true)
  swOperationResultScreenTransition.setNextTab(swOperationResultStartFunction.getEntry())

  const swOperationResultSettingValueChange = TCSidebarEntrySection.alloc().init()
  swOperationResultSettingValueChange.setTitle("Setting Value Change")
  swOperationResultSettingValueChange.setEntryText(oldSwOperationResultSettingValueChange)
  pane.addItem(swOperationResultSettingValueChange)
  swOperationResultSettingValueChange.setupBelow(swOperationResultStartFunction)
  swOperationResultSettingValueChange.setSub(true)
  swOperationResultStartFunction.setNextTab(swOperationResultSettingValueChange.getEntry())

  const swOperationResultOther = TCSidebarEntrySection.alloc().init()
  swOperationResultOther.setTitle("Other")
  swOperationResultOther.setEntryText(oldSwOperationResultOther)
  pane.addItem(swOperationResultOther)
  swOperationResultOther.setupBelow(swOperationResultSettingValueChange)
  swOperationResultOther.setSub(true)
  swOperationResultSettingValueChange.setNextTab(swOperationResultOther.getEntry())

  // -- Space -- //

  space = TCSidebarSpaceSection.alloc().init()
  pane.addItem(space)
  space.setupBelow(swOperationResultOther)

  // Set up beep section

  const beep = TCSidebarChooserSection.alloc().init()
  beep.setTitle("Beep")
  pane.addItem(beep)
  beep.setupBelow(space)

  index = 0
  for (i in BEEP_TYPES) {
    beep.addChoice_selected(BEEP_TYPES[i], index === oldBeep)
    index++
  }

  // -- Space -- //

  space = TCSidebarSpaceSection.alloc().init()
  pane.addItem(space)
  space.setupBelow(beep)

  // Set up panel conditions section

  const conditions = TCSidebarConditionsSection.alloc().init()
  conditions.setTitle("Conditions")
  pane.addItem(conditions)
  conditions.setupBelow(space)
  
  for (i in CONDITIONS) {
    conditions.addConditionType(CONDITIONS[i])
  }

  // Load saved conditions

  let i = 0
  let ci = 0
  CONDITIONS_KEYS.forEach((key) => {
    const inner = newConds[`${key}__${targetObjectID}`]
    if (!inner) { ci++; return }
    restoreCond(conditions, inner, i, CONDITIONS[ci] || CONDITIONS[0])
    ci++
    i++
  })

  // Listen for and persist changes, every 1/10th of a second or so...
  // Now that we have Swift support, we can probably do this more
  // efficiently by responding to real events instead of polling.

  const tick = () => {
    
    // Abort if this pane was removed between now and the last tick

    if (!pane.superview()) {
      coscript.setShouldKeepAround(false)
      return
    }

    // Gather info to save

    let saveMeta = []

    // Save the summary / remarks text

    let summaryText = String(summary.getEntryText())
    let remarksText = String(remarks.getEntryText())

    if (summaryText) {
      saveMeta.push({ type: 'Summary', content: summaryText })
    }

    if (remarksText) {
      saveMeta.push({ type: 'Remarks', content: remarksText })
    }

    // Save part type

    const partChosen = String(partsType.getChoice())
    let partIndex = PART_TYPES.indexOf(partChosen)
    if (partIndex !== -1) {
      saveMeta.push({ type: 'Parts Type', content: { 'id': partIndex, part: partChosen } })
    }

    // Save screen mode
    
    const modeChosen = String(screenMode.getChoice())
    let modeIndex = SCREEN_MODES.indexOf(modeChosen)
    if (modeIndex !== -1) {
      saveMeta.push({ type: 'Screen Mode', content: { 'id': modeIndex, mode: modeChosen } })
    }

    // Save is export
    const exportChosen = String(IsExport.getChoice())
    let exportIndex = MARK_TRUEFALSE.indexOf(exportChosen)
    if (exportIndex !== -1) {
      // saveMeta.push({ type: 'iauto_export_flag', content: { 'id': exportIndex, export: exportChosen } })
      let getOldIsExportStr = command.valueForKey_onLayer_forPluginIdentifier(
        'iauto_export_flag',
        selectedLayer,
        'iautoExportConfig'
      )
      var exportIndexstr = exportIndex == 1 ? "1" : "0"
      if (getOldIsExportStr == nil) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          exportIndexstr,
          'iauto_export_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      } else if (getOldIsExportStr != exportIndexstr) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          exportIndexstr,
          'iauto_export_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      }
    }
    // Save is expand
    const expandChosen = String(IsExpand.getChoice())
    let expandIndex = MARK_TRUEFALSE.indexOf(expandChosen)
    if (expandIndex !== -1) {
      // saveMeta.push({ type: 'iauto_expand_flag', content: { 'id': expandIndex, expand: expandChosen } })
      let getOldIsExpandStr = command.valueForKey_onLayer_forPluginIdentifier(
        'iauto_expand_flag',
        selectedLayer,
        'iautoExportConfig'
      )
      var expandIndexstr = expandIndex == 1 ? "1" : "0"
      if (getOldIsExpandStr == nil) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          expandIndexstr,
          'iauto_expand_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      } else if (getOldIsExpandStr != expandIndexstr) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          expandIndexstr,
          'iauto_expand_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      }
    }
    // Save is common symbol
    const commonSymbolChosen = String(IsCommonSymbol.getChoice())
    let commonSymbolIndex = MARK_TRUEFALSE.indexOf(commonSymbolChosen)
    if (commonSymbolIndex !== -1) {
      // saveMeta.push({ type: 'iauto_common_symbol_flag', content: { 'id': commonSymbolIndex, commonsymbol: commonSymbolChosen } })
      let getOldIsCommonSymbolStr = command.valueForKey_onLayer_forPluginIdentifier(
        'iauto_common_symbol_flag',
        selectedLayer,
        'iautoExportConfig'
      )
      var commonSymbolIndexstr = commonSymbolIndex == 1 ? "1" : "0"
      if (getOldIsCommonSymbolStr == nil) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          commonSymbolIndexstr,
          'iauto_common_symbol_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      } else if (getOldIsCommonSymbolStr != commonSymbolIndexstr) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          commonSymbolIndexstr,
          'iauto_common_symbol_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      }
    }
    // Save is touchable
    const touchableChosen = String(IsTouchable.getChoice())
    let touchableIndex = MARK_TRUEFALSE.indexOf(touchableChosen)
    if (touchableIndex !== -1) {
      // saveMeta.push({ type: 'iauto_touchable_flag', content: { 'id': touchableIndex, touchable: touchableChosen } })
      let getOldIsTouchableStr = command.valueForKey_onLayer_forPluginIdentifier(
        'iauto_touchable_flag',
        selectedLayer,
        'iautoExportConfig'
      )
      var touchableIndexstr = touchableIndex == 1 ? "1" : "0"
      if (getOldIsTouchableStr == nil) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          touchableIndexstr,
          'iauto_touchable_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      } else if (getOldIsTouchableStr != touchableIndexstr) {
        command.setValue_forKey_onLayer_forPluginIdentifier(
          touchableIndexstr,
          'iauto_touchable_flag',
          selectedLayer,
          'iautoExportConfig'
        );
      }
    }

    // Save text/image outside input

    let textImageOutsideInputDisplayContentsText = String(textImageOutsideInputDisplayContents.getEntryText())
    let textImageOutsideInputFormatText = String(textImageOutsideInputFormat.getEntryText())
    let textImageOutsideInputRangeText = String(textImageOutsideInputRange.getEntryText())

    if (textImageOutsideInputDisplayContentsText) {
      saveMeta.push({ type: 'text-image-outside-input', content: {
        type: 'display-contents',
        value: textImageOutsideInputDisplayContentsText
      }})
    }

    if (textImageOutsideInputFormatText) {
      saveMeta.push({ type: 'text-image-outside-input', content: {
        type: 'format',
        value: textImageOutsideInputFormatText
      }})
    }

    if (textImageOutsideInputRangeText) {
      saveMeta.push({ type: 'text-image-outside-input', content: {
        type: 'range',
        value: textImageOutsideInputRangeText
      }})
    }

    // Save text / image validation

    let textImageValidationText = String(textImageValidation.getEntryText())

    if (textImageValidationText) {
      saveMeta.push({ type: 'text-image-validation', content: textImageValidationText })
    }

    // Save SW operation pattern

    const swOperationPatternChosen = String(swOperationPattern.getChoice())
    let swOperationPatternIndex = SW_OPERATION_PATTERNS.indexOf(swOperationPatternChosen)
    if (swOperationPatternIndex !== -1) {
      saveMeta.push({ type: 'sw-operation-pattern', content: {
        'id': swOperationPatternIndex,
        swOperationPattern: swOperationPatternChosen
      }})
    }

    // Save SW operation result

    let swOperationResultScreenTransitionText = String(swOperationResultScreenTransition.getEntryText())
    let swOperationResultStartFunctionText = String(swOperationResultStartFunction.getEntryText())
    let swOperationResultSettingValueChangeText = String(swOperationResultSettingValueChange.getEntryText())
    let swOperationResultOtherText = String(swOperationResultOther.getEntryText())

    if (swOperationResultScreenTransitionText) {
      saveMeta.push({ type: 'sw-operation-result', content: {
        type: 'screen-transition',
        value: swOperationResultScreenTransitionText
      }})
    }

    if (swOperationResultStartFunctionText) {
      saveMeta.push({ type: 'sw-operation-result', content: {
        type: 'start-function',
        value: swOperationResultStartFunctionText
      }})
    }

    if (swOperationResultSettingValueChangeText) {
      saveMeta.push({ type: 'sw-operation-result', content: {
        type: 'setting-value-change',
        value: swOperationResultSettingValueChangeText
      }})
    }

    if (swOperationResultOtherText) {
      saveMeta.push({ type: 'sw-operation-result', content: {
        type: 'other',
        value: swOperationResultOtherText
      }})
    }

    // Save beep

    const beepChosen = String(beep.getChoice())
    let beepIndex = BEEP_TYPES.indexOf(beepChosen)
    if (beepIndex !== -1) {
      saveMeta.push({ type: 'beep', content: {
        'id': beepIndex,
        beep: beepChosen
      }})
    }

    // If target is a child, save in nested format
    // Else, just append all children to save

    if (targetIsParent) {
      oldMeta.forEach(m => {
        if (m.type == 'child') {
          saveMeta.push(m)
        }
      })
    } else {
      const childMeta = { type: 'child', content: {
        'id': targetObjectID,
        metadata: saveMeta
      }}
      saveMeta = [childMeta]
      oldMeta.forEach(m => {
        const isTarget = String(m.type) == 'Target'
        const isMe = String(m.type) == 'child' && String(m.content.id) == targetObjectID
        if (!isMe && !isTarget) {
          saveMeta.push(m)
        }
      })
    }

    // Save target object ID

    let targetObjectIDText = String(subSymbols.getMeta())

    if (targetObjectIDText) {
      saveMeta.push({ type: 'Target', content: targetObjectIDText })
    }

    // Set / replace metadata key on tmnaMM key

    command.setValue_forKey_onLayer_forPluginIdentifier(
      saveMeta,
      'metadata',
      selectedLayer,
      'tmnaMM'
    );

    // Set / replace screenSpecConditions key on tmnaMM key

    const saveConds = {}
    for (let k in newConds) {
      const kk = String(k)
      if (!k || !kk || !newConds[kk]) { continue }
      if (!kk.endsWith(targetObjectID)) {
        saveConds[kk] = condToJS(newConds[kk])
      }
    }
    for (let i=0; i<conditions.getConditionCount(); i++) {
      buildCond(conditions, saveConds, targetObjectID, i)
    }

    command.setValue_forKey_onLayer_forPluginIdentifier(
      saveConds,
      'screenSpecConditions',
      selectedLayer,
      'tmnaMM'
    )
    
    // Abort and unselect / reselect if the target symbol was changed

    if (targetObjectIDText !== targetObjectID) {
      setupPanelNew(context, command, begin)
      return
    }

    // ---

    if (true == checkMetadataPanelStopFlag()) {
      return;
    };

    delayRun(0.2, tick)
  }
  
  tick()
}

// Given a TCSidebarConditionsSection and an index,
// build and return a JSON-ready condition object.
const buildCond = (conditions, cond, targetObjectID, i) => {

  // Wrapping object
  
  const condInner = {}
  const type = String(conditions.getConditionChoice(i))
  let j = 0;
  for (; j<CONDITIONS.length; j++) {
    if (CONDITIONS[j] == type) { break }
  }
  const typeKey = CONDITIONS_KEYS[j]
  cond[`${typeKey}__${targetObjectID}`] = condInner

  // Enabled

  condInner['__enabled'] = conditions.isConditionCheckEnabled(i) || false

  // Formula

  condInner['formula'] = String(conditions.getConditionFormula(i)) || null

  // Conditions

  let ci = 0
  condInner['conditions'] = []
  let entries = conditions.getConditionAlphaEntries(i)
  entries.forEach((e) => {
    if (String(e)) {
      condInner['conditions'].push(String(e))
    } else if (ci != entries.length - 1) {
      condInner['conditions'].push(null)
    }
    ci++
  })

  // Same condition

  condInner['sameCondition'] = {
    'partsID': String(conditions.getConditionPartsID(i)) || null,
    'screenID': String(conditions.getConditionScreenID(i)) || null
  }

  // Else

  condInner['else'] = null

  // log(JSON.stringify(cond))
  return cond
}

// Convert a cocoa string array to JS
const strArrToJS = (arr) => {
  const clean = []
  arr.forEach && arr.forEach(x => {
    const y = strToJS(x)
    if (y) { clean.push(y) }
  })
  return clean
}

// Convert a cocoa bool to JS
const boolToJS = (b) => {
  return `${b}` === "1"
}

// Convert a cond that was saved back to pure JS
const condToJS = (inner) => {
  const sameCond = inner.sameCondition || {}
  return {
    '__enabled': boolToJS(inner['__enabled']),
    'formula': strToJS(inner['formula']),
    'conditions': strArrToJS(inner['conditions']),
    'sameCondition': {
      'partsID': strToJS(sameCond['partsID']),
      'screenID': strToJS(sameCond['screenID'])
    },
    'else': null
  }
}

// Given a TCSidebarConditionsSection and an index,
// build and restore a JSON-ready condition object.
const restoreCond = (conditions, inner, ci, type) => {

  // Load and validate saved values
  
  const enabled = `${inner['__enabled']}` === "1"
  let formula = inner['formula'] || ""
  const entries = inner['conditions'] || []
  const sameCond = inner['sameCondition'] || {}
  let partsId = sameCond['partsID'] || ""
  let screenId = sameCond['screenID'] || ""

  if (formula.class() == "NSNull") { formula = "" }
  if (partsId.class() == "NSNull") { partsId = "" }
  if (screenId.class() == "NSNull") { screenId = "" }

  // Add and configure restored condition

  conditions.addCondition_enabled(type, enabled)
  conditions.setConditionFormula_at(formula, ci)
  let entryCount = 0
  entries.forEach((e) => {
    if (e.class() == "NSNull" || !String(e)) {
      conditions.addConditionAlphaEntry_at("", ci)
    } else {
      conditions.addConditionAlphaEntry_at(String(e), ci)
    }
    entryCount++
  })
  if (entryCount < 2) {
    conditions.addConditionAlphaEntry_at("", ci)
    if (entryCount == 0) {
      conditions.addConditionAlphaEntry_at("", ci)
    }
  }
  conditions.setConditionPartsID_at(partsId, ci)
  conditions.setConditionScreenID_at(screenId, ci)
}

// check if a layer is a valid symbol with a valid master
const isSymbolWithMaster = layer => layer.className() == "MSSymbolInstance" && layer.symbolMaster()

// Push layer into array only if it doesn't already contain given layer
const pushIfNotContains = (layer, layers) => {
  let contains = false
  layers.forEach(l => {
    if (String(l.objectID()) === String(layer.objectID())) {
      contains = true
    }
  })
  if (!contains) { layers.push(layer) }
}

// gather symbols in parent a few levels deep
const allSymbolLayersWithParents = (layer, layers, level) => {

  // if (isLayerIgnored(layer, 'metadatapanel')) { return layers }

  // // Don't recurse deeply.
  // if (!level && level !== 0) {
  //   level = 0
  // } else {
  //   level = level + 1
  // }

  // if (level > 2) { return layers }

  // if (isSymbolWithMaster(layer)) {
  //   pushIfNotContains(layer, layers)
  //   layer.symbolMaster().layers().forEach(l => { allSymbolLayersWithParents(l, layers, level) })
  // } else {
  //   layer.layers && layer.layers().forEach(l => { allSymbolLayersWithParents(l, layers, level) })
  // }

  // return layers

  // return allSymbolLayersWithParentsX(layer, layers, level)

  var xlist = MetadataUtils.getSymbolInstanceSubPartsLayersHMISpec(layer)
  for (var i = 0; i < [xlist count]; i++) {
    var item = xlist[i];
    if (nil!=item && nil!=item.layer) {
        pushIfNotContains(item.layer, layers)
    };
  };
  return layers

}

const pushIfNotContainsX = (item, items) => {
  let contains = false
  items.forEach(l => {
    if (String(l.absoluteObjectID) === String(item.absoluteObjectID)) {
      contains = true
    }
  })
  if (!contains) { items.push(item) }
}
const allSymbolLayersWithParentsX = (layer, items, level) => {

  var xlist = MetadataUtils.getSymbolInstanceSubPartsLayersHMISpec(layer)
  for (var i = 0; i < [xlist count]; i++) {
    var item = xlist[i];
    if (nil!=item) {
        pushIfNotContainsX(item, items)
    };
  };

  return items
}

// TODO - refactor this into the source of truth for loading meta
// right now just used for empty checks...
const loadMeta = (newMeta) => {

  let oldSummary = ""
  let oldRemarks = ""
  let oldPartsTypeStr = ""
  let oldScreenModeStr = ""
  let oldTextImageOutsideInputDisplayContents = ""
  let oldTextImageOutsideInputFormat = ""
  let oldTextImageOutsideInputRange = ""
  let oldTextImageValidation = ""
  let oldSwOperationPatternStr = ""
  let oldSwOperationResultScreenTransition = ""
  let oldSwOperationResultStartFunction = ""
  let oldSwOperationResultSettingValueChange = ""
  let oldSwOperationResultOther = ""
  let oldBeepStr = ""

  newMeta.forEach(m => {
    if (m.type == "Summary") {
      oldSummary = m.content || ""
    } else if (m.type == "Remarks") {
      oldRemarks = m.content || ""
    } else if (m.type == "Parts Type") {
      oldPartsTypeStr = m.content.part || ""
    } else if (m.type == "Screen Mode") {
      oldScreenModeStr = m.content.mode || ""
    } else if (m.type == "text-image-outside-input") {
      const contentType = String(m.content.type)
      if (contentType == "display-contents") {
        oldTextImageOutsideInputDisplayContents = m.content.value || ""
      } else if (contentType == "format") {
        oldTextImageOutsideInputFormat = m.content.value || ""
      } else if (contentType == "range") {
        oldTextImageOutsideInputRange = m.content.value || ""
      }
    } else if (m.type == "text-image-validation") {
      oldTextImageValidation = m.content || ""
    } else if (m.type == "sw-operation-pattern") {
      oldSwOperationPatternStr = m.content.swOperationPattern || ""
    } else if (m.type == "sw-operation-result") {
      const contentType = String(m.content.type)
      if (contentType == "screen-transition") {
        oldSwOperationResultScreenTransition = m.content.value || ""
      } else if (contentType == "start-function") {
        oldSwOperationResultStartFunction = m.content.value || ""
      } else if (contentType == "setting-value-change") {
        oldSwOperationResultSettingValueChange = m.content.value || ""
      } else if (contentType == "other") {
        oldSwOperationResultOther = m.content.value || ""
      }
    } else if (m.type == "beep") {
      oldBeepStr = m.content.beep || ""
    } 
  })

  // let oldTarget = 0
  // const selectedLayerSubSymbols = allSymbolLayersWithParents(selectedLayer, [selectedLayer])
  // selectedLayerSubSymbols.reverse()
  // selectedLayerSubSymbols.unshift(selectedLayerSubSymbols.pop())
  // selectedLayerSubSymbols.forEach((s, idx) => {
  //   if (String(s.objectID()) === String(targetObjectID)) {
  //     oldTarget = idx
  //   }
  // })

  // log("oldPartsTypeStr :" + oldPartsTypeStr + ":")
  let oldPartsType = PART_TYPES.length - 1
  PART_TYPES.forEach((pt, idx) => {
    if (pt == oldPartsTypeStr) {
      oldPartsType = idx
    }
  })

  // log("oldPartsType :" + oldPartsType + ":")
  let oldScreenMode = SCREEN_MODES.length - 1
  SCREEN_MODES.forEach((pt, idx) => {
    if (pt == oldScreenModeStr) {
      oldScreenMode = idx
    }
  })

  let oldSwOperationPattern = 0
  SW_OPERATION_PATTERNS.forEach((pt, idx) => {
    if (pt == oldSwOperationPatternStr) {
      oldSwOperationPattern = idx
    }
  })
  
  let oldBeep = 0
  BEEP_TYPES.forEach((pt, idx) => {
    if (pt == oldBeepStr) {
      oldBeep = idx
    }
  })

  const empty = !oldSummary
  && !oldRemarks
  && oldPartsType === PART_TYPES.length - 1
  && oldScreenMode === SCREEN_MODES.length - 1
  && !oldTextImageOutsideInputDisplayContents
  && !oldTextImageOutsideInputFormat
  && !oldTextImageOutsideInputRange
  && !oldTextImageValidation
  && oldSwOperationPattern === 0
  && !oldSwOperationResultScreenTransition
  && !oldSwOperationResultStartFunction
  && !oldSwOperationResultSettingValueChange
  && !oldSwOperationResultOther
  && !oldSwOperationPattern
  && oldBeep === 0
  // && !newConds

  return {
    summary: oldSummary,
    remarks: oldRemarks,
    partsTypeIndex: oldPartsType,
    screenModeIndex: oldScreenMode,
    textImageOutsideInputDisplayContents: oldTextImageOutsideInputDisplayContents,
    textImageOutsideInputFormat: oldTextImageOutsideInputFormat,
    textImageOutsideInputRange: oldTextImageOutsideInputRange,
    textImageValidation: oldTextImageValidation,
    swOperationPatternStr: oldSwOperationPatternStr,
    swOperationResultScreenTransition: oldSwOperationResultScreenTransition,
    swOperationResultStartFunction: oldSwOperationResultStartFunction,
    swOperationResultSettingValueChange: oldSwOperationResultSettingValueChange,
    swOperationResultOther: oldSwOperationResultOther,
    swOperationPatternIndex: oldSwOperationPattern,
    beepIndex: oldBeep,
    // conditions: newConds,
    empty
  }
}
