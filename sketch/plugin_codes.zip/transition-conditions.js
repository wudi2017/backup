@import 'common.js';
@import 'HelloSketch.framework/HelloSketch.js'

const TRIGGER_TYPES = [
    'Tap', 'Long Press', 'Scroll', 'Timeout', 'Outside Input'
]

var onRun = function(context) {

    // Gather up helper objects
    
    const sketch = context.api()
    const command = context.command
    const document = sketch.selectedDocument
    const page = document.selectedPage
    const pageId = String(page.id)
    const selectedLayers = context.document.selectedLayers()
    const selectedLayer = selectedLayers.firstLayer()
    const doc = context.document;
    const apiDoc = new sketch.Document(doc, new sketch.Application(context))

    // Abort if nothing (or more than one thing) is selected

    if (!selectedLayer || selectedLayers.containsMultipleLayers()) {
        return
    }

    // Abort if we can't find the selected layer's artboard

    let selectedArtboard = null
    page.sketchObject.artboards().forEach(artboard => {
        if (findObject(artboard, String(selectedLayer.objectID()))) {
            selectedArtboard = artboard
        }
    })

    if (!selectedArtboard) {
        log("No selected artboard; abort")
        return
    }

    const artboardId = String(selectedArtboard.objectID())
    const artboardName = String(selectedArtboard.name())
    const artboardFrame = selectedArtboard.frame()

    // Get all artboard names for currently selected page
    
    const pageArtboardNames = ['** No Destination **']
    page.sketchObject.artboards().forEach(artboard => {

        if (String(command.valueForKey_onLayer_forPluginIdentifier(
            'TRANSITION_CONDITION_AUTOGEN',
            artboard,
            'tmnaMM'
        )) === 'TRANSITION_CONDITION_AUTOGEN') {
            return
        }

        const artbName = String(artboard.name())
        if (artbName != artboardName) {
            pageArtboardNames.push(String(artboard.name()))
        }
    })

    // Get all subsymbols of selected layer and their names

    const selectedLayerSubSymbolNames = []
    const selectedLayerSubSymbols = allSymbolLayersWithParents(selectedLayer, [selectedLayer])
    // selectedLayerSubSymbols.reverse()
    selectedLayerSubSymbols.unshift(selectedLayerSubSymbols.pop())
    selectedLayerSubSymbols.forEach((s, idx) => {
      selectedLayerSubSymbolNames.push(String(s.name()))
    })

    // Create alert window

    const transCondAlert = TCTransitionConditionsAlert.create_targets_title_triggerTypes(
        pageArtboardNames,
        selectedLayerSubSymbolNames,
        `Transition from ${artboardName}`,
        TRIGGER_TYPES
    )

    // Gather existing transition conditions

    let metaTriggers = null
    try {
        metaTriggers = JSON.parse(command.valueForKey_onLayer_forPluginIdentifier(
            'triggers',
            page.sketchObject,
            'tmnaMM'
        )) || []
    } catch (e) {
        metaTriggers = []
    }

    const triggers = []
    const myTriggers = {}
    let myTrigger = { trigger: TRIGGER_TYPES[0] }

    metaTriggers.forEach
    && metaTriggers.forEach(t => {
        if (t.elementId == pageId) {
            myTriggers[t.trigger] = t
        } else {
            triggers.push(t)
        }
    })

    // Choose current trigger

    const chooseMyTrigger = (type) => {

        if (type) {
            if (myTriggers[type]) {
                myTrigger = myTriggers[type]
            } else {
                myTrigger = { trigger: type }
            }
            return
        }
        
        for (const i in TRIGGER_TYPES) {
            const tt = TRIGGER_TYPES[i]
            if (myTriggers[tt]) {
                myTrigger = myTriggers[tt]
                return
            }
        }
    }

    chooseMyTrigger()

    // Restore saved trigger info

    const restoreMyTrigger = () => {
        
        transCondAlert.clear()

        if (myTrigger.description) {
            transCondAlert.setDesc(myTrigger.description)
        } else {
            transCondAlert.setDesc("")
        }

        if (myTrigger.trigger) {
            transCondAlert.setTrigger(myTrigger.trigger)
        } else {
            transCondAlert.setTrigger("")
        }

        myTrigger.conditions
        && myTrigger.conditions.forEach
        && myTrigger.conditions.forEach(c => {
    
            let condRestored = false

            if (c.description
            &&  c.actions
            &&  c.actions[0]
            &&  c.actions[0].transition
            &&  c.actions[0].transition.toArtboard) {

                let targetName = null
                selectedLayerSubSymbols.forEach((s) => {
                    if (String(s.objectID()) == c.actions[0].transition.target) {
                        targetName = String(s.name())
                    }
                })
    
                let artbName = null
                page.sketchObject.artboards().forEach(artboard => {
                    if (String(artboard.objectID()) == c.actions[0].transition.toArtboard) {
                        artbName = String(artboard.name())
                    }
                })
    
                if (artbName) {
                    condRestored = true
                    transCondAlert.addCond_target_transitionTo(
                        c.description, targetName || selectedLayerSubSymbolNames[0], artbName)
                }
            }

            if (!condRestored) {
                transCondAlert.addCond_target_transitionTo(
                    c.description, selectedLayerSubSymbolNames[0], '** No Destination **')
            }
        })
    }

    restoreMyTrigger()

    // Save trigger info

    const saveMyTrigger = () => {

        myTrigger.elementId = pageId
        myTrigger.description = String(transCondAlert.getDesc())

        myTrigger.conditions = []
        for (let i=0; i<transCondAlert.getCondCount(); i++) {

            const cond = {}
            cond['id'] = uuidv4()
            cond.description = String(transCondAlert.getCondCondition(i)) || ""
            cond.actions = []

            const transTarget = String(transCondAlert.getCondTarget(i)) || ""
            let transTargetId = ""
            selectedLayerSubSymbols.forEach((s) => {
                if (String(s.name()) === transTarget) {
                    transTargetId = String(s.objectID())
                }
            })

            const transFromId = artboardId
            const transTo = String(transCondAlert.getCondTransitionTo(i)) || ""
            let transToId = ""
            page.sketchObject.artboards().forEach(artboard => {
                if (String(artboard.name()) == transTo) {
                    transToId = String(artboard.objectID())
                }
            })
            
            transToId && cond.actions.push({
                transition: {
                    fromArtboard: transFromId,
                    target: transTargetId,
                    toArtboard: transToId
                }
            })

            myTrigger.conditions.push(cond)
        }

        myTriggers[myTrigger.trigger] = myTrigger
    }

    // Listen for trigger type selection

    transCondAlert.typeChanges().setCOSJSTargetFunction(() => {
        const newType = String(transCondAlert.getTrigger())
        log("Trigger type changed to " + newType)
        saveMyTrigger()
        chooseMyTrigger(newType)
        restoreMyTrigger()
    })

    // Display modal

    const shouldSave = transCondAlert.run()

    // Save final changes to meta & create transition artboard

    if (shouldSave) {

        // First, save the selected trigger

        saveMyTrigger()

        // Delete any existing artboards connected to the selected layer via flow
        // (Save x,y location while deleting for convenient reuse)

        let createArtboardX = artboardFrame.x() + artboardFrame.width() + 50
        let createArtboardY = artboardFrame.y() + artboardFrame.height() - 100

        const removeFlowArtb = (l) => {
            const existingFlow = l.flow()
            if (existingFlow && existingFlow.destinationArtboardID()) {
                let artboardToRemove = null
                page.sketchObject.artboards().forEach(a => {
                    if (String(a.objectID()) === String(existingFlow.destinationArtboardID())) {
                        artboardToRemove = a
                    }
                })
                if (artboardToRemove) {
                    const parent = artboardToRemove.parentGroup()
                    if (parent) {
                        createArtboardX = artboardToRemove.frame().x()
                        createArtboardY = artboardToRemove.frame().y()
                        parent.removeLayer(artboardToRemove)
                    }
                }
            }
        }

        removeFlowArtb(selectedLayer)

        selectedLayer.parentGroup().layers().forEach((l) => {
            if (String(l.name()).indexOf("(TRANSITION SPEC)") !== -1) {
                removeFlowArtb(l)
                selectedLayer.parentGroup().removeLayer(l)
            }
        })

        // Next, gather up whole set of triggers to be saved

        const triggerArtbNamesUsed = []
        let triggerArtbName = ""
        let triggerArtbRows = 0

        for (const t in myTriggers) {

            const tr = myTriggers[t]

            if (!tr.description || !tr.trigger) { continue }

            if (triggerArtbNamesUsed.indexOf(tr.description) === -1) {
                if (triggerArtbName.length === 0) {
                    triggerArtbName += `${tr.description}`
                } else {
                    triggerArtbName += `,${tr.description}`
                }
                triggerArtbNamesUsed.push(tr.description)
            }

            triggerArtbRows += tr.conditions.length + 1
        }

        // If at least one trigger exists to be saved,
        // create a transition condition artboard for it

        if (triggerArtbRows > 0) {

            const triggerArtb = MSArtboardGroup.new()
            triggerArtb.setName(triggerArtbName)
            const frame = triggerArtb.frame()
            frame.setX(createArtboardX)
            frame.setY(createArtboardY)
            frame.setWidth(200)
            frame.setHeight(triggerArtbRows * 20)

            page.sketchObject.addLayer(triggerArtb)

            command.setValue_forKey_onLayer_forPluginIdentifier(
                'TRANSITION_CONDITION_AUTOGEN',
                'TRANSITION_CONDITION_AUTOGEN',
                triggerArtb,
                'tmnaMM'
            )

            let ti = 0
            for (const t in myTriggers) {

                const tr = myTriggers[t]

                if (!tr.description || !tr.trigger) { continue }

                // Create "title rows" in the artboard for each trigger type
                // i.e., "Tap", "Long Press", etc...

                const text = MSTextLayer.new()
                text.stringValue = tr.trigger
                const frame = text.frame()
                frame.setX(0)
                frame.setY(ti * 20)
                frame.setWidth(200)
                frame.setHeight(20)
                triggerArtb.addLayer(text)
                ti++

                // Create the condition rows themselves
                
                tr.conditions.forEach(c => {

                    const text = MSTextLayer.new()
                    text.stringValue = c.description
                    const frame = text.frame()
                    frame.setX(20)
                    frame.setY(ti * 20)
                    frame.setWidth(180)
                    frame.setHeight(20)

                    // If a valid destination artboard exists,
                    // connect it via flow to each condition row

                    if (c.actions
                    &&  c.actions.length > 0
                    &&  c.actions[0].transition
                    &&  c.actions[0].transition.toArtboard) {

                        let flow = MSFlowConnection.new()
                        flow.destinationArtboardID = c.actions[0].transition.toArtboard
                        text.setFlow(flow)
                        
                        let targetSubSymbol = selectedLayer
                        selectedLayerSubSymbols.forEach((s) => {
                            if (String(s.objectID()) == String(c.actions[0].transition.target)) {
                                targetSubSymbol = s
                            }
                        })

                        flow = MSFlowConnection.new()
                        flow.destinationArtboardID = String(triggerArtb.objectID())
                        if (selectedLayer === targetSubSymbol) {
                            selectedLayer.setFlow(flow)
                        } else {
                            const apiGroup = new sketch.Group(selectedLayer.parentGroup(), apiDoc)
                            const frame = targetSubSymbol.frame()
                            const shapeFrame = new sketch.Rectangle(
                                selectedLayer.frame().x() + rootOff(targetSubSymbol).x,
                                selectedLayer.frame().y() + rootOff(targetSubSymbol).y,
                                frame.width(),
                                frame.height())
                            const shape = apiGroup.newShape({ frame: shapeFrame })
                            shape.sketchObject.setName(String(targetSubSymbol.name()) + " (TRANSITION SPEC)")
                            shape.sketchObject.style().setBorders([])
                            const shapeFills = shape.sketchObject.style().setFills([])
                            shape.sketchObject.setFlow(flow)
                        }
                    }

                    triggerArtb.addLayer(text)
                    ti++
                })

                triggers.push(tr)
            }
        }

        // Finally, persist the meta

        command.setValue_forKey_onLayer_forPluginIdentifier(
            JSON.stringify(triggers),
            'triggers',
            page.sketchObject,
            'tmnaMM'
        )
    }
}

// Find an object with the given ID recursively in a layer hierarchy

const findObject = (layer, objectID) => {
    if (String(layer.objectID()) == objectID) { return layer }
    let found = null
    layer.layers && layer.layers().forEach(l => {
        const f = findObject(l, objectID)
        if (f) { found = f }
    })
    return found
}

// Generate a compliant UUIDv4

const uuidv4 = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8)
        return v.toString(16)
    });
}

// check if a layer is a valid symbol with a valid master

const isSymbolWithMaster = layer => layer.className() == "MSSymbolInstance" && layer.symbolMaster()

// Push layer into array only if it doesn't already contain given layer

const pushIfNotContains = (layer, layers) => {
  let contains = false
  layers.forEach(l => {
    if (String(l.objectID()) === String(layer.objectID())) {
      contains = true
    }
  })
  if (!contains) { layers.push(layer) }
}

// gather symbols in parent a few levels deep

const allSymbolLayersWithParents = (layer, layers, level) => {
  if (isLayerIgnored(layer, 'transition')) { return layers }

  // Don't recurse deeply.
  if (!level && level !== 0) {
    level = 0
  } else {
    level = level + 1
  }

  if (level > 2) { return layers }

  if (isSymbolWithMaster(layer)) {
    pushIfNotContains(layer, layers)
    layer.symbolMaster().layers().forEach(l => { allSymbolLayersWithParents(l, layers, level) })
  } else {
    layer.layers && layer.layers().forEach(l => { allSymbolLayersWithParents(l, layers, level) })
  }

  return layers
}

// Calculate x/y offset to the root-level parent of a given layer

const rootOff = (l) => {
    let off = { x: 0, y: 0 }
    let p = l.parentGroup()
    while (p) {
        off.x += l.frame().x()
        off.y += l.frame().y()
        l = p
        p = l.parentGroup()
    }
    return off
}
