@import 'common.js';

var onRun = function(context) {

  var cols = 'Sketch File, Page Name, Artboard Name, Artboard ID, Artboard';

  var sketch = context.api();

  var doc = context.document;
  let apiDoc = new sketch.Document(doc, new sketch.Application(context));

  var pages = doc.pages();

  let sketchDoc = sketch.selectedDocument;
  let rawDocName = removeFileExtension(sketchDoc.sketchObject.displayName());
  let docSplit = rawDocName.indexOf('(');
  let docName = rawDocName.substring(0, docSplit != -1 ? docSplit : rawDocName.lenth).replace(/\s/g,'')

  specFolder = `${NSHomeDirectory()}/rfq-specs/`;
  let filePath = `global-screen-list/${formatDate(new Date)}/`;

  exportFolder = specFolder + filePath;

  let exportOpts = {
    'use-id-for-name': true,
    formats: 'png',
    overwriting: true,
    scales: '1',
    output: exportFolder + '_export'
  }


  for (var i = 0; i < pages.count(); i++) {
    var page = pages[i];
    var pageName = page.name();
    var artboards = page.artboards();

    if (!isPageIgnored(page)) {
      for (var z = 0; z < artboards.count(); z++) {
        let artboard = artboards[z];
        let artboardName = artboard.name();
        let artboardId = String(new sketch.Artboard(artboard, doc).id);

        let userInfo = artboard.userInfo();

        if (userInfo) {
          if (userInfo.tmnaMM && userInfo.tmnaMM.TRANSITION_CONDITION_AUTOGEN) {
            break;
          }
        }

        // Export artboard
        new sketch.Artboard(artboard, apiDoc).export(exportOpts);

        cols += `\n ${docName},${pageName},${artboardName},${artboardId},${exportFolder}_export/${artboardId}.png`

      }
    }
  }

  writeTextToFile(cols, exportFolder + `${docName}--screen-list.csv`)

  doc.showMessage('Global Screen List Generated');
}
