var LOG_LEVEL_DEBUG = "debug";
var LOG_LEVEL_INFO = "info";
var LOG_LEVEL_WARN = "warn";
var LOG_LEVEL_ERROR = "error";
var LOG_LEVEL_PERFORMANCE = "performance";
var LOG_SETTING = {
    "LogSize": 50,
    "LogSizeUnit": "mb",
    "LogEnabled": true,
    "LogLevelDefault": "error",
    "LogInfo": {
        "baselog": "error",
        "importexport": "error",
        "libbase": "error"
    }
}

//用法： LogJS.debug(loggerName, logmessage)
//      LogJS.info(loggerName, logmessage)
//      LogJS.warn(loggerName, logmessage)
//      LogJS.error(loggerName, logmessage)
//      LogJS.performance(loggerName, logmessage)
class LogJS {
    static debug(logName, logInfo) {
        let loggerEnable = LOG_SETTING["LogEnabled"];
        let loggerInfo = LOG_SETTING["LogInfo"];
        
        if (loggerEnable == false) {
            return;
        }

        if (logName in loggerInfo) {
            let logger_opt = {}
            logger_opt["name"] = logName;
            logger_opt["level"] = loggerInfo[logName];

            new Logger(logger_opt).debug(logInfo);
        }
    }

    static info(logName, logInfo) {
        let loggerEnable = LOG_SETTING["LogEnabled"];
        let loggerInfo = LOG_SETTING["LogInfo"];

        if (loggerEnable == false) {
            return;
        }
        
        if (logName in loggerInfo) {
            let logger_opt = {}
            logger_opt["name"] = logName;
            logger_opt["level"] = loggerInfo[logName];
            new Logger(logger_opt).info(logInfo);
        }
    }

    static warn(logName, logInfo) {
        let loggerEnable = LOG_SETTING["LogEnabled"];
        let loggerInfo = LOG_SETTING["LogInfo"];

        if (loggerEnable == false) {
            return;
        }
        
        if (logName in loggerInfo) {
            let logger_opt = {}
            logger_opt["name"] = logName;
            logger_opt["level"] = loggerInfo[logName];
            new Logger(logger_opt).warn(logInfo);
        }
    }

    static error(logName, logInfo) {
        let loggerEnable = LOG_SETTING["LogEnabled"];
        let loggerInfo = LOG_SETTING["LogInfo"];

        if (loggerEnable == false) {
            return;
        }
        
        if (logName in loggerInfo) {
            let logger_opt = {}
            logger_opt["name"] = logName;
            logger_opt["level"] = loggerInfo[logName];
            new Logger(logger_opt).error(logInfo);
        }
    }

    static performance(logName, logInfo) {
        let loggerEnable = LOG_SETTING["LogEnabled"];
        let loggerInfo = LOG_SETTING["LogInfo"];

        if (loggerEnable == false) {
            return;
        }
        
        if (logName in loggerInfo) {
            let logger_opt = {}
            logger_opt["name"] = logName;
            logger_opt["level"] = loggerInfo[logName];
            new Logger(logger_opt).performance(logInfo);
        }
    }
}


class LogUtil {
    static getOrElse(obj, dft) {
        return typeof obj !== "undefined" ? obj : dft;
    }
    
    static getPluginDocumentDir()
    {
        var docDir = NSHomeDirectory();
        docDir = docDir + "/iauto_tmnaplugin";
    
        // init dir
        var fileManager = [NSFileManager defaultManager];
        if(![fileManager fileExistsAtPath:docDir]){
            [fileManager createDirectoryAtPath:docDir withIntermediateDirectories:true attributes:nil error:nil];
        }
    
        return docDir;
    }

    static readFileContent(filepath) {
        var fileManger = [NSFileManager defaultManager];
    
        if (![fileManger fileExistsAtPath:filepath]) {
            return null;
        }
        //read file
        var infh = [NSFileHandle fileHandleForReadingAtPath:filepath];
        if (infh) {
            var contents = [infh readDataToEndOfFile];
            var strContents = [[NSString alloc]initWithData:contents encoding:NSUTF8StringEncoding];
            [infh closeFile];
            return strContents;
        }
        else {
            return null;
        }
    }

}

class Logger {
    constructor(opts) {
        this.name = LogUtil.getOrElse(opts.name, null);
        if (this.name == '') {
            this.name = null;
        }
        this.dateFormat = "YYYY-MM-DD HH:mm:ss,SSS";
        this.logLevel = LogUtil.getOrElse(opts.level, LOG_LEVEL_ERROR);
        this.levelInts = {
            debug: 20, // default
            info:  30,
            warn:  40,
            performance: 45,
            error: 50
        };

        this.logDir = LogUtil.getPluginDocumentDir()+"/log"
        let fileManager = [NSFileManager defaultManager];
        if(![fileManager fileExistsAtPath:this.logDir]) {
            [fileManager createDirectoryAtPath:this.logDir withIntermediateDirectories:true attributes:nil error:nil];
        }
        this.logFileFullPath = null;
        if (this.name != null) {
            this.logFileFullPath = this.logDir + "/iautoplugin.log";
        }
    }

    setEnabled(isEnable) {
        this.enabled = isEnable;
    }

    setLogLevel(logLevel) {
        this.logLevel = logLevel;
    }

    getDateInfo() {
        let nowDate = new Date();
        let year_info = ''+nowDate.getFullYear();
        let month_info = ''+(nowDate.getMonth()+1);
        let day_info = ''+nowDate.getDate();
        let hour_info = ''+nowDate.getHours();
        let min_info = ''+nowDate.getMinutes();
        let second_info = ''+nowDate.getSeconds();
        let milsecond_info = ''+nowDate.getMilliseconds();
        
        let retDateInfo = this.dateFormat.replace("YYYY",year_info);
        retDateInfo = retDateInfo.replace("MM",month_info);
        retDateInfo = retDateInfo.replace("DD",day_info);
        retDateInfo = retDateInfo.replace("HH",hour_info);
        retDateInfo = retDateInfo.replace("mm",min_info);
        retDateInfo = retDateInfo.replace("ss",second_info);
        retDateInfo = retDateInfo.replace("SSS",milsecond_info);

        return retDateInfo;
    }

    logAtLevel(logLevel, logMsg) {
        if (this.name == null) {
            return;
        }

        let showMsg = this.getDateInfo();
        if (logLevel == LOG_LEVEL_DEBUG) {
            showMsg += " [DEBUG] ";
        }
        else if (logLevel == LOG_LEVEL_INFO) {
            showMsg += " [INFO] ";
        }
        else if (logLevel == LOG_LEVEL_WARN) {
            showMsg += " [WARN] ";
        }
        else if (logLevel == LOG_LEVEL_ERROR) {
            showMsg += " [ERROR] ";
        }
        else if (logLevel == LOG_LEVEL_PERFORMANCE) {
            showMsg += " [PERFORMANCE] ";
        }

        showMsg += "[";
        showMsg += this.name;
        showMsg += "]:";
        
        if (typeof logMsg === "object") {
            showMsg += JSON.stringify(logMsg);
        }
        else {
            showMsg += logMsg;
        }

        this.writeLogToFile(showMsg);
    }

    checkAndReduceLogFileSize() {
        if (this.logFileFullPath == null) {
            return;
        }
        let logContent = LogUtil.readFileContent(this.logFileFullPath)
        if (logContent == null) {
            return;
        }

        let sizeLimit = LOG_SETTING["LogSize"];
        sizeLimit = sizeLimit*1024*1024;
        
        if (logContent.length() < sizeLimit) {
            return;
        }

        logContent = logContent.substr(logContent.length()-(sizeLimit/2));

        let nsStrLog = NSString.alloc().initWithString(logContent);
        nsStrLog.writeToFile_atomically(this.logFileFullPath, true);
    }

    writeLogToFile(logMsg) {
        if (this.logFileFullPath == null) {
            return;
        }

        this.checkAndReduceLogFileSize();

        let nsStrLog = NSString.alloc().initWithString(logMsg);
        nsStrLog = nsStrLog.stringByAppendingFormat("\n");

        let filehandle = NSFileHandle.fileHandleForWritingAtPath(this.logFileFullPath)
        if(filehandle)
        {
            
            filehandle.truncateFileAtOffset(filehandle.seekToEndOfFile());
            let nsdata  = nsStrLog.dataUsingEncoding(NSUTF8StringEncoding);
            filehandle.writeData(nsdata);
            filehandle.closeFile();
        }
        else
        {
            nsStrLog.writeToFile_atomically(this.logFileFullPath, true);
        }

    }

    debug(logMsg) {
        if (this.levelInts[this.logLevel] <= this.levelInts[LOG_LEVEL_DEBUG]) {
            this.logAtLevel(LOG_LEVEL_DEBUG, logMsg);
        }
    }

    info(logMsg) {
        if (this.levelInts[this.logLevel] <= this.levelInts[LOG_LEVEL_INFO]) {
            this.logAtLevel(LOG_LEVEL_INFO, logMsg);
        }
    }

    warn(logMsg) {
        if (this.levelInts[this.logLevel] <= this.levelInts[LOG_LEVEL_WARN]) {
            this.logAtLevel(LOG_LEVEL_WARN, logMsg);
        }
    }

    error(logMsg) {
        if (this.levelInts[this.logLevel] <= this.levelInts[LOG_LEVEL_ERROR]) {
            this.logAtLevel(LOG_LEVEL_ERROR, logMsg);
        }
    }

    performance(logMsg) {
        if (this.levelInts[this.logLevel] <= this.levelInts[LOG_LEVEL_PERFORMANCE]) {
            this.logAtLevel(LOG_LEVEL_PERFORMANCE, logMsg);
        }
    }
}

