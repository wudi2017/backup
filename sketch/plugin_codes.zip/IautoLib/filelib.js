function writeTextToFile(text, fileName) {
    // log("writeTextToFile: " + text)
    var t = [NSString stringWithFormat:@"%@", text],
    f = [NSString stringWithFormat:@"%@", fileName];
    return [t writeToFile:f atomically:true encoding:NSUTF8StringEncoding error:nil];
  }

  function readFileContent(filepath)
  {
    var fileManger = [NSFileManager defaultManager];
  
      if (![fileManger fileExistsAtPath:filepath]) {
          return null;
      }
      //read file
      var infh = [NSFileHandle fileHandleForReadingAtPath:filepath];
      if (infh) {
          var contents = [infh readDataToEndOfFile];
          var strContents = [[NSString alloc]initWithData:contents encoding:NSUTF8StringEncoding];
          return strContents;
      }
      else {
          return null;
      }
  }
  
  function readJson(filepath) {
      var fileManger = [NSFileManager defaultManager];
  
      if (![fileManger fileExistsAtPath:filepath]) {
          return null;
      }
      //read file
      var infh = [NSFileHandle fileHandleForReadingAtPath:filepath];
      if (infh) {
          var contents = [infh readDataToEndOfFile];
          var strContents = [[NSString alloc]initWithData:contents encoding:NSUTF8StringEncoding];
          try {
              var configstr = JSON.parse(strContents)
              [infh closeFile];
              return configstr;
          } catch(e) {
              [infh closeFile];
              return null;
          }
      }
      else {
          return null;
      }
  }
  
  function fileExists(filepath) {
      var fileManger = [NSFileManager defaultManager];
      if (![fileManger fileExistsAtPath:filepath]) {
          return false;
      }
  
      return true;
  }
  
  function deleteFile(filepath) {
      var fileManager = [NSFileManager defaultManager];
      if ([fileManager fileExistsAtPath:filepath]) {
          fileManager.removeItemAtPath_error(filepath, nil);
      }
  }

  function createDirectory(dirpath) {
    var fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:dirpath]) {
        return;
    }
    [fileManager createDirectoryAtPath:dirpath withIntermediateDirectories:true attributes:nil error:nil];
  }