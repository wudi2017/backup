function getSketchIAutoPluginDocumentDir()
{
    var docDir = NSHomeDirectory();
    docDir = docDir + "/sketchplugin_iauto";

    // init dir
    var fileManager = [NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:docDir]){
        [fileManager createDirectoryAtPath:docDir withIntermediateDirectories:true attributes:nil error:nil];
    }

    return docDir;
}

function runCommand(exeCmd, argsList = null, envdict = null) {
    task = [[NSTask alloc] init];
    [task setLaunchPath:exeCmd];
    if (argsList) {
        [task setArguments:argsList];
    }

    if (envdict != null) {
        task.setEnvironment(envdict);
    }

    pipe = [NSPipe pipe];
    [task setStandardOutput:pipe];
    [task setStandardError:pipe];
    [task launch];
    
    file = [pipe fileHandleForReading];
    data = [file readDataToEndOfFile]
    retdata = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]
    // console.log(retdata.trim())

    return retdata.trim()
}

function exportLayerTofile(context,layer,savePath,name = -1) {
    if (layer.class() == MSSliceLayer) {
        var slice = layer
    } else {
        var slice = MSExportRequest.exportRequestsFromExportableLayer(layer).firstObject()
    }
    if(name == -1){
        name = layer.name();
    }
    var options =  {
            path: savePath,
            scale: 1,
            name: name,
            prefix: "",
            suffix: "",
            format: 'png'
        },
        document = context.document,
        savePathName = [];

    slice.scale = options.scale;
    slice.format = options.format;

    savePathName.push(
            options.path,
            "/",
            options.prefix,
            options.name,
            options.suffix,
            ".",
            options.format
        );
    savePathName = savePathName.join("");
    document.saveArtboardOrSlice_toFile(slice, savePathName);
}

function isConditionArtboard(artboard)
{
    if(artboard.frame().width() < 400 || artboard.frame().height() < 150)
    {
        return true;
    }
    else
    {
        return false;
    }
}

function toJSString(str){
    return new String(str).toString();
}

function toSlug(str)
{
    return toJSString(str)
            .toLowerCase()
            .replace(/(<([^>]+)>)/ig, "")
            .replace(/[\/\+\|]/g, " ")
            .replace(new RegExp("[\\!@#$%^&\\*\\(\\)\\?=\\{\\}\\[\\]\\\\\\\,\\.\\:\\;\\']", "gi"),'')
            .replace(/\s+/g,'-')
            .replace(/-/g,'_')
            ;
}

function removeBlankspace(str)
{
    return toJSString(str)
            .replace(/\s+/g,'')
            ;
}

function  addSpace(tab){
    var tabSpace = "";
    for (var i = 0; i < tab; i++) {
        tabSpace += "    ";
    }
    return tabSpace;
}

function jsonFomat(jsonStr) 
{
    var t = "";
    var tab = "";
    var inString = false;
    for (var i = 0, len = jsonStr.length; i < len; i++) {
        var c = jsonStr.charAt(i);
        if (inString && c === inString) {
            if (jsonStr.charAt(i - 1) !== '\\') {
                inString = false;
            }
        } else if (!inString && (c === '"' || c === "'")) {
            inString = c;
        } else if (!inString && (c === ' ' || c === "\t")) {
            c = '';
        } else if (!inString && c === ':') {
            c += ' ';
        } else if (!inString && c === ',') {
            c += "\n" + addSpace(tab);
        } else if (!inString && (c === '[' || c === '{')) {
            tab++;
            c += "\n" + addSpace(tab);
        } else if (!inString && (c === ']' || c === '}')) {
            tab--;
            c = "\n" + addSpace(tab) + c;
        }
            
        t+= c;
    }
    
    return t;
};

function getTMAHMISpecInfo(symbol_id, binding_dict) {
    for (let iartboard in binding_dict) {
        let symbol_dict = {}
        if (symbol_id in binding_dict[iartboard]) {
            symbol_dict = binding_dict[iartboard][symbol_id]
            for (let part_id in symbol_dict) {
                return symbol_dict[part_id]
            }
        }
    }

    return null
}

function getDestGradeInfo(artboard_id, binding_dict) {
    if (artboard_id in binding_dict) {
        return binding_dict[artboard_id]["DestGradeInfo"]
    }

    return null;
}

function showAlert(bodyInfo)
{
    var alert = [NSAlert new];
    [alert addButtonWithTitle:@"OK"];
    [alert setMessageText:@"Alert"];
    [alert setInformativeText:bodyInfo];
    [alert setAlertStyle:NSWarningAlertStyle];

    var mr = [alert runModal];
    if (1000 == mr) {
      return "OK"
    }
    else
    {
      return "UNKNOWN";
    }
}

function getAllArtboardGroup(layer_info, grouplist) 
{
    if (layer_info.class() == MSLayerGroup) {
        grouplist.push(layer_info)
    }

    if(layer_info.class() == MSArtboardGroup || layer_info.class() == MSLayerGroup)
    {
        var subLayers = layer_info.layers()
        for(var idxSub=0; idxSub<subLayers.count(); idxSub++)
        {
            var sublayer = subLayers[idxSub];
            getAllArtboardGroup(sublayer, grouplist)
        }
    }
}

//start from 1
function convertNumToStr(num_info) {
    let columnStr = ""
    let letter_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    let num_index = num_info-1

    do {
        if (columnStr.length > 0) {
            num_index = num_index-1
        }
        columnStr = letter_list[num_index % 26] + columnStr
        num_index = (num_index - num_index % 26) / 26;

    } while(num_index > 0 )

    return columnStr
}

function convertStrToNum(columnStr) {
    var letter_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    var length = columnStr.length;
    var value = 0;
    for(var num=0;num<length;num++){
        var curstrChar = columnStr[num];
        if('A' <= curstrChar && curstrChar >= 'Z'){
            var curstrIndex = letter_list.indexOf(curstrChar);
            value = value*26 + curstrIndex + 1
        }
        else{
            return -1;
        }
    }
    return value;
}

function getArtboardRegionInfo(artboard_info) {
    let retinfo = "Global"

    let artboard_name = ""+artboard_info.name()
    if (artboard_name.indexOf("_JP/")>=0) {
        return "JP"
    }
    else if (artboard_name.indexOf("_EU/")>=0) {
        return "EU"
    }
    else if (artboard_name.indexOf("_OTHER/")>=0) {
        return "OTHER"
    }

    return retinfo
}

function getPageRegionInfo(page_info) {
    let retinfo = "Global"

    let page_name = ""+page_info.name()
    if (page_name.indexOf("_JP")==0) {
        return "JP"
    }
    else if (page_name.indexOf("_EU")==0) {
        return "EU"
    }
    else if (page_name.indexOf("_OTHER")==0) {
        return "OTHER"
    }

    return retinfo
}