function showMessageButton1(type, title, content, btn1)
{
  var alert = [NSAlert new];
  [alert addButtonWithTitle:btn1];
  [alert setMessageText:title];
  [alert setInformativeText:content];
  [alert setAlertStyle:type]; // NSWarningAlertStyle NSAlertStyleCritical
  [alert runModal];
}
function showMessageButton2(type, title, content, btn1, btn2)
{
  var alert = [NSAlert new];
  [alert addButtonWithTitle:btn1];
  [alert addButtonWithTitle:btn2];
  [alert setMessageText:title];
  [alert setInformativeText:content];
  [alert setAlertStyle:type]; // NSWarningAlertStyle NSAlertStyleCritical
  [alert runModal];
}
function showMessageWarning(content)
{
  showMessageButton1(NSWarningAlertStyle, "Warning", content, "OK")
}
function showMessageError(content)
{
  showMessageButton1(NSAlertStyleCritical, "Error", content, "OK")
}