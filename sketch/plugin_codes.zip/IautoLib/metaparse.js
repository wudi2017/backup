function getMetaByType(meta_data, data_type) {
    var retobj = null;

    if (meta_data == null) {
        return retobj;
    }    

    meta_data.forEach(imetadata => {
        if (imetadata.type == data_type) {
            retobj = imetadata;
        }
     })

    return retobj
}

function getMetaSummary(meta_data) {
    let retobj = getMetaByType(meta_data, "Summary")
    if (retobj == null) {
        return ""
    }

    return ""+retobj.content
}

function getMetaRemarks(meta_data) {
    let retobj = getMetaByType(meta_data, "Remarks")
    if (retobj == null) {
        return ""
    }

    return ""+retobj.content
}

function getPartsType(meta_data) {
    let retobj = getMetaByType(meta_data, "Parts Type")
    if (retobj == null) {
        return ""
    }
    if (retobj.content.part == "Select Part Type") {
        return ""
    }

    return ""+retobj.content.part
}

function getTextImgDispContent(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "text-image-outside-input" && imetadata.content.type == "display-contents") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getTextImgFormat(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "text-image-outside-input" && imetadata.content.type == "format") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getTextImgRange(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "text-image-outside-input" && imetadata.content.type == "range") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getTextImgValidation(meta_data) {
    let retobj = getMetaByType(meta_data, "text-image-validation")
    if (retobj == null) {
        return ""
    }

    return ""+retobj.content
}

function getSWOpePattern(meta_data) {
    let retobj = getMetaByType(meta_data, "sw-operation-pattern")
    if (retobj == null) {
        return ""
    }

    return ""+retobj.content["id"]
}

function getBeepInfo(meta_data) {
    let retobj = getMetaByType(meta_data, "beep")
    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.beep
}

function getOpeResultScreenTrans(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "sw-operation-result" && imetadata.content.type == "screen-transition") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getOpeResultStartFunc(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "sw-operation-result" && imetadata.content.type == "start-function") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getOpeResultSettingValueChange(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "sw-operation-result" && imetadata.content.type == "setting-value-change") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getOpeResultOther(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    meta_data.forEach(imetadata => {
        if (imetadata.type == "sw-operation-result" && imetadata.content.type == "other") {
            retobj = imetadata;
        }
     })

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getConditionDict(con_meta_data, layer_info, con_name) {
    let con_key = con_name+"__"+layer_info.objectID();
    var conletters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    
    var ret_data_dict = {}
    ret_data_dict["Formula"] = ""
    ret_data_dict["Condition"] = {}
    ret_data_dict["Same Condition"] = {}
    ret_data_dict["Same Condition"]["Parts ID"] = ""
    ret_data_dict["Same Condition"]["Screen ID"] = ""
    ret_data_dict["else"] = ""

    if (con_meta_data == null) {
        return ret_data_dict
    }

    let con_obj = con_meta_data[con_key]
    if (con_obj == null) {
        return ret_data_dict
    }

    ret_data_dict["Formula"] = ""+con_obj.formula
    ret_data_dict["Same Condition"]["Parts ID"]= ""+con_obj.sameCondition.partsID
    ret_data_dict["Same Condition"]["Screen ID"]= ""+con_obj.sameCondition.screenID
    ret_data_dict["else"] = ""+con_obj.else
    if (ret_data_dict["else"].indexOf("null")>=0) {
        ret_data_dict["else"]=""
    }
    if (ret_data_dict["Formula"].indexOf("null")>=0) {
        ret_data_dict["Formula"]=""
    }
    if (ret_data_dict["Same Condition"]["Parts ID"].indexOf("null")>=0) {
        ret_data_dict["Same Condition"]["Parts ID"]=""
    }
    if (ret_data_dict["Same Condition"]["Screen ID"].indexOf("null")>=0) {
        ret_data_dict["Same Condition"]["Screen ID"]=""
    }

    var iletter = 0;
    con_obj.conditions.forEach(icon => {
        iletter = iletter % 26
        let nowLetter = conletters[iletter]
        ret_data_dict["Condition"][nowLetter] = ""+icon
        iletter = iletter+1
     })

    return ret_data_dict
    
}

function getConditionData(json_data) {
    var resCondition = {};
    resCondition["__enabled"] = "1";
    resCondition["conditions"] = [];
    resCondition["else"] = "null"
    resCondition["formula"] = "null"
    resCondition["sameCondition"] = {}
    resCondition["sameCondition"]["partsID"] = "null"
    resCondition["sameCondition"]["screenID"] = "null"
    if(json_data){
        if(json_data["else"] && json_data["else"] != ""){
            resCondition["else"] = json_data["else"];
        }
        if(json_data["Same Condition"] && json_data["Same Condition"]["Parts ID"] && json_data["Same Condition"]["Parts ID"] != ""){
            resCondition["sameCondition"]["partsID"] = json_data["Same Condition"]["Parts ID"];
        }
        if(json_data["Same Condition"] && json_data["Same Condition"]["Screen ID"] && json_data["Same Condition"]["Screen ID"] != ""){
            resCondition["sameCondition"]["screenID"] = json_data["Same Condition"]["Screen ID"];
        }
        if(json_data["Formula"] && json_data["Formula"] != ""){
            resCondition["formula"] = json_data["Formula"];
        }
        if(json_data["Condition"]){
            for(var key in json_data["Condition"]){
                var value = json_data["Condition"][key];
                resCondition["conditions"].push(value);
            }
        }
    }
    return resCondition
}

