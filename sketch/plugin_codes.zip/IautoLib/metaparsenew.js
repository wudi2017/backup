function getMetaSummaryforJson(meta_data) {
    if (meta_data == null) {
        return "";
    } 
    let retobj = meta_data["Summary"]
    if (retobj == null) {
        return ""
    }

    return ""+retobj
}

function getMetaRemarksforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }
    let retobj = meta_data["Remarks"]
    if (retobj == null) {
        return ""
    }

    return ""+retobj
}

function getPartsTypeforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }
    let retobj = meta_data["Parts Type"]
    if (retobj == null) {
        return ""
    }
    if (retobj.part == "Select Part Type") {
        return ""
    }

    return ""+retobj["part"]
}

function getTextImgDispContentforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["text-image-outside-input"] && meta_data["text-image-outside-input"]["type"] == "display-contents")
    {
        retobj = meta_data["text-image-outside-input"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.value
}

function getTextImgFormatforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["text-image-outside-input"] && meta_data["text-image-outside-input"]["type"] == "format")
    {
        retobj = meta_data["text-image-outside-input"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.value
}

function getTextImgRangeforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["text-image-outside-input"] && meta_data["text-image-outside-input"]["type"] == "range")
    {
        retobj = meta_data["text-image-outside-input"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.value
}

function getTextImgValidationforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }
    let retobj = meta_data["text-image-validation"]
    if (retobj == null) {
        return ""
    }

    return ""+retobj
}

function getSWOpePatternforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }
    let retobj = meta_data["sw-operation-pattern"]
    if (retobj == null) {
        return ""
    }

    return ""+retobj["id"]
}

function getBeepInfoforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }
    let retobj = meta_data["beep"]
    if (retobj == null) {
        return ""
    }

    return ""+retobj.beep
}

function getOpeResultScreenTransforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["sw-operation-result"] && meta_data["text-image-outside-input"]["type"] == "screen-transition")
    {
        retobj = meta_data["sw-operation-result"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.value
}

function getOpeResultStartFuncforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["sw-operation-result"] && meta_data["text-image-outside-input"]["type"] == "start-function")
    {
        retobj = meta_data["sw-operation-result"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.value
}

function getOpeResultSettingValueChangeforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["sw-operation-result"] && meta_data["text-image-outside-input"]["type"] == "setting-value-change")
    {
        retobj = meta_data["sw-operation-result"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.content.value
}

function getOpeResultOtherforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }    

    var retobj = null;
    if(meta_data["sw-operation-result"] && meta_data["text-image-outside-input"]["type"] == "other")
    {
        retobj = meta_data["sw-operation-result"];
    }

    if (retobj == null) {
        return ""
    }

    return ""+retobj.value
}

function getTargetIDformMetaforJson(meta_data) {
    if (meta_data == null) {
        return "";
    }
    let retobj = meta_data["Target"]
    if (retobj == null) {
        return ""
    }
    return ""+retobj
}

