@import 'common.js';
@import 'redlines.js';

var onRun = function(context) {
  let sketch = context.api();
  let doc = context.document;

  let allArtboards = []

  doc.pages().forEach(page => {
    if (isPageIgnored(page)) return
    page.artboards().forEach(artboard => {
      var layers = allSymbolLayersWithParents(artboard, [])

      // Sketch orders layers descending, so we need to reverse
      layers.reverse();

      let allSymbols = { }
      // add layers in Y-axis order to map of { 'symbol master name': { symbol, partId } }
      layers.forEach(layerAndParent => { putIfLowerY(allSymbols, layerAndParent) })
      // push tuple of symbol map and artboard onto list
      allArtboards.push({ allSymbols,  artboard })

      // Reset layers to original order
      layers.reverse();
    })
  })

  let apiApp = new sketch.Application(context)
  let apiDoc = new sketch.Document(doc, new sketch.Application(context))
  let tempText = [];
  let tempTextBg = [];
  let tempShape = [];

  // ---- Automated Export Data
  let sketchDoc = sketch.selectedDocument;
  let rawDocName = removeFileExtension(sketchDoc.sketchObject.displayName());
  let docSplit = rawDocName.indexOf('(');
  let docName = rawDocName.substring(0, docSplit != -1 ? docSplit : rawDocName.lenth).replace(/\s/g,'')

  specFolder = `${NSHomeDirectory()}/rfq-specs/`;
  let filePath = `screen-spec/${docName}/${formatDate(new Date)}/`;

  exportFolder = specFolder + filePath;
  // ---- Automated Export Data


  // var exportedOnce = false
  allArtboards.forEach(allSymbolsAndArtboard => {
    let allSymbols = allSymbolsAndArtboard.allSymbols;
    let artboard = allSymbolsAndArtboard.artboard;
    let artboardId = String(new sketch.Artboard(artboard, doc).id);

    const underscoredArtboardName = artboard.name()
    .split('/').map(str => str.trim().toLowerCase()).join('_').replace(/ /g, '_');

    var exportOpts = {
      'use-id-for-name': true,
      formats: 'png',
      overwriting: true,
      scales: '1',
      'group-contents-only': true,
      output: exportFolder + underscoredArtboardName
    }

    // ---- CSV Definitions
    let screenImageCols = `Screen Image, \n ${exportFolder}${underscoredArtboardName}/_export/${artboardId}.png`;
    let partsSpecCols = 'Parts ID, UUID, Display Image, Parts Type, Parts Name, US English';
    let outsideInputCols = 'Display Contents, Format, Range';
    let textImageValidationCols = 'Validation';
    let swOperationPatternCols = 'SW Operation Pattern';
    let swOperationResultCols = 'Screen Transition, Start Function, Setting Value Change, Other';
    let beepCols = 'Beep';
    // ---- CSV Definitions

    // ---- JSON Definitions
    let displayConditions = { "displayConditions": [] };
    let textOrImageDeleteConditionInMotion = { "textOrImageDeleteConditionInMotion": [] };
    let SWTonedownConditionInMotion = { "SWTonedownConditionInMotion": [] };
    let SWTonedownConditionExceptInMotion = { "SWTonedownConditionExceptInMotion": [] };
    let SWSelectedCondition = { "SWSelectedCondition": [] };
    // ---- JSON Definitions

    for (s in allSymbols) {
      let sym = allSymbols[s]
      const symbolId = String(sym.symbol.objectID())
      sym.textValues = [];
      let symParent = sym.symbolParent
      let partId = sym.partId
      let frame = sym.rootLayer ? sym.rootLayer.frame() : sym.symbol.frame()
      let addX = sym.rootLayer ? sym.symbol.frame().x() : 0
      let addY = sym.rootLayer ? sym.symbol.frame().y() : 0
      let apiGroup = new sketch.Group(symParent, apiDoc);

      let libraryUserInfo = sym.symbol.symbolMaster().userInfo();
      let partType = getPartsType(libraryUserInfo);

      // ---- Export Symbol
        var symbolExportOpts = Object.assign({}, exportOpts);

        symbolExportOpts.output = symbolExportOpts.output + "/_export";

        exportLayer(sym.symbol, symbolExportOpts);
      // ---- Export Symbol

      // ---- Text
      let bg = new sketch.Rectangle(
        frame.x() + addX,
        frame.y() + addY,
        24,
        24);
      let textBg = apiGroup.newShape({ frame: bg });
      let textBgBorders = textBg.sketchObject.style().setBorders([]);

      var fill = MSStyleFill.new();
      fill.setColor_(MSColor.rgbColorRed_green_blue(255, 0, 0));
      fill.setFillType_(0);
      fill.enabled = true;
      textBg.sketchObject.style().setFills([fill]);

      tempTextBg.push(textBg);

      if (sym.partId >= 1000) {
        partId = letters[partId - 1000]
      }

      let text = apiGroup.newText({
        text: `${partId}`,
        alignment: 2,
        fixedWidth: true
      });

      text.frame = bg;

      let textStyle = text.sketchObject.style().textStyle();
      // textstyle consists of a dictionary of attributes, take a mutable copy of that dictionary
      let mutableTextAttributes = NSMutableDictionary.dictionaryWithDictionary(textStyle.attributes());
      // set the NSColor key for the attributes dictionary
      mutableTextAttributes.setObject_forKey(NSColor.colorWithRed_green_blue_alpha(1, 1, 1, 1), 'NSColor');
      mutableTextAttributes.setObject_forKey(NSFont.systemFontOfSize(18.0), 'NSFont');

      // write the attributes dictionary back onto the textstyle (and we're done)
      textStyle.setValue_forKey_(mutableTextAttributes, 'attributes');

      tempText.push(text);

      MSLayerMovement.moveToFront([text._object]);
      // ---- Text


      // ---- Shape
      let shapeFrame = new sketch.Rectangle(
        frame.x() + addX,
        frame.y() + addY,
        sym.symbol.frame().width(),
        sym.symbol.frame().height());
      let shape = apiGroup.newShape({ frame: shapeFrame });
      let shapeFills = shape.sketchObject.style().setFills([]);

      var border = MSStyleBorder.new()
      border.setColor_(MSColor.rgbColorRed_green_blue(255, 0, 0))
      border.setFillType_(0)
      border.enabled = true
      shape.sketchObject.style().setBorders([border])

      tempShape.push(shape);
      // ---- Shape


      // ---- Create Array of Text Override Values
        let overrideValues = sym.symbol.overrideValues();

        overrideValues.forEach(val => {
          let isStringValue = val.overrideName().includes('stringValue');

          if (isStringValue) {
            sym.textValues.push(val.value());
          }
        });
      // ---- Create Array of Text Override Values



      // ---- Create Parts Spec CSV
      partsSpecCols += `\n ${partId},${symbolId},${exportFolder}${underscoredArtboardName}/_export/${symbolId}.png,${partType ? partType : ''},${sym.symbol.name()},${sym.textValues.join(' | ')}`;
      // ---- Create Parts Spec CSV

      // ---- Populate Outside Input CSV
      if (sym.rootLayer) {
        var rootInfo = sym.rootLayer.userInfo();

        var thisChildsMetadata = getChildsMetadata(rootInfo, symbolId);

        if (thisChildsMetadata) {
          var outsideInputs = filter(thisChildsMetadata.content.metadata, (data) => data.type == 'text-image-outside-input');

          outsideInputCols += `\n ${getNestedMetaFromArray('display-contents', outsideInputs)}, ${getNestedMetaFromArray('format', outsideInputs)}, ${getNestedMetaFromArray('range', outsideInputs)}`;
        } else {
          outsideInputCols += "\n -, -, -";
        }
      } else {
        outsideInputCols += "\n -, -, -";
      }
      // ---- Populate Outside Input CSV


      // ---- Populate Text / Image Validation
      if (sym.rootLayer) {
        var rootInfo = sym.rootLayer.userInfo();

        var thisChildsMetadata = getChildsMetadata(rootInfo, symbolId);

        if (thisChildsMetadata) {
          var validation = thisChildsMetadata.content.metadata.find((data) => data.type == 'text-image-validation');

          textImageValidationCols += `\n ${validation ? validation.content : '-'}`;
        } else {
          textImageValidationCols += '\n -';
        }
      } else {
        textImageValidationCols += '\n -';
      }
      // ---- Populate Text / Image Validation


      // ---- Populate SW Operation Pattern
      if (sym.rootLayer) {
        var rootInfo = sym.rootLayer.userInfo();

        var thisChildsMetadata = getChildsMetadata(rootInfo, symbolId);

        if (thisChildsMetadata) {
          var swOperationPattern = thisChildsMetadata.content.metadata.find((data) => data.type == 'sw-operation-pattern');
          let val = '-';

          if (swOperationPattern) {
            if (swOperationPattern.content.swOperationPattern == 'Select SW Operation') {
              val = '-'
            } else {
              val = swOperationPattern.content.swOperationPattern;
            }
          }

          swOperationPatternCols += `\n ${val}`;
        } else {
          swOperationPatternCols += '\n -';
        }
      } else {
        swOperationPatternCols += '\n -';
      }
      // ---- Populate SW Operation Pattern


      // ---- Populate SW Operation Result
      if (sym.rootLayer) {
        var rootInfo = sym.rootLayer.userInfo();

        var thisChildsMetadata = getChildsMetadata(rootInfo, symbolId);

        if (thisChildsMetadata) {
          var swOperationResult = filter(thisChildsMetadata.content.metadata, (data) => data.type == 'sw-operation-result');

          swOperationResultCols += `\n ${getNestedMetaFromArray('screen-transition', swOperationResult)}, ${getNestedMetaFromArray('start-function', swOperationResult)}, ${getNestedMetaFromArray('setting-value-change', swOperationResult)}, ${getNestedMetaFromArray('other', swOperationResult)}`;
        } else {
          swOperationResultCols += '\n -';
        }
      } else {
        swOperationResultCols += '\n -';
      }
      // ---- Populate SW Operation Result


      // ---- Populate Beep
      if (sym.rootLayer) {
        var rootInfo = sym.rootLayer.userInfo();

        var thisChildsMetadata = getChildsMetadata(rootInfo, symbolId);

        if (thisChildsMetadata) {
          var beep = thisChildsMetadata.content.metadata.find((data) => data.type == 'beep');
          let val = '-';

          if (beep) {
            if (beep.content.beep == 'Select Beep Type') {
              val = '-'
            } else {
              val = beep.content.beep;
            }
          }

          beepCols += `\n ${val}`;
        } else {
          beepCols += '\n -';
        }
      } else {
        beepCols += '\n -';
      }
      // ---- Populate Beep


      // ---- Populate conditions JSON
      if (sym.rootLayer) {
        buildConditionalJSON(sym.rootLayer.userInfo(), symbolId, 'displayCondition', displayConditions.displayConditions);
        buildConditionalJSON(sym.rootLayer.userInfo(), symbolId, 'textImageDeleteInMotion', textOrImageDeleteConditionInMotion.textOrImageDeleteConditionInMotion);
        buildConditionalJSON(sym.rootLayer.userInfo(), symbolId, 'sWTonedownMotion', SWTonedownConditionInMotion.SWTonedownConditionInMotion);
        buildConditionalJSON(sym.rootLayer.userInfo(), symbolId, 'sWTonedownExceptInMotion', SWTonedownConditionExceptInMotion.SWTonedownConditionExceptInMotion);
        buildConditionalJSON(sym.rootLayer.userInfo(), symbolId, 'sWSelected', SWSelectedCondition.SWSelectedCondition);
      }
      // ---- Populate conditions JSON

    }

    // ---- Create Screen Spec CSV
      let screenSpecCols = 'Screen Spec,';

      screenSpecCols += `\n Screen ID, ${String(new sketch.Artboard(artboard, doc).id)}`;
      screenSpecCols += `\n Basic Screen ID, TODO`;
      screenSpecCols += `\n Screen Name, ${artboard.name()}`;
      screenSpecCols += `\n Notes:, "${getSummary(artboard.userInfo())}"`

      writeTextToFile(screenSpecCols, exportOpts.output + '/screen-spec.csv');
    // ---- Create Screen Spec CSV

    // ---- Create Screen Image CSV
      new sketch.Artboard(artboard, apiDoc).export(symbolExportOpts)

      writeTextToFile(screenImageCols, exportOpts.output + '/screen-image.csv');
    // ---- Create Screen Image CSV

    // ---- Create Parts Spec CSV
      writeTextToFile(partsSpecCols, exportOpts.output + '/parts-spec.csv');
    // ---- Create Parts Spec CSV

    // ---- Create Outside Inputs CSV
      writeTextToFile(outsideInputCols, exportOpts.output + '/outside-input.csv');
    // ---- Create Outside Inputs CSV

    // ---- Create Text / Image Validation CSV
      writeTextToFile(textImageValidationCols, exportOpts.output + '/text-image-validation.csv');
    // ---- Create Text / Image Validation CSV

    // ---- Create SW Operation Pattern CSV
      writeTextToFile(swOperationPatternCols, exportOpts.output + '/sw-operation-pattern.csv');
    // ---- Create SW Operation Pattern CSV

    // ---- Create SW Operation Pattern CSV
      writeTextToFile(swOperationResultCols, exportOpts.output + '/sw-operation-result.csv');
    // ---- Create SW Operation Pattern CSV

    // ---- Create Beep CSV
      writeTextToFile(beepCols, exportOpts.output + '/beep.csv');
    // ---- Create Beep CSV

    // ---- Create JSON Files
      writeTextToFile(JSON.stringify(displayConditions, null, 2), exportOpts.output + '/display-conditions.json');
      writeTextToFile(JSON.stringify(textOrImageDeleteConditionInMotion), exportOpts.output + '/text-or-image-delete-condition-in-motion.json');
      writeTextToFile(JSON.stringify(SWTonedownConditionInMotion), exportOpts.output + '/sw-tonedown-condition-in-motion.json');
      writeTextToFile(JSON.stringify(SWTonedownConditionExceptInMotion), exportOpts.output + '/sw-tonedown-condition-except-in-motion.json');
      writeTextToFile(JSON.stringify(SWSelectedCondition), exportOpts.output + '/sw-selected-condition.json');
    // ---- Create JSON Files


  });

  tempText.forEach(text => text.remove());
  tempTextBg.forEach(textBg => textBg.remove());
  tempShape.forEach(shape => shape.remove());

  doc.showMessage('Screen Spec Generated');
}
