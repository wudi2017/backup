@import "common.js"
@import "IautoLib/filelib.js"
@import "IautoLib/iautolib.js"

function GenerateSymbols(context) {
    var generatesymbolsObj = new generatesymbols(context);
    generatesymbolsObj.initExpandSymbolsConfig();
    generatesymbolsObj.makeExpandInfo();
}

function generatesymbols(context) {
    var openPanel = NSOpenPanel.openPanel();
    [openPanel setCanChooseDirectories:true]; //Can open the directory
    [openPanel setCanChooseFiles:0]; //Can only select directory and can not select file
    [openPanel setDirectory:NSHomeDirectory()]; //The default directory is $home
    [openPanel setPrompt: @"Export"];
    if (openPanel.runModal() != NSOKButton) {
        return false;
    }
    var selected_path = openPanel.URL().path();
    var work_result_dir = ""+selected_path + "/___exportspecs___";
    createDirectory(selected_path+"/images");
    this.exportFilePath = ""+selected_path+"/symbolexpand.json";
    this.exportImagePath = ""+selected_path+"/images";
    var script_full_filename = context.scriptPath;
    var sketchPluginPath = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
    //var sketchPluginPath = "/Users/wuyuchi/Documents/milestone/sketchplugin/tmna-multimedia-iauto.sketchplugin";
    this.symbolExpandConfilePath = sketchPluginPath + "/IautoConfig/symbolexpand.json";
    this.jarPath = sketchPluginPath+"/IautoScripts/GenSymbolList.jar"
    this.xlsResultFile = ""+selected_path+"/symbollist.xlsx"

    this.symbolExpandConfileContent = nil;
    this.context = context;
    //this.currentPage = context.document.documentData().currentPage();
    if (fileExists(this.symbolExpandConfilePath)) {
        this.symbolExpandConfileContent = readJson(this.symbolExpandConfilePath);
    }
    this.curSymbolsExpandInfo = {};
    this.currentPageID = nil;
    this.symbolexpandConfig = nil;
}

generatesymbols.prototype.makeExpandInfo = function() {
    if(this.context){
        for(var pageNum=0;pageNum<this.context.document.pages().length;pageNum++) 
        {
            var currentPage = this.context.document.pages()[pageNum];
            this.currentPageID = currentPage.objectID();
            this.curSymbolsExpandInfo[this.currentPageID] = {}
            this.curSymbolsExpandInfo[this.currentPageID]["name"] = ""+currentPage.name();
            var artboardsInfo = {}
            this.curSymbolsExpandInfo[this.currentPageID]["layers"] = artboardsInfo;
            for(var artNum=0;artNum<currentPage.artboards().length;artNum++){
                var curArtboard = currentPage.artboards()[artNum];
                if(!this.checkArtboardIsNeedImport(curArtboard)){
                    continue;
                }
                var curArtboardID = curArtboard.objectID();
                var symbolsInfo = {}
                artboardsInfo[curArtboardID] = {}
                artboardsInfo[curArtboardID]["name"] = ""+curArtboard.name();
                artboardsInfo[curArtboardID]["layers"] = symbolsInfo;
                var prexKey = ""+this.currentPageID+"_"+curArtboardID
                var allChilds = this.getAllSymbolInstance4Artboard(curArtboard);
                this.getDetailExpandInfo(allChilds,symbolsInfo,prexKey);
            }
            var expandInfoStr = jsonFomat(JSON.stringify(this.curSymbolsExpandInfo));
            writeTextToFile(expandInfoStr, this.exportFilePath);
        }

        let params = []
        params.push("-jar");
        params.push("-Xms1g");
        params.push("-Xmx4g");
        params.push(this.jarPath);
        params.push(this.exportFilePath);
        params.push(this.xlsResultFile);
        runCommand("/usr/bin/java", params);
    }
}

generatesymbols.prototype.getDetailExpandInfo = function(layers,InfoContant,prexKey) {
    for(var childNum=0;childNum<layers.length;childNum++){
        var curNodeLayer = layers[childNum];
        if(this.checkIsNeedImport(curNodeLayer)){
            var curNodeLayerID = curNodeLayer.objectID();
            var curNodeKey = prexKey+"_"+curNodeLayerID
            InfoContant[curNodeLayerID] = {};
            InfoContant[curNodeLayerID]["name"] = ""+curNodeLayer.name();
            if(this.symbolexpandConfig && this.symbolexpandConfig[curNodeKey]){
                InfoContant[curNodeLayerID]["isExpaned"] = this.symbolexpandConfig[curNodeKey]["isExpaned"];
                InfoContant[curNodeLayerID]["expandLevel"] = this.symbolexpandConfig[curNodeKey]["expandLevel"];
            }
            else{
                InfoContant[curNodeLayerID]["isExpaned"] = 0;
                InfoContant[curNodeLayerID]["expandLevel"] = 0;
            }
            exportLayerTofile(this.context, curNodeLayer, this.exportImagePath, curNodeLayerID);
            InfoContant[curNodeLayerID]["imgPath"] = this.exportImagePath+"/"+curNodeLayerID+".png"
        }
    }
}

generatesymbols.prototype.initExpandSymbolsConfig = function(){
    if(this.symbolExpandConfileContent){
        this.symbolexpandConfig = {};
        for(var pageKey in this.symbolExpandConfileContent){
            var artboardsInfo = this.symbolExpandConfileContent[pageKey]["layers"];
            if(!artboardsInfo){
                continue
            }
            for(var artboardKey in artboardsInfo) {
                var allNodeInfo = artboardsInfo[artboardKey]["layers"];
                if(!allNodeInfo){
                    continue
                }
                for(var nodeKey in allNodeInfo){
                    var curKey = ""+pageKey+"_"+artboardKey+"_"+nodeKey
                    log("initExpandSymbolsConfig curKey "+ allNodeInfo[nodeKey]["isExpaned"])
                    this.symbolexpandConfig[curKey] = {}
                    this.symbolexpandConfig[curKey]["isExpaned"] = allNodeInfo[nodeKey]["isExpaned"];
                    this.symbolexpandConfig[curKey]["expandLevel"] = allNodeInfo[nodeKey]["expandLevel"];
                }
            }
        }
    }
}

generatesymbols.prototype.getAllSymbolInstance4Artboard = function(artboardLayer) {
    var allNodes = artboardLayer.children();
    allNodes.reverse()
    allNodes.pop()
    allNodes.reverse()
    return allNodes;
}

generatesymbols.prototype.checkArtboardIsNeedImport =function(targetArtboard){
    if (isConditionArtboard(targetArtboard) == true) {
        return false;
    }
    var nowartboardName = targetArtboard.name()+"";
    if (nowartboardName.toLowerCase().search("\\[ref.+")>=0) {
        return false
    }
    return true;
}

generatesymbols.prototype.checkIsNeedImport =function(tartgetLayer){
    var tartgetLayerClass = tartgetLayer.className();
    if(tartgetLayerClass == "MSArtboardGroup" || tartgetLayerClass == "MSLayerGroup"){
        return false;
    }
    if(isLayerIgnored_iauto(tartgetLayer)){
        return false;
    }
    return true;
}


