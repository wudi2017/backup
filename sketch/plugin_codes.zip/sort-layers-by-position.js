@import 'common.js';

var onRun = function(context) {
  var sketch = context.api();
  var doc = context.document;

  var allArtboards = []

  doc.pages().forEach(page => {
    if (isPageIgnored(page)) return
    page.artboards().forEach(artboard => {
      var allLayers = [];
      artboard.layers().forEach(layer => {
        allLayers.push(layer)
      });

      allArtboards.push({ allLayers,  artboard })
    });
  });

  let apiApp = new sketch.Application(context)
  let apiDoc = new sketch.Document(doc, new sketch.Application(context))

  allArtboards.forEach(allLayersAndArtboards => {
    let allLayers = allLayersAndArtboards.allLayers
    let artboard = allLayersAndArtboards.artboard
    var bgLayers = [];
    var alertLayers = [];
    var alwaysBack;

    allLayers.sort((a,b) => {
      var aX = a.frame().x();
      var aY = a.frame().y();
      var bX = b.frame().x();
      var bY = b.frame().y();

      if (aY == bY) return aX - bX;
      return aY - bY;
    });

    for (l in allLayers) {
      let layer = allLayers[l];
      let layerName = layer.name();

      let layerX = layer.frame().x();
      let layerY = layer.frame().y();

      MSLayerMovement.moveToBack([layer]);

      // Store array of background layers to move to the back.
      if (layerName == '~Shapes/BG~') {
        bgLayers.push(layer);
      }

      if (layerName == '~Shapes/BG LEFT~') {
        alwaysBack = layer;
        bgLayers.push(layer);
      }

      if (layerName == 'UI/System/BG With Divider') {
        alwaysBack = layer;
        bgLayers.push(layer);
      }

      if (layerName == '~Shapes/BG RIGHT~') {
        bgLayers.push(layer);
      }

      if (layerName == 'VR / BG Gradient') {
        bgLayers.push(layer);
      }

      if (layerName == 'VR / BG Gradient Error') {
        bgLayers.push(layer);
      }
      // Store array of Alerts to move forward.
      if (layerName.indexOf('Alert') > -1) {
        log('This is an alert. Move it to the top!')
        alertLayers.push(layer);
      }

      if (layerName.indexOf('Drawer') > -1) {
        alertLayers.push(layer);
      }
    }

    for (l in bgLayers) {
      let layer = bgLayers[l];
      MSLayerMovement.moveToBack([layer]);
    }

    for (l in alertLayers) {
      let layer = alertLayers[l];
      MSLayerMovement.moveToFront([layer]);
    }

    MSLayerMovement.moveToBack(alwaysBack);
  });
}
