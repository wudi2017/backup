@import "metadata-panel-listener.js"

function syncPartsMetadata(context)
{
	setMetadataPanelStopFlag(true);

	var ctx = context;

	delayRun(0.3, () => {
    		initFramework(ctx);
			[UpdateMetadata update];

			restartSetupPanelNew(ctx);
	})
}

function initFramework(context)
{
	coscript.setShouldKeepAround(true);
	var frameworkname = "TMNAFramework"
    var mocha = Mocha.sharedRuntime();
    if (!mocha.valueForKey(frameworkname)) {
       var script_full_filename = context.scriptPath;
		var sketchPluginPath = script_full_filename.substr(0, script_full_filename.lastIndexOf('/'));
		sketchPluginPath = sketchPluginPath.substr(0, sketchPluginPath.lastIndexOf('/'));
		var frameworkpath = sketchPluginPath + "/Resources/";
		var loadflg = [mocha loadFrameworkWithName:frameworkname inDirectory:frameworkpath]
		mocha.setValue_forKey_(true, frameworkname);
        //return;
    }
    
    var command = context.command;
	var document = context.document;
	var scriptPath = context.scriptPath;
	var scriptURL = context.scriptURL;
	var selection = context.selection;
	SketchEventHandler.onSetContextData_Document_ScriptPath_ScriptURL_Selection(command,document,scriptPath,scriptURL,selection);
	var sketchObjects = [MSLayer.new(),MSLayerGroup.new(),MSFlowConnection.new(),MSSymbolCreator.new(),MSLayerArray.new(),MSTextLayer.new(),MSArtboardGroup.new(),MSShapeGroup.new(),MSExportRequest.new(),MSStyle.new(),MSStyleFill.new(),MSColor.new(),MSCurvePoint.new(),MSShapePathLayer.new(),MSRectangleShape.new(),MSTriangleShape.new(),MSOvalShape.new(),MSStarShape.new(),MSPolygonShape.new(),MSAbsoluteRect.new()];
	SketchEventHandler.onInitSketchClassWithObjects(sketchObjects);
}