//
//  CStringUtils.m
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "CStringUtils.h"


@implementation CStringUtils

+ (NSString*) toSlug:(NSString*)s
{
    NSString * result = [NSString stringWithString:s];
    
    result = [result lowercaseString];
    
    {
        // NSRegularExpressionCaseInsensitive
        // NSRegularExpressionDotMatchesLineSeparators
        NSString * regexpStr = @"<[^>]+>";
        NSRegularExpression * regExp = [NSRegularExpression regularExpressionWithPattern:regexpStr options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators  error:nil];
        
        // NSMatchingReportProgress maxlenMatch
        // NSMatchingAnchored startMatch
        // NSMatchingReportCompletion g
        NSString * oriStr = result;
        NSString * replacement = @"";
        NSString * resultStr = nil;
        resultStr = [regExp stringByReplacingMatchesInString:oriStr options:NSMatchingReportCompletion range:NSMakeRange(0, oriStr.length) withTemplate:replacement];
        
        result = resultStr;
    }
    
    {
        NSString * regexpStr = @"[\/\+\|]";
        NSRegularExpression * regExp = [NSRegularExpression regularExpressionWithPattern:regexpStr options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators  error:nil];
        
        NSString * oriStr = result;
        NSString * replacement = @" ";
        NSString * resultStr = nil;
        resultStr = [regExp stringByReplacingMatchesInString:oriStr options:NSMatchingReportCompletion range:NSMakeRange(0, oriStr.length) withTemplate:replacement];
        
        result = resultStr;
    }
    
    {
        NSString * regexpStr = @"[\\!@#$%^&\\*\\(\\)\\?=\\{\\}\\[\\]\\\\\\\,\\.\\:\\;\\']";
        NSRegularExpression * regExp = [NSRegularExpression regularExpressionWithPattern:regexpStr options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators  error:nil];
        
        NSString * oriStr = result;
        NSString * replacement = @"";
        NSString * resultStr = nil;
        resultStr = [regExp stringByReplacingMatchesInString:oriStr options:NSMatchingReportCompletion range:NSMakeRange(0, oriStr.length) withTemplate:replacement];
        
        result = resultStr;
    }
    
    {
        NSString * regexpStr = @"\\s+";
        NSRegularExpression * regExp = [NSRegularExpression regularExpressionWithPattern:regexpStr options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators  error:nil];
        
        NSString * oriStr = result;
        NSString * replacement = @"-";
        NSString * resultStr = nil;
        resultStr = [regExp stringByReplacingMatchesInString:oriStr options:NSMatchingReportCompletion range:NSMakeRange(0, oriStr.length) withTemplate:replacement];
        
        result = resultStr;
    }
    
    {
        NSString * regexpStr = @"-";
        NSRegularExpression * regExp = [NSRegularExpression regularExpressionWithPattern:regexpStr options:NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators  error:nil];
        
        NSString * oriStr = result;
        NSString * replacement = @"_";
        NSString * resultStr = nil;
        resultStr = [regExp stringByReplacingMatchesInString:oriStr options:NSMatchingReportCompletion range:NSMakeRange(0, oriStr.length) withTemplate:replacement];
        
        result = resultStr;
    }
    
    
    return result;
}

+ (NSString*) trimedStr:(NSString*)s
{
    return [self rTrimedStr:[self lTrimedStr:s]];
}

+ (NSString*) lTrimedStr:(NSString*)s
{
    NSRange range = [s rangeOfCharacterFromSet:[NSCharacterSet whitespaceAndNewlineCharacterSet].invertedSet];
    return [s substringFromIndex:range.location];
}

+ (NSString*) rTrimedStr:(NSString*)s
{
    NSRange range = [s rangeOfCharacterFromSet:[NSCharacterSet whitespaceAndNewlineCharacterSet].invertedSet options:NSBackwardsSearch];
    return [s substringToIndex:range.location+1];
}

+ (NSString*) convertNumToStr:(NSInteger)num_info
{
    NSString* columnStr = @"";
    NSArray* letter_list = [NSArray arrayWithObjects:@"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K",@"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", nil];
        NSInteger  num_index = num_info;
    while(num_index > 0){
        num_index = num_index -1;
        NSString* curChar = [letter_list objectAtIndex:num_index%26];
        columnStr = [curChar stringByAppendingString:columnStr];
        num_index = (num_index - num_index%26) / 26;
    }
    return columnStr;
}
@end
