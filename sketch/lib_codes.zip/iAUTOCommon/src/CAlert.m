//
//  CAlert.m
//  sketchPluginFramework
//
//  Created by nb on 2017/11/27.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CAlert.h"

@implementation CAlert

+ (void) showAlertDiagAndContinue:(NSString*)msg
{
    NSAlert* alert = [NSAlert new];
    [alert addButtonWithTitle:@"OK"];
    [alert setMessageText:@"information:"];
    [alert setInformativeText:msg];
    [alert setAlertStyle:NSWarningAlertStyle];
    [alert runModal];
}

+ (void) showAlertDiagAndExit:(NSString*)msg
{
    [self showAlertDiagAndContinue:msg];
    exit(0);
}

+ (void) showAlertDiagAndException:(NSString*)msg
{
    [self showAlertDiagAndContinue:msg];
    
    NSString *exceptionName = @"EName";
    NSString *exceptionReason = @"EReason";
    NSDictionary *exceptionUserInfo = nil;
    NSException *exception = [NSException exceptionWithName:exceptionName reason:exceptionReason userInfo:exceptionUserInfo];
    @throw exception;
}
@end

