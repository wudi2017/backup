//
//  CJSONXConvertor.m
//  sketchPluginFramework
//
//  Created by nb on 2018/12/4.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CJSONXConvertor.h"

//---------------------------------------------------------------

@implementation CJsonSerializer
- (NSString*) serializeClassName
{
    return @"";
}
- (id) serializeToJson:(id)xObject
{
    return @"";
}
- (id) parseFormJson:(id)jsonFormatObject
{
    return nil;
}
@end

@implementation CJsonXConvertor
- (id) convertXObjectToValidJsonFormatObject:(id)xDictArr
{
    id newXObj = nil;
    NSString * className = [xDictArr className];
    if ([className rangeOfString:@"String"].location != NSNotFound) { // String
        newXObj = [NSString stringWithString:xDictArr];
    }
    else if([className rangeOfString:@"Number"].location != NSNotFound) { // Number
        newXObj = xDictArr;
    }
    else if([className rangeOfString:@"Dictionary"].location != NSNotFound) { // Dict
        newXObj = [NSMutableDictionary dictionary];
        for(NSString * oldKey in xDictArr)
        {
            id oldVal = [xDictArr objectForKey:oldKey];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj setObject:newVal forKey:oldKey];
            }
        }
    }
    else if([className rangeOfString:@"Array"].location != NSNotFound) { // Array
        newXObj = [NSMutableArray array];
        for(int iOldArr=0;iOldArr<[xDictArr count];iOldArr++)
        {
            id oldVal = [xDictArr objectAtIndex:iOldArr];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj addObject:newVal];
            }
        }
    }
    return newXObj;
}
- (id) convertXObjectToJsonString:(id)xDictArr
{
    NSError* error = nil;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:xDictArr options:NSJSONWritingPrettyPrinted error:&error];
    NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}
- (id) convertJsonStringToXObject:(NSString*)jsonString
{
    NSData* jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
    NSString* className = [jsonObject className];
    return jsonObject;
}
- (id) convertJsonFormatObjectToXObject:(id)jsonFormatObject
{
    id newXObj = nil;
    NSString * className = [jsonFormatObject className];
    if ([className rangeOfString:@"String"].location != NSNotFound) { // String
        newXObj = [NSString stringWithString:jsonFormatObject];
    }
    else if([className rangeOfString:@"Number"].location != NSNotFound) { // Number
        newXObj = jsonFormatObject;
    }
    else if([className rangeOfString:@"Dictionary"].location != NSNotFound) { // Dict
        newXObj = [NSMutableDictionary dictionary];
        for(NSString * oldKey in jsonFormatObject)
        {
            id oldVal = [jsonFormatObject objectForKey:oldKey];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj setObject:newVal forKey:oldKey];
            }
        }
    }
    else if([className rangeOfString:@"Array"].location != NSNotFound) { // Array
        newXObj = [NSMutableArray array];
        for(int iOldArr=0;iOldArr<[jsonFormatObject count];iOldArr++)
        {
            id oldVal = [jsonFormatObject objectAtIndex:iOldArr];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj addObject:newVal];
            }
        }
    }
    return newXObj;
}
- (void) addSerializer:(CJsonSerializer*)serializer
{
    
}
@end

//---------------------------------------------------------------
@implementation CJsonSerializerNSFont
+ (instancetype) instance
{
    static CJsonSerializerNSFont *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CJsonSerializerNSFont alloc] init];
    });
    return instance;
}
- (NSString*)serializeClassName
{
    return @"NSFont";
}
- (id) serializeToJson:(id)xObject
{
    NSFont* xNSFont = (NSFont*)xObject;
    if (!xNSFont) {
        return nil;
    }
    NSMutableDictionary * jsonDict = [NSMutableDictionary dictionary];
    
    NSString * fontName = [xNSFont fontName];
    float pointSize = [xNSFont pointSize];
    
    [jsonDict setObject:fontName forKey:@"fontName"];
    [jsonDict setObject:[NSNumber numberWithFloat:pointSize] forKey:@"pointSize"];
    
    return jsonDict;
}
- (id) parseFormJson:(id)jsonFormatObject
{
    NSMutableDictionary * jsonFont = jsonFormatObject;
    NSString* fontName = [jsonFont objectForKey:@"fontName"];
    float pointSize = [[jsonFont objectForKey:@"pointSize"] floatValue];
    NSFont* font = [NSFont fontWithName:fontName size:pointSize];
    return font;
}
@end

//---------------------------------------------------------------

@implementation CJsonSerializerCGPoint
+ (instancetype) instance
{
    static CJsonSerializerCGPoint *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CJsonSerializerCGPoint alloc] init];
    });
    return instance;
}
- (NSString*) serializeClassName
{
    return @"CGPoint";
}
- (id) serializeToJson:(CGPoint)xObject
{
    NSMutableDictionary * jsonDict = [NSMutableDictionary dictionary];
    
    [jsonDict setObject:[NSNumber numberWithInt:xObject.x] forKey:@"x"];
    [jsonDict setObject:[NSNumber numberWithInt:xObject.y] forKey:@"y"];
    
    return jsonDict;
}
- (CGPoint) parseFormJson:(id)jsonFormatObject
{
    NSMutableDictionary * jsonFont = jsonFormatObject;
    float x = [[jsonFont objectForKey:@"x"] floatValue];
    float y = [[jsonFont objectForKey:@"y"] floatValue];
    return NSMakePoint(x, y);
}
@end


@implementation CJsonSerializerCGSize
+ (instancetype) instance
{
    static CJsonSerializerCGSize *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CJsonSerializerCGSize alloc] init];
    });
    return instance;
}
- (NSString*) serializeClassName
{
    return @"CGSize";
}
- (id) serializeToJson:(CGSize)xObject
{
    NSMutableDictionary * jsonDict = [NSMutableDictionary dictionary];
    [jsonDict setObject:[NSNumber numberWithFloat:xObject.width] forKey:@"width"];
    [jsonDict setObject:[NSNumber numberWithFloat:xObject.height] forKey:@"height"];
    return jsonDict;
}
- (CGSize) parseFormJson:(id)jsonFormatObject
{
    NSMutableDictionary * jsonFont = jsonFormatObject;
    float width = [[jsonFont objectForKey:@"width"] floatValue];
    float height = [[jsonFont objectForKey:@"height"] floatValue];
    return NSMakeSize(width, height);
}
@end

@implementation CJsonSerializerCGRect
+ (instancetype) instance
{
    static CJsonSerializerCGRect *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CJsonSerializerCGRect alloc] init];
    });
    return instance;
}
- (NSString*) serializeClassName
{
    return @"CGRect";
}
- (id) serializeToJson:(CGRect)xObject
{
    NSMutableDictionary * jsonDict = [NSMutableDictionary dictionary];
    NSMutableDictionary * jsonDictForOrigin = [[CJsonSerializerCGPoint instance] serializeToJson:xObject.origin];
    NSMutableDictionary * jsonDictForSize = [[CJsonSerializerCGSize instance] serializeToJson:xObject.size];
    [jsonDict setObject:jsonDictForOrigin forKey:@"origin"];
    [jsonDict setObject:jsonDictForSize forKey:@"size"];
    return jsonDict;
}
- (CGRect) parseFormJson:(id)jsonFormatObject
{
    NSMutableDictionary * jsonDict = jsonFormatObject;
    NSMutableDictionary * jsonDictForOrigin = [jsonDict objectForKey:@"origin"];
    NSMutableDictionary * jsonDictForSize = [jsonDict objectForKey:@"size"];
    CGPoint origin = [[CJsonSerializerCGPoint instance] parseFormJson:jsonDictForOrigin];
    CGSize size = [[CJsonSerializerCGSize instance] parseFormJson:jsonDictForSize];
    return NSMakeRect(origin.x, origin.y, size.width, size.height);
}
@end


//---------------------------------------------------------------
@implementation CJSONXConvertor

+ (NSString*) convertXObjectToValidJsonFormatObject:(id)xDictArr
{
    id newXObj = nil;
    NSString * className = [xDictArr className];
    if ([className rangeOfString:@"String"].location != NSNotFound) { // String
        newXObj = [NSString stringWithString:xDictArr];
    }
    else if([className rangeOfString:@"Number"].location != NSNotFound) { // Number
        newXObj = xDictArr;
    }
    else if([className rangeOfString:@"Dictionary"].location != NSNotFound) { // Dict
        newXObj = [NSMutableDictionary dictionary];
        for(NSString * oldKey in xDictArr)
        {
            id oldVal = [xDictArr objectForKey:oldKey];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj setObject:newVal forKey:oldKey];
            }
        }
    }
    else if([className rangeOfString:@"Array"].location != NSNotFound) { // Array
        newXObj = [NSMutableArray array];
        for(int iOldArr=0;iOldArr<[xDictArr count];iOldArr++)
        {
            id oldVal = [xDictArr objectAtIndex:iOldArr];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj addObject:newVal];
            }
        }
    }
    return newXObj;
}

+ (id) convertJsonFormatObjectToXObject:(id)jsonFormatObject
{
    id newXObj = nil;
    NSString * className = [jsonFormatObject className];
    if ([className rangeOfString:@"String"].location != NSNotFound) { // String
        newXObj = [NSString stringWithString:jsonFormatObject];
    }
    else if([className rangeOfString:@"Number"].location != NSNotFound) { // Number
        newXObj = jsonFormatObject;
    }
    else if([className rangeOfString:@"Dictionary"].location != NSNotFound) { // Dict
        newXObj = [NSMutableDictionary dictionary];
        for(NSString * oldKey in jsonFormatObject)
        {
            id oldVal = [jsonFormatObject objectForKey:oldKey];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj setObject:newVal forKey:oldKey];
            }
        }
    }
    else if([className rangeOfString:@"Array"].location != NSNotFound) { // Array
        newXObj = [NSMutableArray array];
        for(int iOldArr=0;iOldArr<[jsonFormatObject count];iOldArr++)
        {
            id oldVal = [jsonFormatObject objectAtIndex:iOldArr];
            id newVal = [self convertXObjectToValidJsonFormatObject:oldVal];
            if (newVal) {
                [newXObj addObject:newVal];
            }
        }
    }
    return newXObj;
}

+ (void)test
{
    NSMutableDictionary * dict = [NSMutableDictionary dictionary];
    [dict setObject:@"stringVal" forKey:@"key1"];
    NSFileManager * mgr = [NSFileManager defaultManager];
    [dict setObject:mgr forKey:@"key2"];
    [dict setObject:@177 forKey:@"key3"];
    [dict setObject:@3.1415 forKey:@"key4"];
    
    NSMutableArray * arr = [NSMutableArray array];
    [arr addObject:@"arrObj1"];
    [arr addObject:@"arrObj2"];
    [arr addObject:@3333];
    NSMutableDictionary * dictSub = [NSMutableDictionary dictionary];
    [dictSub setObject:@"xx" forKey:@"skey2"];
    [arr addObject:dictSub];
    [arr addObject:[NSFileManager defaultManager]];
    [dict setObject:arr forKey:@"key5"];
    
    
    NSMutableDictionary * jsonDict = [self convertXObjectToValidJsonFormatObject:dict];
    NSLog(@"");
}

@end
