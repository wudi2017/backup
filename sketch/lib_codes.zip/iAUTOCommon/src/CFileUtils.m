//
//  CFileUtils.m
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CFileUtils.h"

@implementation CFileUtils

+ (NSDictionary*) readDictinaryFromJsonFile:(NSString*)filepath {
    NSFileManager* fileManger = [NSFileManager defaultManager];
    if(![fileManger fileExistsAtPath:filepath]){
        return nil;
    }
    NSFileHandle* infh = [NSFileHandle fileHandleForReadingAtPath:filepath];
    if(!infh){
        return nil;
    }
    NSData* contents =  [infh readDataToEndOfFile];
    
    [infh closeFile];
    
    //NSString* strContents = [[NSString alloc]initWithData:contents encoding:NSUTF8StringEncoding];
    id jsonObject = [NSJSONSerialization JSONObjectWithData:contents options:NSJSONReadingAllowFragments error:nil];
    if([jsonObject isKindOfClass:[NSDictionary class]]){
        NSDictionary* res = (NSDictionary*) jsonObject;
        return res;
    }
    return  nil;
}

+ (void)writeArrayToFile:(NSString*)filePath FileName:(NSString*)fileName FileContent:(NSMutableArray*)fileContent
{
    NSError* error = nil;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:fileContent options:NSJSONWritingPrettyPrinted error:&error];
    NSString* temp_fileContent = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    [self writeContentToFile:filePath FileName:fileName FileContent:temp_fileContent];
}
+ (void)writeDictionaryToFile:(NSString*)filePath FileName:(NSString*)fileName FileContent:(NSDictionary*)fileContent
{
    NSError* error = nil;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:fileContent options:NSJSONWritingPrettyPrinted error:&error];
    NSString* temp_fileContent = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    [self writeContentToFile:filePath FileName:fileName FileContent:temp_fileContent];
}
+ (void)writeContentToFile:(NSString*)filePath FileName:(NSString*)fileName FileContent:(NSString*)fileContent
{
    [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:true attributes:nil error:nil];
    NSString* filePathandName = [[filePath stringByAppendingString:@"/"] stringByAppendingString:fileName];
    [fileContent writeToFile:filePathandName atomically:false encoding:NSUTF8StringEncoding error:nil];
}


+ (BOOL)fileExists:(NSString*)filePath
{
    NSFileManager* fileManger = [NSFileManager defaultManager];
    if([fileManger fileExistsAtPath:filePath]){
        return true;
    }
    return false;
}

+ (void)removeFile:(NSString*)filePath
{
    NSFileManager* fileManger = [NSFileManager defaultManager];
    if([fileManger fileExistsAtPath:filePath]){
        [fileManger removeItemAtPath:filePath error:nil];
    }
}

+ (void)moveFile:(NSString*)oldfilePath newfilePath:(NSString*)newFilePath
{
    NSFileManager* fileManger = [NSFileManager defaultManager];
    if([fileManger fileExistsAtPath:oldfilePath]){
        [fileManger moveItemAtPath:oldfilePath toPath:newFilePath error:nil];
    }
}

+ (void)createDirectory:(NSString*)dirpath
{
    NSFileManager* fileManger = [NSFileManager defaultManager];
    if(![fileManger fileExistsAtPath:dirpath]){
        [fileManger createDirectoryAtPath:dirpath withIntermediateDirectories:true attributes:nil error:nil];
    }
}

@end

