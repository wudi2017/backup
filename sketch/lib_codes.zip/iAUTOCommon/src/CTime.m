//
//  CTime.m
//  sketchPluginFramework
//
//  Created by nb on 2017/1/25.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CTime.h"

@implementation CTime

+ (NSString*) getCurrentTimeString
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    
    NSDate * datenow = [NSDate  date];
    NSString * currentTimeString = [formatter stringFromDate:datenow];
    return currentTimeString;
}

@end
