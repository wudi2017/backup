//
//  CLog.cpp
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#include "CLog.h"
#include "sys/syscall.h"
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void BaseCLog(const char * Fmt, ...)
{
    va_list ap;
    char TempStr[512];
    va_start(ap, Fmt);
    vsprintf(TempStr, Fmt, ap);
    va_end(ap);
    
    char TempStrOut[512];
    snprintf(TempStrOut, 512, "%s", TempStr);
    
    // file
    FILE * fp;
    fp = fopen("/tmp/testlog.log", "a+");
    if (NULL != fp) {
        char TempStrOutLn[512];
        strcpy(TempStrOutLn, TempStrOut);
        strcat(TempStrOutLn, "\n");
        fwrite(TempStrOutLn, strlen(TempStrOutLn), 1, fp);
        fclose(fp);
    }
}
