//
//  CGraphicsUtils.m
//  sketchPluginFramework
//
//  Created by nb on 2018/12/3.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CGraphicsUtils.h"

@implementation CGraphicsUtils

+ (NSValue*) calcCoincideRect:(NSRect)rect1 WithOtherRect:(NSRect)rect2
{
    CGFloat x1 = rect1.origin.x;
    CGFloat y1 = rect1.origin.y;
    CGFloat width1 = rect1.size.width;
    CGFloat height1 = rect1.size.height;
    
    CGFloat x2 = rect2.origin.x;
    CGFloat y2 = rect2.origin.y;
    CGFloat width2 = rect2.size.width;
    CGFloat height2 = rect2.size.height;
    
    CGFloat endx = MAX(x1+width1, x2+width2);
    CGFloat startx = MIN(x1,x2);
    CGFloat width = width1+width2-(endx-startx);
    CGFloat x = MAX(x1,x2);
    
    CGFloat endy = MAX(y1+height1, y2+height2);
    CGFloat starty = MIN(y1,y2);
    CGFloat height = height1+height2-(endy-starty);
    CGFloat y = MAX(y1,y2);
    
    if (width<=0 || height<=0) {
        return nil;
    }
    else
    {
        // coincideRect
        NSRect coincideRect = NSMakeRect(x, y, width, height);
        NSValue * coincideRectVal = [NSValue valueWithRect:coincideRect];
        return coincideRectVal;
    }
}
+ (float) calcCoincidePercentage:(CGRect)baseRect WithOtherRect:(CGRect)otherRect
{
    NSValue * coincideRectVal = [self calcCoincideRect:baseRect WithOtherRect:otherRect];
    if (coincideRectVal) {
        NSRect coincideRect = [coincideRectVal rectValue];
        float coincideRectAreaValue = coincideRect.size.width * coincideRect.size.height;
        float baseRectAreaValue = baseRect.size.width * baseRect.size.height;
        if (baseRectAreaValue == 0) {
            return 0;
        }
        else
        {
            return coincideRectAreaValue/baseRectAreaValue;
        }
    }
    else
    {
        return 0;
    }
}

@end
