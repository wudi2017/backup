//
//  CLog.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/29.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLog.h"
#import "CTime.h"

const NSString * BLOGTAG_BASE = @"Base";
const NSString * BLOGTAG_PERFORMANCE = @"Performance";
const NSString * BLOGTAG_COMMON = @"Common";
const NSString * BLOGTAG_IAUTOTREE_DIFF = @"IAUTOTreeDiff";
const NSString * BLOGTAG_IAUTOTREE_CREATE = @"IAUTOTreeCreate";

void BLOG(const NSString * tag, const NSString * fmt, ...)
{
    //return; // release not output
    
    va_list args;
    va_start(args, fmt);
    NSString * logContent = [[NSString alloc] initWithFormat:fmt arguments:args];
    va_end(args);
    logContent = [logContent stringByAppendingString:@"\n"];
    
    
    NSString * nsStrLog = [NSString stringWithFormat:@"[%@][%@] %@", [CTime getCurrentTimeString], tag, logContent];
    
    NSString* homeDir = NSHomeDirectory();
    NSString* logDir = [homeDir stringByAppendingString:@"/sketchplugin_iauto"];
    [[NSFileManager defaultManager] createDirectoryAtPath:logDir withIntermediateDirectories:YES attributes:nil error:nil];
    
    NSString* logFullFileName = [logDir stringByAppendingString:@"/sketchPluginFramework_"];
    logFullFileName = [logFullFileName stringByAppendingString:tag];
    logFullFileName = [logFullFileName stringByAppendingString:@".log"];
    NSFileHandle* filehandle = [NSFileHandle fileHandleForWritingAtPath:logFullFileName];
    if(filehandle)
    {
        [filehandle truncateFileAtOffset: [filehandle seekToEndOfFile]];
        NSData* nsdata = [nsStrLog dataUsingEncoding:NSUTF8StringEncoding];
        [filehandle writeData:nsdata];
        [filehandle closeFile];
    }
    else
    {
        [nsStrLog writeToFile:logFullFileName atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
}
