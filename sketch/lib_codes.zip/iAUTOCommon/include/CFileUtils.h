//
//  CFileUtils.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef CFileUtils_h
#define CFileUtils_h

@interface CFileUtils : NSObject

+ (NSDictionary*) readDictinaryFromJsonFile:(NSString*)filepath;
+ (void)writeArrayToFile:(NSString*)filePath FileName:(NSString*)fileName FileContent:(NSMutableArray*)fileContent;
+ (void)writeDictionaryToFile:(NSString*)filePath FileName:(NSString*)fileName FileContent:(NSDictionary*)fileContent;
+ (void)writeContentToFile:(NSString*)filePath FileName:(NSString*)fileName FileContent:(NSString*)fileContent;
+ (BOOL)fileExists:(NSString*)filePath;
+ (void)removeFile:(NSString*)filePath;
+ (void)moveFile:(NSString*)oldfilePath newfilePath:(NSString*)newFilePath;
+ (void)createDirectory:(NSString*)dirpath;

@end

#endif /* CFileUtils_h */
