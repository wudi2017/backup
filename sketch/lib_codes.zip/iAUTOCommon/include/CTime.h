//
//  CTime.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/25.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef CTime_h
#define CTime_h

@interface CTime : NSObject

+ (NSString*) getCurrentTimeString;

@end


#endif /* CTime_h */
