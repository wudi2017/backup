//
//  CLog.hpp
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef CLog_hpp
#define CLog_hpp

#include <stdio.h>
#include <stdarg.h>

//const char* CLOG_TAG_BASE = "BASE";

#ifdef __cplusplus

extern "C" {
    void BaseCLog(const char * fmt, ...);
}

#else

#import <Foundation/Foundation.h>

extern const NSString * BLOGTAG_BASE;
extern const NSString * BLOGTAG_PERFORMANCE;
extern const NSString * BLOGTAG_COMMON;
extern const NSString * BLOGTAG_IAUTOTREE_DIFF;
extern const NSString * BLOGTAG_IAUTOTREE_CREATE;

void BLOG(const NSString * tag, const NSString * fmt, ...);

#endif



#endif /* CLog_hpp */
