//
//  CGraphicsUtils.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/3.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef CGraphicsUtils_h
#define CGraphicsUtils_h

#import <Foundation/Foundation.h>
#import "CLog.h"

@interface CGraphicsUtils : NSObject

+ (NSValue*) calcCoincideRect:(NSRect)rect1 WithOtherRect:(NSRect)rect2;
+ (float) calcCoincidePercentage:(CGRect)baseRect WithOtherRect:(CGRect)otherRect;

@end

#endif /* CGraphicsUtils_h */
