//
//  StringCommon.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef CStringUtils_h
#define CStringUtils_h

@interface CStringUtils : NSObject

+ (NSString*) toSlug:(NSString*)s;
+ (NSString*) trimedStr:(NSString*)s;
+ (NSString*) lTrimedStr:(NSString*)s;
+ (NSString*) rTrimedStr:(NSString*)s;
+ (NSString*) convertNumToStr:(NSInteger)num_info;

@end


#endif /* CStringUtils_h */
