//
//  CJSONXConvertor.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/4.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef JSONXConvertor_h
#define JSONXConvertor_h

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "CLog.h"

/***********************************************************************/
// base

@interface CJsonSerializer : NSObject
- (NSString*) serializeClassName;
- (id) serializeToJson:(id)xObject;
- (id) parseFormJson:(id)jsonFormatObject;
@end

@interface CJsonXConvertor : NSObject
- (id) convertXObjectToValidJsonFormatObject:(id)xDictArr;
- (id) convertJsonFormatObjectToXObject:(id)jsonFormatObject;
- (void) addSerializer:(CJsonSerializer*)serializer;
- (NSString*) convertXObjectToJsonString:(id)xDictArr;
- (id) convertJsonStringToXObject:(NSString*)jsonString;
@end

/***********************************************************************/

@interface CJsonSerializerNSFont : CJsonSerializer
+ (instancetype) instance;
- (NSString*) serializeClassName;
- (id) serializeToJson:(id)xObject;
- (id) parseFormJson:(id)jsonFormatObject;
@end

@interface CJsonSerializerCGPoint : CJsonSerializer
+ (instancetype) instance;
- (NSString*) serializeClassName;
- (id) serializeToJson:(CGPoint)xObject;
- (CGPoint) parseFormJson:(id)jsonFormatObject;
@end

@interface CJsonSerializerCGSize : CJsonSerializer
+ (instancetype) instance;
- (NSString*) serializeClassName;
- (id) serializeToJson:(CGSize)xObject;
- (CGSize) parseFormJson:(id)jsonFormatObject;
@end

@interface CJsonSerializerCGRect : CJsonSerializer
+ (instancetype) instance;
- (NSString*) serializeClassName;
- (id) serializeToJson:(CGRect)xObject;
- (CGRect) parseFormJson:(id)jsonFormatObject;
@end


/***********************************************************************/

@interface CJSONXConvertor : NSObject
// Common
+ (id) convertXObjectToValidJsonFormatObject:(id)xDictArr;
+ (id) convertJsonFormatObjectToXObject:(id)jsonFormatObject;
+ (void)test;
@end

#endif /* CJSONXConvertor_h */
