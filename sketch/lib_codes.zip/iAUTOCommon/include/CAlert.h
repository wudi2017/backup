//
//  CAlert.h
//  sketchPluginFramework
//
//  Created by nb on 2017/11/27.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef CAlert_h
#define CAlert_h

#import <Cocoa/Cocoa.h>

@interface CAlert : NSObject

+ (void) showAlertDiagAndContinue:(NSString*)msg;
+ (void) showAlertDiagAndExit:(NSString*)msg;
+ (void) showAlertDiagAndException:(NSString*)msg;

@end

#endif /* CAlert_h */
