//
//  TestCoreData.m
//  TMNAFramework
//
//  Created by nb on 2018/12/29.
//

#import <Foundation/Foundation.h>
#import "TestCoredata.h"
#import "CLog.h"
#import "IAUTOSpecFactory.h"
#import "IAUTOScreenSpec.h"
#import "IAUTOPartsSpec.h"
#import "SketchCommon.h"

@implementation SketchTreeExpandPolicyTest
- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer
{
    NSString* layerName = [expandLayer name];
    if ([[currentLayer className] isEqualToString:@"MSSymbolInstance"]
        //&& [layerName isEqualToString:@"UI/Button/Round/Large/Fill"]
        ) {
        return NSIntegerMax;
    }
    else{
        return -1;
    }
}
@end


@implementation TestCoreData

- (void) test
{
    [[CoreDataEngine instance] reset];
    SketchTreeExpandPolicyTest* expandPolicy = [[SketchTreeExpandPolicyTest alloc] init];
    [[CoreDataEngine instance] setSketchTreeExpandPolicy:expandPolicy];
    
    [self test_virtualCoreTree_visit_sketchdataSingleLayer];
    
//    [self test_virtualCoreTree_visit_sketchdata];
    
//    [self test_virtualCoreTree_clear_spec];
//
//    [self test_virtualCoreTree_create_partsSpec];
//    [self test_virtualCoreTree_visit_partsSpec];
//
//    [self test_virtualCoreTree_create_screenSpec];
//    [self test_virtualCoreTree_visit_screenSpec];
}

/*
 *****************************************************************************************************************
 */

- (void) test_virtualCoreTree_visit_sketchdata
{
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self test_virtualCoreTree_visit_sketchdata_help:it CurrentPositon: [it name]];
        
        [coreDataTree unload];
    }
}
- (void) test_virtualCoreTree_visit_sketchdata_help:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    NSString* objectID = [it objectID];
    NSString* name = [it name];
    NSString* className = [it className];
    NSString* type = [it type];
    if ([className isEqualToString:@"MSTextLayer"]) {
        NSString* stringValue = [it stringValue];
        stringValue = nil;
    }
    //NSString* userData = [it getCustomData:@"layerData"];
    
    //    BLOG(@"Test", @"visitLayer Position: %@", strPosition);
    //    BLOG(@"Test", @"    name:%@", name);
    //    BLOG(@"Test", @"    expandType:%@", expandType);
    //    BLOG(@"Test", @"    hasChildren:%d", [it hasChildren]);
    
    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_visit_sketchdata_help:childIt CurrentPositon:subPosition];
    }
}

/*
 *****************************************************************************************************************
 */

- (void) test_virtualCoreTree_visit_sketchdataSingleLayer
{
    NSMutableArray* selections = [SketchCommon selection];
    if (selections && [selections count] > 0) {
        
        for (int iSelect=0; iSelect<[selections count]; iSelect++) {
            id<MSLayer> selectLayer = [selections objectAtIndex:iSelect];
            
            CoreDataTree* coreDataTree = [[CoreDataEngine instance] coreDataLayerTree:selectLayer];
            [coreDataTree load];
            
            CoreDataIterator* it = [coreDataTree rootIterator];
            [self test_virtualCoreTree_visit_sketchdataSingleLayer:it CurrentPositon: [it name]];
            
            [coreDataTree unload];
            
        }
    }
}
- (void) test_virtualCoreTree_visit_sketchdataSingleLayer:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    NSString* objectID = [it objectID];
    NSString* absoluteObjectID = [it absoluteObjectID];
    NSString* type = [it type];
    NSString* name = [it name];
    NSString* className = [it className];
    bool bHasChildrens = [it hasChildrens];
    
    id<MSLayer> currentLayer = [it originLayer];
    id<MSLayer> expandLayer = [it expandLayer];

    BLOG(@"Test", @"visitLayer Position: %@", strPosition);
    BLOG(@"Test", @"    absoluteObjectID:%@", absoluteObjectID);
    BLOG(@"Test", @"    name:%@", name);
    BLOG(@"Test", @"    expandType:%@", type);
    if ([type isEqualToString:CoreDataIteratorType_Replaced]) {
        BLOG(@"Test", @"    replacedMasterName:%@", [[it replacedLayerMaster] name]);
    }
    BLOG(@"Test", @"    bHasChildrens:%d", bHasChildrens);
    //NSString* userData = [it getCustomData:@"layerData"];
    
    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_visit_sketchdataSingleLayer:childIt CurrentPositon:subPosition];
    }
}

/*
 *****************************************************************************************************************
 */
- (void) test_virtualCoreTree_create_partsSpec
{
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self test_virtualCoreTree_create_partsSpec_help:it CurrentPositon: [it name]];
        [coreDataTree commit];
        
        [coreDataTree unload];
    }
}
- (void) test_virtualCoreTree_create_partsSpec_help:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    NSString* name = [it name];

    IAUTOSpec* spec = [[IAUTOSpecFactory instance] getSpec:it];
    if (nil == spec) {
        spec = [[IAUTOSpecFactory instance] autoCreateSpec:it];
    }
    
    if (nil != spec && [[spec specType] isEqualToString:IAUTOSPECTYPE_PARTS]) { // visit parts spec
        
        IAUTOPartsSpec* partsSpec = spec;
        [partsSpec reset];
        
        NSMutableArray* statusList = [partsSpec statusList];
        if (nil == statusList || [statusList count] == 0) {
            
            [partsSpec addStatus:@"Default"];
            [partsSpec changeStatus:@"Default"];
            [partsSpec setPartsName:[name stringByAppendingString:@"_Default"]];
            [partsSpec setPartsID:[name stringByAppendingString:@"_1"]];
            [partsSpec addLanguage:@"US" TextContent:@"this is Default US String"];
            [partsSpec addLanguage:@"CN" TextContent:@"这是中文Default内容"];
            
            [partsSpec addStatus:@"Active"];
            [partsSpec changeStatus:@"Active"];
            [partsSpec setPartsName:[name stringByAppendingString:@"_Active"]];
            [partsSpec setPartsID:[name stringByAppendingString:@"_3"]];
            [partsSpec addLanguage:@"US" TextContent:@"this is Active US String"];
            [partsSpec addLanguage:@"CN" TextContent:@"这是中文Active内容"];
        }
    }
    
    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_create_partsSpec_help:childIt CurrentPositon:subPosition];
    }
}

/*
 *****************************************************************************************************************
 */

- (void) test_virtualCoreTree_visit_partsSpec
{
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self test_virtualCoreTree_visit_partsSpec_help:it CurrentPositon: [it name]];
        
        [coreDataTree unload];
    }
}
- (void) test_virtualCoreTree_visit_partsSpec_help:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    IAUTOSpec* spec = [[IAUTOSpecFactory instance] getSpec:it];
    if (nil != spec && [[spec specType] isEqualToString:IAUTOSPECTYPE_PARTS]) { // visit parts spec
        
        IAUTOPartsSpec* partsSpec = spec;
        
        NSString* partsID = [partsSpec partsID];
        
        NSMutableArray* statusList = [partsSpec statusList];
        NSString* currentStatus = [partsSpec currentStatusName];
        
        NSMutableArray* languageList = [partsSpec languageList];
        NSString* currentLanguage = [partsSpec currentLanguage];
        
        NSString* partsName = [partsSpec partsName];
        NSString* textCount = [partsSpec textContent];
        
        // change status
        if ([statusList count] > 1)
        {
            
            NSString* statusName = [statusList objectAtIndex:1];
            [partsSpec changeStatus:statusName];
            currentStatus = [partsSpec currentStatusName];
            
            // change language
            if ([languageList count] > 1)
            {
                NSString* language = [languageList objectAtIndex:1];
                [partsSpec changeLanguage:language];
                currentLanguage = [partsSpec currentLanguage];
                
                NSString* partsName = [partsSpec partsName];
                textCount = [partsSpec textContent];
                
                textCount = @"";
            }
        }
        
        //BLOG(@"test", @"Location:%@", strPosition);
    }
    
    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_visit_partsSpec_help:childIt CurrentPositon:subPosition];
    }
}

/*
 *****************************************************************************************************************
 */

- (void) test_virtualCoreTree_create_screenSpec
{
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self test_virtualCoreTree_create_screenSpec_help:it CurrentPositon: [it name]];
        [coreDataTree commit];
        
        [coreDataTree unload];
    }
}

- (void) test_virtualCoreTree_create_screenSpec_help:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    NSString* name = [it name];
    NSString* className = [it className];
    
    IAUTOSpec* spec = [[IAUTOSpecFactory instance] getSpec:it];
    if (nil == spec) { // not found screen spec, create a null screenSpec
        spec = [[IAUTOSpecFactory instance] autoCreateSpec:it];
    }
    
    if (nil != spec && [[spec specType] isEqualToString:IAUTOSPECTYPE_SCREEN]) { // visit parts spec
        
        IAUTOScreenSpec* screenSpec = spec;
        [screenSpec reset];
        
        [screenSpec setBasicScreenID:[@"BasicScreenID_" stringByAppendingString:name]];
        [screenSpec setScreenID:[@"ScreenID_" stringByAppendingString:name]];
        [screenSpec setScreenName:[@"ScreenName_" stringByAppendingString:name]];
        
        // dest screen spec
        {
            [screenSpec addDestScreenSpec:@"screenID_XXXXX"];
            IAUTOScreenSpec* destScreenSpec = [screenSpec destScreenSpec:@"screenID_XXXXX"];
            [destScreenSpec setBasicScreenID:@"BasicScreenID_XXXXX"];
            [destScreenSpec setScreenID:@"ScreenID_XXXXX"];
            [destScreenSpec setScreenName:@"ScreenName_XXXXX"];
            
            // display area spec
            {
                [destScreenSpec addDisplayAreaSpec:@"DisplayAreaSpec_name1"];
                IAUTODisplayAreaSpec* displayAreSpec = [destScreenSpec displayAreaSpec:@"DisplayAreaSpec_name1"];
                [displayAreSpec setDisplayAreaRectValue:NSMakeRect(0, 0, 100, 120)];
                
                // add parts
                {
                    [displayAreSpec addPartsSpec:@"Parts_SUB1"];
                    IAUTOPartsSpec* partsSpec = [displayAreSpec partsSpec:@"Parts_SUB1"];
                    
                    [partsSpec addStatus:@"Normal"];
                    [partsSpec changeStatus:@"Normal"];
                    [partsSpec setPartsName:@"partsName_xxx"];
                    [partsSpec addLanguage:@"CN" TextContent:@"中文字符串"];
                    [partsSpec addLanguage:@"US" TextContent:@"this is us eng"];
                    
                    [partsSpec addStatus:@"Active"];
                    [partsSpec changeStatus:@"Active"];
                    [partsSpec setPartsName:@"partsName_123"];
                    [partsSpec addLanguage:@"CN" TextContent:@"中文字符串X"];
                    [partsSpec addLanguage:@"US" TextContent:@"this is us engX"];
                    
                }
            }
        }
    }
    
    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_create_screenSpec_help:childIt CurrentPositon:subPosition];
    }
}

/*
 *****************************************************************************************************************
 */

- (void) test_virtualCoreTree_visit_screenSpec
{
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self test_virtualCoreTree_visit_screenSpec_help:it CurrentPositon: [it name]];
        
        [coreDataTree unload];
    }
}
- (void) test_virtualCoreTree_visit_screenSpec_help:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    IAUTOSpec* spec = [[IAUTOSpecFactory instance] getSpec:it];
    if (nil != spec && [[spec specType] isEqualToString:IAUTOSPECTYPE_SCREEN]) { // visit screen spec
        
        IAUTOScreenSpec* screenSpec = spec;
        
        NSString* screenID = [screenSpec screenID];
        NSString* basicScreenID = [screenSpec basicScreenID];
        NSString* screenName = [screenSpec screenName];
        
        // dest screen spec
        NSMutableArray<IAUTOScreenSpec*>* destScreenSpecList = [screenSpec destScreenSpecList];
        if (nil != destScreenSpecList && [destScreenSpecList count]>0) {
            IAUTOScreenSpec* destScreenSpec = [destScreenSpecList objectAtIndex:0];
            
            // display area spec
            NSMutableArray<IAUTODisplayAreaSpec*>* displayAreaSpecList = [destScreenSpec displayAreaSpecList];
            if (nil != displayAreaSpecList && [displayAreaSpecList count] > 0) {
                IAUTODisplayAreaSpec* displayAreaSpec = [displayAreaSpecList objectAtIndex:0];
                
                NSString* areaID = [displayAreaSpec displayAreaID];
                NSRect rect = [displayAreaSpec displayAreaRect];
                NSMutableArray* partsSpecList = [displayAreaSpec partsSpecList];
                
                // parts spec
                if (nil != partsSpecList && [partsSpecList count] > 0) {
                    IAUTOPartsSpec* partsSpec = [partsSpecList objectAtIndex:0];
                    
                    NSString* partsName = [partsSpec partsName];
                    NSString* textCount = [partsSpec textContent];
                    
                    textCount = @"";
                }
            }
        }
    }
        
    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_visit_screenSpec_help:childIt CurrentPositon:subPosition];
    }
}

/*
 *****************************************************************************************************************
 */

- (void) test_virtualCoreTree_clear_spec
{
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self test_virtualCoreTree_clear_spec_help:it CurrentPositon: [it name]];
        [coreDataTree commit];
        
        [coreDataTree unload];
    }
}
- (void) test_virtualCoreTree_clear_spec_help:(CoreDataIterator*)it CurrentPositon:(NSString*)strPosition
{
    [[IAUTOSpecFactory instance] clearSpec:it];

    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [strPosition stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self test_virtualCoreTree_clear_spec_help:childIt CurrentPositon:subPosition];
    }
}
@end
