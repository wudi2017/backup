//
//  TestCoredata.h
//  TMNAFramework
//
//  Created by nb on 2018/12/29.
//

#ifndef TestCoredata_h
#define TestCoredata_h

#import <Foundation/Foundation.h>
#import "CoreDataEngine.h"

@interface SketchTreeExpandPolicyTest : SketchTreeExpandPolicy
- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer;
@end

@interface TestCoreData : NSObject

- (void) test;

// test base sketch data
- (void) test_virtualCoreTree_visit_sketchdata;
- (void) test_virtualCoreTree_visit_sketchdataSingleLayer;

// test parts spec create visit
- (void) test_virtualCoreTree_create_partsSpec;
- (void) test_virtualCoreTree_visit_partsSpec;

// test screen spec create visit
- (void) test_virtualCoreTree_create_screenSpec;
- (void) test_virtualCoreTree_visit_screenSpec;

// test clear screen spec
- (void) test_virtualCoreTree_clear_spec;

@end


#endif /* TestCoredata_h */
