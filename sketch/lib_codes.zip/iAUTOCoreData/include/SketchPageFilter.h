//
//  SketchPageFilter.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/30.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef SketchPageFilter_h
#define SketchPageFilter_h

#import "Sketch.h"

// SketchPageFilter
@interface SketchPageFilter : NSObject

- (bool) filterOut:(id<MSPage>)page;

@end

// SketchPageFilter default
@interface SketchPageFilterDefault : SketchPageFilter

- (bool) filterOut:(id<MSPage>)page;

@end

#endif /* SketchPageFilter_h */
