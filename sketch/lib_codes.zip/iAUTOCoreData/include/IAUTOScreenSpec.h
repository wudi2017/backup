//
//  IAUTOScreenSpecAccessor.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef IAUTOScreenSpecAccessor_h
#define IAUTOScreenSpecAccessor_h

#import "IAUTOSpec.h"
#import "IAUTOPartsSpec.h"

// IAUTODisplayRecionSpec
@interface IAUTODisplayAreaSpec : NSObject
{
    NSMutableDictionary* m_specDict;
}
- (instancetype) init:(NSMutableDictionary*)dictData;

- (NSString*) displayAreaID;
- (bool) setDisplayAreaID:(NSString*)areaID;

- (NSRect) displayAreaRect;
- (bool) setDisplayAreaRectValue:(NSRect)rect;

- (bool) hasPartsSpec:(NSString*)partsID;
- (bool) addPartsSpec:(NSString*)partsID;
- (bool) removePartsSpec:(NSString*)partsID;
- (IAUTOPartsSpec*) partsSpec:(NSString*)partsID;
- (NSMutableArray<IAUTOPartsSpec*>*) partsSpecList;
@end


// IAUTOScreenSpecAccessor
@interface IAUTOScreenSpec : IAUTOSpec
{
    NSMutableDictionary* m_specDict;
}
- (instancetype) init:(NSMutableDictionary*)dictData;
- (id) specRawData;
- (const NSString*) specType;
- (bool) reset;

- (NSString*) screenName;
- (bool) setScreenName:(NSString*)screenName;

- (NSString*) screenID;
- (bool) setScreenID:(NSString*)screenID;

- (NSString*) basicScreenID;
- (bool) setBasicScreenID:(NSString*)basicScreenID;

- (bool) hasDisplayAreaSpec:(NSString*)displayAreaID;
- (bool) addDisplayAreaSpec:(NSString*)displayAreaID;
- (bool) removeDisplayAreaSpec:(NSString*)displayAreaID;
- (IAUTODisplayAreaSpec*) displayAreaSpec:(NSString*)displayAreaID;
- (NSMutableArray<IAUTODisplayAreaSpec*>*) displayAreaSpecList;

- (bool) hasDestScreenSpec:(NSString*)screenID;
- (bool) addDestScreenSpec:(NSString*)screenID;
- (bool) removeDestScreenSpec:(NSString*)screenID;
- (IAUTOScreenSpec*) destScreenSpec:(NSString*)screenID;
- (NSMutableArray<IAUTOScreenSpec*>*) destScreenSpecList;

@end


#endif /* IAUTOScreenSpecAccessor_h */
