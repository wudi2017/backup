//
//  IAUTOSpecAccessor.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef IAUTOSpec_h
#define IAUTOSpec_h

#import <Foundation/Foundation.h>
#import "CoreDataIterator.h"
#import "Sketch.h"

extern const NSString* IAUTOSPECTYPE_PARTS;
extern const NSString* IAUTOSPECTYPE_SCREEN;

@interface IAUTOSpec : NSObject
{
    CoreDataIterator* m_coreDataIterator;
};

- (instancetype) init:(CoreDataIterator*)coreDataIterator;
- (id) specRawData;
- (NSString*) objectID;
- (NSString*) layerName;

// implement in sub class
- (const NSString*) specType; // PartsSpec ScreenSpec
- (bool) reset;

@end


#endif /* IAUTOSpecAccessor_h */
