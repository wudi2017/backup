//
//  Header.h
//  IAUTOSpecAccessorFactory
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef IAUTOSpecAccessorFactory_h
#define IAUTOSpecAccessorFactory_h

#import <Foundation/Foundation.h>
#import "CoreDataIterator.h"
#import "Sketch.h"
#import "IAUTOSpec.h"

@interface IAUTOSpecFactory : NSObject
+ (instancetype) instance;
- (IAUTOSpec*) createSpecOnDict:(NSMutableDictionary*)dict SpecType:(const NSString*)specType;
- (IAUTOSpec*) createSpecOnIt:(CoreDataIterator*)coreDataIt SpecType:(const NSString*)specType;
- (IAUTOSpec*) autoCreateSpec:(CoreDataIterator*)coreDataIt; // page->nil artboard->screenspec other->partsspec
- (IAUTOSpec*) getSpec:(CoreDataIterator*)coreDataIt;
- (bool) clearSpec:(CoreDataIterator*)coreDataIt;
@end

#endif /* IAUTOSpecAccessorFactory_h */
