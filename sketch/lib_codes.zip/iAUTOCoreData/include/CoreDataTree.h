//
//  CoreDataTree.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/30.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef CoreDataTree_h
#define CoreDataTree_h

#import <Foundation/Foundation.h>
#import "CoreDataIterator.h"
#import "Sketch.h"

@class SketchTreeCustomCache;
@class SketchTreeCache;
@class SketchTreeExpandCache;
@class SketchTreeJsonCache;
@class CoreDataEngineConfig;

@interface CoreDataTree : NSObject
{
    CoreDataEngineConfig* m_coreDataEngineConfig;
    id<MSLayer> m_rootLayer;
    id<MSLayer> m_page;
    SketchTreeCustomCache * m_originPageCustomCache;
    SketchTreeCache* m_originPageTree;
    SketchTreeExpandCache* m_expandPageTree;
    SketchTreeJsonCache* m_jsonCache;
}

- (instancetype) init:(id<MSLayer>)rootLayer CoreDataEngineConfig:(CoreDataEngineConfig*)coreDataEngineConfig;
- (bool) load;
- (bool) unload;
- (NSString*) pageObjectID;
- (NSString*) pageName;
- (CoreDataIterator*) rootIterator;
- (bool) commit;

- (SketchTreeCustomCache*) getSketchTreeCustomCacheCache;
- (SketchTreeCache*) getSketchTreeCache;
- (SketchTreeExpandCache*) getSketchTreeExpandCache;
- (SketchTreeJsonCache*) getSketchTreeJsonCache;

@end

#endif /* CoreDataTree_h */
