//
//  IAUTOCoreData.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/5.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef IAUTOCoreData_h
#define IAUTOCoreData_h

#import <Foundation/Foundation.h>

#import "CoreDataTree.h"
#import "CoreDataIterator.h"
#import "CoreDataEngine.h"

#import "SketchPageFilter.h"
#import "SketchTreeExpandPolicy.h"

#import "IAUTOSpec.h"
#import "IAUTOPartsSpec.h"
#import "IAUTOScreenSpec.h"
#import "IAUTOSpecFactory.h"

#endif /* IAUTOCoreData_h */
