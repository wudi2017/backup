//
//  CoreDataEngine.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef CoreDataEngine_h
#define CoreDataEngine_h

#import <Foundation/Foundation.h>
#import "CoreDataTree.h"
#import "CoreDataIterator.h"
#import "SketchPageFilter.h"
#import "SketchTreeExpandPolicy.h"

@class CoreDataEngineConfig;

@interface CoreDataEngine : NSObject
{
    CoreDataEngineConfig* m_coreDataEngineConfig;
}

+ (instancetype) instance;
- (instancetype) init;
- (bool) reset;
- (bool) setPageFilter:(SketchPageFilter*)filter;
- (bool) setSketchTreeExpandPolicy:(SketchTreeExpandPolicy*)expandPolicy;
-  (NSMutableArray<CoreDataTree*>*) coreDataPageTrees;
-  (CoreDataTree*) coreDataLayerTree:(id<MSLayer>)layer;

@end

#endif /* CoreDataEngine_h */
