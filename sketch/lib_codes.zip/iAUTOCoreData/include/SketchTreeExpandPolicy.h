//
//  SketchTreeExpandPolicy.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/30.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef SketchTreeExpandPolicy_h
#define SketchTreeExpandPolicy_h

#import "Sketch.h"

// SketchTreeExpandPolicy
@interface SketchTreeExpandPolicy : NSObject

// return current symbol instance detach level:
// -1 : not detach
// 0: only left one root master group
// x: detach the symbol and left x level nodes
// NSIntegerMax: detach all
- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer;

@end

// SketchTreeExpandPolicy default
@interface SketchTreeExpandPolicyDefault : NSObject

- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer;

@end

#endif /* SketchTreeExpandPolicy_h */
