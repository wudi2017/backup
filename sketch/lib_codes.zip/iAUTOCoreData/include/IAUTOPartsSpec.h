//
//  IAUTOPartsSpecAccessor.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef IAUTOPartsSpec_h
#define IAUTOPartsSpec_h

#import "IAUTOSpec.h"

// IAUTOPartsSpec
@interface IAUTOPartsSpec : IAUTOSpec
{
    NSMutableDictionary* m_specDict;
    NSMutableDictionary* m_currentStatus;
    NSString* m_currentLanguage;
}

- (instancetype) init:(NSMutableDictionary*)dictData;
- (id) specRawData;
- (const NSString*) specType;
- (bool) reset;

- (NSString*) partsID;
- (bool) setPartsID:(NSString*)partsID;

// status
- (NSString*) currentStatusName;
- (NSMutableArray<NSString*>*) statusList;
- (bool) hasStatus:(NSString*)statusName;
- (bool) addStatus:(NSString*)statusName;
- (bool) removeStatus:(NSString*)statusName;
- (bool) removeAllStatus;
- (bool) changeStatus:(NSString*)statusName;
- (bool) changeToFirstStatus;

// multi language
- (NSString*) currentLanguage;
- (NSMutableArray<NSString*>*) languageList;
- (bool) hasLanguage:(NSString*)language;
- (bool) addLanguage:(NSString*)language TextContent:(NSString*)textContent;
- (bool) removeLanguage:(NSString*)language;
- (bool) removeAllLanguage;
- (bool) changeLanguage:(NSString*)language;
- (bool) changeToFirstLanguage;
- (NSString*) textContent;

// base spec data
- (NSString*) partsName;
- (bool) setPartsName:(NSString*)partsName;

@end



#endif /* IAUTOPartsSpecAccessor_h */
