//
//  CoreDataIterator.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef CoreDataIterator_h
#define CoreDataIterator_h

#import <Foundation/Foundation.h>

@protocol MSLayer;
@protocol MSSymbolMaster;
@protocol MSAbsoluteRect;
@class CoreDataTree;

// CoreDataIteratorType
extern const NSString* CoreDataIteratorType_Origin;
extern const NSString* CoreDataIteratorType_Expand;
extern const NSString* CoreDataIteratorType_Replaced;

@interface CoreDataIterator : NSObject
{
    CoreDataTree* m_coreDataTree;
    NSMutableDictionary* m_currentNodeForExpandTree;
    id<MSLayer> m_originLayer;
    id<MSLayer> m_expandLayer;
    id<MSLayer> m_replacedLayerMaster;
}

- (instancetype) init:(CoreDataTree*)coreDataTree;

- (NSString*) type; // CoreDataIteratorType origin replaced or expand

// sketch layer property
- (NSString*) objectID;
- (NSString*) absoluteObjectID;
- (NSString*) realFullID;
- (NSString*) className;
- (NSString*) name;
- (bool) setName:(NSString*)name;
- (CGRect) rect;
- (bool) setRect:(CGRect)rect;
- (id<MSAbsoluteRect>) absoluteRect;
- (bool) setAbsoluteRect:(id<MSAbsoluteRect>)absoluteRect;
- (NSDictionary*) overrides;
- (bool) setOverrides:(NSDictionary*)overrides;
- (NSString*) stringValue;

// childrens iterators
- (bool) hasChildrens;
- (NSArray<CoreDataIterator*>*) childrens;

// custom data
- (bool) setCustomData:(NSString*)customKey CustomData:(id)customData;
- (id) getCustomData:(NSString*)customKey;
- (bool) clearCustomData:(NSString*)customKey;

// extend interface
- (id<MSLayer>) originLayer;
- (id<MSLayer>) expandLayer;
- (id<MSSymbolMaster>) replacedLayerMaster;

@end


#endif /* CoreDataIterator_h */
