//
//  IAUTOCoreData.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/5.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAUTOCoreData.h"
