//
//  IAUTOScreenSpecAccessor.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAUTOScreenSpec.h"
#import "CJSONXConvertor.h"
#import "IAUTOSpecFactory.h"

@implementation  IAUTODisplayAreaSpec
- (instancetype) init:(NSMutableDictionary*)dictData
{
    self = [super init];
    m_specDict = dictData;
    return self;
}
- (NSString*) displayAreaID
{
    NSString* displayAreaID = nil;
    if (nil != m_specDict) {
        displayAreaID = [m_specDict objectForKey:@"areaID"];
    }
    return displayAreaID;
}
- (bool) setDisplayAreaID:(NSString*)areaID
{
    if (nil != m_specDict) {
        [m_specDict setObject:areaID forKey:@"areaID"];
    }
    return false;
}
- (NSRect) displayAreaRect
{
    NSRect retRect = NSZeroRect;
    if (nil != m_specDict) {
        NSMutableDictionary* rectDict = [m_specDict objectForKey:@"rect"];
        retRect = [[CJsonSerializerCGRect instance] parseFormJson:rectDict];
    }
    return retRect;
}
- (bool) setDisplayAreaRectValue:(NSRect)rect
{
    if (nil != m_specDict) {
        NSMutableDictionary* rectDict = [[CJsonSerializerCGRect instance] serializeToJson:rect];
        [m_specDict setObject:rectDict forKey:@"rect"];
        return true;
    }
    return false;
}
- (bool) hasPartsSpec:(NSString*)partsID
{
    bool bHas = false;
    if (nil != m_specDict) {
        NSMutableArray* partsSpecList = [m_specDict objectForKey:@"partsSpecList"];
        if (nil != partsSpecList) {
            for (int i=0; i<[partsSpecList count]; i++) {
                NSMutableDictionary* partsSpecDict = [partsSpecList objectAtIndex:i];
                if (nil != partsSpecDict) {
                    IAUTOPartsSpec* partsSpec = (IAUTOPartsSpec*)[[IAUTOSpecFactory instance] createSpecOnDict:partsSpecDict SpecType:IAUTOSPECTYPE_PARTS];
                    NSString* tmpPartsID = [partsSpec partsID];
                    if (nil != tmpPartsID && [tmpPartsID isEqualToString:partsID]) {
                        bHas = true;
                    }
                }
            }
        }
    }
    return bHas;
}
- (bool) addPartsSpec:(NSString*)partsID
{
    if ([self hasPartsSpec:partsID]) {
        return false;
    }
    bool bAdd = false;
    if (nil != m_specDict) {
        NSMutableArray* partsSpecList = [m_specDict objectForKey:@"partsSpecList"];
        if (nil == partsSpecList) {
            partsSpecList = [NSMutableArray array];
            [m_specDict setObject:partsSpecList forKey:@"partsSpecList"];
        }
        
        NSMutableDictionary* partsSpecDict = [NSMutableDictionary dictionary];
        [partsSpecList addObject:partsSpecDict];
        
        IAUTOPartsSpec* partsSpec = (IAUTOPartsSpec*)[[IAUTOSpecFactory instance] createSpecOnDict:partsSpecDict SpecType:IAUTOSPECTYPE_PARTS];
        [partsSpec setPartsID:partsID];
        
        bAdd = true;
    }
    return bAdd;
}
- (bool) removePartsSpec:(NSString*)partsID
{
    if (nil != m_specDict) {
        NSMutableArray* partsSpecList = [m_specDict objectForKey:@"partsSpecList"];
        if (nil != partsSpecList) {
            int iRemoveIndex = -1;
            for (int i=0; i<[partsSpecList count]; i++) {
                NSMutableDictionary* partsSpecDict = [partsSpecList objectAtIndex:i];
                if (nil != partsSpecDict) {
                    IAUTOPartsSpec* partsSpec = (IAUTOPartsSpec*)[[IAUTOSpecFactory instance] createSpecOnDict:partsSpecDict SpecType:IAUTOSPECTYPE_PARTS];
                    NSString* tmpPartsID = [partsSpec partsID];
                    if (nil != tmpPartsID && [tmpPartsID isEqualToString:partsID]) {
                        iRemoveIndex = i;
                    }
                }
            }
            if (iRemoveIndex >= 0) {
                [partsSpecList removeObjectAtIndex:iRemoveIndex];
            }
        }
    }
    return true;
}
- (IAUTOPartsSpec*) partsSpec:(NSString*)partsID
{
    IAUTOPartsSpec* tarPartsSpec = nil;
    if (nil != m_specDict) {
        NSMutableArray* partsSpecList = [m_specDict objectForKey:@"partsSpecList"];
        if (nil != partsSpecList) {
            for (int i=0; i<[partsSpecList count]; i++) {
                NSMutableDictionary* partsSpecDict = [partsSpecList objectAtIndex:i];
                if (nil != partsSpecDict) {
                    IAUTOPartsSpec* partsSpec = (IAUTOPartsSpec*)[[IAUTOSpecFactory instance] createSpecOnDict:partsSpecDict SpecType:IAUTOSPECTYPE_PARTS];
                    NSString* tmpPartsID = [partsSpec partsID];
                    if (nil != tmpPartsID && [tmpPartsID isEqualToString:partsID]) {
                        tarPartsSpec = partsSpec;
                        break;
                    }
                }
            }
        }
    }
    return tarPartsSpec;
}
- (NSMutableArray<IAUTOPartsSpec*>*) partsSpecList
{
    NSMutableArray* tarPartsSpecList = nil;
    if (nil != m_specDict) {
        NSMutableArray* partsSpecList = [m_specDict objectForKey:@"partsSpecList"];
        if (nil != partsSpecList) {
            tarPartsSpecList = [NSMutableArray array];
            for (int i=0; i<[partsSpecList count]; i++) {
                NSMutableDictionary* partsSpecDict = [partsSpecList objectAtIndex:i];
                if (nil != partsSpecDict) {
                    IAUTOPartsSpec* partsSpec = (IAUTOPartsSpec*)[[IAUTOSpecFactory instance] createSpecOnDict:partsSpecDict SpecType:IAUTOSPECTYPE_PARTS];
                    [tarPartsSpecList addObject:partsSpec];
                }
            }
        }
    }
    return tarPartsSpecList;
}
@end



@implementation IAUTOScreenSpec

- (instancetype) init:(NSMutableDictionary*)dictData
{
    self = [super init];
    m_specDict = dictData;
    return self;
}
- (id) specRawData
{
    return m_specDict;
}
- (const NSString*) specType
{
    return IAUTOSPECTYPE_SCREEN;
}
- (bool) reset
{
    if (nil != m_specDict) {
        [m_specDict removeAllObjects];
    }
    return true;
}

- (NSString*) screenName
{
    NSString* screenName = nil;
    if (nil != m_specDict) {
        screenName = [m_specDict objectForKey:@"screenName"];
    }
    return screenName;
}
- (bool) setScreenName:(NSString*)screenName
{
    if (nil != m_specDict) {
        [m_specDict setObject:screenName forKey:@"screenName"];
        return true;
    }
    return false;
}

- (NSString*) screenID
{
    NSString* screenID = nil;
    if (nil != m_specDict) {
        screenID = [m_specDict objectForKey:@"screenID"];
    }
    return screenID;
}
- (bool) setScreenID:(NSString*)screenID
{
    if (nil != m_specDict) {
        [m_specDict setObject:screenID forKey:@"screenID"];
        return true;
    }
    return false;
}

- (NSString*) basicScreenID
{
    NSString* basicScreenID = nil;
    if (nil != m_specDict) {
        basicScreenID = [m_specDict objectForKey:@"basicScreenID"];
    }
    return basicScreenID;
}
- (bool) setBasicScreenID:(NSString*)basicScreenID
{
    if (nil != m_specDict) {
        [m_specDict setObject:basicScreenID forKey:@"basicScreenID"];
        return true;
    }
    return false;
}

- (bool) hasDisplayAreaSpec:(NSString*)displayAreaID
{
    bool bHas = false;
    if (nil != m_specDict) {
        NSMutableArray* displayAreaSpecList = [m_specDict objectForKey:@"displayAreaSpec"];
        if (nil != displayAreaSpecList) {
            for (int i=0; i<[displayAreaSpecList count]; i++) {
                NSMutableDictionary* displayAreaSpecDict = [displayAreaSpecList objectAtIndex:i];
                if (nil != displayAreaSpecDict) {
                    IAUTODisplayAreaSpec* tmpDestScreenSpec = [[IAUTODisplayAreaSpec alloc] init:displayAreaSpecDict];
                    NSString* tmpDisplayAreaID = [tmpDestScreenSpec displayAreaID];
                    if (nil != tmpDisplayAreaID && [tmpDisplayAreaID isEqualToString:displayAreaID]) {
                        bHas = true;
                    }
                }
            }
        }
    }
    return bHas;
}
- (bool) addDisplayAreaSpec:(NSString*)displayAreaID
{
    if ([self hasDisplayAreaSpec:displayAreaID]) {
        return false;
    }
    bool bAdd = false;
    if (nil != m_specDict) {
        NSMutableArray* displayAreaSpecList = [m_specDict objectForKey:@"displayAreaSpec"];
        if (nil == displayAreaSpecList) {
            displayAreaSpecList = [NSMutableArray array];
            [m_specDict setObject:displayAreaSpecList forKey:@"displayAreaSpec"];
        }
        
        NSMutableDictionary* displayAreaSpecDict = [NSMutableDictionary dictionary];
        [displayAreaSpecDict setObject:displayAreaID forKey:@"areaID"];
        
        [displayAreaSpecList addObject:displayAreaSpecDict];
        bAdd = true;
    }
    return bAdd;
}
- (bool) removeDisplayAreaSpec:(NSString*)displayAreaID
{
    if (nil != m_specDict) {
        NSMutableArray* displayAreaSpecList = [m_specDict objectForKey:@"displayAreaSpec"];
        if (nil != displayAreaSpecList) {
            int iRemoveIndex = -1;
            for (int i=0; i<[displayAreaSpecList count]; i++) {
                NSMutableDictionary* displayAreaSpecDict = [displayAreaSpecList objectAtIndex:i];
                if (nil != displayAreaSpecDict) {
                    IAUTODisplayAreaSpec* tmpDestScreenSpec = [[IAUTODisplayAreaSpec alloc] init:displayAreaSpecDict];
                    NSString* tmpDisplayAreaID = [tmpDestScreenSpec displayAreaID];
                    if (nil != tmpDisplayAreaID && [tmpDisplayAreaID isEqualToString:displayAreaID]) {
                        iRemoveIndex = i;
                        break;
                    }
                }
            }
            if (iRemoveIndex >= 0) {
                [displayAreaSpecList removeObjectAtIndex:iRemoveIndex];
            }
        }
    }
    return true;
}
- (IAUTODisplayAreaSpec*) displayAreaSpec:(NSString*)displayAreaID
{
    IAUTODisplayAreaSpec* tarDisplayAreaSpec = nil;
    if (nil != m_specDict) {
        NSMutableArray* displayAreaSpecList = [m_specDict objectForKey:@"displayAreaSpec"];
        if (nil != displayAreaSpecList) {
            for (int i=0; i<[displayAreaSpecList count]; i++) {
                NSMutableDictionary* displayAreaSpecDict = [displayAreaSpecList objectAtIndex:i];
                if (nil != displayAreaSpecDict) {
                    IAUTODisplayAreaSpec* tmpDestScreenSpec = [[IAUTODisplayAreaSpec alloc] init:displayAreaSpecDict];
                    NSString* tmpDisplayAreaID = [tmpDestScreenSpec displayAreaID];
                    if (nil != tmpDisplayAreaID && [tmpDisplayAreaID isEqualToString:displayAreaID]) {
                        tarDisplayAreaSpec = tmpDestScreenSpec;
                        break;
                    }
                }
            }
        }
    }
    return tarDisplayAreaSpec;
}
- (NSMutableArray<IAUTODisplayAreaSpec*>*) displayAreaSpecList
{
    NSMutableArray* tarDisplayAreaSpecList = nil;
    if (nil != m_specDict) {
        NSMutableArray* displayAreaSpecList = [m_specDict objectForKey:@"displayAreaSpec"];
        if (nil != displayAreaSpecList) {
            tarDisplayAreaSpecList = [NSMutableArray array];
            for (int i=0; i<[displayAreaSpecList count]; i++) {
                NSMutableDictionary* displayAreaSpecDict = [displayAreaSpecList objectAtIndex:i];
                if (nil != displayAreaSpecDict) {
                    IAUTODisplayAreaSpec* tmpDestScreenSpec = [[IAUTODisplayAreaSpec alloc] init:displayAreaSpecDict];
                    [tarDisplayAreaSpecList addObject:tmpDestScreenSpec];
                }
            }
        }
    }
    return tarDisplayAreaSpecList;
}

- (bool) hasDestScreenSpec:(NSString*)screenID
{
    bool bHas = false;
    if (nil != m_specDict) {
        NSMutableArray* destScreenSpecList = [m_specDict objectForKey:@"destScreenSpec"];
        if (nil != destScreenSpecList) {
            for (int i=0; i<[destScreenSpecList count]; i++) {
                NSMutableDictionary* destScreenSpecDict = [destScreenSpecList objectAtIndex:i];
                if (nil != destScreenSpecDict) {
                    IAUTOScreenSpec* destScreenSpec = [[IAUTOScreenSpec alloc] init:destScreenSpecDict];
                    NSString* destScreenID = [destScreenSpec screenID];
                    if (nil != destScreenID && [destScreenID isEqualToString:screenID]) {
                        bHas = true;
                    }
                }
            }
        }
    }
    return bHas;
}
- (bool) addDestScreenSpec:(NSString*)screenID
{
    if ([self hasDestScreenSpec:screenID]) {
        return false;
    }
    bool bAdd = false;
    if (nil != m_specDict) {
        NSMutableArray* destScreenSpecList = [m_specDict objectForKey:@"destScreenSpec"];
        if (nil == destScreenSpecList) {
            destScreenSpecList = [NSMutableArray array];
            [m_specDict setObject:destScreenSpecList forKey:@"destScreenSpec"];
        }
        
        NSMutableDictionary* destScreenSpec = [NSMutableDictionary dictionary];
        [destScreenSpec setObject:screenID forKey:@"screenID"];
        
        [destScreenSpecList addObject:destScreenSpec];
        bAdd = true;
    }
    return bAdd;
}
- (bool) removeDestScreenSpec:(NSString*)screenID
{
    if (nil != m_specDict) {
        NSMutableArray* destScreenSpecList = [m_specDict objectForKey:@"destScreenSpec"];
        if (nil != destScreenSpecList) {
            int iRemoveIndex = -1;
            for (int i=0; i<[destScreenSpecList count]; i++) {
                NSMutableDictionary* destScreenSpecDict = [destScreenSpecList objectAtIndex:i];
                if (nil != destScreenSpecDict) {
                    IAUTOScreenSpec* destScreenSpec = [[IAUTOScreenSpec alloc] init:destScreenSpecDict];
                    NSString* destScreenID = [destScreenSpec screenID];
                    if (nil != destScreenID && [destScreenID isEqualToString:screenID]) {
                        iRemoveIndex = i;
                        break;
                    }
                }
            }
            if (iRemoveIndex >= 0) {
                [destScreenSpecList removeObjectAtIndex:iRemoveIndex];
            }
        }
    }
    return true;
}
- (IAUTOScreenSpec*) destScreenSpec:(NSString*)screenID
{
    IAUTOScreenSpec* tarDestScreenSpec = nil;
    if (nil != m_specDict) {
        NSMutableArray* destScreenSpecList = [m_specDict objectForKey:@"destScreenSpec"];
        if (nil != destScreenSpecList) {
            for (int i=0; i<[destScreenSpecList count]; i++) {
                NSMutableDictionary* destScreenSpecDict = [destScreenSpecList objectAtIndex:i];
                if (nil != destScreenSpecDict) {
                    IAUTOScreenSpec* destScreenSpec = [[IAUTOScreenSpec alloc] init:destScreenSpecDict];
                    NSString* destScreenID = [destScreenSpec screenID];
                    if (nil != destScreenID && [destScreenID isEqualToString:screenID]) {
                        tarDestScreenSpec = destScreenSpec;
                        break;
                    }
                }
            }
        }
    }
    return tarDestScreenSpec;
}
- (NSMutableArray<IAUTOScreenSpec*>*) destScreenSpecList
{
    NSMutableArray* tarDestScreenSpecList = nil;
    if (nil != m_specDict) {
        NSMutableArray* destScreenSpecList = [m_specDict objectForKey:@"destScreenSpec"];
        if (nil != destScreenSpecList) {
            tarDestScreenSpecList = [NSMutableArray array];
            for (int i=0; i<[destScreenSpecList count]; i++) {
                NSMutableDictionary* destScreenSpecDict = [destScreenSpecList objectAtIndex:i];
                if (nil != destScreenSpecDict) {
                    IAUTOScreenSpec* destScreenSpec = [[IAUTOScreenSpec alloc] init:destScreenSpecDict];
                    [tarDestScreenSpecList addObject:destScreenSpec];
                }
            }
        }
    }
    return tarDestScreenSpecList;
}

@end
