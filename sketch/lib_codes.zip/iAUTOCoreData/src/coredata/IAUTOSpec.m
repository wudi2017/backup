//
//  IAUTOSpecDataVisitor.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAUTOSpec.h"

const NSString* IAUTOSPECTYPE_PARTS = @"PartsSpec";
const NSString* IAUTOSPECTYPE_SCREEN = @"ScreenSpec";

@implementation IAUTOSpec
- (instancetype) init:(CoreDataIterator*)coreDataIterator
{
    self = [super init];
    m_coreDataIterator = coreDataIterator;
    return self;
}
- (id) specRawData
{
    return nil;
}
- (NSString*) objectID
{
    return [m_coreDataIterator objectID];
}
- (NSString*) layerName
{
    return [m_coreDataIterator name];
}
- (const NSString*) specType
{
    return nil;
}
- (bool) reset
{
    return false;
}
@end
