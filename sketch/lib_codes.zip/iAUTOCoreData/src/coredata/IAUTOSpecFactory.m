//
//  IAUTOSpecAccessorFactory.m
//  IAUTOSpecAccessorFactory
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAUTOSpecFactory.h"
#import "IAUTOPartsSpec.h"
#import "IAUTOScreenSpec.h"

@implementation IAUTOSpecFactory

+ (instancetype) instance
{
    static IAUTOSpecFactory *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[IAUTOSpecFactory alloc] init];
    });
    return instance;
}
- (IAUTOSpec*) createSpecOnDict:(NSMutableDictionary*)dict SpecType:(const NSString*)specType
{
    IAUTOSpec* spec = nil;
    
    if (nil != dict) {
        if ([specType isEqualToString:IAUTOSPECTYPE_SCREEN]) {
            
            spec = [[IAUTOScreenSpec alloc] init:dict];
        }
        if ([specType isEqualToString:IAUTOSPECTYPE_PARTS]) {
            
            spec = [[IAUTOPartsSpec alloc] init:dict];
        }
    }
    
    return spec;
}
- (IAUTOSpec*) createSpecOnIt:(CoreDataIterator*)coreDataIt SpecType:(const NSString*)specType
{
    IAUTOSpec* spec = nil;
    
    NSMutableDictionary* specDict = [NSMutableDictionary dictionary];
    if ([specType isEqualToString:IAUTOSPECTYPE_SCREEN]) {
        
        [coreDataIt setCustomData:@"screenSpecData" CustomData:specDict];
    }
    
    if ([specType isEqualToString:IAUTOSPECTYPE_PARTS]) {
        
        [coreDataIt setCustomData:@"partsSpecData" CustomData:specDict];
    }
    
    return [self createSpecOnDict:specDict SpecType:specType];
}
- (IAUTOSpec*) autoCreateSpec:(CoreDataIterator*)coreDataIt
{
    NSString* className = [coreDataIt className];
    if (![className isEqualToString:@"MSPage"]) {
        if ([className isEqualToString:@"MSArtboardGroup"]) {
            return [self createSpecOnIt:coreDataIt SpecType:IAUTOSPECTYPE_SCREEN];
        }
        else
        {
            return [self createSpecOnIt:coreDataIt SpecType:IAUTOSPECTYPE_PARTS];
        }
    }
    else
    {
        return nil;
    }
}
- (IAUTOSpec*) getSpec:(CoreDataIterator*)coreDataIt
{
    IAUTOSpec* spec = nil;
    
    NSMutableDictionary* screenSpecData = [coreDataIt getCustomData:@"screenSpecData"];
    if (nil != screenSpecData) {
        spec = [[IAUTOScreenSpec alloc] init:screenSpecData];
    }
    else
    {
        NSMutableDictionary* partsSpecData = [coreDataIt getCustomData:@"partsSpecData"];
        if (nil != partsSpecData) {
            spec = [[IAUTOPartsSpec alloc] init:partsSpecData];
        }
    }
    
    return spec;
}

- (bool) clearSpec:(CoreDataIterator*)coreDataIt
{
    if (nil != coreDataIt) {
        NSMutableDictionary* screenSpecData = [coreDataIt getCustomData:@"screenSpecData"];
        if (nil != screenSpecData) {
            [coreDataIt clearCustomData:@"screenSpecData"];
        }
        NSMutableDictionary* partsSpecData = [coreDataIt getCustomData:@"partsSpecData"];
        if (nil != partsSpecData) {
            [coreDataIt clearCustomData:@"partsSpecData"];
        }
    }
    return true;
}

@end


