//
//  IAUTOPartsSpecAccessor.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/2.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAUTOPartsSpec.h"

@implementation IAUTOPartsSpec

- (instancetype) init:(NSMutableDictionary*)dictData
{
    self = [super init];
    m_specDict = dictData;
    m_currentLanguage = nil;
    
    [self changeToFirstStatus];
    [self changeToFirstLanguage];
    
    return self;
}
- (id) specRawData
{
    return m_specDict;
}
- (const NSString*) specType
{
    return IAUTOSPECTYPE_PARTS;
}
- (bool) reset
{
    if (nil != m_specDict) {
        [m_specDict removeAllObjects];
    }
    return true;
}

- (NSString*) partsID
{
    NSString* partsID = nil;
    if (nil != m_specDict) {
        partsID = [m_specDict objectForKey:@"partsID"];
    }
    return partsID;
}
- (bool) setPartsID:(NSString*)partsID
{
    if (nil != m_specDict) {
        [m_specDict setObject:partsID forKey:@"partsID"];
        return true;
    }
    return false;
}


- (NSString*) currentStatusName
{
    if (nil != m_currentStatus) {
        return [m_currentStatus objectForKey:@"statusName"];
    }
    return nil;
}
- (NSMutableArray<NSString*>*) statusList
{
    NSMutableArray* statusNameList = nil;
    NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
    if (nil != statusList) {
        statusNameList = [NSMutableArray array];
        for (int i=0; i<[statusList count]; i++) {
            NSMutableDictionary* tmpStatus = [statusList objectAtIndex:i];
            if (nil != tmpStatus) {
                NSString* statusName = [tmpStatus objectForKey:@"statusName"];
                [statusNameList addObject:statusName];
            }
        }
    }
    return statusNameList;
}
- (bool) hasStatus:(NSString*)statusName
{
    bool bHas = false;
    {
        NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
        if (nil != statusList) {
            for (int i=0 ;i<[statusList count]; i++) {
                NSMutableDictionary* tmpStatus = [statusList objectAtIndex:i];
                if (nil != tmpStatus) {
                    NSString* tmpStatusName = [tmpStatus objectForKey:@"statusName"];
                    if ([tmpStatusName isEqualToString:statusName]) {
                        bHas = true;
                        break;
                    }
                }
            }
        }
    }
    return bHas;
}
- (bool) addStatus:(NSString*)statusName
{
    if ([self hasStatus:statusName]) {
        return false;
    }
    NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
    if (nil == statusList) {
        statusList = [NSMutableArray array];
        [m_specDict setObject:statusList forKey:@"status"];
    }
    
    NSMutableDictionary* aStatus = [NSMutableDictionary dictionary];
    [aStatus setObject:statusName forKey:@"statusName"];
    [statusList addObject:aStatus];
    
    return true;
}
- (bool) removeStatus:(NSString*)statusName
{
    if (nil != m_specDict) {
        int iRemoveIndex = -1;
        NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
        if (nil != statusList) {
            for (int i=0 ;i<[statusList count]; i++) {
                NSMutableDictionary* tmpStatus = [statusList objectAtIndex:i];
                if (nil != tmpStatus) {
                    NSString* tmpStatusName = [tmpStatus objectForKey:@"statusName"];
                    if ([tmpStatusName isEqualToString:statusName]) {
                        iRemoveIndex = i;
                        break;
                    }
                }
            }
        }
        if (iRemoveIndex >=0) {
            [statusList removeObjectAtIndex:iRemoveIndex];
        }
    }
    return true;
}
- (bool) removeAllStatus
{
    if (nil != m_specDict) {
        NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
        if (nil != statusList) {
            [statusList removeAllObjects];
        }
    }
    return true;
}
- (bool) changeStatus:(NSString*)statusName
{
    if (![self hasStatus:statusName]) {
        return false;
    }
    
    NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
    if (nil != statusList) {
        for (int i=0 ;i<[statusList count]; i++) {
            NSMutableDictionary* tmpStatus = [statusList objectAtIndex:i];
            if (nil != tmpStatus) {
                NSString* tmpStatusName = [tmpStatus objectForKey:@"statusName"];
                if ([tmpStatusName isEqualToString:statusName]) {
                    m_currentStatus = tmpStatus;
                    break;
                }
            }
        }
    }
    
    return true;
}
- (bool) changeToFirstStatus
{
    bool bChange = false;
    NSMutableArray* statusList = [m_specDict objectForKey:@"status"];
    if (nil != statusList) {
        for (int i=0 ;i<[statusList count]; i++) {
            NSMutableDictionary* tmpStatus = [statusList objectAtIndex:i];
            if (nil != tmpStatus) {
                m_currentStatus = tmpStatus;
                bChange = true;
                break;
            }
        }
    }
    return bChange;
}


- (NSString*) currentLanguage
{
    return m_currentLanguage;
}
- (NSMutableArray<NSString*>*) languageList
{
    NSMutableArray* languageList = [NSMutableArray array];
    if (nil != m_specDict && nil != m_currentStatus) {
        NSMutableDictionary* multiLanguage = [m_currentStatus objectForKey:@"multiLanguage"];
        if (nil != multiLanguage) {
            for (NSString* aLang in multiLanguage) {
                [languageList addObject:aLang];
            }
        }
    }
    return languageList;
}
- (bool) hasLanguage:(NSString*)language
{
    bool bHas = false;
    if (nil != m_specDict && nil != m_currentStatus) {
        NSMutableDictionary* multiLanguage = [m_currentStatus objectForKey:@"multiLanguage"];
        if (nil != multiLanguage) {
            NSString* langContent = [multiLanguage objectForKey:language];
            if (nil != langContent) {
                 bHas = true;
            }
        }
    }
    return bHas;
}
- (bool) addLanguage:(NSString*)language TextContent:(NSString*)textContent
{
    if ([self hasLanguage:language]) {
        return false;
    }
    bool bAdd = false;
    if (nil != m_specDict && nil != m_currentStatus) {
        NSMutableDictionary* multiLanguage = [m_currentStatus objectForKey:@"multiLanguage"];
        if (nil == multiLanguage) {
            multiLanguage = [NSMutableDictionary dictionary];
            [m_currentStatus setObject:multiLanguage forKey:@"multiLanguage"];
        }
        [multiLanguage setObject:textContent forKey:language];
        bAdd = true;
    }
    return bAdd;
}
- (bool) removeLanguage:(NSString*)language
{
    if (![self hasLanguage:language]) {
        return true;
    }
    if (nil != m_specDict && nil != m_currentStatus) {
        NSMutableDictionary* multiLanguage = [m_currentStatus objectForKey:@"multiLanguage"];
        if (nil != multiLanguage) {
            [multiLanguage removeObjectForKey:language];
        }
    }
    return true;
}
- (bool) removeAllLanguage
{
    if (nil != m_specDict && nil != m_currentStatus) {
        NSMutableDictionary* multiLanguage = [m_currentStatus objectForKey:@"multiLanguage"];
        if (nil != multiLanguage) {
            [multiLanguage removeAllObjects];
        }
    }
    return true;
}
- (bool) changeLanguage:(NSString*)language
{
    if (![self hasLanguage:language]) {
        return false;
    }
    m_currentLanguage = language;
    return true;
}
- (bool) changeToFirstLanguage
{
    bool bChange = false;
    NSMutableArray* languageList = [self languageList];
    if (nil != languageList) {
        for (int i=0; i<[languageList count]; i++) {
            NSString* language = [languageList objectAtIndex:i];
            if (nil != language) {
                m_currentLanguage = language;
                bChange = true;
                break;
            }
        }
    }
    return bChange;
}
- (NSString*) textContent
{
    NSString* textContent = nil;
    if (nil == m_currentLanguage) {
        return false;
    }
    if (![self hasLanguage:m_currentLanguage]) {
        return false;
    }
    if (nil != m_specDict && nil != m_currentStatus) {
        NSMutableDictionary* multiLanguage = [m_currentStatus objectForKey:@"multiLanguage"];
        if (nil != multiLanguage) {
            textContent = [multiLanguage objectForKey:m_currentLanguage];
        }
    }
    return textContent;
}

- (NSString*) partsName
{
    NSString* partsName = nil;
    if (nil != m_currentStatus) {
        partsName = [m_currentStatus objectForKey:@"partsName"];
    }
    return partsName;
}
- (bool) setPartsName:(NSString*)partsName
{
    if (nil != m_currentStatus) {
        [m_currentStatus setObject:partsName forKey:@"partsName"];
        return true;
    }
    return false;
}

@end
