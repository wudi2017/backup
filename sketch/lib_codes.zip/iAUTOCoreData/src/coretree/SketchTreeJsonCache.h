//
//  SketchTreeJsonCache.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/7.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef SketchTreeJsonCache_h
#define SketchTreeJsonCache_h
#import "Sketch.h"
#import "SketchCommon.h"
#import "SketchTreeExpandPolicy.h"
#import "SketchTreeCache.h"
#import "SketchTreeExpandPolicy.h"
#import "SketchTreeExpandCache.h"

@interface SketchTreeJsonCache : NSObject
{
    SketchTreeCache* m_sketchTreeCache;
    SketchTreeExpandCache* m_sketchTreeExpandCache;
    SketchTreeExpandPolicy* m_sketchTreeExpandPolicy;
    NSMutableDictionary*   m_expandTreeRootJsonLayer;
    NSMutableDictionary*   m_fastAccessJsonLayerMap; // expandLayerID - SketchTreeDataNode
    NSMutableDictionary*   m_virtualTreeMap; // expandLayerID - expandLayer 
}
- (instancetype) init;
- (bool) clear;
- (bool) load:(SketchTreeCache*)sketchTreeCache SketchTreeExpandCache:(SketchTreeExpandCache*)sketchTreeExpandCache SketchTreeExpandPolicy:(SketchTreeExpandPolicy*)sketchTreeExpandPolicy;
- (NSMutableDictionary*) rootJsonLayer;
- (NSMutableDictionary*) getJsonLayerByObjectID:(NSString*)objectID;

@end

#endif /* SketchTreeJsonCache_h */
