//
//  SketchTreeExpandPolicy.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/30.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SketchTreeExpandPolicy.h"

// SketchPageFilter
@implementation SketchTreeExpandPolicy

- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer;
{
    return NSIntegerMax;
}

@end

// SketchPageFilter default
@implementation SketchTreeExpandPolicyDefault

- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer;
{
    if ([[currentLayer className] isEqualToString:@"MSSymbolInstance"]) {
        return NSIntegerMax;
    }
    else{
        return -1;
    }
}

@end
