//
//  CoreDataTree.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/30.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreDataTree.h"
#import "SketchTreeCache.h"
#import "SketchPageFilter.h"
#import "SketchTreeExpandCache.h"
#import "SketchTreeCustomCache.h"
#import "CoreDataEngineConfig.h"
#import "CJsonXConvertor.h"
#import "SketchTreeJsonCache.h"
#import "PrivateDefine.h"

@implementation CoreDataTree

- (instancetype) init:(id<MSLayer>)rootLayer CoreDataEngineConfig:(CoreDataEngineConfig*)coreDataEngineConfig
{
    self = [super init];
    m_rootLayer = rootLayer;
    if ([[m_rootLayer className] isEqualToString:@"MSPage"]) {
        m_page = m_rootLayer;
    }
    else
    {
        m_page = [m_rootLayer parentPage];
    }
    m_coreDataEngineConfig = coreDataEngineConfig;
    
    m_originPageCustomCache = nil;
    m_originPageTree = nil;
    m_expandPageTree = nil;
    m_jsonCache = nil;
    
    return self;
}
- (NSString*) pageObjectID
{
    return [m_page objectID];
}
- (NSString*) pageName
{
    return [m_page name];
}
- (bool) load
{
    @autoreleasepool
    {
        // init CustomCache
        m_originPageCustomCache = [[SketchTreeCustomCache alloc] init];
        NSString* jsonString = [SketchCommon readLayerInfo:@"iAUTOData" layer:m_page];
        [m_originPageCustomCache loadFromJsonString:jsonString];
        
        // load origin page tree
        m_originPageTree = [[SketchTreeCache alloc] init];
        [m_originPageTree load:m_rootLayer];
        
        // load expand page tree
        m_expandPageTree = [[SketchTreeExpandCache alloc] init];
        [m_expandPageTree load:m_originPageTree SketchTreeExpandPolicy:m_coreDataEngineConfig.sketchTreeExpandPolicy];
        
        // load json cache
        m_jsonCache = [[SketchTreeJsonCache alloc] init];
        [m_jsonCache load:m_originPageTree SketchTreeExpandCache:m_expandPageTree SketchTreeExpandPolicy:m_coreDataEngineConfig.sketchTreeExpandPolicy];
    }
    return true;
}
- (bool) unload
{
    // delete temp expand page
    if (enableDebug) {
    }
    else
    { // for release, delete expand tree
        [SketchCommon removeLayer:[m_expandPageTree rootExpandLayer]];
    }
    
    [m_originPageCustomCache clear];
    m_originPageCustomCache = nil;
    
    [m_originPageTree clear];
    m_originPageTree = nil;
    
    [m_expandPageTree clear];
    m_expandPageTree = nil;
    
    [m_jsonCache clear];
    m_jsonCache = nil;
    
    return true;
}

- (CoreDataIterator*) rootIterator
{
    if (nil == m_expandPageTree) {
        [self load];
    }
    CoreDataIterator* coreCoreDataIterator = [[CoreDataIterator alloc] init:self];
    return coreCoreDataIterator;
}
- (bool) commit
{
    // commit custom cache, save data to the page
    NSMutableDictionary* customDataMap = [m_originPageCustomCache getDataMap];
    NSString* jsonString = [[[CJsonXConvertor alloc] init] convertXObjectToJsonString:customDataMap];
    [SketchCommon writeLayerInfo:@"iAUTOData" value:jsonString layer:m_page];
    return true;
}
- (SketchTreeCustomCache*) getSketchTreeCustomCacheCache
{
    return m_originPageCustomCache;
}
- (SketchTreeCache*) getSketchTreeCache
{
    return m_originPageTree;
}
- (SketchTreeExpandCache*) getSketchTreeExpandCache
{
    return m_expandPageTree;
}
- (SketchTreeJsonCache*) getSketchTreeJsonCache
{
    return m_jsonCache;
}
@end
