//
//  PrivateDefine.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/1.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>

const NSString * BLOGTAG_COREDATA = @"CoreData";
bool enableDebug = false;
