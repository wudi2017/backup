//
//  PrivateDefine.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/1.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef PrivateDefine_h
#define PrivateDefine_h

extern const NSString * BLOGTAG_COREDATA;
extern bool enableDebug;

#endif /* PrivateDefine_h */
