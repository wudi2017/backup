//
//  CoreDataEngineConfigs.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/4.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef CoreDataEngineConfig_h
#define CoreDataEngineConfig_h

#import "Sketch.h"
#import "SketchPageFilter.h"
#import "SketchTreeExpandPolicy.h"

@interface CoreDataEngineConfig : NSObject

@property id<MSDocument> document;
@property NSString* workSpace;
@property SketchPageFilter* sketchPageFilter;
@property SketchTreeExpandPolicy* sketchTreeExpandPolicy;

@end


#endif /* CoreDataEngineConfig_h */
