//
//  SketchTreeExpandCache.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SketchTreeExpandCache.h"
#import "CFileUtils.h"
#import "PrivateDefine.h"
#import "CJSONXConvertor.h"

const NSInteger CorrespondType_DirectCorrespond = 0x00000001;
const NSInteger CorrespondType_DirectExpand = 0x00000002;
const NSInteger CorrespondType_DeepExpand = 0x00000004;
const NSInteger CorrespondType_Virtual = 0x00000008;
const NSInteger CorrespondType_Replaced = 0x00000010;

@implementation SketchTreeExpandCache

- (instancetype) init
{
    self = [super init];
    m_rootExpandLayer = nil;
    m_expandCorrespondMap = [NSMutableDictionary dictionary];
    m_expandCorrespondTypeMap = [NSMutableDictionary dictionary];
    m_expandMap = [NSMutableDictionary dictionary];
    m_expandCorrespondMasterMap = [NSMutableDictionary dictionary];
    m_expandCorrespondLevelMap = [NSMutableDictionary dictionary];
    return self;
}

- (bool) clear
{
    if (nil != m_expandCorrespondMap) {
        [m_expandCorrespondMap removeAllObjects];
        m_expandCorrespondMap = nil;
    }
    if (nil != m_expandCorrespondTypeMap) {
        [m_expandCorrespondTypeMap removeAllObjects];
        m_expandCorrespondTypeMap = nil;
    }
    if (nil != m_expandMap) {
        [m_expandMap removeAllObjects];
        m_expandMap = nil;
    }
    if (nil != m_expandCorrespondMasterMap) {
        [m_expandCorrespondMasterMap removeAllObjects];
        m_expandCorrespondMasterMap = nil;
    }
    if (nil != m_expandCorrespondLevelMap) {
        [m_expandCorrespondLevelMap removeAllObjects];
        m_expandCorrespondLevelMap = nil;
    }
    return true;
}

- (void) setCorrespondType:(NSString*)expandLayerObjectID Type:(NSInteger)type
{
    id val = [m_expandCorrespondTypeMap objectForKey:expandLayerObjectID];
    NSInteger originType = 0;
    if (nil != val) {
        originType = [val integerValue];
    }
    originType = originType | type;
    [m_expandCorrespondTypeMap setObject:[NSNumber numberWithInteger:originType] forKey:expandLayerObjectID];
}

- (void) leftDetachLayersbyLevel:(id<MSLayer>) layer CurrentLevel:(NSInteger)curLevel LeftLevel:(NSInteger)leftLevel
{
    if (curLevel>leftLevel) {
        [layer removeFromParent];
        return;
    }
    if ([layer containsLayers] ) {
        @autoreleasepool
        {
            NSMutableArray* subLayers = [layer layers];
            NSMutableArray * copyArray = [NSMutableArray array];
            [copyArray addObjectsFromArray:subLayers];
            for (int i=0; i<[copyArray count]; i++) {
                id<MSLayer> subLayer = [copyArray objectAtIndex:i];
                [self leftDetachLayersbyLevel:subLayer CurrentLevel:curLevel+1 LeftLevel:leftLevel];
            }
            [copyArray removeAllObjects];
        }
    }
}

- (void) detachTreeSymbols:(id<MSLayer>)detachLayer CorrespondOriginLayer:(id<MSLayer>)currentLayer ReplaycedLayer:(id<MSSymbolMaster>)replacedLayer CurrentPositon:(NSString*)strPosition
{
//    BLOG(BLOGTAG_COREDATA, @"detachTreeSymbols %@", strPosition);
//    // for debug
//    if ([strPosition isEqualToString:@"08 Sirius XM - X_Temp->04.08.08.01 - SXM / Home Copy 5 basetestYYY->UI/System/Left Navigation"]) {
//        BLOG(BLOGTAG_COREDATA, @"DEBUGPOINT");
//    }
    
    NSString* currentLayerObjectID = [currentLayer objectID];
    
    bool bIsSymbolInstance = [SketchCommon isInstance:detachLayer];
    NSInteger iDetachLevel = NSIntegerMax;
    if (bIsSymbolInstance) {
        iDetachLevel = [m_sketchTreeExpandPolicy instanceDetachLevel:currentLayer ExpandLayer:detachLayer];
    }
    
    if (nil != [m_sketchTreeCache getOriginLayerByObjectID:currentLayerObjectID]) {
        if (bIsSymbolInstance && iDetachLevel >= 0) {
            // need detach [direct detach]
        }
        else
        {
            // make direct correspond info
            NSString* detachLayerID = [detachLayer objectID];
            NSString* currentLayerID = [currentLayer objectID];
            [self setCorrespondType:detachLayerID Type:CorrespondType_DirectCorrespond];
            if (nil != replacedLayer) {
                [self setCorrespondType:detachLayerID Type:CorrespondType_Replaced];
                [m_expandCorrespondMasterMap setObject:replacedLayer forKey:detachLayerID];
            }
            [m_expandMap setObject:detachLayer forKey:detachLayerID];
            [m_expandCorrespondMap setObject:currentLayer forKey:detachLayerID];
        }
    }
    else
    {
        if (bIsSymbolInstance && iDetachLevel >= 0) {
            // need detach [deep detach]
        }
        else
        {
            // make virtual correspond info
            NSString* detachLayerID = [detachLayer objectID];
            [self setCorrespondType:detachLayerID Type:CorrespondType_Virtual];
            if (nil != replacedLayer) {
                [self setCorrespondType:detachLayerID Type:CorrespondType_Replaced];
                [m_expandCorrespondMasterMap setObject:replacedLayer forKey:detachLayerID];
            }
            [m_expandMap setObject:detachLayer forKey:detachLayerID];
            [m_expandCorrespondMap setObject:currentLayer forKey:detachLayerID];
        }
    }
    
    
    // find sub layers
    NSMutableArray * subDetachLayers = nil;
    NSMutableArray * subOriginLayers = nil;
    
    if ([detachLayer containsLayers]) {
        subDetachLayers = [detachLayer containedLayers];
        subOriginLayers = [currentLayer containedLayers];
    }
    else
    {
        if (bIsSymbolInstance && iDetachLevel >= 0) {
            
            // detach instance
            NSString* detachLayerID = [detachLayer objectID];
            id<MSSymbolInstance> detachLayerSymbolInstance = detachLayer;
            id<MSLayerGroup> detachLayerGroup = [SketchCommon detachByReplacingWithMasterGroup:detachLayerSymbolInstance];
            
            // special: if detach layer is root layer, update current root layer
            if ([[m_rootExpandLayer objectID] isEqualToString:detachLayerID]) {
                m_rootExpandLayer = detachLayerGroup;
            }
            
            if ([detachLayerGroup containsLayers] && [[detachLayerGroup layers] count]>0) {
                subDetachLayers = [detachLayerGroup containedLayers];
            }
            
            // make expand correspond info
            if (nil != detachLayerGroup) {
                NSString* detachGroupID = [detachLayerGroup objectID];
                [m_expandCorrespondLevelMap setObject:[NSNumber numberWithInteger:iDetachLevel] forKey:detachGroupID];
                if (nil != replacedLayer) {
                    [self setCorrespondType:detachGroupID Type:CorrespondType_Replaced];
                    [m_expandCorrespondMasterMap setObject:replacedLayer forKey:detachGroupID];
                }
                if (nil != [m_sketchTreeCache getOriginLayerByObjectID:currentLayerObjectID]) {
                    [self setCorrespondType:detachGroupID Type:CorrespondType_DirectExpand];
                    [m_expandMap setObject:detachLayerGroup forKey:detachGroupID];
                }
                else
                {
                    [self setCorrespondType:detachGroupID Type:CorrespondType_DeepExpand];
                    [m_expandMap setObject:detachLayerGroup forKey:detachGroupID];
                }
                if (nil != currentLayer) {
                    [m_expandCorrespondMap setObject:currentLayer forKey:detachGroupID];
                }
            }

            // get sub origin layers
            subOriginLayers = [[detachLayerSymbolInstance symbolMaster] layers];
            
            // May be the sub instance replaced with other instance, need to save the correspond correct master
            NSMutableArray* subOriginAllLayers = [[detachLayerSymbolInstance symbolMaster] children];
            NSMutableArray* subDetachAllLayers = [detachLayerGroup children];
            NSMutableArray* overrides = [detachLayerSymbolInstance overrides];
            if (nil != subOriginAllLayers && nil != overrides && [[overrides className] rangeOfString:@"Dictionary"].location != NSNotFound) {
                for (int iSubOriLayer=0; iSubOriLayer<[subOriginAllLayers count]; iSubOriLayer++) {

                    id<MSLayer> subOriginLayer = [subOriginAllLayers objectAtIndex:iSubOriLayer];
                    NSString* subOriginLayerObjectID = [subOriginLayer objectID];

                    NSMutableDictionary* overrideItem = [overrides valueForKey:subOriginLayerObjectID];
                    if (nil != overrideItem && [[overrideItem className] rangeOfString:@"Dictionary"].location != NSNotFound ) { // overrideItem may textoverride, overrideItem type is string value
                        NSString* symbolID = [overrideItem objectForKey:@"symbolID"];
                        if (nil != symbolID && ![symbolID isEqualToString:@""]) {
                            NSDictionary* allSymbols= [[[SketchCommon document] documentData] symbolMap];
                            id<MSSymbolMaster> symbolMaster = [allSymbols valueForKey:symbolID];
                            if (nil != symbolMaster) {
                                if (nil != subDetachAllLayers) {
                                    id<MSLayer> subDetachLayer = [subDetachAllLayers objectAtIndex:iSubOriLayer];
                                
                                    // change realName for the instance replaced
                                    NSString* masterName = [symbolMaster name];
                                    [subDetachLayer setName:masterName];
                                    
                                    // cache symbolmaster
                                    NSString* subDetachLayerObjectID = [subDetachLayer objectID];
                                    [m_expandCorrespondMasterMap setObject:symbolMaster forKey:subDetachLayerObjectID];
                                }
                            }
                        }
                    }

                }
            }
        }
    }
    
    if (subDetachLayers && [subDetachLayers count] > 0) {
        
        @autoreleasepool
        {
            NSMutableArray * copiedSubDetachLayers = [NSMutableArray array];
            [copiedSubDetachLayers addObjectsFromArray:subDetachLayers];
            for (int iSubLayer=0; iSubLayer < copiedSubDetachLayers.count; iSubLayer++) {
                id<MSLayer> subDetachLayer = [copiedSubDetachLayers objectAtIndex:iSubLayer];
                NSString* subDetachLayerObjectID = [subDetachLayer objectID];
                
                id<MSLayer> subCurrentLayer = [subOriginLayers objectAtIndex:iSubLayer];
                
                id<MSSymbolMaster> replacedLayer = [m_expandCorrespondMasterMap objectForKey:subDetachLayerObjectID];
                
                NSString* subPosition = [strPosition stringByAppendingString:@"->"];
                subPosition = [subPosition stringByAppendingString:subDetachLayer.name];
                [self detachTreeSymbols:subDetachLayer CorrespondOriginLayer:subCurrentLayer ReplaycedLayer:replacedLayer CurrentPositon:subPosition];
            }
            [copiedSubDetachLayers removeAllObjects];
        }
    }
}

- (bool) load:(SketchTreeCache*)sketchTreeCache SketchTreeExpandPolicy:(SketchTreeExpandPolicy*)sketchTreeExpandPolicy
{
    m_sketchTreeCache = sketchTreeCache;
    m_sketchTreeExpandPolicy = sketchTreeExpandPolicy;
    
    id<MSLayer> originRootLayer = [m_sketchTreeCache rootLayer];
    
    // copy origin object
    NSString* originPageName = [originRootLayer name];
    NSString* tempPageName = [originPageName stringByAppendingString:@"_Temp"];
    if ([[originRootLayer className] isEqualToString:@"MSPage"]) {
        m_rootExpandLayer = [SketchCommon duplicatePage:originRootLayer NewName:tempPageName];
    }
    else
    {
        m_rootExpandLayer = [originRootLayer copy];
        id<MSLayerGroup> parentGroup = [originRootLayer parentGroup];
        [parentGroup addLayer:m_rootExpandLayer];
    }

    // deatch newPage and make correspondInfo
    [self detachTreeSymbols:m_rootExpandLayer CorrespondOriginLayer:originRootLayer ReplaycedLayer:nil CurrentPositon:m_rootExpandLayer.name];
    
    return true;
}
- (id<MSLayer>) rootExpandLayer
{
    return m_rootExpandLayer;
}
- (NSString*) getOriginLayerObjectIDbyExpandNodeObjectID:(NSString*)objectID
{
    id<MSLayer> originLayer = [self getOriginLayerbyExpandNodeObjectID:objectID];
    return [originLayer objectID];
}
- (id<MSLayer>) getOriginLayerbyExpandNodeObjectID:(NSString*)objectID
{
    return [m_expandCorrespondMap objectForKey:objectID];
}
- (id<MSSymbolMaster>) getReplacedMasterbyExpandNodeObjectID:(NSString*)objectID
{
    return [m_expandCorrespondMasterMap objectForKey:objectID];
}
- (NSInteger) getExpandCorrespondTypeByObjectID:(NSString*)objectID
{
    return [[m_expandCorrespondTypeMap objectForKey:objectID] integerValue];
}
- (id<MSLayer>) getExpandLayerbyExpandNodeObjectID:(NSString*)objectID
{
     return [m_expandMap objectForKey:objectID];
}
- (NSInteger) getExpandPolicyLevelbyExpandNodeObjectID:(NSString*)objectID
{
    NSInteger level = NSIntegerMax;
    NSNumber* levelNum = [m_expandCorrespondLevelMap objectForKey:objectID];
    if (nil != levelNum) {
        level = [levelNum integerValue];
    }
    return level;
}
@end
