//
//  SketchTreeCache.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SketchTreeCache.h"

@implementation SketchTreeCache

- (instancetype) init
{
    self = [super init];
    m_fastAccessOriginLayerMap = [NSMutableDictionary dictionary];
    return self;
}
- (bool) clear
{
    if (nil != m_fastAccessOriginLayerMap) {
        [m_fastAccessOriginLayerMap removeAllObjects];
        m_fastAccessOriginLayerMap = nil;
    }
    return true;
}
- (void) visitLayer:(id<MSLayer>)layer
{
    // visit current layer
    NSString * objectID = [layer objectID];
    NSString * name = [layer name];
    
    [m_fastAccessOriginLayerMap setObject:layer forKey:objectID];
    
    // trans sub layers
    if ([layer containsLayers]) {
        NSArray * subLayers = [layer containedLayers];
        for (int iSubLayer=0; iSubLayer < subLayers.count; iSubLayer++) {
            id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
            [self visitLayer:subLayer];
        }
    }
}

- (id<MSPage>) rootLayer
{
    return m_rootLayer;
}

- (id<MSLayer>) getOriginLayerByObjectID:(NSString*)objectID
{
    return [m_fastAccessOriginLayerMap objectForKey:objectID];
}

- (bool) load:(id<MSLayer>)rootLayer
{
    m_rootLayer = rootLayer;
    [self visitLayer:rootLayer];
    return true;
}

@end
