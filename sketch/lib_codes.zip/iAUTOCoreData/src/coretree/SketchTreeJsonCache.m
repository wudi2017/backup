//
//  SketchTreeJsonCache.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/7.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SketchTreeJsonCache.h"
#import "CJSONXConvertor.h"
#import "PrivateDefine.h"
#import "CFileUtils.h"
#import "CStringUtils.h"

@implementation SketchTreeJsonCache

- (instancetype) init
{
    self = [super init];
    m_sketchTreeCache = nil;
    m_sketchTreeExpandCache = nil;
    m_sketchTreeExpandPolicy = nil;
    m_expandTreeRootJsonLayer = [NSMutableDictionary dictionary];
    m_fastAccessJsonLayerMap = [NSMutableDictionary dictionary];
    m_virtualTreeMap = [NSMutableDictionary dictionary];
    return self;
}

- (void) clearNode:(NSMutableDictionary*)node
{
    NSMutableArray* subNodes = [node objectForKey:@"layers"];
    for (int iSub=0; iSub<[subNodes count]; iSub++) {
        NSMutableDictionary* subNode = [subNodes objectAtIndex:iSub];
        [self clearNode:subNode];
    }
    
    // remove all property
    [node removeAllObjects];
}
- (bool) clear
{
    m_sketchTreeCache = nil;
    m_sketchTreeExpandCache = nil;
    m_sketchTreeExpandPolicy = nil;
    if (nil != m_expandTreeRootJsonLayer) {
        [self clearNode:m_expandTreeRootJsonLayer];
        m_expandTreeRootJsonLayer = nil;
    }
    if (nil != m_fastAccessJsonLayerMap) {
        [m_fastAccessJsonLayerMap removeAllObjects];
        m_fastAccessJsonLayerMap = nil;
    }
    if (nil != m_virtualTreeMap) {
        [m_virtualTreeMap removeAllObjects];
        m_virtualTreeMap = nil;
    }
    return true;
}
- (bool) addDirectCorrespondNode:(id<MSLayer>)layer
{
    NSString* objectID = [layer objectID];
    NSInteger correspondType = [m_sketchTreeExpandCache getExpandCorrespondTypeByObjectID:objectID];
    if ((correspondType & CorrespondType_DirectCorrespond) == CorrespondType_DirectCorrespond
        || (correspondType & CorrespondType_DirectExpand) == CorrespondType_DirectExpand) {
        [self addGenerateJonsNodeMap:objectID Layer:layer];
    }
    if ([layer containsLayers]) {
        NSArray * subLayers = [layer containedLayers];
        for (int iSubLayer=0; iSubLayer < subLayers.count; iSubLayer++) {
            id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
            [self addDirectCorrespondNode:subLayer];
        }
    }
    return true;
}
- (bool) isNeedGenerateJonsNode:(NSString*)objectID
{
    id<MSLayer> layer = [m_virtualTreeMap objectForKey:objectID];
    if (nil != layer) {
        return true;
    }
    else
    {
        return false;
    }
}
- (bool) addGenerateJonsNodeMap:(NSString*)objectID Layer:(id<MSLayer>)layer
{
    [m_virtualTreeMap setObject:layer forKey:objectID];
    return true;
}

- (bool) load:(SketchTreeCache*)sketchTreeCache SketchTreeExpandCache:(SketchTreeExpandCache*)sketchTreeExpandCache SketchTreeExpandPolicy:(SketchTreeExpandPolicy*)sketchTreeExpandPolicy;
{
    m_sketchTreeCache = sketchTreeCache;
    m_sketchTreeExpandCache = sketchTreeExpandCache;
    m_sketchTreeExpandPolicy = sketchTreeExpandPolicy;
    
    id<MSLayer> expandLayer = [m_sketchTreeExpandCache rootExpandLayer];
    m_expandTreeRootJsonLayer = [NSMutableDictionary dictionary];
    
    [self addDirectCorrespondNode:expandLayer];
    
    [self makeDetachJsonLayerInfo:expandLayer ExpandJsonLayer:m_expandTreeRootJsonLayer CurrentPositon:expandLayer.name];
    
    [self makeDetachJsonLayerCorrespondAbsoluteObjectID];
    
    [self makeDetachJsonLayerCorrespondrealFullID];
    
    if (enableDebug) {
        NSString* rootLayerName = [[m_sketchTreeExpandCache rootExpandLayer] name];
        rootLayerName = [CStringUtils toSlug:rootLayerName];
        NSString* detachJsonTreeName = [rootLayerName stringByAppendingString:@".detach.json"];
        
        NSString* filePath = [NSHomeDirectory() stringByAppendingString:@"/sketchplugin_iauto"];
        [CFileUtils writeArrayToFile:filePath FileName:detachJsonTreeName FileContent:m_expandTreeRootJsonLayer];
    }
    
    return true;
}

- (void) makeCurrentJsonLayerData:(id<MSLayer>)layer ExpandJsonLayer:(NSMutableDictionary*)expandJsonLayer
{
    // make node self info
    NSString* objectID = [layer objectID];
    [expandJsonLayer setObject:objectID forKey:@"expandLayerObjectID"];
    
    id<MSLayer> originLayer = [m_sketchTreeExpandCache getOriginLayerbyExpandNodeObjectID:objectID];
    NSString* className = [originLayer className];
    [expandJsonLayer setObject:className forKey:@"className"];
    
    NSString* name = [layer name];
    [expandJsonLayer setObject:name forKey:@"name"];
    
    CGRect rect = [layer rect];
    [expandJsonLayer setObject:[[CJsonSerializerCGRect instance] serializeToJson:rect] forKey:@"rect"];
    
    NSInteger correspondType = [m_sketchTreeExpandCache getExpandCorrespondTypeByObjectID:objectID];
    [expandJsonLayer setObject:[NSNumber numberWithInteger:correspondType] forKey:@"correspondType"];
    
    NSString* correspondLayerObjectID = [m_sketchTreeExpandCache getOriginLayerObjectIDbyExpandNodeObjectID:objectID];
    [expandJsonLayer setObject:correspondLayerObjectID forKey:@"originLayerObjectID"];
    
    if ((correspondType & CorrespondType_Replaced) == CorrespondType_Replaced) {
        id<MSSymbolMaster> replacedMaster = [m_sketchTreeExpandCache getReplacedMasterbyExpandNodeObjectID:objectID];
        NSString* replacedMasterObjectID = [replacedMaster objectID];
        [expandJsonLayer setObject:replacedMasterObjectID forKey:@"replacedMasterObjectID"];
    }
    
    if ([className isEqualToString:@"MSTextLayer"]) {
        id<MSTextLayer> textLayer = layer;
        NSString* stringValue = [textLayer stringValue];
        [expandJsonLayer setObject:stringValue forKey:@"stringValue"];
    }
    
//    if(![[layer className] isEqualToString:@"MSPage"]){
//        NSString* imagePath = [NSHomeDirectory() stringByAppendingString:@"/sketchplugin_iauto/images"];
//        [CFileUtils createDirectory:imagePath];
//        [SketchCommon exportLayerTofile:layer filePath:imagePath];
//        NSString* layerName = [CStringUtils toSlug:[layer objectID]];
//        NSString* imagePathSrc = [[[imagePath stringByAppendingString:@"/"] stringByAppendingString:layerName] stringByAppendingString:@".png"];
//        [expandJsonLayer setObject:imagePathSrc forKey:@"imagePath"];
//    }

    // BLOG(@"test", @"name:%s", treeDataNode.className)
    
    // add child
    if ([layer containsLayers]) {
        NSArray * subLayers = [layer containedLayers];
        for (int iSubLayer=0; iSubLayer < subLayers.count; iSubLayer++) {
            NSString* subLayerID = [[subLayers objectAtIndex:iSubLayer] objectID];

            if ([self isNeedGenerateJonsNode:subLayerID]) {
                
                NSMutableArray* layers = [expandJsonLayer objectForKey:@"layers"];
                if (nil == layers) {
                    layers = [NSMutableArray array];
                    [expandJsonLayer setObject:layers forKey:@"layers"];
                }
                
                NSMutableDictionary* subTreeDataNode = [NSMutableDictionary dictionary];
                [layers addObject:subTreeDataNode];
            }
        }
    }
}
- (void) AddGenerateNodeTableLayersbyLevel:(id<MSLayer>)layer CurrentLevel:(NSInteger)curLevel ExpandLevel:(NSInteger)leftLevel
{
    if (curLevel<=leftLevel) {
        [self addGenerateJonsNodeMap:[layer objectID] Layer:layer];
    }
    else
    {
        return;
    }
    if ([layer containsLayers] ) {
        @autoreleasepool
        {
            NSMutableArray* subLayers = [layer layers];
            NSMutableArray * copyArray = [NSMutableArray array];
            [copyArray addObjectsFromArray:subLayers];
            for (int i=0; i<[copyArray count]; i++) {
                id<MSLayer> subLayer = [copyArray objectAtIndex:i];
                [self AddGenerateNodeTableLayersbyLevel:subLayer CurrentLevel:curLevel+1 ExpandLevel:leftLevel];
            }
            [copyArray removeAllObjects];
        }
    }
}
- (void) makeDetachJsonLayerInfo:(id<MSLayer>)layer ExpandJsonLayer:(NSMutableDictionary*)expandJsonLayer CurrentPositon:(NSString*)strPosition
{
    //BLOG(BLOGTAG_COREDATA, @"makeDetachJsonLayer subPosition: %@", strPosition);
    // for debug
    //    if ([strPosition isEqualToString:@"08 Sirius XM - X_Temp/04.08.08.01 - SXM / Home Copy 5 basetestYYY/UI/System/Left Navigation/Group/Icon/System/Blank"]) {
    //        BLOG(BLOGTAG_COREDATA, @"DEBUGPOINT");
    //    }
    
    // add need generate node map
    NSString* expandLayerObjectID = [layer objectID];
    id<MSLayer> originLayer = [m_sketchTreeExpandCache getOriginLayerbyExpandNodeObjectID:expandLayerObjectID];
    if (nil != originLayer) {
        NSString* originLayerClassName = [originLayer className];
        if ([originLayerClassName isEqualToString:@"MSSymbolInstance"]) {
            NSInteger iExpandLevel = [m_sketchTreeExpandCache getExpandPolicyLevelbyExpandNodeObjectID:expandLayerObjectID];
            [self AddGenerateNodeTableLayersbyLevel:layer CurrentLevel:0 ExpandLevel:iExpandLevel];
        }
        else
        {
            [self AddGenerateNodeTableLayersbyLevel:layer CurrentLevel:0 ExpandLevel:NSIntegerMax];
        }
    }

    // make current json Node info
    NSString* objectID = [layer objectID];
    if ([self isNeedGenerateJonsNode:objectID]) {
        // make fast access
        [m_fastAccessJsonLayerMap setObject:layer forKey:[layer objectID]];
        // make tree node info
        [self makeCurrentJsonLayerData:layer ExpandJsonLayer:expandJsonLayer];
    }
    
    // trans sub layers
    if ([layer containsLayers]) {
        NSArray * subLayers = [layer containedLayers];
        for (int iSubLayer=0; iSubLayer < subLayers.count; iSubLayer++) {
            id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
            
            // try get subJson Node
            NSMutableArray* subTreeDataNodes = [expandJsonLayer objectForKey:@"layers"];
            NSMutableDictionary* subTreeDataNode = nil;
            if (nil != subTreeDataNodes) {
                subTreeDataNode = [subTreeDataNodes objectAtIndex:iSubLayer];
            }
            
            // call sub node makeDetachJsonLayerInfo
            NSString* subPosition = [strPosition stringByAppendingString:@"->"];
            subPosition = [subPosition stringByAppendingString:subLayer.name];
            if (nil != subTreeDataNode) {
                [self makeDetachJsonLayerInfo:subLayer ExpandJsonLayer:subTreeDataNode CurrentPositon:subPosition];
            }
        }
    }
}

- (void) makeDetachJsonLayerCorrespondAbsoluteObjectID_visitJsonLayer:(NSMutableDictionary*)jsonLayer AbsoluteObjectID:(NSString*)pabsoluteObjectID
{
    NSString* curJsonLayerObjectID = [jsonLayer objectForKey:@"originLayerObjectID"];
    NSInteger correspondType = [[jsonLayer objectForKey:@"correspondType"] integerValue];
    NSString* curAbsoluteLayerObjectID = @"";
//    if ((correspondType & CorrespondType_Replaced) == CorrespondType_Replaced) {
//        curJsonLayerObjectID = [jsonLayer objectForKey:@"replacedMasterObjectID"];
//    }
    if([pabsoluteObjectID isEqualToString:@""]){
        curAbsoluteLayerObjectID = [pabsoluteObjectID stringByAppendingString:curJsonLayerObjectID];
        [jsonLayer setObject:curAbsoluteLayerObjectID forKey:@"correspondAbsoluteObjectID"];
    }
    else{
        curAbsoluteLayerObjectID = [[pabsoluteObjectID stringByAppendingString:@"_"] stringByAppendingString:curJsonLayerObjectID];
        [jsonLayer setObject:curAbsoluteLayerObjectID forKey:@"correspondAbsoluteObjectID"];
    }
    
    NSMutableArray* subJsonLayers = [jsonLayer objectForKey:@"layers"];
    if (nil != subJsonLayers) {
        NSString* curLayerClassName = [jsonLayer objectForKey:@"className"];
        NSString* nextpabsoluteObjectID = pabsoluteObjectID;
        if([curLayerClassName isEqualToString:@"MSSymbolInstance"]){
            nextpabsoluteObjectID = curAbsoluteLayerObjectID;
        }
        for (int iSubJsonLayer=0; iSubJsonLayer<[subJsonLayers count]; iSubJsonLayer++) {
            NSMutableDictionary* subJsonLayer = [subJsonLayers objectAtIndex:iSubJsonLayer];
            
//            NSString* subJsonLayerObjectID = [subJsonLayer objectForKey:@"originLayerObjectID"];
//            NSInteger correspondType = [[subJsonLayer objectForKey:@"correspondType"] integerValue];
//            if ((correspondType & CorrespondType_Replaced) == CorrespondType_Replaced) {
//                subJsonLayerObjectID = [subJsonLayer objectForKey:@"replacedMasterObjectID"];
//            }
            
//            NSString* subAbsoluteObjectID = [absoluteObjectID stringByAppendingString:@"_"];
//            subAbsoluteObjectID = [subAbsoluteObjectID stringByAppendingString:subJsonLayerObjectID];
            [self makeDetachJsonLayerCorrespondAbsoluteObjectID_visitJsonLayer:subJsonLayer AbsoluteObjectID:nextpabsoluteObjectID];
        }
    }
}
- (void) makeDetachJsonLayerCorrespondAbsoluteObjectID
{
    NSString* rootCorrespondAbsoluteObjectID = @"";
//    if([[m_expandTreeRootJsonLayer className] isEqualToString:@"MSSymbolInstance"]){
//        rootCorrespondAbsoluteObjectID = [m_expandTreeRootJsonLayer objectForKey:@"originLayerObjectID"];
//    }
    [self makeDetachJsonLayerCorrespondAbsoluteObjectID_visitJsonLayer:m_expandTreeRootJsonLayer AbsoluteObjectID:rootCorrespondAbsoluteObjectID];
}


- (void) makeDetachJsonLayerCorrespondrealFullID_visitJsonLayer:(NSMutableDictionary*)jsonLayer ParentRealFullID:(NSString*)parentRealFullID
{
    NSString* curJsonLayerObjectID = [jsonLayer objectForKey:@"originLayerObjectID"];
    NSInteger correspondType = [[jsonLayer objectForKey:@"correspondType"] integerValue];
    NSString* curRealFullID = @"";
    
    // check master replaced
    if ((correspondType & CorrespondType_Replaced) == CorrespondType_Replaced) {
        curJsonLayerObjectID = [jsonLayer objectForKey:@"replacedMasterObjectID"];
    }
    
    if([parentRealFullID isEqualToString:@""]){
        curRealFullID = [parentRealFullID stringByAppendingString:curJsonLayerObjectID];
        [jsonLayer setObject:curRealFullID forKey:@"realFullID"];
    }
    else{
        curRealFullID = [[parentRealFullID stringByAppendingString:@"_"] stringByAppendingString:curJsonLayerObjectID];
        [jsonLayer setObject:curRealFullID forKey:@"realFullID"];
    }
    
    NSMutableArray* subJsonLayers = [jsonLayer objectForKey:@"layers"];
    if (nil != subJsonLayers) {
        for (int iSubJsonLayer=0; iSubJsonLayer<[subJsonLayers count]; iSubJsonLayer++) {
            NSMutableDictionary* subJsonLayer = [subJsonLayers objectAtIndex:iSubJsonLayer];
            // SString* subAbsoluteObjectID = [absoluteObjectID stringByAppendingString:@"_"];
            // subAbsoluteObjectID = [subAbsoluteObjectID stringByAppendingString:subJsonLayerObjectID];
            [self makeDetachJsonLayerCorrespondrealFullID_visitJsonLayer:subJsonLayer ParentRealFullID:curRealFullID];
        }
    }
}
- (void) makeDetachJsonLayerCorrespondrealFullID
{
    NSString* realFullID = @"";
    //    if([[m_expandTreeRootJsonLayer className] isEqualToString:@"MSSymbolInstance"]){
    //        rootCorrespondAbsoluteObjectID = [m_expandTreeRootJsonLayer objectForKey:@"originLayerObjectID"];
    //    }
    [self makeDetachJsonLayerCorrespondrealFullID_visitJsonLayer:m_expandTreeRootJsonLayer ParentRealFullID:realFullID];
}

- (NSMutableDictionary*) rootJsonLayer
{
    return m_expandTreeRootJsonLayer;
}
- (NSMutableDictionary*) getJsonLayerByObjectID:(NSString*)objectID
{
    return [m_fastAccessJsonLayerMap objectForKey:objectID];
}
@end
