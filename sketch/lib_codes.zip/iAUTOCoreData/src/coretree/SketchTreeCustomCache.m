//
//  SketchLogicTreeCustomData.m
//  iAUTOCoreData
//
//  Created by nb on 2019/1/1.
//  Copyright © 2019年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SketchTreeCustomCache.h"
#import "CJSONXConvertor.h"

@implementation SketchTreeCustomCache

- (instancetype) init
{
    self = [super init];
    m_fastAccessDataMap = [NSMutableDictionary dictionary];
    return self;
}
- (bool) clear
{
    if (nil != m_fastAccessDataMap) {
        for (NSString* objectID in m_fastAccessDataMap) {
            NSMutableDictionary* nodeCustomData = [m_fastAccessDataMap objectForKey:objectID];
            if (nil != nodeCustomData) {
                [nodeCustomData removeAllObjects];
            }
        }
        [m_fastAccessDataMap removeAllObjects];
        m_fastAccessDataMap = nil;
    }
    return true;
}
- (bool) loadFromJsonString:(NSString*)jsonString
{
    if (nil != jsonString) {
        CJsonXConvertor* jsonxConv = [[CJsonXConvertor alloc] init];
        NSDictionary* jsonObj = [jsonxConv convertJsonStringToXObject:jsonString];
        
        //m_fastAccessDataMap = [jsonObj mutableCopy];
        
        // deep mutable copy
        CJsonXConvertor* jxConv = [[CJsonXConvertor alloc] init];
        m_fastAccessDataMap = [jxConv convertXObjectToValidJsonFormatObject:jsonObj];
    }
    return true;
}
- (NSMutableDictionary*) getDataMap
{
    return m_fastAccessDataMap;
}
- (id) getCustomDataByKey:(NSString*)objectID CustomKey:(NSString*)customKey
{
    id retData = nil;
    
    if (nil != m_fastAccessDataMap) {
        NSMutableDictionary* nodeCustomData = [m_fastAccessDataMap objectForKey:objectID];
        if (nil != nodeCustomData) {
            retData = [nodeCustomData objectForKey:customKey];
        }
    }
    
    return retData;
}
- (bool) setCustomDataForKey:(NSString*)objectID CustomKey:(NSString*)customKey CustomData:(id)customData
{
    if (nil != m_fastAccessDataMap) {
        NSMutableDictionary* nodeCustomData = [m_fastAccessDataMap objectForKey:objectID];
        if (nil == nodeCustomData) {
            nodeCustomData = [NSMutableDictionary dictionary];
            [m_fastAccessDataMap setObject:nodeCustomData forKey:objectID];
        }
        [nodeCustomData setObject:customData forKey:customKey];
        return true;
    }
    return false;
}
- (bool) clearCustomDataByKey:(NSString*)objectID CustomKey:(NSString*)customKey
{
    if (nil != m_fastAccessDataMap) {
        NSMutableDictionary* nodeCustomData = [m_fastAccessDataMap objectForKey:objectID];
        if (nil != nodeCustomData) {
            [nodeCustomData removeObjectForKey:customKey];
        }
    }
    return true;
}

@end
