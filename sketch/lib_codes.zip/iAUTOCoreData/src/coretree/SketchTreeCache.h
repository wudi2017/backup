//
//  SketchTreeCache.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef SketchTreeCache_h
#define SketchTreeCache_h

#import "Sketch.h"

@interface SketchTreeCache : NSObject
{
    id<MSLayer> m_rootLayer;
    NSMutableDictionary* m_fastAccessOriginLayerMap;
}

- (instancetype) init;
- (bool) clear;
- (bool) load:(id<MSLayer>)rootLayer;
- (id<MSPage>) rootLayer;
- (id<MSLayer>) getOriginLayerByObjectID:(NSString*)objectID;

@end


#endif /* SketchTreeCache_h */
