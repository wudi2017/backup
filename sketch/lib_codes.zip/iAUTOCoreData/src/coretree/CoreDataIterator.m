//
//  CoreDataIterator.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreDataIterator.h"
#import "CoreDataTree.h"
#import "SketchTreeExpandCache.h"
#import "SketchTreeJsonCache.h"
#import "SketchTreeCustomCache.h"
#import "CLog.h"
#import "CJSONXConvertor.h"

const NSString* CoreDataIteratorType_Origin = @"CoreDataIteratorType_Origin";
const NSString* CoreDataIteratorType_Expand = @"CoreDataIteratorType_Expand";
const NSString* CoreDataIteratorType_Replaced = @"CoreDataIteratorType_Replaced";

extern const NSInteger CorrespondType_DirectCorrespond;
extern const NSInteger CorrespondType_DirectExpand;
extern const NSInteger CorrespondType_DeepExpand;
extern const NSInteger CorrespondType_Virtual;
extern const NSInteger CorrespondType_Replaced;

@implementation CoreDataIterator

- (instancetype) init:(CoreDataTree*)coreDataTree
{
    self = [super init];
    m_coreDataTree = coreDataTree;
    [self setIterator:[[coreDataTree getSketchTreeJsonCache] rootJsonLayer]];
    return self;
}
- (void) setIterator:(NSMutableDictionary*)jsonNode
{
    m_currentNodeForExpandTree = jsonNode;
    
    NSString* expandLayerObjectID = [m_currentNodeForExpandTree objectForKey:@"expandLayerObjectID"];
    NSString* originLayerObjectID = [m_currentNodeForExpandTree objectForKey:@"originLayerObjectID"];
    NSInteger correspondType = [[m_currentNodeForExpandTree objectForKey:@"correspondType"] integerValue];
    m_originLayer = [[m_coreDataTree getSketchTreeExpandCache] getOriginLayerbyExpandNodeObjectID:expandLayerObjectID];
    m_expandLayer = [[m_coreDataTree getSketchTreeExpandCache] getExpandLayerbyExpandNodeObjectID:expandLayerObjectID];
    m_replacedLayerMaster = [[m_coreDataTree getSketchTreeExpandCache] getReplacedMasterbyExpandNodeObjectID:expandLayerObjectID];
}
- (NSString*) type
{
    NSString* type = nil;
    NSInteger correspondType = [[m_currentNodeForExpandTree objectForKey:@"correspondType"] integerValue];
    if ((correspondType & CorrespondType_DirectCorrespond) == CorrespondType_DirectCorrespond
        || (correspondType & CorrespondType_DirectExpand) == CorrespondType_DirectExpand) {
        type = CoreDataIteratorType_Origin;
    }
    else
    {
        if ((correspondType & CorrespondType_Replaced) == CorrespondType_Replaced) {
            type = CoreDataIteratorType_Replaced;
        }
        else
        {
            type = CoreDataIteratorType_Expand;
        }
    }
    return type;
}
- (NSString*) objectID
{
    return [m_originLayer objectID];
}
- (NSString*) absoluteObjectID
{
    NSString* absoluteObjectID = nil;
    if (nil != m_currentNodeForExpandTree) {
         absoluteObjectID = [m_currentNodeForExpandTree objectForKey:@"correspondAbsoluteObjectID"];
    }
    return absoluteObjectID;
}
- (NSString*) realFullID
{
    NSString* realFullID = nil;
    if (nil != m_currentNodeForExpandTree) {
        realFullID = [m_currentNodeForExpandTree objectForKey:@"realFullID"];
    }
    return realFullID;
}
- (NSString*) className
{
    return [m_originLayer className];
}
- (NSString*) name
{
    int32_t correspondType = [[m_currentNodeForExpandTree objectForKey:@"correspondType"] integerValue];;
    if ((correspondType & CorrespondType_DirectCorrespond) == CorrespondType_DirectCorrespond
        || (correspondType && CorrespondType_DirectExpand) == CorrespondType_DirectExpand) {
        return [m_originLayer name];
    }
    else
    {
        return [m_currentNodeForExpandTree objectForKey:@"name"];
    }
}
- (bool) setName:(NSString*)name
{
    if ([[self type] isEqualToString:CoreDataIteratorType_Expand]) {
        return false;
    }
    [m_originLayer setName:name];
    return true;
}
- (CGRect) rect
{
    if ([[self type] isEqualToString:CoreDataIteratorType_Origin]) {
        return [m_originLayer rect];
    }
    else
    {
        NSMutableDictionary* rectDict = [m_currentNodeForExpandTree objectForKey:@"rect"];
        return [[CJsonSerializerCGRect instance] parseFormJson:rectDict];
    }
}
- (bool) setRect:(CGRect)rect
{
    if ([[self type] isEqualToString:CoreDataIteratorType_Expand]) {
        return false;
    }
    [m_originLayer setRect:rect];
    return false;
}
- (id<MSAbsoluteRect>) absoluteRect
{
    return [m_originLayer absoluteRect];
}
- (bool) setAbsoluteRect:(id<MSAbsoluteRect>)absoluteRect
{
    if ([[self type] isEqualToString:CoreDataIteratorType_Expand]) {
        return false;
    }
    [m_originLayer setAbsoluteRect:absoluteRect];
    return true;
}
- (NSDictionary*) overrides
{
    return [m_originLayer overrides];
}
- (bool) setOverrides:(NSDictionary*)overrides
{
    if ([[self type] isEqualToString:CoreDataIteratorType_Expand]) {
        return false;
    }
    [m_originLayer setOverrides:overrides];
    return true;
}
- (NSString*) stringValue
{
    NSString* stringValue = [m_currentNodeForExpandTree objectForKey:@"stringValue"];
    return stringValue;
}

- (bool) hasChildrens
{
    NSMutableArray* subNodes = [m_currentNodeForExpandTree objectForKey:@"layers"];
    if (nil != subNodes) {
        if (subNodes.count > 0) {
            return true;
        }
        else{
            return false;
        }
    }
    else
    {
        return false;
    }
}

- (NSArray<CoreDataIterator*>*) childrens
{
    NSMutableArray* retIts = nil;
    
    NSMutableArray* subNodes = [m_currentNodeForExpandTree objectForKey:@"layers"];
    if (nil != subNodes) {
        retIts = [NSMutableArray array];
        for (int iNode=0; iNode <  subNodes.count; iNode++) {
            NSMutableDictionary* subNode = [subNodes objectAtIndex:iNode];
            
            CoreDataIterator* subIt = [[CoreDataIterator alloc] init:m_coreDataTree];
            [subIt setIterator:subNode];
            [retIts addObject:subIt];
        }
    }
    
    return retIts;
}

- (bool) setCustomData:(NSString*)customKey CustomData:(id)customData
{
//    if (nil == [self objectID]) {
//        BLOG(@"EE", @"");
//    }
    NSString* absoluteObjectID = [self absoluteObjectID];
    return [[m_coreDataTree getSketchTreeCustomCacheCache] setCustomDataForKey:absoluteObjectID CustomKey:customKey CustomData:customData];
}
- (id) getCustomData:(NSString*)customKey
{
    NSString* absoluteObjectID = [self absoluteObjectID];
    return [[m_coreDataTree getSketchTreeCustomCacheCache] getCustomDataByKey:absoluteObjectID CustomKey:customKey];
}
- (bool) clearCustomData:(NSString*)customKey
{
    NSString* absoluteObjectID = [self absoluteObjectID];
    return [[m_coreDataTree getSketchTreeCustomCacheCache] clearCustomDataByKey:absoluteObjectID CustomKey:customKey];
}

- (id<MSLayer>) originLayer
{
    return m_originLayer;
}
- (id<MSLayer>) expandLayer
{
    return m_expandLayer;
}
- (id<MSSymbolMaster>) replacedLayerMaster
{
    return m_replacedLayerMaster;
}
@end
