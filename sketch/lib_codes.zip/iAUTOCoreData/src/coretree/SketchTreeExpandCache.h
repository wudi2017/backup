//
//  TreeExpandCache.h
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#ifndef SketchTreeExpandCache_h
#define SketchTreeExpandCache_h

#import "Sketch.h"
#import "SketchCommon.h"
#import "SketchTreeExpandPolicy.h"
#import "SketchTreeCache.h"

extern const NSInteger CorrespondType_DirectCorrespond;
extern const NSInteger CorrespondType_DirectExpand;
extern const NSInteger CorrespondType_DeepExpand;
extern const NSInteger CorrespondType_Virtual;
extern const NSInteger CorrespondType_Replaced;

@interface SketchTreeExpandCache : NSObject
{
    id<MSLayer> m_rootExpandLayer;
    SketchTreeCache* m_sketchTreeCache;
    SketchTreeExpandPolicy* m_sketchTreeExpandPolicy;
    NSMutableDictionary*   m_expandMap;             // expandLayerID - expandLayer
    NSMutableDictionary*   m_expandCorrespondTypeMap; // expandLayerID - SketchExpandLayerCorrespondType
    NSMutableDictionary*   m_expandCorrespondMap; // expandLayerID - originLayer
    NSMutableDictionary*   m_expandCorrespondMasterMap; // expandLayerID - masterLayer
    NSMutableDictionary*   m_expandCorrespondLevelMap; // expandLayerID - expandLevel(int)
}

- (instancetype) init;
- (bool) clear;
- (bool) load:(SketchTreeCache*)sketchTreeCache SketchTreeExpandPolicy:(SketchTreeExpandPolicy*)sketchTreeExpandPolicy;
- (id<MSLayer>) rootExpandLayer;
- (NSInteger) getExpandCorrespondTypeByObjectID:(NSString*)objectID;
- (NSString*) getOriginLayerObjectIDbyExpandNodeObjectID:(NSString*)objectID;
- (id<MSLayer>) getOriginLayerbyExpandNodeObjectID:(NSString*)objectID;
- (id<MSSymbolMaster>) getReplacedMasterbyExpandNodeObjectID:(NSString*)objectID;
- (id<MSLayer>) getExpandLayerbyExpandNodeObjectID:(NSString*)objectID;
- (NSInteger) getExpandPolicyLevelbyExpandNodeObjectID:(NSString*)objectID;

@end



#endif /* SketchTreeExpandCache_h */
