//
//  SketchTreeExtendCache.h
//  iAUTOCoreData
//
//  Created by nb on 2019/1/1.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef SketchTreeCustomCache_h
#define SketchTreeCustomCache_h

@interface SketchTreeCustomCache : NSObject
{
    NSMutableDictionary* m_fastAccessDataMap;
}

- (instancetype) init;
- (bool) clear;
- (bool) loadFromJsonString:(NSString*)jsonString;
- (NSMutableDictionary*) getDataMap;
- (id) getCustomDataByKey:(NSString*)objectID CustomKey:(NSString*)customKey;
- (bool) setCustomDataForKey:(NSString*)objectID CustomKey:(NSString*)customKey CustomData:(id)customData;
- (bool) clearCustomDataByKey:(NSString*)objectID CustomKey:(NSString*)customKey;

@end

#endif /* SketchTreeExtendCache_h */
