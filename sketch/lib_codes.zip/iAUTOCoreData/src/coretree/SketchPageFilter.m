//
//  SketchPageFilter.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/30.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Foundation/Foundation.h>
#import "SketchPageFilter.h"

@implementation SketchPageFilter

- (bool) filterOut:(id<MSPage>)page
{
    return false;
}

@end


@implementation SketchPageFilterDefault

- (bool) filterOut:(id<MSPage>)page
{
    bool bFilterOut = false;
    NSMutableArray* filterNames = [NSMutableArray array];
    [filterNames addObject:@"symbol"];
    [filterNames addObject:@"_temp"];
    [filterNames addObject:@"_tmp"];
    
    NSString * currentPageName = [page name];
    NSString * currentPageNameLowercase = [[page name] lowercaseString];
    
    for (int i=0; i<[filterNames count]; i++) {
        NSString* filterName = [filterNames objectAtIndex:i];
        if ([currentPageNameLowercase rangeOfString:filterName].location != NSNotFound) {
            bFilterOut = true;
            break;
        }
    }
    
    return bFilterOut;
}

@end
