//
//  CoreDataEngine.m
//  iAUTOCoreData
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreDataEngine.h"
#import "Sketch.h"
#import "SketchCommon.h"
#import "CoreDataEngineConfig.h"

@implementation CoreDataEngine

+ (instancetype) instance
{
    static CoreDataEngine *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CoreDataEngine alloc] init];
    });
    return instance;
}

- (instancetype) init
{
    self = [super init];
    [self reset];
    return self;
}

- (bool) reset
{
    m_coreDataEngineConfig = [[CoreDataEngineConfig alloc] init];
    m_coreDataEngineConfig.document = nil;
    m_coreDataEngineConfig.workSpace = nil;
    m_coreDataEngineConfig.sketchPageFilter = [[SketchPageFilterDefault alloc] init];
    m_coreDataEngineConfig.sketchTreeExpandPolicy = [[SketchTreeExpandPolicyDefault alloc] init];
    return true;
}

- (bool) setPageFilter:(SketchPageFilter*)filter
{
    m_coreDataEngineConfig.sketchPageFilter = filter;
    return true;
}

- (bool) setSketchTreeExpandPolicy:(SketchTreeExpandPolicy*)expandPolicy
{
    m_coreDataEngineConfig.sketchTreeExpandPolicy = expandPolicy;
    return true;
}

-  (NSMutableArray<CoreDataTree*>*) coreDataPageTrees
{
    m_coreDataEngineConfig.document = [SketchCommon document];
    m_coreDataEngineConfig.workSpace = [SketchCommon getWorkSpace];
    
    NSMutableArray<CoreDataTree*>* trees = [NSMutableArray array];
    if (nil != m_coreDataEngineConfig.document) {
        NSArray* pages = [m_coreDataEngineConfig.document pages];
        NSMutableArray * copyArray = [NSMutableArray array];
        [copyArray addObjectsFromArray:pages];
        for(NSInteger pageNum=0;pageNum<[copyArray count];pageNum++){
            id<MSPage> curPage = [copyArray objectAtIndex:pageNum];
            if (![m_coreDataEngineConfig.sketchPageFilter filterOut:curPage]) {
                NSString* pageID = [curPage objectID];
                NSString* name = [curPage name];
                
                CoreDataTree* coreDataTree = [[CoreDataTree alloc] init:curPage CoreDataEngineConfig:m_coreDataEngineConfig];
                [trees addObject:coreDataTree];
            }
        }
    }
    return trees;
}

- (CoreDataTree*) coreDataLayerTree:(id<MSLayer>)layer
{
    m_coreDataEngineConfig.document = [SketchCommon document];
    m_coreDataEngineConfig.workSpace = [SketchCommon getWorkSpace];
    CoreDataTree* coreDataTree = [[CoreDataTree alloc] init:layer CoreDataEngineConfig:m_coreDataEngineConfig];
    return coreDataTree;
}
@end
