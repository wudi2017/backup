//
//  MSModelObject.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/27.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef MSModelObject_h
#define MSModelObject_h

/*
 *  MSModelObjectCommon
 */

@class MSModelObjectCache;
@class MSModelObjectCacheGeneration;

@protocol MSModelObjectCommon<NSObject>

// My Add Begin
- (NSString*)className;
- (id)name;
- (void)setName:(id)arg1;
// My Add End

+ (id)generateObjectID;
+ (id)defaultName;
+ (void)clearInstanceCount;
+ (void)printInstanceCount:(id)arg1;

@property(readonly, nonatomic) BOOL hasModelObjectCacheGeneration;
@property(readonly) MSModelObjectCacheGeneration *modelObjectCacheGeneration;
- (BOOL)propertiesAreEqual:(id)arg1;
- (id)primitiveObjectID;
@property(copy, nonatomic) NSString *objectID; // @synthesize objectID=_objectID;
- (BOOL)hasObjectID;
- (id)recursivelyGenerateObjectID;
- (id)generateObjectID;
- (void)enumerateDescendants:(id)arg1 withAncestors:(id)arg2;
- (void)enumerateDescendants:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
- (void)setNilValueForKey:(id)arg1;
- (id)defaultName;
- (void)objectDidInit;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (void)performInitEmptyObject;
- (id)initWithNoSetup;
- (id)initWithBlock:(id)arg1;
- (id)init;
@property(readonly, copy) NSString *description;
- (id)treeAsDictionary;
- (id)simpleTreeStructure;
- (id)treeStructure;
- (void)appendTreeStructureToString:(id)arg1 withIndent:(unsigned long long)arg2;
- (void)appendSimpleStructureToString:(id)arg1 withIndent:(unsigned long long)arg2;
- (void)recordDeallocation;
- (void)recordAllocation;
- (BOOL)isContainedByInstanceOfForeignSymbol:(id)arg1;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly) unsigned long long hash;
@property(readonly) Class superclass;

@end

/*
 *  MSModelObject
 */

@protocol MSDocumentData;

@protocol MSModelObject<MSModelObjectCommon>
+ (Class)immutableClass;
+ (BOOL)allowsFaulting;
@property(nonatomic) __weak id<MSDocumentData> documentData; // @synthesize documentData=_documentData;@class MSDocumentData
@property(nonatomic) BOOL isFault; // @synthesize isFault=_isFault;

- (void)breakConnectionWith:(id)arg1;
@property(nonatomic) __weak id *parentObject; // @synthesize parentObject=_parentObject;
- (id)parentGroupRecursive;
- (id)parentGroup;
- (void)setAsParentOnChildren;
- (id)rootModelObject;
- (void)invalidateImmutableObjectAndAncestors;
- (void)invalidateImmutableObject;
- (void)invaliateImmutableObject;
- (void)invalidateModelCacheGeneration;
- (void)object:(id)arg1 didChangeProperty:(id)arg2;
@property(readonly, nonatomic) id immutableModelObject;
- (void)fireFaultIfNecessary;
- (void)fireFault;
- (id)initWithImmutableModelObject:(id)arg1;
- (id)initWithBlock:(id)arg1;
- (void)clearCachedValueForKey:(id)arg1;
- (void)clearCache;
- (void)updateCachedValue:(id)arg1 forKey:(id)arg2;
- (id)cachedValueForKey:(id)arg1 setUsingBlock:(id)arg2;
- (id)cachedValueForKey:(id)arg1;
@property(readonly, nonatomic) BOOL isForeign;
@property(readonly, nonatomic) id foreignObject;
@property(retain, nonatomic) id cachedImmutableModelObject;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)syncPropertiesFromObject:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (id)copyWithOptions:(unsigned long long)arg1;
- (id)copyWithZone:(struct _NSZone *)arg1;
- (id)metadataForKey:(id)arg1;
- (void)storeMetadata:(id)arg1 forKey:(id)arg2;
@property(readonly, nonatomic) NSString *UIMetadataKey;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly, copy) NSString *description;
@property(readonly) unsigned long long hash;
@property(readonly, copy, nonatomic) NSString *objectID;
@property(readonly) Class superclass;
@end

#endif /* MSModelObject_h */
