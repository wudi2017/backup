//
//  Sketch.m
//  sketchPluginFramework
//
//  Created by nb on 2017/1/26.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Sketch.h"

Class MSLayer = nil;
Class MSLayerArray = nil;
Class MSLayerGroup = nil;
Class MSFlowConnection = nil;
Class MSSymbolCreator = nil;
Class MSTextLayer = nil;
Class MSArtboardGroup = nil;
Class MSShapeGroup = nil;
Class MSExportRequest = nil;
Class MSStyle = nil;
Class MSStyleFill = nil;
Class MSColor = nil;
Class MSCurvePoint = nil;
Class MSShapePathLayer = nil;
Class MSRectangleShape = nil;
Class MSTriangleShape;
Class MSOvalShape = nil;
Class MSStarShape = nil;
Class MSPolygonShape = nil;
Class MSAbsoluteRect = nil;

@implementation Sketch

+ (instancetype)instance
{
    static Sketch *sketch = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sketch = [[Sketch alloc] init];
    });
    return sketch;
}

-(bool) visitLayer: (NSObject*)layerObj
{
    id<MSLayer> layer = (id<MSLayer>)layerObj;
    
    //visit layer
    NSString * clsName = [layer className];
    NSLog(@"ClsName:%@", clsName);
    
    if (!MSLayerGroup && [clsName isEqualToString:@"MSLayerGroup"]) {
        MSLayerGroup = [layer class];
    }
    
    id<MSFlowConnection> flow = [layer flow];
    if (!MSFlowConnection && flow) {
        MSFlowConnection = [flow class];
    }
    
    if (nil != MSLayerGroup && nil != MSFlowConnection) {
        return true; // find all class
    }
    
    NSArray * layers = [layer containedLayers];
    for (int iLayer=0; iLayer < layers.count; iLayer++) {
        id<MSLayer> layer = [layers objectAtIndex:iLayer];
        bool bExit = [self visitLayer:layer];
        if (bExit) {
            return true;
        }
    }
    return false;
}

- (void) initialize:(id<MSDocument>)document
{
    id<MSDocument> msDoc = (id<MSDocument>)document;
    // tranversal page
    NSArray * pages = [msDoc pages];
    for (int iPage=0; iPage < pages.count; iPage++) {
        id<MSPage> page = [pages objectAtIndex:iPage];
        NSString * nsPageName = [page name];
        
        // tranversal artboard
        NSArray * artboards = [page artboards];
        for (int iArtboard=0; iArtboard < artboards.count; iArtboard++) {
            id<MSArtboardGroup> artboard = [artboards objectAtIndex:iArtboard];
            NSString * nsArtboardName = [artboard name];
                
            bool bExit = [self visitLayer:artboard];
            if (bExit) {
                return;
            }
        }
    }
}

- (void) initSketchClass: (NSMutableDictionary*) objDict
{
    NSMutableArray * objects = [NSMutableArray array];
    for (NSString* key in objDict) {
        NSObject * obj = [objDict objectForKey:key];
        [objects addObject:obj];
    }
    [self initSketchClassWithObjects:objects];
}

- (void) initSketchClassWithObjects: (NSMutableArray*) objects
{
    for (int i=0; i<[objects count]; i++) {
        NSObject * obj = [objects objectAtIndex:i];
        NSString* className = [obj className];
        if ([className isEqualToString:@"MSLayer"]) {
            MSLayer = [obj class];
        }
        else if ([className isEqualToString:@"MSLayerArray"]) {
            MSLayerArray = [obj class];
        }
        else if ([className isEqualToString:@"MSLayerGroup"]) {
            MSLayerGroup = [obj class];
        }
        else if ([className isEqualToString:@"MSFlowConnection"]) {
            MSFlowConnection = [obj class];
        }
        else if ([className isEqualToString:@"MSSymbolCreator"]) {
            MSSymbolCreator = [obj class];
        }
        else if ([className isEqualToString:@"MSTextLayer"]) {
            MSTextLayer = [obj class];
        }
        else if ([className isEqualToString:@"MSArtboardGroup"]) {
            MSArtboardGroup = [obj class];
        }
        else if([className isEqualToString:@"MSExportRequest"]){
            MSExportRequest = [obj class];
        }
        else if([className isEqualToString:@"MSShapeGroup"]){
            MSShapeGroup = [obj class];
        }
        else if([className isEqualToString:@"MSStyle"]){
            MSStyle = [obj class];
        }
        else if([className isEqualToString:@"MSStyleFill"]){
            MSStyleFill = [obj class];
        }
        else if([className isEqualToString:@"MSColor"]){
            MSColor = [obj class];
        }
        else if([className isEqualToString:@"MSCurvePoint"]){
            MSCurvePoint = [obj class];
        }
        else if([className isEqualToString:@"MSShapePathLayer"]){
            MSShapePathLayer = [obj class];
        }
        else if([className isEqualToString:@"MSRectangleShape"]){
            MSRectangleShape = [obj class];
        }
        else if([className isEqualToString:@"MSTriangleShape"]){
            MSTriangleShape = [obj class];
        }
        else if([className isEqualToString:@"MSOvalShape"]){
            MSOvalShape = [obj class];
        }
        else if([className isEqualToString:@"MSStarShape"]){
            MSStarShape = [obj class];
        }
        else if([className isEqualToString:@"MSPolygonShape"]){
            MSPolygonShape = [obj class];
        }
        else if([className isEqualToString:@"MSAbsoluteRect"]){
            MSAbsoluteRect = [obj class];
        }
    }
}
@end
