//
//  MSLayerArray.h
//  sketchPluginFramework
//
//  Created by wuyuchi on 2018/8/20.
//  Copyright © 2018 iauto. All rights reserved.
//

#ifndef MSLayerArray_h
#define MSLayerArray_h

@protocol MSLayerArray

+ (id)emptyArray;
+ (id)arrayWithLayers:(id)arg1;
+ (id)arrayWithLayer:(id)arg1;
@property(copy, nonatomic) NSArray *layers; // @synthesize layers=_layers;
//- (void).cxx_destruct;
- (unsigned long long)hash;
- (BOOL)isEqual:(id)arg1;
- (id)description;
//- (id)sortedArrayByUsingComparator:(CDUnknownBlockType)arg1;
//- (BOOL)enumerateLayersWithOptions:(unsigned long long)arg1 block:(CDUnknownBlockType)arg2;
//- (void)enumerateLayers:(CDUnknownBlockType)arg1;
//- (unsigned long long)countByEnumeratingWithState:(CDStruct_70511ce9 *)arg1 objects:(id *)arg2 count:(unsigned long long)arg3;
- (unsigned long long)indexOfLayer:(id)arg1;
- (id)layerAtIndex:(unsigned long long)arg1;
- (id)lastLayer;
- (id)firstLayer;
- (BOOL)containsMultipleLayers;
- (BOOL)containsOneLayer;
- (BOOL)containsLayers;
- (BOOL)containsNoOrOneLayers;
- (BOOL)canBeContainedByGroup;
- (BOOL)canBeContainedByDocument;
- (BOOL)canContainLayer:(id)arg1;
- (unsigned long long)containedLayersCount;
- (id)containedLayers;
//- (id)filter:(CDUnknownBlockType)arg1;
//- (id)map:(CDUnknownBlockType)arg1;
- (id)commonArtboard;
- (id)layersSuitableForInsertingIntoGroup:(id)arg1;
- (id)layerToInsertAfter;
- (id)effectiveArtboard;
- (id)effectivePage;
- (id)uniqueParents;
- (id)parentOfFirstLayer;
- (id)copyWithZone:(struct _NSZone *)arg1;
- (id)initWithLayers:(id)arg1;
- (void)removeUnusedStylePartsOfType:(unsigned long long)arg1;
- (id)addStylePartsOfType:(unsigned long long)arg1;
- (unsigned long long)indexOfLayerWithID:(id)arg1;
- (void)updateFlowDestinationsWithMapping:(id)arg1;
- (id)copyByGivingNewObjectIDs;

@end

#endif /* MSLayerArray_h */
