//
//  MSTriangleShape.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSTriangleShape_h
#define MSTriangleShape_h

#import "MSShapePathLayer.h"

/*
 *  _MSTriangleShape **********************************************************************************************
 */

@protocol _MSTriangleShape<MSShapePathLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) BOOL isEquilateral; // @synthesize isEquilateral=_isEquilateral;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSTriangleShape **********************************************************************************************
 */

@protocol MSTriangleShape<_MSTriangleShape>
- (BOOL)canFlatten;
- (void)resetPoints;
- (struct CGRect)boundsForCursorPreview;
@end

#endif /* MSTriangleShape_h */
