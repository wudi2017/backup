//
//  MSStyleBasicFill.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSStyleBasicFill_h
#define MSStyleBasicFill_h

#import "MSLayer.h"
#import "MSStylePart.h"
/*
 *  MSStyleBasicFill **********************************************************************************************
 */
@class MSGradient, MSGraphicsContextSettings;

@protocol _MSStyleBasicFill<MSStylePart>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

// My Add Begin
- (void)setColor:(id)color;
// My Add End

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) MSGradient *gradient; // @synthesize gradient=_gradient;
@property(retain, nonatomic) MSGraphicsContextSettings *contextSettings; // @synthesize contextSettings=_contextSettings;
@property(retain, nonatomic) id color; // @synthesize color=_color;
@property(nonatomic) unsigned long long fillType; // @synthesize fillType=_fillType;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSStyleBasicFill **********************************************************************************************
 */

@protocol MSStyleBasicFill<_MSStyleBasicFill>

+ (id)defaultFillColor;
+ (void)drawNoiseFill:(id)arg1 inRect:(struct CGRect)arg2 context:(struct CGContext *)arg3;
+ (void)drawPatternFill:(id)arg1 inRect:(struct CGRect)arg2;
+ (void)drawGradientFill:(id)arg1 colorSpace:(id)arg2 inRect:(struct CGRect)arg3;
+ (void)drawColorFill:(id)arg1 colorSpace:(id)arg2 inRect:(struct CGRect)arg3;
+ (void)drawColor:(id)arg1 enabled:(BOOL)arg2 inRect:(struct CGRect)arg3;
+ (void)drawBasicFill:(id)arg1 colorSpace:(id)arg2 enabled:(BOOL)arg3 inRect:(struct CGRect)arg4;
+ (void)drawCheckerboardBackgroundInRect:(struct CGRect)arg1;
- (void)convertColorsUsing:(id)arg1;
- (void)performInitEmptyObject;
- (id)previewImageOfSize:(struct CGSize)arg1 colorSpace:(id)arg2 clippingAsBorder:(BOOL)arg3 borderWidth:(double)arg4;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly, copy) NSString *description;
@property(readonly) unsigned long long hash;
@property(readonly) Class superclass;
@end

#endif /* MSStyleBasicFill_h */
