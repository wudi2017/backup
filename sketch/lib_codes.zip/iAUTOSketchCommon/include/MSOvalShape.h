//
//  MSOvalShape.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSOvalShape_h
#define MSOvalShape_h

#import "MSShapePathLayer.h"

/*
 *  _MSOvalShape **********************************************************************************************
 */

@protocol _MSOvalShape<MSShapePathLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSTriangleShape **********************************************************************************************
 */

@protocol MSOvalShape<_MSOvalShape>
- (BOOL)canFlatten;
- (void)resetPoints;
@end

#endif /* MSOvalShape_h */
