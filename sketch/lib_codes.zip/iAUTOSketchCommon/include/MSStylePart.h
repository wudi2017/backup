//
//  MSStylePart.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSStylePart_h
#define MSStylePart_h

#import "MSLayer.h"

/*
 *  _MSStylePart **********************************************************************************************
 */

@protocol _MSStylePart<MSModelObject>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) BOOL isEnabled; // @synthesize isEnabled=_isEnabled;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSStylePart **********************************************************************************************
 */

@protocol MSStylePart<_MSStylePart>
+ (id)defaultStylePartForStyle:(id)arg1;
- (id)parentLayer;
- (id)parentStyle;
- (void)multiplyBy:(double)arg1;
- (void)setValue:(id)arg1 forUndefinedKey:(id)arg2;
- (id)valueForUndefinedKey:(id)arg1;
- (id)topViewForColorInspector:(id)arg1;
- (id)blendingViewForColorInspector:(id)arg1;
- (id)previewImageForSize:(struct CGSize)arg1 colorSpace:(id)arg2;

// Remaining properties
@property(readonly, nonatomic) BOOL isEnabled;
@end


#endif /* MSStylePart_h */
