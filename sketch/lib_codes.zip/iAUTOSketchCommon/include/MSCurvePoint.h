//
//  MSCurvePoint.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSCurvePoint_h
#define MSCurvePoint_h

#import "MSLayer.h"

/*
 *  _MSCurvePoint **********************************************************************************************
 */

@protocol _MSCurvePoint<MSModelObject>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) struct CGPoint point; // @synthesize point=_point;
@property(nonatomic) BOOL hasCurveTo; // @synthesize hasCurveTo=_hasCurveTo;
@property(nonatomic) BOOL hasCurveFrom; // @synthesize hasCurveFrom=_hasCurveFrom;
@property(nonatomic) struct CGPoint curveTo; // @synthesize curveTo=_curveTo;
@property(nonatomic) long long curveMode; // @synthesize curveMode=_curveMode;
@property(nonatomic) struct CGPoint curveFrom; // @synthesize curveFrom=_curveFrom;
@property(nonatomic) double cornerRadius; // @synthesize cornerRadius=_cornerRadius;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end


/*
 *  MSCurvePoint **********************************************************************************************
 */

@protocol MSCurvePoint<_MSCurvePoint>
+ (id)pointWithPoint:(struct CGPoint)arg1 curveTo:(struct CGPoint)arg2 curveFrom:(struct CGPoint)arg3;
+ (id)pointWithPoint:(struct CGPoint)arg1;
+ (id)point;
@property(readonly, copy) NSString *description;
- (void)multiplyBy:(double)arg1;
- (void)moveCurveFromTo:(struct CGPoint)arg1;
- (void)moveCurveToTo:(struct CGPoint)arg1;
- (void)movePointTo:(struct CGPoint)arg1;
- (struct CGPoint)locationOfPoint:(unsigned long long)arg1;
- (void)inferCurveMode;
- (BOOL)isEffectivelyStraight;
@property(readonly, nonatomic) BOOL isStraight;
- (BOOL)isRounded;
- (void)changeCurveModeTo:(long long)arg1 usingPoint:(unsigned long long)arg2;
- (Class)currentBehaviour;
- (id)initWithPoint:(struct CGPoint)arg1 curveTo:(struct CGPoint)arg2 curveFrom:(struct CGPoint)arg3;
- (id)initWithPoint:(struct CGPoint)arg1;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly) unsigned long long hash;
@property(readonly) Class superclass;
@end



#endif /* MSCurvePoint_h */
