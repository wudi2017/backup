//
//  MSColor.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSColor_h
#define MSColor_h

#import "MSLayer.h"

/*
 *  _MSColor **********************************************************************************************
 */

@protocol _MSColor<MSModelObject>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
- (void)setRed:(double)arg1;
@property(readonly, nonatomic) double red; // @synthesize red=_red;
- (void)setGreen:(double)arg1;
@property(readonly, nonatomic) double green; // @synthesize green=_green;
- (void)setBlue:(double)arg1;
@property(readonly, nonatomic) double blue; // @synthesize blue=_blue;
- (void)setAlpha:(double)arg1;
@property(readonly, nonatomic) double alpha; // @synthesize alpha=_alpha;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSColor **********************************************************************************************
 */

@protocol MSColor<_MSColor>
+ (id)rgbColorRed:(long long)arg1 green:(long long)arg2 blue:(long long)arg3;
+ (id)colorWithNSColor:(id)arg1;
+ (id)colorWithHue:(double)arg1 saturation:(double)arg2 brightness:(double)arg3 alpha:(double)arg4;
+ (id)blackColor;
+ (id)whiteColor;
+ (id)colorWithRed:(double)arg1 green:(double)arg2 blue:(double)arg3 alpha:(double)arg4;
+ (id)colorWithRGBADictionary:(id)arg1;
- (id)colorWithAlphaComponent:(double)arg1;
- (BOOL)fuzzyIsEqualExcludingAlpha:(id)arg1 precision:(double)arg2;
- (BOOL)fuzzyIsEqualExcludingAlpha:(id)arg1;
- (BOOL)fuzzyIsEqual:(id)arg1 precision:(double)arg2;
- (BOOL)fuzzyIsEqual:(id)arg1;
@property(readonly, nonatomic) double brightness;
@property(readonly, nonatomic) double saturation;
@property(readonly, nonatomic) double hue;
- (id)HSBColor;
@property(readonly, copy) NSString *description;
- (id)NSColorWithColorSpace:(id)arg1;
@property(readonly) unsigned long long hash;
- (BOOL)isEqual:(id)arg1;
- (id)initWithImmutableObject:(id)arg1;
- (id)initWithRed:(double)arg1 green:(double)arg2 blue:(double)arg3 alpha:(double)arg4;
- (id)treeAsDictionary;
- (id)scaledColor:(double)arg1;
- (id)RGBADictionary;
- (BOOL)isAssetEqual:(id)arg1;
- (unsigned long long)assetType;

// Remaining properties
@property(readonly, nonatomic) double alpha;
@property(readonly, nonatomic) double blue;
@property(readonly, copy) NSString *debugDescription;
@property(readonly, nonatomic) double green;
@property(readonly, nonatomic) double red;
@property(readonly) Class superclass;
@end

#endif /* MSColor_h */
