//
//  MSSymbolInstance.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/29.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSSymbolInstance_h
#define MSSymbolInstance_h

#import "MSStyledLayer.h"

/*
 *  _MSSymbolInstance **********************************************************************************************
 */

@protocol _MSSymbolInstance<MSStyledLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)moveOverrideValueIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllOverrideValues;
- (void)removeOverrideValuesAtIndexes:(id)arg1;
- (void)removeOverrideValueAtIndex:(unsigned long long)arg1;
- (void)removeOverrideValue:(id)arg1;
- (void)insertOverrideValues:(id)arg1 afterOverrideValue:(id)arg2;
- (void)insertOverrideValue:(id)arg1 afterOverrideValue:(id)arg2;
- (void)insertOverrideValues:(id)arg1 beforeOverrideValue:(id)arg2;
- (void)insertOverrideValue:(id)arg1 beforeOverrideValue:(id)arg2;
- (void)insertOverrideValue:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addOverrideValues:(id)arg1;
- (void)addOverrideValue:(id)arg1;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSArray *overrideValues; // @synthesize overrideValues=_overrideValues;
@property(nonatomic) double verticalSpacing; // @synthesize verticalSpacing=_verticalSpacing;
@property(retain, nonatomic) NSString *symbolID; // @synthesize symbolID=_symbolID;
@property(nonatomic) double scale; // @synthesize scale=_scale;
@property(nonatomic) double horizontalSpacing; // @synthesize horizontalSpacing=_horizontalSpacing;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSSymbolInstance **********************************************************************************************
 */
@protocol MSSymbolInstance <_MSSymbolInstance>

+ (id)keyPathsForValuesAffectingPreviewImages;
@property(nonatomic) long long masterRefreshCounter; // @synthesize masterRefreshCounter=_masterRefreshCounter;
- (BOOL)invalidateIfAffectedBySymbolMastersIn:(id)arg1;
- (void)applyOverride:(id)arg1 toPoint:(id)arg2;
- (void)applyOverrides:(id)arg1;
- (void)setValue:(id)arg1 forOverridePoint:(id)arg2;
- (void)prepareOverrideMappingForPoint:(id)arg1 withSymbolMapTable:(id)arg2 attributeMapTable:(id)arg3;
- (void)mapOverridesUnderOverridePoint:(id)arg1 inBlock:(id)arg2;
- (void)mapOverrides:(id)arg1 forOverridePoint:(id)arg2;
- (void)internalSetValue:(id)arg1 forOverridePointNamed:(id)arg2;
- (id)availableOverridesUnderPoint:(id)arg1;
- (void)updateOverridesWithObjectIDMap:(id)arg1;
@property(readonly, nonatomic) NSSet *influencingSymbolIDs;
- (BOOL)canScale;
- (BOOL)canBeTransformed;
- (struct CGSize)naturalSize;
- (void)multiplyBy:(double)arg1;
- (double)scale;
- (void)resetSizeToMaster;
- (void)updateOverrides:(id)arg1 withMapping:(id)arg2;
- (void)resizeInstanceToFitSymbol:(id)arg1;
- (BOOL)shouldWrapDetachedSymbolMasterInGroup:(id)arg1;
- (id)detachByReplacingWithGroup;

// add new IF in version 53 begin
- (id)detachByReplacingWithGroupRecursively:(BOOL)arg1 withDocument:(id)arg2 visitedSymbols:(id)arg3;
- (id)detachStylesAndReplaceWithGroupRecursively:(BOOL)arg1;
// add new IF in version 53 end

- (unsigned long long)numberOfVisibleCells;
- (void)invalidateImmutableObject;
- (void)changeInstanceToSymbol:(id)arg1;
- (BOOL)isInstanceForMaster:(id)arg1;
- (id)symbolID;
- (id)symbolMaster;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (BOOL)shouldRefreshOverlayForFlows;
- (id)inspectorViewControllerNames;
- (struct MSModelObject *)sharedMaster;
- (unsigned long long)shareableObjectType;
- (id)unselectedPreviewImage;
- (id)selectedPreviewImage;
- (id)replaceWithInstanceOfSymbol:(id)arg1;
- (BOOL)canMoveToLayer:(id)arg1 beforeLayer:(id)arg2;
@property(copy, nonatomic) NSDictionary *overrides;
@property(readonly, nonatomic) NSArray *availableOverrides;
- (id)overridePoints;
- (id)setupWithLayerBuilderDictionary:(id)arg1;

@end

#endif /* MSSymbolInstance_h */
