//
//  MSStyledLayer.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSStyledLayer_h
#define MSStyledLayer_h

#import "MSLayer.h"

/*
 *  _MSStyledLayer **********************************************************************************************
 */

@protocol _MSStyledLayer<MSLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) id style; // @synthesize style=_style;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSStyledLayer **********************************************************************************************
 */

@protocol MSStyledLayer<_MSStyledLayer>
+ (id)layerWithImage:(id)arg1;
+ (id)layerWithImageFromFileURL:(id)arg1;
+ (id)layerWithImageFromPasteboard:(id)arg1;
+ (void)pasteExportOptions:(id)arg1 onLayers:(id)arg2;
+ (void)pasteTextStyle:(id)arg1 onLayers:(id)arg2;
+ (void)pasteStyleDict:(id)arg1 onLayers:(id)arg2 document:(id)arg3;
+ (void)pasteStyleFromPasteboard:(id)arg1 onLayers:(id)arg2 document:(id)arg3;
+ (void)pasteStyleFromPasteboardOnLayers:(id)arg1 document:(id)arg2;
+ (id)supportedPasteboardTypesForStyleCopying;
- (id)styledLayer;
- (BOOL)hasEnabledBackgroundBlur;
- (void)multiplyBy:(double)arg1;
- (void)layerStyleDidChange;
- (void)setStyleByPreservingSharedObjectReference:(id)arg1;
- (id)sharedObject;
- (BOOL)hasSharedStyle;
- (id)stylesForColorAdjustingWithPreferredName:(id)arg1;
- (void)applyScreenPickerColor:(id)arg1 preferredStyleName:(id)arg2;
- (unsigned long long)shareableObjectType;
- (void)changeColor:(id)arg1;
- (id)copiedStyleAttributesForLayer:(id)arg1;
- (void)writeStyleToPasteboard:(id)arg1;
- (void)copyStyleToPasteboard:(id)arg1;
- (id)copyStyleToPasteboard;
- (id)CSSAttributes;
- (id)setupWithLayerBuilderDictionary:(id)arg1;
@end

#endif /* MSStyledLayer_h */
