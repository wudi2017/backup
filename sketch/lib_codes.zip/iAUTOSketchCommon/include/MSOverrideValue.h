//
//  MSOverrideValue.h
//  iAUTOSketchCommon
//
//  Created by nb on 2019/1/17.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef MSOverrideValue_h
#define MSOverrideValue_h

#import "MSModelObject.h"

/*
 *  _MSOverrideValue **********************************************************************************************
 */
@protocol _MSOverrideValue<MSModelObject>

+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSObject<NSCopying> *value; // @synthesize value=_value;
@property(retain, nonatomic) NSString *overrideName; // @synthesize overrideName=_overrideName;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;

@end


/*
 *  MSOverrideValue **********************************************************************************************
 */


@protocol MSOverrideValue<_MSOverrideValue>

@property(retain, nonatomic) id<MSOverrideValue> predecessor; // @synthesize predecessor=_predecessor;
@property(nonatomic) BOOL isInherited; // @synthesize isInherited=_isInherited;

- (unsigned long long)hash;
- (BOOL)isEqual:(id)arg1;
- (void)addPredecessor:(id)arg1;
- (id)description;
- (id)initWithName:(id)arg1 value:(id)arg2;

@end



#endif /* MSOverrideValue_h */
