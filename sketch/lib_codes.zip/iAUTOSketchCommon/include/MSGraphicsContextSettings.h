//
//  MSGraphicsContextSettings.h
//  sketchPluginFramework
//
//  Created by wuyuchi on 2018/12/13.
//  Copyright © 2018 iauto. All rights reserved.
//

#ifndef MSGraphicsContextSettings_h
#define MSGraphicsContextSettings_h

@protocol _MSGraphicsContextSettings<MSModelObject>

+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) double opacity; // @synthesize opacity=_opacity;
@property(nonatomic) long long blendMode; // @synthesize blendMode=_blendMode;
- (void)performInitWithImmutableModelObject:(id)arg1;
//- (void)enumerateChildProperties:(CDUnknownBlockType)arg1;
//- (void)enumerateProperties:(CDUnknownBlockType)arg1;

@end

@protocol MSGraphicsContextSettings<_MSGraphicsContextSettings>

@end

#endif /* MSGraphicsContextSettings_h */
