//
//  Sketch.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef Sketch_h
#define Sketch_h

#import <Foundation/Foundation.h>

#include "MSPluginCommand.h"
#include "MSModelObject.h"
#include "MSDocument.h"
#include "MSDocumentData.h"
#include "MSPage.h"
#include "MSArtboardGroup.h"
#include "MSLayer.h"
#include "MSSymbolInstance.h"
#include "MSLayerGroup.h"
#include "MSAbsoluteRect.h"
#include "MSSymbolMaster.h"
#include "MSFlowConnection.h"
#include "MSSymbolCreator.h"
#include "AppController.h"
#include "MSAssetLibraryController.h"
#include "MSTextLayer.h"
#include "MSExportRequest.h"
#include "MSHotspotLayer.h"
#include "MSStyle.h"
#include "MSStyleFill.h"
#include "MSStyleBorder.h"
#include "MSStyleBasicFill.h"
#include "MSStylePart.h"
#include "MSColor.h"
#include "MSStyledLayer.h"
#include "MSCurvePoint.h"
#include "MSShapePathLayer.h"
#include "MSRectangleShape.h"
#include "MSTriangleShape.h"
#include "MSOvalShape.h"
#include "MSStarShape.h"
#include "MSPolygonShape.h"
#include "MSGraphicsContextSettings.h"
#include "MSImageData.h"
#include "MSOverridePoint.h"
#include "MSOverrideValue.h"

extern Class MSLayer;
extern Class MSLayerArray;
extern Class MSLayerGroup;
extern Class MSFlowConnection;
extern Class MSSymbolCreator;
extern Class MSTextLayer;
extern Class MSArtboardGroup;
extern Class MSShapeGroup;
extern Class MSExportRequest;
extern Class MSStyle;
extern Class MSStyleFill;
extern Class MSColor;
extern Class MSCurvePoint;
extern Class MSShapePathLayer;
extern Class MSRectangleShape;
extern Class MSTriangleShape;
extern Class MSOvalShape;
extern Class MSStarShape;
extern Class MSPolygonShape;
extern Class MSAbsoluteRect;

@interface Sketch : NSObject

+ (instancetype)instance;

- (void) initialize:(id<MSDocument>)document;
- (void) initSketchClass: (NSMutableDictionary*) objDict;
- (void) initSketchClassWithObjects: (NSMutableArray*) objects;

@end

#endif /* Sketch_h */
