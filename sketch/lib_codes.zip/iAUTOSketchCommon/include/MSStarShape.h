//
//  MSStarShape.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSStarShape_h
#define MSStarShape_h

#import "MSShapePathLayer.h"

/*
 *  _MSStarShape **********************************************************************************************
 */

@protocol _MSStarShape<MSShapePathLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) double radius; // @synthesize radius=_radius;
@property(nonatomic) long long numberOfPoints; // @synthesize numberOfPoints=_numberOfPoints;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSStarShape **********************************************************************************************
 */

@protocol MSStarShape<_MSStarShape>
- (BOOL)shouldHitTestOnFill:(id)arg1;
- (BOOL)canFlatten;
- (void)resetPoints;
- (struct CGRect)boundsForCursorPreview;
- (id)inspectorViewControllerNames;
@end


#endif /* MSStarShape_h */
