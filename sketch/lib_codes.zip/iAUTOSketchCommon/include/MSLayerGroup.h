//
//  MSLayerGroup.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/29.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSLayerGroup_h
#define MSLayerGroup_h

#import "MSLayer.h"

/*
 *  _MSLayerGroup **********************************************************************************************
 */

@protocol _MSLayerGroup<MSStyledLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)moveLayerIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllLayers;
- (void)removeLayersAtIndexes:(id)arg1;
- (void)removeLayerAtIndex:(unsigned long long)arg1;
- (void)removeLayer:(id)arg1;
- (void)insertLayers:(id)arg1 afterLayer:(id)arg2;
- (void)insertLayer:(id)arg1 afterLayer:(id)arg2;
- (void)insertLayers:(id)arg1 beforeLayer:(id)arg2;
- (void)insertLayer:(id)arg1 beforeLayer:(id)arg2;
- (void)insertLayer:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addLayers:(id)arg1;
- (void)addLayer:(id)arg1;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSArray *layers; // @synthesize layers=_layers;
@property(retain, nonatomic) NSString *sharedObjectID; // @synthesize sharedObjectID=_sharedObjectID;
@property(nonatomic) BOOL hasClickThrough; // @synthesize hasClickThrough=_hasClickThrough;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSLayerGroup **********************************************************************************************
 */

@protocol MSLayerGroup<_MSLayerGroup>
+ (BOOL)groupBoundsShouldBeIntegral;
+ (struct CGRect)groupBoundsForContainer:(id)arg1;
+ (void)moveLayers:(id)arg1 intoGroup:(id)arg2;
+ (id)groupWithLayers:(id)arg1;
@property(nonatomic) unsigned long long disableAutomaticScalingCounter; // @synthesize disableAutomaticScalingCounter=_disableAutomaticScalingCounter;
@property(nonatomic) long long preCalculatedHasSelectedLayer; // @synthesize preCalculatedHasSelectedLayer=_preCalculatedHasSelectedLayer;
- (id)candidatesForMasking;
- (void)layerDidEndResize;
- (void)layerWillStartResize;
- (void)rect:(id)arg1 didChangeFromRect:(struct CGRect)arg2;
- (void)resizeChildrenWithOldSize:(struct CGSize)arg1;
- (struct CGSize)calculateMinimumSize;
@property(readonly, nonatomic) BOOL isAutomaticScalingEnabled;
- (void)disableAutomaticScalingInBlock:(id)arg1;
- (void)multiplyBy:(double)arg1;
- (void)insertLayer:(id)arg1 afterLayerOrAtEnd:(id)arg2;
- (BOOL)resizeToFitChildrenWithOption:(long long)arg1;
- (struct CGRect)requiredRect;
- (void)setIsHighlighted:(BOOL)arg1;
- (BOOL)isOpenForSelectionWithOptions:(unsigned long long)arg1;
- (BOOL)isSelectableOnCanvasWithOptions:(unsigned long long)arg1;
- (BOOL)containsSelectedItemIncludingSelf:(BOOL)arg1;
- (BOOL)isExpanded;
- (void)deselectLayerAndParent;
- (void)refreshOverlay;
- (void)moveInLayerTreeInBlock:(id)arg1;
- (BOOL)shouldStripShadowsAndInnerShadow;
- (void)setStyle:(id)arg1;
- (id)defaultStyle;
- (id)parentGroupRecursive;
- (void)objectDidInit;
- (void)performInitEmptyObject;
- (BOOL)shouldRefreshOverlayForFlows;
- (BOOL)handleDoubleClick;
- (id)inspectorViewControllerNames;
- (void)drawHoverWithZoom:(double)arg1 color:(id)arg2 cache:(id)arg3;
- (void)prepareAsMaskContainer;
- (id)unselectedPreviewImage;
- (id)selectedPreviewImage;
- (BOOL)expandableInLayerList;
- (void)enumerateLayersAvoidingFaultingWithOptions:(unsigned long long)arg1 passingTest:(id)arg2 usingBlock:(id)arg3;
- (void)moveTransformsToChildren:(id)arg1;
- (id)ungroupReturningNextUngroupGroup;
- (BOOL)hasStyleOrTransform;
- (void)translateChildrenFrameToLayers:(id)arg1;
- (id)moveLayersToParent;
- (void)ungroupSingleChildDescendentGroups;
- (id)ungroup;
- (void)setUpNewGroup;
- (BOOL)enumerateLayersWithOptions:(unsigned long long)arg1 block:(id)arg2;
- (void)enumerateLayers:(id)arg1;
- (unsigned long long)indexOfLayer:(id)arg1;
- (id)layerAtIndex:(unsigned long long)arg1;
- (id)lastLayer;
- (id)firstLayer;
- (BOOL)containsMultipleLayers;
- (BOOL)containsOneLayer;
- (BOOL)containsLayers;
- (BOOL)containsNoOrOneLayers;
- (BOOL)canContainLayer:(id)arg1;
- (unsigned long long)containedLayersCount;
- (id)containedLayers;
- (id)CSSAttributeString;

// Remaining properties
@property(readonly, nonatomic) NSArray *layers;

@end

#endif /* MSLayerGroup_h */
