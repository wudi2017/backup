//
//  MSHotspotLayer.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/1.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSHotspotLayer_h
#define MSHotspotLayer_h

#import "MSLayer.h"

/*
 *  _MSHotspotLayer **********************************************************************************************
 */

@protocol _MSHotspotLayer<MSLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end


/*
 *  MSHotspotLayer **********************************************************************************************
 */
@protocol MSHotspotLayer<_MSHotspotLayer>
+ (id)hotspotLayerFromLayer:(id)arg1;
+ (id)keyPathsForValuesAffectingPreviewImages;
- (void)resetFlow;
- (BOOL)canRotate;
- (BOOL)canBeTransformed;
- (void)setFlow:(id)arg1;
- (void)performInitEmptyObject;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)shouldDrawSelectionStroke;
- (id)unselectedPreviewImage;
- (id)selectedPreviewImage;
- (BOOL)isExportableViaDragAndDrop;
- (BOOL)isActive;
- (unsigned long long)filterType;
- (void)applyOverride:(id)arg1 toPoint:(id)arg2;
@end

#endif /* MSHotspotLayer_h */
