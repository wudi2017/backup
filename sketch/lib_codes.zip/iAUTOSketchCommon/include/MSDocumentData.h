//
//  MSDocumentData.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/29.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSDocumentData_h
#define MSDocumentData_h

#import "MSModelObject.h"

/*
 *  _MSDocumentData **********************************************************************************************
 */

@class MSAssetCollection, MSSharedStyleContainer, MSSharedTextStyleContainer, MSSymbolContainer;

@protocol _MSDocumentData<MSModelObject>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)movePageIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllPages;
- (void)removePagesAtIndexes:(id)arg1;
- (void)removePageAtIndex:(unsigned long long)arg1;
- (void)removePage:(id)arg1;
- (void)insertPages:(id)arg1 afterPage:(id)arg2;
- (void)insertPage:(id)arg1 afterPage:(id)arg2;
- (void)insertPages:(id)arg1 beforePage:(id)arg2;
- (void)insertPage:(id)arg1 beforePage:(id)arg2;
- (void)insertPage:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addPages:(id)arg1;
- (void)addPage:(id)arg1;
- (void)moveForeignTextStyleIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllForeignTextStyles;
- (void)removeForeignTextStylesAtIndexes:(id)arg1;
- (void)removeForeignTextStyleAtIndex:(unsigned long long)arg1;
- (void)removeForeignTextStyle:(id)arg1;
- (void)insertForeignTextStyles:(id)arg1 afterForeignTextStyle:(id)arg2;
- (void)insertForeignTextStyle:(id)arg1 afterForeignTextStyle:(id)arg2;
- (void)insertForeignTextStyles:(id)arg1 beforeForeignTextStyle:(id)arg2;
- (void)insertForeignTextStyle:(id)arg1 beforeForeignTextStyle:(id)arg2;
- (void)insertForeignTextStyle:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addForeignTextStyles:(id)arg1;
- (void)addForeignTextStyle:(id)arg1;
- (void)moveForeignSymbolIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllForeignSymbols;
- (void)removeForeignSymbolsAtIndexes:(id)arg1;
- (void)removeForeignSymbolAtIndex:(unsigned long long)arg1;
- (void)removeForeignSymbol:(id)arg1;
- (void)insertForeignSymbols:(id)arg1 afterForeignSymbol:(id)arg2;
- (void)insertForeignSymbol:(id)arg1 afterForeignSymbol:(id)arg2;
- (void)insertForeignSymbols:(id)arg1 beforeForeignSymbol:(id)arg2;
- (void)insertForeignSymbol:(id)arg1 beforeForeignSymbol:(id)arg2;
- (void)insertForeignSymbol:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addForeignSymbols:(id)arg1;
- (void)addForeignSymbol:(id)arg1;
- (void)moveForeignLayerStyleIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllForeignLayerStyles;
- (void)removeForeignLayerStylesAtIndexes:(id)arg1;
- (void)removeForeignLayerStyleAtIndex:(unsigned long long)arg1;
- (void)removeForeignLayerStyle:(id)arg1;
- (void)insertForeignLayerStyles:(id)arg1 afterForeignLayerStyle:(id)arg2;
- (void)insertForeignLayerStyle:(id)arg1 afterForeignLayerStyle:(id)arg2;
- (void)insertForeignLayerStyles:(id)arg1 beforeForeignLayerStyle:(id)arg2;
- (void)insertForeignLayerStyle:(id)arg1 beforeForeignLayerStyle:(id)arg2;
- (void)insertForeignLayerStyle:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addForeignLayerStyles:(id)arg1;
- (void)addForeignLayerStyle:(id)arg1;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSArray *pages; // @synthesize pages=_pages;
@property(retain, nonatomic) MSSharedTextStyleContainer *layerTextStyles; // @synthesize layerTextStyles=_layerTextStyles;
@property(retain, nonatomic) MSSymbolContainer *layerSymbols; // @synthesize layerSymbols=_layerSymbols;
@property(retain, nonatomic) MSSharedStyleContainer *layerStyles; // @synthesize layerStyles=_layerStyles;
@property(retain, nonatomic) NSArray *foreignTextStyles; // @synthesize foreignTextStyles=_foreignTextStyles;
@property(retain, nonatomic) NSArray *foreignSymbols; // @synthesize foreignSymbols=_foreignSymbols;
@property(retain, nonatomic) NSArray *foreignLayerStyles; // @synthesize foreignLayerStyles=_foreignLayerStyles;
@property(retain, nonatomic) MSAssetCollection *assets; // @synthesize assets=_assets;
@property(copy, nonatomic) NSDictionary *userInfo; // @synthesize userInfo=_userInfo;
@property(nonatomic) unsigned long long currentPageIndex; // @synthesize currentPageIndex=_currentPageIndex;
@property(nonatomic) unsigned long long colorSpace; // @synthesize colorSpace=_colorSpace;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end


/*
 *  MSDocumentData **********************************************************************************************
 */

@class BCCache, MSFontList;
@protocol MSDocumentDataDelegate;
@protocol MSPage;

@protocol MSDocumentData<_MSDocumentData>
+ (void)initialize;
@property(retain, nonatomic) MSFontList *fontList; // @synthesize fontList=_fontList;
@property(retain, nonatomic) NSDictionary *metadata; // @synthesize metadata=_metadata;
@property(nonatomic) BOOL autoExpandGroupsInLayerList; // @synthesize autoExpandGroupsInLayerList=_autoExpandGroupsInLayerList;
@property(nonatomic) __weak id <MSDocumentDataDelegate> delegate; // @synthesize delegate=_delegate;
@property(retain, nonatomic) BCCache *cache; // @synthesize cache=_cache;

- (void)determineCurrentArtboard;
- (void)refreshOverlay;
- (void)refreshOverlayInRect:(struct CGRect)arg1;
- (void)immediatelyShowSelectionForAllLayers;
- (void)temporarilyHideSelectionForLayers:(id)arg1;
- (void)replaceExistingCreationMetadata;
- (id)images;
- (id)sharedObjectContainerOfType:(unsigned long long)arg1;
- (void)purgeForeignObjects;
- (void)purgeForeignStyles;
- (void)purgeForeignSymbols;
- (id)symbolsReferencedBySymbolInstances;
- (id)symbolsReferencedBySymbolMasters;
- (id)symbolsReferencedByInstances:(id)arg1;
- (void)enumerateForeignObjects:(id)arg1 withLibraries:(id)arg2 block:(id)arg3;
- (id)libraryForForeignObject:(id)arg1 inLibraries:(id)arg2;
- (void)invalidateAffectedSymbolInstances;
- (id)addCopyOfInstanceMasterToDocumentIfNecessary:(id)arg1;
- (void)addSymbolMaster:(id)arg1;
- (id)addCopyOfMasterToDocumentIfNecessary:(id)arg1;
- (id)symbolWithID:(id)arg1;
@property(readonly, nonatomic) NSDictionary *symbolMap; // @synthesize symbolMap=_symbolMap;
- (id)allForeignObjects;
- (id)allSymbols;
- (id)localSymbols;
- (id)allArtboards;
- (void)populateDictionary:(id)arg1 withChildrenOf:(id)arg2;
- (id)layersByObjectID;
- (id)artboardWithID:(id)arg1;
- (id)layerWithID:(id)arg1;
- (void)layerTreeLayoutDidChange;
- (void)layerSelectionMightHaveChanged;
- (id)selectedLayers;
- (BOOL)documentIsEmpty;
- (void)sharedObjectDidChange:(struct MSModelObject *)arg1;
- (id)nameForNewPage;
- (id)symbolsPageOrCreateIfNecessary;
- (id)symbolsPage;
- (id)addBlankPage;
- (void)removePages:(id)arg1 detachInstances:(BOOL)arg2;
@property(retain, nonatomic) id<MSPage> currentPage;
- (void)setCurrentPageIndex:(unsigned long long)arg1;
- (void)dealloc;
- (id)documentData;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)objectDidInit;
- (void)performInitEmptyObject;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (id)defaultPagesArray;
- (void)object:(id)arg1 didChangeProperty:(id)arg2;
- (void)convertToColorSpace:(unsigned long long)arg1;
- (void)assignColorSpace:(unsigned long long)arg1;
- (void)replaceInstancesOfColor:(id)arg1 withColor:(id)arg2 ignoreAlphaWhenMatching:(BOOL)arg3 replaceAlphaOfOriginalColor:(BOOL)arg4;
- (void)enumerateColorConvertiblesIgnoringForeignSymbols:(id)arg1;
- (void)replaceFonts:(id)arg1;
- (void)invalidateFonts;
- (BOOL)enumerateLayersWithOptions:(unsigned long long)arg1 block:(id)arg2;
- (void)enumerateLayers:(id)arg1;
- (id)lastLayer;
- (id)firstLayer;
- (BOOL)canContainLayer:(id)arg1;
- (unsigned long long)indexOfLayer:(id)arg1;
- (id)layerAtIndex:(unsigned long long)arg1;
- (BOOL)containsNoOrOneLayers;
- (BOOL)containsLayers;
- (BOOL)containsMultipleLayers;
- (BOOL)containsOneLayer;
- (unsigned long long)containedLayersCount;
- (id)containedLayers;
- (BOOL)canBeContainedByDocument;
- (BOOL)canBeContainedByGroup;
- (id)metadataForKey:(id)arg1 object:(id)arg2;
- (void)storeMetadata:(id)arg1 forKey:(id)arg2 object:(id)arg3;
- (id)UIMetadataKey;

// Remaining properties
@property(readonly, nonatomic) NSArray *pages;
@end

#endif /* MSDocumentData_h */
