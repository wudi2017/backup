//
//  MSShapePathLayer.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSShapePathLayer_h
#define MSShapePathLayer_h

#import "MSLayer.h"

/*
 *  _MSShapePathLayer **********************************************************************************************
 */

@protocol _MSShapePathLayer<MSLayer>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)moveCurvePointIndex:(unsigned long long)arg1 toIndex:(unsigned long long)arg2;
- (void)removeAllCurvePoints;
- (void)removeCurvePointsAtIndexes:(id)arg1;
- (void)removeCurvePointAtIndex:(unsigned long long)arg1;
- (void)removeCurvePoint:(id)arg1;
- (void)insertCurvePoints:(id)arg1 afterCurvePoint:(id)arg2;
- (void)insertCurvePoint:(id)arg1 afterCurvePoint:(id)arg2;
- (void)insertCurvePoints:(id)arg1 beforeCurvePoint:(id)arg2;
- (void)insertCurvePoint:(id)arg1 beforeCurvePoint:(id)arg2;
- (void)insertCurvePoint:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)addCurvePoints:(id)arg1;
- (void)addCurvePoint:(id)arg1;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSArray *points; // @synthesize points=_points;
@property(nonatomic) long long pointRadiusBehaviour; // @synthesize pointRadiusBehaviour=_pointRadiusBehaviour;
@property(nonatomic) BOOL isClosed; // @synthesize isClosed=_isClosed;
@property(nonatomic) BOOL edited; // @synthesize edited=_edited;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;

@end

/*
 *  MSShapePathLayer **********************************************************************************************
 */

@protocol MSShapePathLayer<_MSShapePathLayer>
+ (void)performBatchEdits:(id)arg1;
+ (id)shapeWithPath:(id)arg1;
+ (id)keyPathsForValuesAffectingBadgeMap;
+ (id)keyPathsForValuesAffectingPreviewImages;
@property(nonatomic) BOOL isEditing; // @synthesize isEditing=_isEditing;
- (void)didChangeValueForKey:(id)arg1;
- (void)willChangeValueForKey:(id)arg1;
- (BOOL)isPolygon;
- (BOOL)isRectangle;
- (BOOL)attemptToSimplifyBetweenPoint:(id)arg1 andPoint:(id)arg2;
- (BOOL)simplifyPathOnce;
- (void)simplify;
- (id)pointsAroundIndex:(unsigned long long)arg1;
- (BOOL)isLine;
- (BOOL)shouldHitTestOnFill:(id)arg1;
- (id)flattenedLayer;
- (void)flatten;
@property(readonly, nonatomic) BOOL canFlatten;
@property(readonly, nonatomic) id<MSCurvePoint> lastPoint;
@property(readonly, nonatomic) id<MSCurvePoint> firstPoint;
@property(readonly, nonatomic) unsigned long long numberOfCurvePoints;
@property(readonly, nonatomic) BOOL hasRoundedCorners;
- (id)layerSuitableForInsertingIntoGroup:(id)arg1;
- (BOOL)canBeContainedByGroup;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setEndMarkerType:(unsigned long long)arg1;
- (void)setStartMarkerType:(unsigned long long)arg1;
- (double)distanceSquaredToSegmentAtIndex:(unsigned long long)arg1 fromPoint:(struct CGPoint)arg2 tolerance:(double)arg3;
- (unsigned long long)indexOfSegmentAtPoint:(struct CGPoint)arg1 tolerance:(struct CGSize)arg2;
- (void)multiplyBy:(double)arg1;
- (BOOL)isPartOfClippingMask;
- (void)setBooleanOperation:(long long)arg1;
- (BOOL)isNearlyEmpty;
- (struct CGPoint)convertPointToPathCoordinates:(struct CGPoint)arg1;
- (struct CGPoint)convertPointFromPathCoordinates:(struct CGPoint)arg1;
- (void)didEdit;
- (struct CGPoint)pointCenteredAfterPointIndex:(unsigned long long)arg1;
@property(copy, nonatomic) MSPath *pathInFrame; // @dynamic pathInFrame;
- (void)adjustGeometryToBoundsRect:(struct CGRect)arg1;
- (struct CGRect)boundsOfPathIntegral:(BOOL)arg1;
- (void)adjustFrameAfterEditIntegral:(BOOL)arg1;
- (void)applyAffineTransformToPath:(struct CGAffineTransform)arg1;
- (void)reversePath;
- (BOOL)editable;
- (void)resetPoints;
- (void)setNilValueForKey:(id)arg1;
- (void)resetPointsBasedOnUserInteraction;
- (void)applyPropertiesToBezier:(id)arg1;
- (void)performInitEmptyObject;
- (id)styledLayer;
- (BOOL)shouldDrawSelectionStroke;
- (BOOL)shouldDrawSelection;
- (BOOL)canSmartRotate;
- (Class)handlerClass;
- (BOOL)handleDoubleClick;
- (struct CGRect)boundsForCursorPreview;
- (id)bezierPathForCursorPreview;
- (id)insertionCursor;
- (id)unselectedPreviewImage;
- (id)selectedPreviewImage;
- (BOOL)isMasked;
- (void)handleBadgeClickWithAltState:(BOOL)arg1;
- (void)moveToLayer:(id)arg1 beforeLayer:(id)arg2;
- (BOOL)isExportableViaDragAndDrop;
- (id)badgeMenu;
- (void)onBooleanOperation:(id)arg1;
- (unsigned long long)selectedBadgeMenuItem;
- (BOOL)canCopyToLayer:(id)arg1 beforeLayer:(id)arg2;
- (unsigned long long)shareableObjectType;
- (BOOL)booleanOperationCanBeReset;
- (BOOL)supportsInnerOuterBorders;
- (id)setupWithLayerBuilderDictionary:(id)arg1;

@end


#endif /* MSShapePathLayer_h */
