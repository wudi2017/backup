//
//  MSPage.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSPage_h
#define MSPage_h

#import "MSArtboardGroup.h"
#import "MSLayerArray.h"

extern Class MSLayerArray;

/*
 *  _MSPage **********************************************************************************************
 */

@class MSLayoutGrid, MSRulerData, MSSimpleGrid;

@protocol _MSPage<MSLayerGroup>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) MSRulerData *verticalRulerData; // @synthesize verticalRulerData=_verticalRulerData;
@property(retain, nonatomic) MSLayoutGrid *layout; // @synthesize layout=_layout;
@property(retain, nonatomic) MSRulerData *horizontalRulerData; // @synthesize horizontalRulerData=_horizontalRulerData;
@property(retain, nonatomic) MSSimpleGrid *grid; // @synthesize grid=_grid;
@property(nonatomic) BOOL includeInCloudUpload; // @synthesize includeInCloudUpload=_includeInCloudUpload;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end


/*
 *  MSPage **********************************************************************************************
 */

@class MSLayoutGrid, MSRulerData, MSSimpleGrid;
@protocol MSRootLayer;

@protocol MSPage<_MSPage>

+ (id)page;
@property(retain, nonatomic) id<MSLayerArray> cachedSelectedLayers; // @synthesize cachedSelectedLayers=_cachedSelectedLayers;
@property(retain, nonatomic) NSArray *cachedArtboards; // @synthesize cachedArtboards=_cachedArtboards;
@property(retain, nonatomic) NSArray *cachedExportableLayers; // @synthesize cachedExportableLayers=_cachedExportableLayers;
@property(nonatomic) __weak id<MSArtboardGroup> currentArtboard; // @synthesize currentArtboard=_currentArtboard;

- (void)setIsLocked:(BOOL)arg1;
- (BOOL)isLocked;
- (void)setIsVisible:(BOOL)arg1;
- (BOOL)isVisible;
@property(nonatomic) double zoomValue;
@property(nonatomic) struct CGPoint scrollOrigin;
@property(readonly, nonatomic) NSArray *symbols;
- (struct CGPoint)originForNewArtboardWithSize:(struct CGSize)arg1;
- (id)artboardsMatchingWidth:(double)arg1;
- (BOOL)contentIntersectsWithRect:(struct CGRect)arg1;
- (BOOL)hasClickThrough;
- (BOOL)limitsSelectionToBounds;
- (BOOL)containsPoint:(struct CGPoint)arg1 zoomValue:(double)arg2;
@property(readonly, nonatomic) MSRulerData *currentVerticalRulerData;
@property(readonly, nonatomic) MSRulerData *currentHorizontalRulerData;
- (void)moveLayersToArtboards;
- (BOOL)canContainLayer:(id)arg1;
- (void)rectSizeDidChange:(id)arg1;
- (void)changeLayerExpandedTypeToAutomaticIfCollapsed;
- (id)artboardWithID:(id)arg1;
@property(readonly, nonatomic) __weak NSArray *artboards;
- (id)parentRoot;
//@property(readonly, nonatomic) MSLayerGroup<MSRootLayer> *currentRoot;
- (id)ancestorsAndSelfTransforms;
- (id)parentPage;
@property(readonly, nonatomic) struct CGRect contentBounds;
- (BOOL)resizeToFitChildrenWithOption:(long long)arg1;
- (BOOL)layers:(id)arg1 fitOnArtboard:(id)arg2;
- (id)destinationArtboardForLayers:(id)arg1 artboards:(id)arg2;
- (BOOL)tryToMoveLayerToArtboard:(id)arg1;
- (BOOL)addOrRemoveLayerFromArtboardIfNecessary:(id)arg1;
- (BOOL)tryToMoveLayer:(id)arg1 toArtboards:(id)arg2;
@property(readonly, nonatomic) NSArray *exportableLayers;
- (id)symbolLayersInGroup:(id)arg1;
- (id)artboardForSlice:(id)arg1 inArtboards:(id)arg2;
@property(nonatomic) struct CGPoint rulerBase;
- (void)refreshOverlayInRect:(struct CGRect)arg1;
- (id)transform;
- (void)object:(id)arg1 didChangeProperty:(id)arg2;
- (BOOL)canBeContainedByDocument;
- (void)dealloc;
- (void)clearSelectionCache;
- (void)changeSelectionBySelectingLayers:(id)arg1;
- (void)changeSelectionUsingBlock:(id)arg1;
- (BOOL)isLayerSelected:(id)arg1;
- (id)layersWithIDs:(id)arg1;
- (id)layersByObjectID;
- (id)selectedLayers;
@property(retain, nonatomic) NSMutableSet *selectedLayerIDs; // @synthesize selectedLayerIDs=_selectedLayerIDs;
- (id)parentGroup;
- (void)objectDidInit;
- (void)resetSelectedLayerIDs:(id)arg1;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (struct CGPoint)scrollOriginToCenterContentInViewBounds:(struct CGRect)arg1;
- (void)adjustRulerDataToTopLeftInViewBounds;
- (BOOL)shouldDrawSelection;
- (BOOL)canBeHovered;
- (id)displayName;
- (BOOL)isExportableViaDragAndDrop;
- (BOOL)canCopyToLayer:(id)arg1 beforeLayer:(id)arg2;
- (id)previewImages;
- (unsigned long long)displayType;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly, copy) NSString *description;
@property(copy, nonatomic) MSSimpleGrid *grid;
@property(readonly) unsigned long long hash;
@property(copy, nonatomic) MSRulerData *horizontalRulerData;
@property(copy, nonatomic) MSLayoutGrid *layout;
@property(readonly, nonatomic) struct CGRect rect;
@property(readonly) Class superclass;
@property(copy, nonatomic) MSRulerData *verticalRulerData;

@end


#endif /* MSPage_h */
