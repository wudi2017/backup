//
//  MSDocument.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSDocument_h
#define MSDocument_h

#import "MSDocumentData.h"

@protocol MSDocument<NSObject>

- (id)addBlankPage;
- (id)pages;
- (void)removePage:(id)arg1;
- (void)setCurrentPage:(id)arg1;
- (void)pageTreeLayoutDidChange;
- (void)layerTreeLayoutDidChange;
- (void)currentArtboardDidChange;
- (void)saveArtboardOrSlice:(id)arg1 toFile:(id)arg2;

@property(retain, nonatomic) NSURL *fileURL; // @synthesize fileURL=_fileURL;
@property(retain, nonatomic) id<MSDocumentData> documentData;

@end

#endif /* MSDocument_h */
