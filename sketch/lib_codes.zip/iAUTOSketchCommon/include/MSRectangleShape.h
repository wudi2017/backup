//
//  MSRectangleShape.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSRectangleShape_h
#define MSRectangleShape_h

#import "MSShapePathLayer.h"

/*
 *  _MSRectangleShape **********************************************************************************************
 */

@protocol _MSRectangleShape<MSShapePathLayer>

+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) BOOL hasConvertedToNewRoundCorners; // @synthesize hasConvertedToNewRoundCorners=_hasConvertedToNewRoundCorners;
@property(nonatomic) double fixedRadius; // @synthesize fixedRadius=_fixedRadius;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSShapePathLayer **********************************************************************************************
 */

@protocol MSRectangleShape<_MSRectangleShape>

+ (BOOL)validateComponentString:(id)arg1;
+ (id)componentStringWithValues:(id)arg1;
+ (BOOL)looksLikeComponentString:(id)arg1;
+ (BOOL)useSmoothCorners;
+ (double)lastUsedCornerRadius;
- (BOOL)canFlatten;
- (void)multiplyBy:(double)arg1;
- (void)resetPointsIfNecessary;
- (void)resetPathsToRoundedRect;
@property(readonly, nonatomic) double maximumAllowedRadius;
- (void)resetPathsToRect;
- (void)resetPoints;
- (BOOL)shouldDrawSelectionStroke;
- (id)bezierPathForCursorPreview;
- (id)inspectorViewControllers;
- (void)resetPointsBasedOnUserInteraction;
@property(readonly, nonatomic) BOOL smoothCornersAllowed;
@property(nonatomic) BOOL hasSmoothCorners;
- (void)didChangeValues;
- (void)willChangeValues;
- (double)floatFromNumbers:(id)arg1 atIndex:(unsigned long long)arg2;
- (void)setCornerRadiusFromSimpleString:(id)arg1;
- (void)setCornerRadiusFromComponents:(id)arg1;
@property(copy, nonatomic) NSString *cornerRadiusString;
- (id)rectangleNumberFormatter;
@property(nonatomic) double cornerRadiusFloat;
@property(nonatomic) double normalizedExponentialCornerRadius;
- (BOOL)validateProposedCornerRadiusWithFloat:(double)arg1;
- (BOOL)validateProposedCornerRadiusSizeWithString:(id)arg1;

@end

#endif /* MSRectangleShape_h */
