//
//  MSStyleFill.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSStyleFill_h
#define MSStyleFill_h

#import "MSLayer.h"
#import "MSStyleBasicFill.h"

/*
 *  _MSStyleFill **********************************************************************************************
 */
@class MSImageData;

@protocol _MSStyleFill<MSStyleBasicFill>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) double patternTileScale; // @synthesize patternTileScale=_patternTileScale;
@property(nonatomic) long long patternFillType; // @synthesize patternFillType=_patternFillType;
@property(nonatomic) double noiseIntensity; // @synthesize noiseIntensity=_noiseIntensity;
@property(nonatomic) long long noiseIndex; // @synthesize noiseIndex=_noiseIndex;
@property(retain, nonatomic) MSImageData *image; // @synthesize image=_image;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end


/*
 *  MSStyleFill **********************************************************************************************
 */

@protocol MSStyleFill<_MSStyleFill>
+ (id)defaultStylePartForStyle:(id)arg1;
+ (id)defaultFillColor;
+ (id)keyPathsForValuesAffectingInterfaceOpacity;
@property(readonly, nonatomic) BOOL canReduceImageSize;
- (void)setReducedImage:(id)arg1;
@property(readonly, nonatomic) struct CGSize targetSizeForReduction;
- (id)NSImage;
- (void)setOpacity:(double)arg1;
- (BOOL)hasOpacity;
- (void)setPatternTileScale:(double)arg1;
- (void)performInitEmptyObject;
- (id)topViewForColorInspector:(id)arg1;
- (id)parentStyle;
@property(nonatomic) double interfaceOpacity;
- (id)CSSAttributeString;

// Remaining properties
@property(retain, nonatomic) MSImageData *image;
@end

#endif /* MSStyleFill_h */
