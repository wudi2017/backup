//
//  MSOverridePoint.h
//  iAUTOSketchCommon
//
//  Created by nb on 2019/1/17.
//  Copyright © 2019年 suntec. All rights reserved.
//

#ifndef MSOverridePoint_h
#define MSOverridePoint_h

@protocol MSOverridePoint<NSObject>

@property(copy, nonatomic) NSString *name; // @synthesize name=_name;
@property(readonly, nonatomic) NSString *layerName; // @synthesize layerName=_layerName;
@property(readonly, nonatomic) __weak id *parent; // @synthesize parent=_parent;
@property(retain, nonatomic) NSString *dataIdentifier; // @synthesize dataIdentifier=_dataIdentifier;
@property(readonly, nonatomic) NSString *property; // @synthesize property=_property;
@property(readonly, nonatomic) NSString *layerID; // @synthesize layerID=_layerID;

- (unsigned long long)distanceToOverridePoint:(id)arg1;
- (long long)comparisonScoreAgainst:(id)arg1;
@property(readonly, nonatomic) BOOL isSymbolOverride;
- (BOOL)isEqual:(id)arg1;
- (id)description;
@property(readonly, nonatomic) NSString *layerIDPath; // @synthesize layerIDPath=_layerIDPath;
- (id)initWithLayer:(id)arg1 property:(id)arg2 parent:(id)arg3;

@end

#endif /* MSOverridePoint_h */
