//
//  SketchCommon.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef SketchCommon_h
#define SketchCommon_h

#import <Foundation/Foundation.h>
#import "Sketch.h"
#import "CLog.h"

@interface SketchCommon : NSObject

// context
+ (void)setContextData:
(id<MSPluginCommand>)command
              Document:(id<MSDocument>)document
            ScriptPath:(NSString*)scriptPath
             ScriptURL:(NSString*)scriptURL
             Selection:(NSMutableArray*)selection;
+ (id<MSPluginCommand>) command;
+ (id<MSDocument>) document;
+ (NSString*) scriptPath;
+ (NSString*) scriptURL;
+ (NSMutableArray*) selection;

// version
+ (NSString*) maxVersionStringOfSketchApp;

// workspace
+ (void) setWorkSpace:(NSString*)path;
+ (NSString*) getWorkSpace;

// object
+ (void) setCurrentObjectRectOnly:(id)object Rect:(CGRect)rect;
+ (void) setCurrentObjectAbsoluteRectOnly:(id)object Rect:(CGRect)rect;

// page
+ (id)duplicatePage:(id)doc Page:(id)page NewName:(NSString*)newName;
+ (id)duplicatePage:(id)page NewName:(NSString*)newName;
+ (BOOL) isPageIgnored:(id<MSPage>)page;

// document
+ (NSString*) getSketchDocumentName;
+ (NSString*) getSketchDocumentNameWithoutVersion;
+ (id<MSSymbolMaster>) getcurSymbolMasterBySymbolID:(NSString*)symbolID;

// artboard
+ (int)indexOfArtboard:(id<MSArtboardGroup>)artboard;
+ (id<MSArtboardGroup>)getArtboard:(id<MSLayer>)layer;
+ (BOOL)checkisConditionArtboard:(id<MSArtboardGroup>)artboard;

// layer
+ (NSString*) getDesignID:(id<MSLayer>) layer;
+ (NSString*) loadDesingIDDesignID:() layer;
+ (bool) isInstance:(id<MSLayer>)layer;
+ (NSDictionary*) getCCPropertyDefaultValuesByType:(NSString*)cctype;
+ (id) readLayerInfo:(NSString*)key layer:(id<MSLayer>)tarLayer;
+ (void)writeLayerInfo:(NSString*)key value:(id)value layer:(id<MSLayer>)tarLayer;
+ (id) readLayerInfo:(NSString*)key layer:(id<MSLayer>)tarLayer keyWord:(NSString*)keyWord;
+ (void)writeLayerInfo:(NSString*)key value:(id)value layer:(id<MSLayer>)tarLayer keyWord:(NSString*)keyWord;
+ (id<MSLayerGroup>) detachByReplacingWithMasterGroup:(id<MSSymbolInstance>)symbolInstance;
+ (id<MSLayerGroup>) detachByReplacingWithAutoGroup:(id<MSSymbolInstance>)symbolInstance;
+ (bool) removeLayer:(id<MSLayer>) layer;
+ (bool) checkIsTextInstance:(id<MSLayer>)layer;
+ (NSString*) getTextInstanceValue:(id<MSLayer>)layer;

//other
+ (void) exportLayerTofile:(id<MSLayer>)targetLayer filePath:(NSString*)filePath;
+ (void) exportLayerTofile:(id<MSLayer>)targetLayer filePath:(NSString*)filePath fileName:(NSString*)fileName;

@end


#endif /* SketchCommon_h */

