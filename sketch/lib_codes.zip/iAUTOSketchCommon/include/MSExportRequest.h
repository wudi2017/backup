//
//  MSExportRequest.h
//  sketchPluginFramework
//
//  Created by wuyuchi on 2018/8/30.
//  Copyright © 2018 iauto. All rights reserved.
//

#ifndef MSExportRequest_h
#define MSExportRequest_h

#import <Foundation/Foundation.h>
@class MSImmutableColor, MSImmutableDocumentData, MSImmutableLayer, NSSet, NSString;;

@protocol MSExportRequest<NSObject>

+ (id)exportRequestFromLayerAncestry:(id)arg1 exportFormat:(id)arg2 inRect:(struct CGRect)arg3;
+ (id)exportRequestsFromLayerAncestry:(id)arg1 exportFormats:(id)arg2 inRect:(struct CGRect)arg3;
+ (id)exportRequestsFromLayerAncestry:(id)arg1 exportFormats:(id)arg2;
+ (id)exportRequestsFromLayerAncestry:(id)arg1 inRect:(struct CGRect)arg2;
+ (id)exportRequestsFromLayerAncestry:(id)arg1;
+ (id)exportRequestFromExportFormat:(id)arg1 layer:(id)arg2 inRect:(struct CGRect)arg3 useIDForName:(BOOL)arg4;
+ (id)exportRequestsFromExportableLayer:(id)arg1 exportFormats:(id)arg2 inRect:(struct CGRect)arg3 useIDForName:(BOOL)arg4;
+ (id)exportRequestsFromExportableLayer:(id)arg1 inRect:(struct CGRect)arg2 useIDForName:(BOOL)arg3;
+ (id)exportRequestsFromExportableLayer:(id)arg1 exportFormats:(id)arg2 useIDForName:(BOOL)arg3;
+ (id)exportRequestsFromExportableLayer:(id)arg1 useIDForName:(BOOL)arg2;
+ (id)exportRequestsFromExportableLayer:(id)arg1;
@property(nonatomic) BOOL includeArtboardBackground; // @synthesize includeArtboardBackground=_includeArtboardBackground;
@property(nonatomic) BOOL interlaced; // @synthesize interlaced=_interlaced;
@property(nonatomic) BOOL progressive; // @synthesize progressive=_progressive;
@property(nonatomic) double compression; // @synthesize compression=_compression;
@property(nonatomic) BOOL saveForWeb; // @synthesize saveForWeb=_saveForWeb;
@property(copy, nonatomic) NSString *format; // @synthesize format=_format;
@property(retain, nonatomic) MSImmutableDocumentData *immutableDocument; // @synthesize immutableDocument=_immutableDocument;
@property(retain, nonatomic) MSImmutableLayer *rootLayer; // @synthesize rootLayer=_rootLayer;
@property(copy, nonatomic) MSImmutableColor *backgroundColor; // @synthesize backgroundColor=_backgroundColor;
@property(nonatomic) BOOL shouldTrim; // @synthesize shouldTrim=_shouldTrim;
@property(nonatomic) double scale; // @synthesize scale=_scale;
@property(copy, nonatomic) NSSet *includedLayerIDs; // @synthesize includedLayerIDs=_includedLayerIDs;
@property(nonatomic) unsigned long long options; // @synthesize options=_options;
@property(copy, nonatomic) NSString *name; // @synthesize name=_name;
@property(nonatomic) struct CGRect rect; // @synthesize rect=_rect;
//- (void).cxx_destruct;
- (id)copyWithZone:(struct _NSZone *)arg1;
- (id)init;
- (id)objectIDsForSelfAncestorsAndChildrenOfAncestry:(id)arg1;
- (void)configureForLayerAncestry:(id)arg1 layerOptions:(unsigned long long)arg2 includedIDs:(id)arg3;
- (void)setNameFromID:(id)arg1 exportFormat:(id)arg2;
- (void)readSettingsFromDefaults;
@property(readonly, nonatomic) NSString *pasteboardType;
- (void)configureForLayer:(id)arg1 layerOptions:(unsigned long long)arg2 includedIDs:(id)arg3;

@end

#endif /* MSExportRequest_h */
