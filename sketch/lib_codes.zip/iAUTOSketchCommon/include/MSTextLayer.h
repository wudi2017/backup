//
//  MSTextLayer.h
//  sketchPluginFramework
//
//  Created by wuyuchi on 2018/8/27.
//  Copyright © 2018 iauto. All rights reserved.
//

#ifndef MSTextLayer_h
#define MSTextLayer_h

//#import "_MSTextLayer"

@protocol _MSTextLayer<MSLayer>

+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
//- (void).cxx_destruct;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) long long textBehaviour; // @synthesize textBehaviour=_textBehaviour;
//@property(retain, nonatomic) MSImageData *preview; // @synthesize preview=_preview;
@property(nonatomic) long long lineSpacingBehaviour; // @synthesize lineSpacingBehaviour=_lineSpacingBehaviour;
@property(nonatomic) struct CGRect glyphBounds; // @synthesize glyphBounds=_glyphBounds;
@property(nonatomic) BOOL dontSynchroniseWithSymbol; // @synthesize dontSynchroniseWithSymbol=_dontSynchroniseWithSymbol;
@property(nonatomic) BOOL automaticallyDrawOnUnderlyingPath; // @synthesize automaticallyDrawOnUnderlyingPath=_automaticallyDrawOnUnderlyingPath;
//@property(retain, nonatomic) MSAttributedString *attributedString; // @synthesize attributedString=_attributedString;
- (void)performInitWithImmutableModelObject:(id)arg1;
//- (void)enumerateChildProperties:(CDUnknownBlockType)arg1;
//- (void)enumerateProperties:(CDUnknownBlockType)arg1;

@end


@protocol MSTextLayer<_MSTextLayer>

//+ (long long)menuItemStateForTest:(CDUnknownBlockType)arg1 forLayers:(id)arg2;
+ (long long)menuItemStateForAlignment:(unsigned long long)arg1 forLayers:(id)arg2;
+ (void)setTextAlignment:(unsigned long long)arg1 forLayers:(id)arg2;
+ (BOOL)canSetTextAlignmentForLayers:(id)arg1;
+ (long long)menuItemStateForTextVerticalAlignment:(long long)arg1 forLayers:(id)arg2;
+ (void)setTextVerticalAlignment:(long long)arg1 forLayers:(id)arg2;
+ (BOOL)canSetTextVerticalAlignmentForLayers:(id)arg1;
+ (id)keyPathsForValuesAffectingTextBehaviourSegmentIndex;
+ (id)keyPathsForValuesAffectingSupportsVerticalAlignment;
+ (id)keyPathsForValuesAffectingHasFixedHeight;
+ (id)keyPathsForValuesAffectingCanFixHeight;
//+ (void)maintainTextLayerBaselinesForLayers:(id)arg1 inBlock:(CDUnknownBlockType)arg2;
@property(copy, nonatomic) NSArray *baselineOffsetsValue; // @synthesize baselineOffsetsValue=_baselineOffsetsValue;
@property(retain, nonatomic) NSNumber *defaultLineHeightValue; // @synthesize defaultLineHeightValue=_defaultLineHeightValue;
//@property(nonatomic) __weak id <MSTextLayerEditingDelegate> editingDelegate; // @synthesize editingDelegate=_editingDelegate;
@property(retain, nonatomic) NSValue *transientGlyphBoundsValue; // @synthesize transientGlyphBoundsValue=_transientGlyphBoundsValue;
@property(nonatomic) BOOL isEditingText; // @synthesize isEditingText=_isEditingText;
@property(nonatomic) struct CGRect previousRectCache; // @synthesize previousRectCache=_previousRectCache;
//- (void).cxx_destruct;
- (void)convertColorsUsing:(id)arg1;
- (BOOL)canLockProportions;
- (BOOL)canScale;
- (BOOL)canBeTransformed;
- (BOOL)constrainProportions;
- (void)checkTextBehaviourAndClippingAfterResizeFromCorner:(long long)arg1 mayClip:(BOOL)arg2;
- (void)resizeWithOldGroupSize:(struct CGSize)arg1;
- (void)layerDidResizeFromRect:(struct CGRect)arg1 corner:(long long)arg2;
- (void)replaceTextPreservingAttributeRanges:(id)arg1;
- (void)setTextTransform:(unsigned long long)arg1 range:(struct _NSRange)arg2;
- (void)makeLowercase:(id)arg1;
- (void)makeUppercase:(id)arg1;
- (void)multiplyBy:(double)arg1;
- (id)attributeForKey:(id)arg1;
- (void)addAttribute:(id)arg1 value:(id)arg2;
- (void)addAttributes:(id)arg1 forRange:(struct _NSRange)arg2;
- (void)setAttributes:(id)arg1 forRange:(struct _NSRange)arg2;
- (void)addAttribute:(id)arg1 value:(id)arg2 forRange:(struct _NSRange)arg3;
//- (void)ignoreDelegateNotificationsInBlock:(CDUnknownBlockType)arg1;
@property(copy, nonatomic) NSString *stringValue;
//- (void)updateAttributedStringInBlock:(CDUnknownBlockType)arg1;
- (void)setGlyphBounds:(struct CGRect)arg1;
- (void)setAttributedString:(id)arg1;
@property(copy, nonatomic) NSAttributedString *attributedStringValue;
- (void)layerStyleDidChange;
- (BOOL)isEmpty;
@property(copy, nonatomic) NSDictionary *styleAttributes;
@property(copy, nonatomic) id textColor;
@property(nonatomic) double lineHeight;
- (double)baseLineHeight;
@property(retain, nonatomic) NSNumber *characterSpacing;
@property(retain, nonatomic) NSString *fontPostscriptName;
- (void)setFont:(id)arg1;
@property(nonatomic) double fontSize;
@property(nonatomic) long long verticalAlignment;
@property(nonatomic) unsigned long long textAlignment;
- (void)setLeading:(double)arg1;
- (double)leading;
- (id)paragraphStyle;
- (void)setKerning:(float)arg1;
- (float)kerning;
- (void)refreshOverlay;
- (id)bezierPathFromGlyphsInBounds;
- (struct CGPoint)drawingPointForText;
- (double)startingPositionOnPath:(id)arg1;
- (double)defaultLineHeight:(id)arg1;
- (NSFont*)font;
- (void)changeFont:(id)arg1;
- (unsigned long long)selectionCornerMaskWithZoomValue:(double)arg1;
- (id)shapeToUseForTextOnPath;
- (void)updateNameFromStorage;
- (void)changeListType:(id)arg1;
- (void)setRectAccountingForClipped:(struct CGRect)arg1;
- (void)adjustFrameToFit;
- (void)finishEditing;
- (double)baselineAdjustmentForLayoutManager:(id)arg1;
- (void)replaceMissingFontsIfNecessary;
- (BOOL)compareAttributes:(id)arg1 withAttributes:(id)arg2;
- (void)syncTextStyleAttributes;
- (id)sharedObject;
- (void)setupBehaviour:(BOOL)arg1;
- (void)setTextBehaviour:(long long)arg1;
- (void)setTextBehaviour:(long long)arg1 mayAdjustFrame:(BOOL)arg2;
- (void)setStyle:(id)arg1;
- (void)object:(id)arg1 didChangeProperty:(id)arg2;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)performInitEmptyObject;
- (void)objectDidInit;
- (id)initWithFrame:(struct CGRect)arg1 attributes:(id)arg2 documentColorSpace:(id)arg3 type:(long long)arg4;
- (id)initWithAttributedString:(id)arg1 documentColorSpace:(id)arg2 maxWidth:(double)arg3;
- (id)initWithFrame:(struct CGRect)arg1;
- (id)PDFPreview;
- (BOOL)shouldStorePDFPreviews;
- (struct CGRect)measurementRectWithOptions:(unsigned long long)arg1;
- (long long)cornerRectType;
- (BOOL)shouldDrawSelection;
- (Class)handlerClass;
- (void)layerDidResizeFromInspector:(unsigned long long)arg1;
- (id)inspectorViewControllerNames;
- (void)drawHoverWithZoom:(double)arg1 color:(id)arg2 cache:(id)arg3;
- (void)applyScreenPickerColor:(id)arg1 preferredStyleName:(id)arg2;
- (void)copyStylePropertiesToShape:(id)arg1;
- (void)copyTextPropertiesToShape:(id)arg1;
- (BOOL)canConvertToOutlines;
- (id)layersByConvertingToOutlines;
- (unsigned long long)shareableObjectType;
- (id)snapLines;
- (Class)snapItemClass;
- (id)unselectedPreviewImage;
- (id)selectedPreviewImage;
- (void)changeTextColorTo:(id)arg1;
- (void)changeColor:(id)arg1;
- (void)setTextBehaviourSegmentIndex:(long long)arg1;
- (long long)textBehaviourSegmentIndex;
@property(readonly, nonatomic) BOOL supportsVerticalAlignment;
- (BOOL)supportsInnerOuterBorders;
- (void)resetSharedStyle;
- (void)setSharedStyle:(id)arg1;
- (id)foreignSharedStyles;
- (id)localSharedStyles;
- (void)reapplyPreviousAttributesFromString:(id)arg1;
- (void)applyOverride:(id)arg1 toPoint:(id)arg2;
- (unsigned long long)resizingConstraint;
- (BOOL)canFixHeight;
- (void)invalidateFonts;
- (void)replaceFonts:(id)arg1;
- (void)embedInRotatedGroup;
- (long long)cornerForBaselineMaintaining;
- (void)writeStyleToPasteboard:(id)arg1;
- (id)CSSAttributes;
- (long long)layoutDirection;
- (id)setupWithLayerBuilderDictionary:(id)arg1;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly, copy) NSString *description;
@property(readonly) unsigned long long hash;
@property(readonly) Class superclass;

@end

#endif /* MSTextLayer_h */
