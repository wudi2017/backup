//
//  MSStyleBorder.h
//  sketchPluginFramework
//
//  Created by nb on 2018/12/6.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSStyleBorder_h
#define MSStyleBorder_h

#import "MSLayer.h"
#import "MSStyleBasicFill.h"

/*
 *  _MSStyleBorder **********************************************************************************************
 */
@protocol _MSStyleBorder<MSStyleBasicFill>

// My Add Begin
- (void)setThickness:(id)thickness;
// My Add End


+ (BOOL)allowsFaulting;
+ (Class)immutableClass;
- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(nonatomic) double thickness; // @synthesize thickness=_thickness;
@property(nonatomic) long long position; // @synthesize position=_position;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end



/*
 *  MSStyleBorder **********************************************************************************************
 */

@protocol MSStyleBorder<_MSStyleBorder>
+ (id)defaultFillColor;
- (BOOL)supportsAdvancedBorderSettings;
- (void)multiplyBy:(double)arg1;
- (long long)patternFillType;
- (double)noiseIntensity;
- (void)performInitEmptyObject;
- (id)topViewForColorInspector:(id)arg1;
- (id)blendingViewForColorInspector:(id)arg1;
- (id)CSSAttributeString;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly, copy) NSString *description;
@property(readonly) unsigned long long hash;
@property(readonly) Class superclass;
@end

#endif /* MSStyleBorder_h */
