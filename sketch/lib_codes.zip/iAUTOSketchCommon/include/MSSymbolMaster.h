//
//  MSSymbolMaster.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/27.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef MSSymbolMaster_h
#define MSSymbolMaster_h

#import "MSArtboardGroup.h"


/*
 *  _MSSymbolMaster **********************************************************************************************
 */

@protocol _MSSymbolMaster<MSArtboardGroup>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSString *symbolID; // @synthesize symbolID=_symbolID;
@property(nonatomic) BOOL includeBackgroundColorInInstance; // @synthesize includeBackgroundColorInInstance=_includeBackgroundColorInInstance;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end


/*
 *  MSSymbolMaster **********************************************************************************************
 */

@protocol MSSymbolMaster<_MSSymbolMaster>

+ (void)copyPropertiesFrom:(id)arg1 to:(id)arg2;
+ (id)convertSymbolToArtboard:(id)arg1;
+ (id)convertArtboardToSymbol:(id)arg1;
@property(nonatomic) BOOL isDirty; // @synthesize isDirty=_isDirty;
@property(nonatomic) long long changeIdentifier; // @synthesize changeIdentifier=_changeIdentifier;
- (BOOL)limitsSelectionToBounds;
- (void)object:(id)arg1 didChangeProperty:(id)arg2;
- (id)parentSymbol;
- (id)rootForNameUniquing;
- (id)ancestorIDsForLayerNamed:(id)arg1 skip:(id)arg2;
- (id)ancestorIDsForLayerNamed:(id)arg1;
- (BOOL)isSafeToDelete;
- (void)multiplyBy:(double)arg1;
- (id)ungroup;
- (void)removeFromParentAndDetachAllInstances;
- (void)detachAllInstances;
- (BOOL)ensureSymbolIDUniqueInDocument:(id)arg1;
- (BOOL)canInsertInstanceIntoGroupWithoutInfiniteRecursion:(id)arg1;
- (BOOL)hasInstances;
@property(readonly, nonatomic) NSArray *allInfluencedInstances;
- (id)nestedSymbolsSkipping:(id)arg1;
@property(readonly, nonatomic) NSSet *nestedSymbols;
@property(readonly, nonatomic) NSArray *allInstances;
- (id)newSymbolInstance;
- (id)copyWithIDMapping:(id)arg1;
- (void)moveChildrenToIdenticalPositionAfterResizeFromRect:(struct CGRect)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)invalidateImmutableObject;
- (void)syncPropertiesFromObject:(id)arg1;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (id)initWithFrame:(struct CGRect)arg1;
- (void)generatePreviewWithImageSize:(struct CGSize)arg1 previewSize:(struct CGSize)arg2 colorSpace:(id)arg3 backingScale:(double)arg4 completionBlock:(id)arg5;
- (id)unselectedPreviewImage;
- (id)selectedPreviewImage;
- (struct CGRect)optimalBoundingBox;
- (BOOL)canSnap:(unsigned long long)arg1 toLayer:(id)arg2;
- (Class)shareableObjectReferenceClass_bc;
- (void)applyStyleToMenuItem:(id)arg1 withColorSpace:(id)arg2;
- (void)generatePreviewWithImageSize:(struct CGSize)arg1 previewSize:(struct CGSize)arg2 backingScale:(double)arg3 shadow:(BOOL)arg4 colorSpace:(id)arg5 completionBlock:(id)arg6;
- (void)generatePreviewForSyncSheetWithSize:(struct CGSize)arg1 backingScale:(double)arg2 shadow:(BOOL)arg3 colorSpace:(id)arg4 completionBlock:(id)arg5;
- (id)generatePreviewForManageSheetWithBackingScale:(double)arg1 completionBlock:(id)arg2;
- (id)generatePreviewForPopup:(id)arg1 backingScale:(double)arg2 completionBlock:(id)arg3;
- (id)generatePreviewForMenuItem:(id)arg1 withColorSpace:(id)arg2 backingScale:(double)arg3 completionBlock:(id)arg4;
- (void)applyOverrides:(id)arg1;
@property(readonly, nonatomic) NSArray *availableOverrides;

// Remaining properties
@property(readonly, copy) NSString *debugDescription;
@property(readonly, copy) NSString *description;
@property(readonly) unsigned long long hash;
@property(readonly, nonatomic) NSString *name;
@property(readonly) Class superclass;
@end

#endif /* MSSymbolMaster_h */
