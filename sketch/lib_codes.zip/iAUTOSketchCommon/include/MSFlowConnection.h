//
//  MSFlowConnection.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/9/4.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef MSFlowConnection_h
#define MSFlowConnection_h

//#import "MSArtboardGroup.h"

#import "MSModelObject.h"

/*
 *  _MSFlowConnection **********************************************************************************************
 */

@protocol _MSFlowConnection<MSModelObject>
+ (BOOL)allowsFaulting;
+ (Class)immutableClass;

- (void)syncPropertiesFromObject:(id)arg1;
- (BOOL)propertiesAreEqual:(id)arg1;
- (void)copyPropertiesToObject:(id)arg1 options:(unsigned long long)arg2;
- (void)setAsParentOnChildren;
- (void)initializeUnsetObjectPropertiesWithDefaults;
- (BOOL)hasDefaultValues;
- (void)performInitEmptyObject;
@property(retain, nonatomic) NSString *destinationArtboardID; // @synthesize destinationArtboardID=_destinationArtboardID;
@property(nonatomic) long long animationType; // @synthesize animationType=_animationType;
- (void)performInitWithImmutableModelObject:(id)arg1;
- (void)enumerateChildProperties:(id)arg1;
- (void)enumerateProperties:(id)arg1;
@end

/*
 *  MSFlowConnection **********************************************************************************************
 */

@protocol MSLayer;
@protocol MSArtboardGroup;

@protocol MSFlowConnection<_MSFlowConnection>

+ (long long)defaultAnimationType;
+ (id)flowConnectionBack;
+ (id)flowConnectionTo:(id)arg1 ofType:(long long)arg2;
@property(readonly, nonatomic) BOOL isValidFlowConnection;
- (id)bezierPathForRenderingFlowAtZoomLevel:(double)arg1;
@property(readonly, nonatomic) __weak id<MSArtboardGroup> destinationArtboard;
@property(readonly, nonatomic) __weak id<MSLayer> sendingLayer;
@property(nonatomic) BOOL isBackAction;

@end

#endif /* MSFlowConnection_h */
