//
//  SketchTest.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef SketchTest_h
#define SketchTest_h

#import <Foundation/Foundation.h>


@interface SketchTest : NSObject

+ (void)testmethod1:(NSObject *)doc;

@end

#endif /* SketchTest_h */
