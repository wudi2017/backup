//
//  SketchTest.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/8/28.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import "Sketch.h"
#import "SketchTest.h"
#import "CLog.h"

@implementation SketchTest

+ (void)testmethod1:(NSObject *)doc {
    BLOG(BLOGTAG_BASE, @"testmethod1 begin");
    
    id<MSDocument> msDoc = (id<MSDocument>)doc;
    
    // tranversal page
    NSArray * pages = [msDoc pages];
    for (int iPage=0; iPage < pages.count; iPage++) {
        id<MSPage> page = [pages objectAtIndex:iPage];
        
        NSString * nsPageName = [page name];
        BLOG(BLOGTAG_BASE, @"PageName:%@", nsPageName);
        
        if (0 == iPage) {
            // copy page
            id<MSPage> newPage = [page duplicate];
            [newPage setName:@"new page"];
            [[msDoc documentData] addPage:newPage];
            [msDoc pageTreeLayoutDidChange];
            
            // tranversal artboard
            NSArray * artboards = [page artboards];
            for (int iArtboard=0; iArtboard < artboards.count; iArtboard++) {
                id<MSArtboardGroup> artboard = [artboards objectAtIndex:iArtboard];
                
                NSString * nsArtboardName = [artboard name];
                BLOG(BLOGTAG_BASE, @"    ArtboardName:%@", nsArtboardName);
                
                if(0 == iArtboard)
                {
                    // tranversal 1 level layers
                    NSArray * layers = [artboard containedLayers];
                    for (int iLayer=0; iLayer < layers.count; iLayer++) {
                        id<MSLayer> layer = [layers objectAtIndex:iLayer];
                        
                        NSString * nsLayerClassName = [layer className];
                        NSString * nsLayerName = [layer name];
                        BLOG(BLOGTAG_BASE, @"        LayerName:%@ Class:%@", nsLayerName, nsLayerClassName);
                    }
                }
            }
        }
    }
    BLOG(BLOGTAG_BASE, @"testmethod1 end");
}

@end
