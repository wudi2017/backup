//
//  SketchCommon.m
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SketchCommon.h"
#import "CStringUtils.h"

static Class flowClass;

static id<MSPluginCommand> s_command;
static id<MSDocument> s_document;
static NSString* s_scriptPath;
static NSString * s_scriptURL;
static NSMutableArray* s_selection;
static NSString* s_maxVerString = nil;

static NSString * s_workspace;
static NSString * s_documentName;


@implementation SketchCommon

// context
+ (void)setContextData:
(id<MSPluginCommand>)command
              Document:(id<MSDocument>)document
            ScriptPath:(NSString*)scriptPath
             ScriptURL:(NSString*)scriptURL
             Selection:(NSMutableArray*)selection
{
    s_command = command;
    s_document = document;
    s_scriptPath = s_scriptPath;
    s_scriptURL = scriptURL;
    s_selection = [NSArray arrayWithArray:selection];
    
    // init document name
    {
        NSString * docFullPath = [[s_document fileURL] path];
        int b = [docFullPath rangeOfString:@"/" options:NSBackwardsSearch].location;
        int e = [docFullPath rangeOfString:@"." options:NSBackwardsSearch].location;
        //        if(e < 0){
        //            e = [docFullPath rangeOfString:@"." options:NSBackwardsSearch].location;
        //        }
        s_documentName = [docFullPath substringWithRange:NSMakeRange(b+1,e-b-1)];
    }
}

+ (id<MSPluginCommand>) command
{
    return s_command;
}

+ (id<MSDocument>) document
{
    return s_document;
}

+ (NSString*) scriptPath
{
    return s_scriptPath;
}

+ (NSString*) scriptURL
{
    return s_scriptURL;
}

+ (NSMutableArray*) selection
{
    return s_selection;
}

+ (NSString*) maxVersionStringOfSketchApp
{
    if (nil == s_maxVerString) {
        s_maxVerString = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    }
    return s_maxVerString;
}

+ (void) setWorkSpace:(NSString*)path
{
    s_workspace = [NSString stringWithString:path];
}

+ (NSString*) getWorkSpace
{
    return s_workspace;
}

+ (NSString*) getSketchDocumentName
{
    return s_documentName;
}

+ (NSString*) getSketchDocumentNameWithoutVersion
{
    NSString* sketch_path = [[s_document fileURL] path];
    NSRange range = [sketch_path rangeOfString:@"/" options:NSBackwardsSearch];
    NSUInteger start = 0;
    NSUInteger e = 0;
    if(range.length > 0){
        start = range.location;
        range = [sketch_path rangeOfString:@"("];
        if(range.length > 0){
            e = range.location;
        }
        else{
            range = [sketch_path rangeOfString:@"." options:NSBackwardsSearch];
            if(range.length > 0){
                e = range.location;
            }
            else{
                return  @"-1";
            }
        }
        
    }
    else{
        return @"-1";
    }
    //    NSInteger blank_count = 1;
    //    NSString* temp_str = [sketch_path substringWithRange:NSMakeRange(e-1, 1)];
    //    while (e > blank_count && [temp_str isEqualToString:@" "]) {
    //        temp_str = [sketch_path substringWithRange:NSMakeRange(e-blank_count, 1)];
    //        blank_count++;
    //    }
    if(start >0 && e > start){
        NSString* res = [sketch_path substringWithRange:NSMakeRange(start+1, e-start-1)];
        res = [CStringUtils trimedStr:res];
        return [CStringUtils toSlug:res];
    }
    return @"-1";
}

+ (id<MSSymbolMaster>) getcurSymbolMasterBySymbolID:(NSString*)symbolID
{
    id<MSSymbolMaster> master = nil;
    NSDictionary* allSymbols= [[[SketchCommon document] documentData] symbolMap];
    if(allSymbols && [allSymbols valueForKey:symbolID]){
        master =  [allSymbols valueForKey:symbolID];
    }
    return master;
}

// object
+ (void) setCurrentObjectRectOnly:(id)object Rect:(CGRect)rect
{
    id<MSLayerGroup> curObj = (id<MSLayerGroup>)object;
    
    NSMutableArray * subLayers = [NSMutableArray array];
    NSMutableArray * absRectLayers = [NSMutableArray array];
    if ([curObj containsLayers]) {
        for (int iSubLayer=0; iSubLayer<[curObj containedLayersCount]; iSubLayer++) {
            
            id<MSLayer> subLayer = [curObj layerAtIndex:iSubLayer];
            [subLayers addObject:subLayer];
            
            CGRect absRect = [[subLayer absoluteRect] absoluteRect];
            NSValue * absRectVal = [NSValue valueWithRect:absRect];
            [absRectLayers addObject:absRectVal];
        }
    }
    
    //    if ([curObj containsLayers]) {
    //        [curObj removeAllLayers];
    //    }
    
    // set current rect
    [curObj setRect:rect];
    CGRect currentObjAbsRect = [[curObj absoluteRect] absoluteRect];
    
    if ([subLayers count]>0) {
        // add sublayers
        //[curObj addLayers:subLayers];
        
        if (subLayers) {
            for (int iSubLayer=0; iSubLayer<[subLayers count]; iSubLayer++) {
                id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
                CGRect subLayerAbsRect = [[absRectLayers objectAtIndex:iSubLayer] rectValue];
                
                int rectX = subLayerAbsRect.origin.x - currentObjAbsRect.origin.x;
                int rectY = subLayerAbsRect.origin.y - currentObjAbsRect.origin.y;
                int rectW = subLayerAbsRect.size.width;
                int rectH = subLayerAbsRect.size.height;
                
                //[self setCurrentObjectRectOnly:subLayer Rect:NSMakeRect(rectX, rectY, rectW, rectH)];
                [subLayer setRect:NSMakeRect(rectX, rectY, rectW, rectH)];
            }
        }
    }
}
+ (void) setCurrentObjectAbsoluteRectOnly:(id)object Rect:(CGRect)rect
{
    id<MSLayerGroup> curObj = (id<MSLayerGroup>)object;
    
    NSMutableArray * subLayers = [NSMutableArray array];
    NSMutableArray * absRectLayers = [NSMutableArray array];
    if ([curObj containsLayers]) {
        for (int iSubLayer=0; iSubLayer<[curObj containedLayersCount]; iSubLayer++) {
            
            id<MSLayer> subLayer = [curObj layerAtIndex:iSubLayer];
            [subLayers addObject:subLayer];
            
            CGRect absRect = [[subLayer absoluteRect] absoluteRect];
            NSValue * absRectVal = [NSValue valueWithRect:absRect];
            [absRectLayers addObject:absRectVal];
        }
    }
    
    // set current abs rect
    id<MSAbsoluteRect> absRect = [MSAbsoluteRect new];
    [absRect initWithLayer:curObj];
    [absRect setRect:rect];
    [curObj setAbsoluteRect:absRect];
    
    if ([subLayers count]>0) {
        // add sublayers
        //[curObj addLayers:subLayers];
        
        if (subLayers) {
            for (int iSubLayer=0; iSubLayer<[subLayers count]; iSubLayer++) {
                id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
                CGRect subLayerAbsRect = [[absRectLayers objectAtIndex:iSubLayer] rectValue];
                
                id<MSAbsoluteRect> absRect = [MSAbsoluteRect new];
                [absRect initWithLayer:subLayer];
                [absRect setRect:subLayerAbsRect];
                [subLayer setAbsoluteRect:absRect];
            }
        }
    }
}

// indexOfArtboard -----------------
+ (int)indexOfArtboard:(id<MSArtboardGroup>)artboard
{
    id<MSPage> parentPage = [artboard parentPage];
    NSArray * artboards = [parentPage artboards];
    for (int iAB=0; iAB<[artboards count]; iAB++) {
        id<MSArtboardGroup> tmpArtboard = [artboards objectAtIndex:iAB];
        
        NSString * tmpArtboardID = [tmpArtboard objectID];
        NSString * artboardID = [artboard objectID];
        if ([tmpArtboardID isEqualToString:artboardID]) {
            return iAB;
        }
    }
    return 0;
}

// duplicatePage -------------------
+ (void)reloadflow:(id)newPage Artboard:(id<MSArtboardGroup>)artboard FlowObj:(NSMutableDictionary*)abFlow
{
    NSMutableArray* layerIndexList = [abFlow valueForKey:@"layerIndexList"];
    NSNumber * nToArtboardIndex = [abFlow valueForKey:@"toArtboardIndex"];
    int toArtboardIndex = [nToArtboardIndex integerValue];
    int levelMax = [layerIndexList count];
    
    id<MSLayer> curLayer = artboard;
    for (int iLevel = 0; iLevel < levelMax; iLevel++) {
        NSNumber * nIndex = [layerIndexList objectAtIndex:iLevel];
        int index = [nIndex integerValue];
        
        NSArray * layers = [curLayer containedLayers];
        curLayer = [layers objectAtIndex:index];
        
        if (iLevel == levelMax-1) {
            
            id<MSFlowConnection> newFlow = nil;
            
            if (-1 == toArtboardIndex) { // back flow
                newFlow  = [flowClass flowConnectionBack];
            }
            else
            {
                NSArray * artboards = [newPage artboards];
                id<MSArtboardGroup> toArtboard = [artboards objectAtIndex:toArtboardIndex];
                newFlow = [flowClass flowConnectionTo:toArtboard ofType:0];
            }

            [curLayer resetFlow];
            [curLayer setFlow:newFlow];
            
            //BLOG(BLOGTAG_BASE, @"Connect");
        };
    }
}

+ (void)reloadflowsForArtboard:(id)newPage Artboard:(id<MSArtboardGroup>)artboard FlowData:(NSMutableArray*)abFlows
{
    for (int iFlow = 0; iFlow < [abFlows count]; iFlow++) {
        NSMutableDictionary* abFlow = [abFlows objectAtIndex:iFlow];
        [self reloadflow:newPage Artboard:artboard FlowObj:abFlow];
    };
}
+ (void)clearAllFlows:(id)layer
{
    if (nil == layer) {
        return;
    }
    
    [layer resetFlow];
    
    if([layer containsLayers])
    {
        NSArray * subLayers = [layer containedLayers];
        for (int iSubLayer=0; iSubLayer < subLayers.count; iSubLayer++) {
            id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
            [self clearAllFlows:subLayer];
        }
    }
}

+ (void)duplicatePage_help_getSubFlow:(id)layer Level:(int)level LevelList:(NSMutableArray*)iLevelList IndexList:(NSMutableArray*)iIndexList
                             FlowData:(NSMutableArray*)artboardFlowData
{
    id<MSLayer> msLayer = (id<MSLayer>)layer;
    //BLOG(BLOGTAG_BASE, @"duplicatePage_help_getSubFlowOther layerName:%@ level:%d", [msLayer name] ,level);
    if (nil == msLayer) {
        return;
    };
    
    NSNumber * nLevel = [NSNumber numberWithInt:level];
    [iLevelList addObject:nLevel];
    NSNumber * nIndex = [NSNumber numberWithInt:0];
    [iIndexList addObject:nIndex];
    
    NSString * layerClsName = [msLayer className];
    if([msLayer containsLayers])
    {
        NSArray * layers = [msLayer containedLayers];
        //BLOG(BLOGTAG_BASE, @"    layers count:%d", [layers count]);
        
        for (int iLayer=0; iLayer < layers.count; iLayer++) {
            [iIndexList replaceObjectAtIndex:[nLevel intValue] withObject:[NSNumber numberWithInt:iLayer]];
            
            id<MSLayer> sublayer = [layers objectAtIndex:iLayer];
            
            id<MSFlowConnection> flow = [sublayer flow];
            if (!flowClass && flow) {
                flowClass = [flow class];
            }
            
            if (nil != flow) {
                if ([flow isBackAction]) {
                    // add flow data
                    NSMutableDictionary* flowObj = [NSMutableDictionary dictionary];
                    
                    NSMutableArray* layerIndexList = [NSMutableArray array];
                    for (int iTmp=0; iTmp<[iIndexList count]; iTmp++) {
                        [layerIndexList addObject: [iIndexList objectAtIndex:iTmp] ];
                    }
                    [flowObj setObject:layerIndexList forKey:@"layerIndexList"];
                    
                    [flowObj setObject:[NSNumber numberWithInt:-1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ] forKey:@"toArtboardIndex"]; // back
                    
                    [artboardFlowData addObject:flowObj];
                }
                else
                {
                    if (nil != [flow destinationArtboard]) {
                        // check destartboard is in current page
                        NSString* destinationArtboardPageID = [[[flow destinationArtboard] parentPage] objectID];
                        NSString* layerPageID = [[sublayer parentPage] objectID];
                        if (nil!=layerPageID && [layerPageID isEqualToString:destinationArtboardPageID]) {
                            
                            // add flow data
                            NSMutableDictionary* flowObj = [NSMutableDictionary dictionary];
                            
                            NSMutableArray* layerIndexList = [NSMutableArray array];
                            for (int iTmp=0; iTmp<[iIndexList count]; iTmp++) {
                                [layerIndexList addObject: [iIndexList objectAtIndex:iTmp] ];
                            }
                            [flowObj setObject:layerIndexList forKey:@"layerIndexList"];
                            
                            id<MSArtboardGroup> destinationArtboard = [flow destinationArtboard];
                            int indexOfArtboard = [self indexOfArtboard:destinationArtboard];
                            [flowObj setObject:[NSNumber numberWithInt:indexOfArtboard                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ] forKey:@"toArtboardIndex"];
                            
                            [artboardFlowData addObject:flowObj];
                        }
                    }
                }
            }
            
            if([sublayer containsLayers])
            {
                [self duplicatePage_help_getSubFlow:sublayer Level:[nLevel intValue]+1 LevelList:iLevelList IndexList:iIndexList FlowData:artboardFlowData];
            }
        }
    }
    
    [iLevelList removeLastObject];
    [iIndexList removeLastObject];
}

+ (id)duplicatePage:(id)doc Page:(id)page NewName:(NSString*)newName;
{
    id<MSDocument> msDoc = (id<MSDocument>)doc;
    id<MSPage> msPage = (id<MSPage>)page;
    
    //BLOG(BLOGTAG_BASE, @"duplicatePage oldName[%@] newPage[%@]", [msPage name], newName);
    
    // get origin page flow data
    NSMutableDictionary* flowData = [NSMutableDictionary dictionary];
    NSArray * artboards = [page artboards];
    for (int iArtboard=0; iArtboard < artboards.count; iArtboard++) {
        id<MSArtboardGroup> artboard = [artboards objectAtIndex:iArtboard];
        
        NSMutableArray* abFlows = [NSMutableArray array];
        NSMutableArray* iLevelList = [NSMutableArray array];
        NSMutableArray* iIndexList = [NSMutableArray array];
        
        [self duplicatePage_help_getSubFlow:artboard Level:0 LevelList:iLevelList IndexList:iIndexList FlowData:abFlows];
        
        NSString* iArtboardKey = [NSString stringWithFormat:@"%d", iArtboard];
        [flowData setObject:abFlows forKey:iArtboardKey];
    }
    
    // copy page object
    id<MSPage> newPage = [msPage duplicate];
    [newPage setName:newName];
    [[doc documentData] addPage:newPage];
    [doc pageTreeLayoutDidChange];
    
    // reconnect flow for new page
    {
        [self clearAllFlows:newPage];
        
        NSArray * artboards = [newPage artboards];
        for (int iArtboard=0; iArtboard < artboards.count; iArtboard++) {
            id<MSArtboardGroup> artboard = [artboards objectAtIndex:iArtboard];
            
            
            
            NSString * sIndexArtboard = [NSString stringWithFormat:@"%d", iArtboard];
            NSMutableArray* abFlows = [flowData valueForKey:sIndexArtboard];
            if (abFlows) {
                [self reloadflowsForArtboard:newPage Artboard:artboard FlowData:abFlows];
            };
        }
    }
    
    return newPage;
}

+ (id)duplicatePage:(id)page NewName:(NSString*)newName
{
    id<MSDocument> doc = [SketchCommon document];
    return [SketchCommon duplicatePage:doc Page:page NewName:newName];
}

+ (NSString*) getDesignID:(id<MSLayer>) layer
{
    if(layer)
    {
        NSString* objectID = [layer objectID];
        return  objectID;
    }
    return  nil;
}

+ (bool) isInstance:(id<MSLayer>)layer
{
    if([[layer className] isEqualToString:@"MSSymbolInstance"]){
        return true;
    }
    else{
        return false;
    }
}+ (id<MSPage>) getCombinePage
{
    id<MSPage> result = nil;
    if (![SketchCommon document]) {
        return nil;
    }
    NSArray* pages = [[SketchCommon document] pages];
    for(NSUInteger pagenum=0;pagenum<[pages count];pagenum++){
        id<MSPage> curpage = [pages objectAtIndex:pagenum];
        NSString* pagename = [curpage name];
        if([pagename isEqualToString:@"iAutoArtboardsCombine"]){
            result = curpage;
        }
    }
    return result;
}

//function getDesignID(context, layer)
//{
//    var layerDesignID = "";
//    layerDesignID = getDesignObjectIDByLayer(layer, context);
//    if (nil == layerDesignID) {
//        layerDesignID = layer.objectID();
//    };
//    //layerDesignID = layer.objectID();
//    return layerDesignID;
//}

/*
 function getArtboardByObjID(objectIns) {
 var tempObj = objectIns;
 while(tempObj && tempObj.class() != MSPage && tempObj.class() != MSArtboardGroup && MSSymbolMaster != tempObj.class()){
 tempObj = tempObj.parentGroup();
 }
 if(tempObj.class() == MSArtboardGroup || MSSymbolMaster == tempObj.class()){
 return tempObj;
 }
 return -1;
 }
 */

+ (id<MSArtboardGroup>)getArtboard:(id<MSLayer>)layer
{
    NSArray* targetLayerNames = [[NSArray alloc] initWithObjects:@"MSArtboardGroup",@"MSPage",@"MSSymbolMaster", nil];
    if(layer){
        id<MSLayer> curLayer = layer;
        NSString* curLayerClass = [curLayer className];
        while(curLayer  && ![targetLayerNames containsObject:curLayerClass]){
            curLayer = [curLayer parentGroup];
            curLayerClass = [curLayer className];
        }
        
        if([curLayerClass isEqualToString:@"MSArtboardGroup"]){
            return curLayer;
        }
    }
    return nil;
    
}

+ (BOOL)checkisConditionArtboard:(id<MSArtboardGroup>)artboard
{
    CGFloat width = [[artboard absoluteRect] width];
    CGFloat heidth = [[artboard absoluteRect] height];
    if(width<960 || heidth < 540)
    {
        return true;
    }
    return false;
}

+ (NSDictionary*) getCCPropertyDefaultValuesByType:(NSString*)cctype
{
    NSMutableDictionary* res = [NSMutableDictionary dictionary];
    if([cctype isEqualToString:@"NormalImage"])
    {
        [res setObject:@"NormalImage" forKey:@"TYPE"];
        [res setObject:@"none" forKey:@"NORMALIMAGEMARK_DATA"];
    }
    else if([cctype isEqualToString:@"NormalLabel"]){
        [res setObject:@"NormalLabel" forKey:@"TYPE"];
        [res setObject:@"Radio" forKey:@"NORMALLABEL_VALUE_TEXT"];
        [res setObject:@"48" forKey:@"NORMALLABEL_VALUE_FONTSIZE"];
        [res setObject:@"ToyotaType-Regular" forKey:@"NORMALLABEL_VALUE_FONTFILE"];
        [res setObject:@"LeftAligned" forKey:@"NORMALLABEL_VALUE_HALIGNMENT"];
        [res setObject:@"CenterAligned" forKey:@"NORMALLABEL_VALUE_VALIGNMENT"];
        [res setObject:@"tl:FFFFFFFF tr:FFFFFFFF bl:FFFFFFFF br:FFFFFFFF" forKey:@"NORMALLABEL_VALUE_FONTCOLOR"];
        [res setObject:@"none" forKey:@"NORMALLABEL_VALUE_ADAPTER"];
    }
    else if([cctype isEqualToString:@"CustomButton"]){
        [res setObject:@"CustomButton" forKey:@"TYPE"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_CHECKABLESTATE"];
        [res setObject:@"1" forKey:@"CUSTOMBUTTON_KEY_VISIBLESTATE"];
        [res setObject:@"0" forKey:@"ID"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_ADAPTER"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_FAKEDISABLESTATE"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_CHECKEDSTATE"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_PROHIBITIONSTATE"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_AVPROHIBITIONSTATE"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_CLICKBEEP"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_LONGCLICKBEEP"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_ANIMENABLE"];
        [res setObject:@"0" forKey:@"CUSTOMBUTTON_KEY_ANIMTYPE"];
        [res setObject:@"0" forKey:@"TAG_UI_HAS_REQUEST"];
        [res setObject:@"1" forKey:@"CUSTOMBUTTON_KEY_HASBG"];
    }
    else if([cctype isEqualToString:@"FullView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"FullView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    else if([cctype isEqualToString:@"SubView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"SubView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    else if([cctype isEqualToString:@"MainView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"MainView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    else if([cctype isEqualToString:@"PopView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"PopView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    else if([cctype isEqualToString:@"AlertView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"AlertView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    //    else if([cctype isEqualToString:@"UnusedView"]){
    //        [res setObject:@"Frame" forKey:@"TYPE"];
    //        [res setObject:@"UnusedView" forKey:@"MARK_VIEW"];
    //        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    //    }
    else if([cctype isEqualToString:@"FullView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"FullView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    else if([cctype isEqualToString:@"FullView"]){
        [res setObject:@"Frame" forKey:@"TYPE"];
        [res setObject:@"FullView" forKey:@"MARK_VIEW"];
        [res setObject:@"NormalLayer" forKey:@"MARK_LAYER"];
    }
    else{
        NSArray* ccontroler = [[NSArray alloc] initWithObjects:@"StaticList",@"DynamicList",@"CategoryList",@"StatusBar",@"PlayStatus",@"PlayModeSelect",@"TitleBar",@"NXFrame",@"GlobalMenu",@"Banner",@"Message",@"GlobalMenu6Item", nil];
        if([ccontroler containsObject:cctype]){
            [res setObject:cctype forKey:@"TYPE"];
        }
        else{
            return nil;
        }
    }
    return res;
}

+ (id) readLayerInfo:(NSString*)key layer:(id<MSLayer>)tarLayer
{
    if(!tarLayer){
        tarLayer = [SketchCommon document];
    }
    id<MSPluginCommand> command = [SketchCommon command];
    return [command valueForKey:key onLayer:tarLayer forPluginIdentifier:@"iauto"];
}

+ (void)writeLayerInfo:(NSString*)key value:(id)value layer:(id<MSLayer>)tarLayer
{
    if(!tarLayer){
        tarLayer = [SketchCommon document];
    }
    if(key){
        id<MSPluginCommand> command = [SketchCommon command];
        [command setValue:value forKey:key onLayer:tarLayer forPluginIdentifier:@"iauto"];
    }
}

+ (id) readLayerInfo:(NSString*)key layer:(id<MSLayer>)tarLayer keyWord:(NSString*)keyWord
{
    if(!tarLayer){
        tarLayer = [[SketchCommon document] documentData];
    }
    id<MSPluginCommand> command = [SketchCommon command];
    return [command valueForKey:key onLayer:tarLayer forPluginIdentifier:keyWord];
}

+ (void)writeLayerInfo:(NSString*)key value:(id)value layer:(id<MSLayer>)tarLayer keyWord:(NSString*)keyWord
{
    if(!tarLayer){
        tarLayer = [[SketchCommon document] documentData];
    }
    if(key){
        id<MSPluginCommand> command = [SketchCommon command];
        [command setValue:value forKey:key onLayer:tarLayer forPluginIdentifier:keyWord];
    }
}

+ (void) exportLayerTofile:(id<MSLayer>)targetLayer filePath:(NSString*)filePath
{
    NSArray* exportRequests = [MSExportRequest exportRequestsFromExportableLayer:targetLayer];
    id<MSExportRequest> slice = [exportRequests firstObject];
    NSString* layerName = [CStringUtils toSlug:[targetLayer objectID]];
    
    NSString* fillPathName = [[[filePath stringByAppendingString:@"/"] stringByAppendingString:layerName] stringByAppendingString:@".png"];
    [slice setShouldTrim:true];
    [slice setScale:1];
    [slice setCompression:0.5];
    [slice setFormat:@"png"];
    id<MSDocument> doc = [SketchCommon document];
    [doc saveArtboardOrSlice:slice toFile:fillPathName];
}

+ (void) exportLayerTofile:(id<MSLayer>)targetLayer filePath:(NSString*)filePath fileName:(NSString*)fileName
{
    NSArray* exportRequests = [MSExportRequest exportRequestsFromExportableLayer:targetLayer];
    id<MSExportRequest> slice = [exportRequests firstObject];
    
    NSString* fillPathName = [[[filePath stringByAppendingString:@"/"] stringByAppendingString:fileName] stringByAppendingString:@".png"];
    [slice setShouldTrim:true];
    [slice setScale:1];
    [slice setCompression:0.5];
    [slice setFormat:@"png"];
    id<MSDocument> doc = [SketchCommon document];
    [doc saveArtboardOrSlice:slice toFile:fillPathName];
}

+ (BOOL) isPageIgnored:(id<MSPage>)page {
    NSString* name = [page name];
    NSArray* ccontroler = [[NSArray alloc] initWithObjects:@"Symbols",@"symbols",@"Config",@"Sandbox",@"_sandbox",@"_archive",@"_reference", nil];
    if([ccontroler containsObject:name]){
        return true;
    }
    return false;
}

+ (id<MSLayerGroup>) detachByReplacingWithMasterGroup:(id<MSSymbolInstance>)symbolInstance
{
    id<MSLayerGroup> retLayerGroup = nil;
    
    NSString* instanceName = [symbolInstance name];
    CGRect instanceRect = [symbolInstance rect];
    
    id<MSLayerGroup> parentGroup = [symbolInstance parentGroup];
    int indexOfInstance = [parentGroup indexOfLayer:symbolInstance];
    
    id<MSLayerGroup> detachGroup = nil;
    NSString* sketchVer = [self maxVersionStringOfSketchApp];
    if ([sketchVer compare:@"53"] < 0) {
        detachGroup = [symbolInstance detachByReplacingWithGroup];
    }
    else
    {
        detachGroup = [symbolInstance detachStylesAndReplaceWithGroupRecursively:false];
    }
    
    bool bNeedReplaceWithGroup = false;
    id<MSLayer> symbolMaster = [symbolInstance symbolMaster];
    if (nil == symbolMaster) {
        bNeedReplaceWithGroup = true;
    }
    else
    {
        NSMutableArray* symbolMasterChildrens = [symbolMaster children];
        if (nil == symbolMasterChildrens) {
            bNeedReplaceWithGroup = true;
        }
        else
        {
            NSMutableArray* detachGroupChildrens = [detachGroup children];
            if (nil == detachGroupChildrens) {
                bNeedReplaceWithGroup = true;
            }
            else
            {
                if ([detachGroupChildrens count] != [symbolMasterChildrens count]) {
                    bNeedReplaceWithGroup = true;
                }
                else
                {
                    bNeedReplaceWithGroup = false;
                }
            }
        }
    }

    
    if (bNeedReplaceWithGroup) {
        id<MSLayerGroup> tempgroup = [MSLayerArray arrayWithLayer:detachGroup];
        id<MSLayerGroup> newparentgroup = [MSLayerGroup groupWithLayers:tempgroup];
        retLayerGroup = newparentgroup;
//        retLayerGroup = [MSLayerGroup new];
//        retLayerGroup.name = instanceName;
//        retLayerGroup.rect = instanceRect;
//        [parentGroup insertLayer:retLayerGroup atIndex:indexOfInstance];
//        if (nil != detachGroup) {
//            [detachGroup moveToLayer:retLayerGroup beforeLayer:nil];
//        }
    }
    else
    {
        retLayerGroup = detachGroup;
    }
    
    return retLayerGroup;
}

+ (id<MSLayerGroup>) detachByReplacingWithAutoGroup:(id<MSSymbolInstance>)symbolInstance
{
    return [symbolInstance detachByReplacingWithGroup];
}

+ (bool) removeLayer:(id<MSLayer>) layer
{
    NSString* className = [layer className];
    if ([className isEqualToString:@"MSPage"]) {
        [[self document] removePage:layer];
    }
    else
    {
        [layer removeFromParent];
    }
    return true;
}

+(bool) checkIsTextInstance:(id<MSLayer>)layer
{
    if ([[layer className] isEqualToString:@"MSTextLayer"]) {
        return true;
    }
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        id<MSSymbolInstance> instance = layer;
        NSMutableArray* overridesPoints = [instance overridePoints];
        if (nil != overridesPoints && 1 == [overridesPoints count]) {
            id<MSOverridePoint> overridePoint = [overridesPoints objectAtIndex:0];
            if (nil != overridePoint) {
                NSString* overridesVal = [overridePoint name];
                if (nil != overridesVal && [overridesVal rangeOfString:@"_stringValue"].location != NSNotFound) {
                    if (48 == [overridesVal length]) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

+(NSString*) getTextInstanceValue:(id<MSLayer>)layer
{
    NSString* contentValue = @"";
    if ([[layer className] isEqualToString:@"MSTextLayer"]) {
        id<MSTextLayer> textLayer = layer;
        contentValue = [textLayer stringValue];
    }
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        id<MSSymbolInstance> instance = layer;
        NSMutableArray* symbolLayers = [[instance symbolMaster] layers];
        NSString* testSymbolID = nil;
        for (int i=0; i<[symbolLayers count]; i++) {
            id<MSLayer> symbolLayer = [symbolLayers objectAtIndex:i];
            if ([[symbolLayer className] isEqualToString:@"MSTextLayer"]) {
                testSymbolID = [symbolLayer objectID];
            }
        }
        if (nil != testSymbolID) {
            NSMutableDictionary* overrides = [instance overrides];
            if (nil != overrides && [overrides count] > 0) {
                contentValue = [overrides objectForKey:testSymbolID];
            }
        }
    }
    return contentValue;
}

@end

