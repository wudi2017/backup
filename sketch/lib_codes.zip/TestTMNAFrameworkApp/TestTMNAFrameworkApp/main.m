//
//  main.m
//  TestTMNAFrameworkApp
//
//  Created by nb on 2018/12/29.
//  Copyright © 2018年 suntec. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
