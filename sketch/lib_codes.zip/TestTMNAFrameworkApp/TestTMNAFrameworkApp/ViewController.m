//
//  ViewController.m
//  TestTMNAFrameworkApp
//
//  Created by nb on 2017/2/8.
//  Copyright © 2017年 nb. All rights reserved.
//

#import "ViewController.h"

@import TMNAFramework;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    
    // Do any additional setup after loading the view.
    //    JsonItem *item = nil;
    CGRect rect = NSMakeRect(0, 0, 800, 800);
    //  return [[FTGWindow alloc] initWithContentRect:rect styleMask:NSTitledWindowMask|NSClosableWindowMask backing:NSBackingStoreBuffered defer:YES];
    NSWindow *window = [[NSWindow alloc] initWithContentRect:rect styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:YES];
    //    [window setContentView: [[JsonTableView alloc] init] ];

    //ScreenAdoptionView * testView = [[ScreenAdoptionView alloc] init];
    //SPartsInfoView * testView = [[SPartsInfoView alloc] init];
    SIAUTOMainView * testmainView = [[SIAUTOMainView alloc] init];
    SPartsInfoView * testView = [testmainView getPartsInfoView];
    
    [testView clearModelData];
    
    NSMutableDictionary * testModelData = [testView getTestModelData];
    [testView setModelData:testModelData];

    NSMutableDictionary * curModelData = [testView getModelData];
    [testView setModelData:curModelData];

    [testView clearModelData];
    
    testModelData = [testView getTestModelData];
    [testView setModelData:testModelData];

    NSScrollView * testMainScrollView = [[NSScrollView alloc] init];
    [testMainScrollView setHasVerticalScroller:YES];
    [testMainScrollView setHasHorizontalScroller:YES];
    NSView * documentView = [[NSView alloc] init];
    [documentView setFrame:NSMakeRect(0, 0, 800, 1600)];
    [documentView addSubview:testmainView];
    [testMainScrollView setDocumentView: documentView];
    [window setContentView:testMainScrollView];

    [[NSApplication sharedApplication] runModalForWindow:window];
    
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
