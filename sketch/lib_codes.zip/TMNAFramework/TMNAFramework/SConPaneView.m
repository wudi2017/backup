//
//  SConPanelView.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/21.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import "SConPaneView.h"

@implementation SConPaneView

-(void)clearModelData
{
    [self.m_tfA setStringValue:@""];
    [self.m_tfB setStringValue:@""];
    [self.m_tfC setStringValue:@""];
    [self.m_tfFormula setStringValue:@""];
    [self.m_tfSamePartsID setStringValue:@""];
    [self.m_tfSameScreenID setStringValue:@""];
    [self.m_tfElse setStringValue:@""];
}

-(void)setModelData:(NSMutableDictionary*)modelData
{
    [self clearModelData];
    int count = [modelData count];
    NSLog(@"modelData count： %d\n",count);
    
    // enum all key
    NSLog(@"allkey enum\n");
    NSEnumerator * enumeratorKey = [modelData keyEnumerator];
    for (NSObject *object in enumeratorKey) {
        NSString *key = object;
        NSString *value = modelData[object];
        NSLog(@"    k:%@ v:%@\n",key, value);
        
        // ---
        if (NSOrderedSame == [key compare:@"A"]) {
            [self.m_tfA setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"B"]) {
            [self.m_tfB setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"C"]) {
            [self.m_tfC setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"Formula"]) {
            [self.m_tfFormula setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"SamePartsID"]) {
            [self.m_tfSamePartsID setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"SameScreenID"]) {
            [self.m_tfSameScreenID setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"Else"]) {
            [self.m_tfElse setStringValue:value];
        }
        
    }
}

-(NSMutableDictionary*)getModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    NSString * sA = [self.m_tfA stringValue];
    if (sA) {
        [modelData setObject:sA forKey:@"A"];
    }
    NSString * sB = [self.m_tfB stringValue];
    if (sB) {
        [modelData setObject:sB forKey:@"B"];
    }
    NSString * sC = [self.m_tfC stringValue];
    if (sC) {
        [modelData setObject:sC forKey:@"C"];
    }
    NSString * sFormula = [self.m_tfFormula stringValue];
    if (sFormula) {
        [modelData setObject:sFormula forKey:@"Formula"];
    }
    NSString * sSamePartsID = [self.m_tfSamePartsID stringValue];
    if (sSamePartsID) {
        [modelData setObject:sSamePartsID forKey:@"SamePartsID"];
    }
    NSString * sSameScreenID = [self.m_tfSameScreenID stringValue];
    if (sSameScreenID) {
        [modelData setObject:sSameScreenID forKey:@"SameScreenID"];
    }
    NSString * sElse = [self.m_tfElse stringValue];
    if (sElse) {
        [modelData setObject:sElse forKey:@"Else"];
    }
    
    return modelData;
}

-(instancetype)init {
    self = [super init];
    
    int iViewH = 235;
    int iViewW = 200;
    //[super setFrame:NSMakeRect(20,20,iViewW,iViewH)];
    
    int heightNow = iViewH-5;
    
    [super setWantsLayer:YES];
    CALayer * layer = [super layer];
    NSColor * tstNSColor = [NSColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:0.0];
    [layer setBackgroundColor:[tstNSColor CGColor]];
    [layer setBorderWidth:1.0f];
    [layer setBorderColor:CGColorCreateGenericRGB(0.0, 0.0, 0.0, 0.3)];
    
    // A B C
    NSTextField * lbA = [[NSTextField alloc] init];
    [lbA setBezeled:false];
    [lbA setStringValue:@"A"];
    [lbA setSelectable:false];
    [lbA setEditable:false];
    [lbA setDrawsBackground:false];
    [lbA setFont:[NSFont fontWithName:@"Arial" size:12]];
    [lbA setTextColor:[NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.5]];
    [lbA setFrame:NSMakeRect(5,heightNow-30,20,20)];
    [super addSubview:lbA];
    NSTextField * tfA = [[NSTextField alloc] init];
    [tfA setBezeled:false];
    [tfA setFont:[NSFont fontWithName:@"Arial" size:12]];
    [tfA setWantsLayer:true];
    [[tfA layer] setCornerRadius:5];
    [tfA setFrame:NSMakeRect(20,heightNow-40,iViewW-20-6,40)];
    [super addSubview:tfA];
    self.m_tfA = tfA;
    heightNow=heightNow-41;
    
    NSTextField * lbB = [[NSTextField alloc] init];
    [lbB setBezeled:false];
    [lbB setStringValue:@"B"];
    [lbB setSelectable:false];
    [lbB setEditable:false];
    [lbB setDrawsBackground:false];
    [lbB setFont:[NSFont fontWithName:@"Arial" size:12]];
    [lbB setTextColor:[NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.5]];
    [lbB setFrame:NSMakeRect(5,heightNow-30,20,20)];
    [super addSubview:lbB];
    NSTextField * tfB = [[NSTextField alloc] init];
    [tfB setBezeled:false];
    [tfB setFont:[NSFont fontWithName:@"Arial" size:12]];
    [tfB setWantsLayer:true];
    [[tfB layer] setCornerRadius:5];
    [tfB setFrame:NSMakeRect(20,heightNow-40,iViewW-20-6,40)];
    [super addSubview:tfB];
    self.m_tfB = tfB;
    heightNow=heightNow-41;
    
    NSTextField * lbC = [[NSTextField alloc] init];
    [lbC setBezeled:false];
    [lbC setStringValue:@"C"];
    [lbC setSelectable:false];
    [lbC setEditable:false];
    [lbC setDrawsBackground:false];
    [lbC setFont:[NSFont fontWithName:@"Arial" size:12]];
    [lbC setTextColor:[NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.5]];
    [lbC setFrame:NSMakeRect(5,heightNow-30,20,20)];
    [super addSubview:lbC];
    NSTextField * tfC = [[NSTextField alloc] init];
    [tfC setBezeled:false];
    [tfC setFont:[NSFont fontWithName:@"Arial" size:12]];
    [tfC setWantsLayer:true];
    [[tfC layer] setCornerRadius:5];
    [tfC setFrame:NSMakeRect(20,heightNow-40,iViewW-20-6,40)];
    [super addSubview:tfC];
    self.m_tfC = tfC;
    heightNow=heightNow-41;
    
    // Formula
    NSTextField * lbFormula = [[NSTextField alloc] init];
    [lbFormula setBezeled:false];
    [lbFormula setStringValue:@"Formula"];
    [lbFormula setSelectable:false];
    [lbFormula setEditable:false];
    [lbFormula setDrawsBackground:false];
    [lbFormula setFont:[NSFont fontWithName:@"Arial" size:11]];
    [lbFormula setTextColor:[NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3]];
    [lbFormula setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:lbFormula];
    heightNow=heightNow-15;
    
    NSTextField * tfFormula = [[NSTextField alloc] init];
    [tfFormula setBezeled:false];
    [tfFormula setFont:[NSFont fontWithName:@"Arial" size:11]];
    [tfFormula setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:tfFormula];
    self.m_tfFormula = tfFormula;
    heightNow=heightNow-15;

    // lbSameCon
    NSTextField * lbSameCon = [[NSTextField alloc] init];
    [lbSameCon setBezeled:false];
    [lbSameCon setStringValue:@"Same Condition"];
    [lbSameCon setSelectable:false];
    [lbSameCon setEditable:false];
    [lbSameCon setDrawsBackground:false];
    [lbSameCon setFont:[NSFont fontWithName:@"Arial" size:11]];
    [lbSameCon setTextColor:[NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3]];
    [lbSameCon setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:lbSameCon];
    heightNow=heightNow-15;

    NSTextField * tfPartsID = [[NSTextField alloc] init];
    [tfPartsID setBezeled:false];
    [tfPartsID setFont:[NSFont fontWithName:@"Arial" size:11]];
    [tfPartsID setPlaceholderString:@"Parts ID"];
    [tfPartsID setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:tfPartsID];
    self.m_tfSamePartsID = tfPartsID;
    heightNow=heightNow-16;

    NSTextField * tfScreenID = [[NSTextField alloc] init];
    [tfScreenID setBezeled:false];
    [tfScreenID setFont:[NSFont fontWithName:@"Arial" size:11]];
    [tfScreenID setPlaceholderString:@"Screen ID"];
    [tfScreenID setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:tfScreenID];
    self.m_tfSameScreenID = tfScreenID;
    heightNow=heightNow-15;
    
    // lbElse
    NSTextField * lbElse = [[NSTextField alloc] init];
    [lbElse setBezeled:false];
    [lbElse setStringValue:@"Else"];
    [lbElse setSelectable:false];
    [lbElse setEditable:false];
    [lbElse setDrawsBackground:false];
    [lbElse setFont:[NSFont fontWithName:@"Arial" size:11]];
    [lbElse setTextColor:[NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3]];
    [lbElse setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:lbElse];
    heightNow=heightNow-15;
    
    NSTextField * tfElse = [[NSTextField alloc] init];
    [tfElse setBezeled:false];
    [tfElse setFont:[NSFont fontWithName:@"Arial" size:11]];
    [tfElse setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
    [super addSubview:tfElse];
    self.m_tfElse = tfElse;
    heightNow=heightNow-16;
    
    return self;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
}

@end

