//
//  common.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/26.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef common_h
#define common_h

#import <Foundation/Foundation.h>

@interface SCommon : NSObject

+ (instancetype)shared;

-(NSString *)TaskRun:(NSString *)exefile param:(NSString*)args;

-(bool)setMemProperty:(NSString *)key Value:(NSObject*)val;
-(NSObject *)getMemProperty:(NSString *)key;
@property NSMutableDictionary * m_memPropMap;

@end

#endif /* common_h */
