//
//  SButton.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/7/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#include "SButtonView.h"

@implementation SButtonView

- (instancetype)init
{
    self = [super init];
    
    // set layer
    CALayer * layer = [CALayer layer];
    [layer setBackgroundColor:CGColorCreateGenericRGB(0.4, 0.4, 0.4, 0.0)];
    [super setLayer:layer];
    
    // image view
    self.m_imageView = [[NSImageView alloc] init];
    [self.m_imageView setImageScaling:NSImageScaleAxesIndependently];
    
    [super addSubview:self.m_imageView];
    
    return self;
}

- (void)setFrame:(NSRect)rect
{
    [self.m_imageView setFrame:NSMakeRect(0, 0, rect.size.width, rect.size.height)];
    [super setFrame:rect];
}

-(void)setImage:(NSImage *)img
{
    self.m_defaultImg = img;
    [self.m_imageView setImage:self.m_defaultImg];
}
-(void)setPushDownImage:(NSImage *)img
{
    self.m_pushDownImg = img;
}

- (void)mouseDown:(NSEvent *)theEvent {
    
    NSLog(@"SButtonView::mouseDown");
    if(self.m_pushDownImg)
    {
         [self.m_imageView setImage:self.m_pushDownImg];
    }
    else{
        NSShadow * sd = [[NSShadow alloc] init];
        [sd setShadowColor:[NSColor colorWithRed:0 green:0 blue:0 alpha:1]];
        [self.m_imageView setShadow:sd];
    }
    
    [super mouseDown:theEvent];
    
    NSLog(@"SButtonView::mouseUp");
    if(self.m_pushDownImg)
    {
        [self.m_imageView setImage:self.m_defaultImg];
    }
    else{
        NSShadow * sd = [[NSShadow alloc] init];
        [sd setShadowColor:[NSColor colorWithRed:0 green:0 blue:0 alpha:0]];
        [self.m_imageView setShadow:sd];
    }
}

@end
