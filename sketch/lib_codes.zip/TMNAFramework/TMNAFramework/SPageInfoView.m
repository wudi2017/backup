//
//  SPageInfoView.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/7/2.
//  Copyright © 2018年 iauto. All rights reserved.
//

#include "SPageInfoView.h"

#include "SButtonView.h"

@implementation SPageInfoViewDelegate
-(void)onSaveButtonClick
{
    
}
@end

@implementation SPageInfoView

-(void)awakeFromNib
{
    [self init];
}
- (BOOL)isFlipped
{
    return YES;
}

-(void)setDelegage:(SPageInfoViewDelegate*)delegage
{
    self.m_delegate = delegage;
}

-(void)setModelData:(NSMutableDictionary*)modelData
{
    [self clearModelData];
    
    int count = [modelData count];
    NSLog(@"modelData count： %d\n",count);
    NSLog(@"data=%@\n",modelData);
    
    // enum all key
    NSLog(@"allkey enum\n");
    NSEnumerator * enumeratorKey = [modelData keyEnumerator];
    for (NSObject *object in enumeratorKey) {
        NSString *key = object;
        NSObject *value = modelData[object];
        NSLog(@"    k:%@ v:%@\n",key, value);
        
        if (NSOrderedSame == [key compare:@"PageID"]) {
            [self.m_tfPageID setStringValue:value];
        }
    }
}

-(NSMutableDictionary*)getModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    NSString * sPageID = [self.m_tfPageID stringValue];
    if (sPageID) {
        [modelData setObject:sPageID forKey:@"PageID"];
    }
    return modelData;
}

-(void)clearModelData
{
    [self.m_tfPageID setStringValue:@""];
}

-(NSMutableDictionary*)getTestModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    [modelData setObject:@"pageID1" forKey:@"PageID"];
    return modelData;
}

-(instancetype)init {
    self = [super init];
    
    int iViewH = 270;
    int iViewW = 200;
    
    [super setFrame:NSMakeRect(250,20,iViewW,iViewH)];
    [super setWantsLayer:YES];
    CALayer * layer = [super layer];
    NSColor * tstNSColor = [NSColor colorWithRed:0.92549 green:0.92549 blue:0.92549 alpha:1.0];
    [layer setBackgroundColor:[tstNSColor CGColor]];
    
    int heightNow = 0;
    NSColor * colSplitLineTitle = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3];
    NSColor * colSplitLine = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.33];
    NSColor * colSubTitle = [NSColor colorWithRed:0.35 green:0.35 blue:0.35 alpha:1];
    
    // title & btnsync
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Page"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica-Bold" size:13]];
        [lbTitle setFrame:NSMakeRect(5,heightNow+3,iViewW,20)];
        [super addSubview:lbTitle];
        
        SButtonView * btnSync = [[SButtonView alloc] init];
        [btnSync setFrame:NSMakeRect(iViewW-20,heightNow+5,16,16)];
        NSBundle *bundle = [NSBundle bundleForClass:[SPageInfoView class]];
        NSImage * image = [bundle imageForResource:@"save"];
        [btnSync setImage:image];
        NSImage * imagePush = [bundle imageForResource:@"save3"];
        [btnSync setPushDownImage:imagePush];
        [btnSync setBordered:false];
        [btnSync setImageScaling:NSImageScaleAxesIndependently];
        [super addSubview:btnSync];
        [btnSync setTarget:self];
        [btnSync setAction:@selector(onSaveButtonClick:)];
        self.m_btnSave = btnSync;
    }
    heightNow=heightNow + 25;
    
    // split line
    {
        NSView * splitLine = [[NSView alloc] init];
        [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
        [splitLine setWantsLayer:true];
        [[splitLine layer] setBackgroundColor:[colSplitLineTitle CGColor]];
        [super addSubview:splitLine];
    }
    heightNow=heightNow + 10;
    
    // Page ID
    {
        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"Page Name"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow+20;
        
        NSTextField * tfContent = [[NSTextField alloc] init];
        [tfContent setBezeled:false];
        [tfContent setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfContent setFrame:NSMakeRect(2,heightNow,iViewW-2,20)];
        [tfContent setWantsLayer:true];
        [[tfContent layer] setCornerRadius:5];
        [super addSubview:tfContent];
        self.m_tfPageID = tfContent;
        heightNow=heightNow+20;
    }
    
    return self;
}

-(void)onSaveButtonClick:(id)sender
{
    NSLog(@"onSaveButtonClick");
    if (self.m_delegate) {
        [self.m_delegate onSaveButtonClick];
    }
}

@end


