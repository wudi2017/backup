//
//  SPageInfoView.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/7/2.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef SPageInfoView_h
#define SPageInfoView_h

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>

@interface SPageInfoViewDelegate : NSObject
-(void)onSaveButtonClick;
@end

@interface SPageInfoView : NSView

-(instancetype)init;
-(void)setModelData:(NSMutableDictionary*)modelData;
-(NSMutableDictionary*)getModelData;
-(void)clearModelData;
-(NSMutableDictionary*)getTestModelData;
-(void)setDelegage:(SPageInfoViewDelegate*)delegage;

@property NSButton * m_btnSave;
@property NSTextField * m_tfPageID;
@property SPageInfoViewDelegate * m_delegate;

/*
 model data (NSMutableDictionary NSMutableArray)
 
 modelData =
 {
    "PageID":"xx"
 }
 
 */

@end

#endif /* SPageInfoView_h */
