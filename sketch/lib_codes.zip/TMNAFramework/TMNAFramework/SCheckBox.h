//
//  SCheckBox.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/29.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef SCheckBox_h
#define SCheckBox_h

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>

@interface SCheckBoxDelegate : NSObject
-(void)onClick:(bool)bCheck;
@end

@interface SCheckBox : NSView

-(instancetype)init;
- (void)setFrame:(CGRect)frame;
- (void)setCheckFlag:(bool)bCheck;
- (bool)getCheckFlag;
- (void)setText:(NSString *)text;
- (NSString*)getText;
-(void)setDelegage:(SCheckBoxDelegate*)delegage;

@property NSButton * m_btnCheckBox;
@property NSImage * m_image0;
@property NSImage * m_image1;
@property NSTextField * m_tfLBText;
@property bool m_bCheckFlag;

@property SCheckBoxDelegate * m_delegate;

@end

#endif /* SCheckBox_h */
