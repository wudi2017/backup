//
//  ScreenIDEditView.h
//  TMNAFramework
//
//  Created by nb on 2017/11/28.
//

#ifndef ScreenIDEditView_h
#define ScreenIDEditView_h

#import <Cocoa/Cocoa.h>

@interface ScreenIDEditViewDelegate : NSObject
-(void)onSaveButtonClick;
-(void)onCancelButtonClick;
@end


@interface ScreenIDEditView : NSView

+ (id) instance;

-(void)setModelData:(NSMutableDictionary*)modelData;
-(NSMutableDictionary*)getModelData;
-(void)clearModelData;
-(NSMutableDictionary*)getTestModelData;
/*
 data={
    "Func":{"Current":"X","List":["Y","X"]},
    "Region":{"Current":"X","List":["Y","X"]},
    "RegionMap":{"Y":21},
    "ArtboardVal":{"Current":"X","List":["Y","X"]}
 }
 */
-(void)setDelegage:(ScreenIDEditViewDelegate*)delegage;

@property NSMutableDictionary * m_modelData;
@property NSComboBox * m_cbFunc;
@property NSComboBox * m_cbRegon;
@property NSComboBox * m_tfRegon;
@property NSTextField * m_tfArtboardVal;
@property NSTextField * m_tfDisplayScreenID;
@property NSButton * m_saveBtn;

@property ScreenIDEditViewDelegate * m_delegate;

@end

#endif /* ScreenIDEditView_h */
