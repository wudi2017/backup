//
//  SScreenInfoView.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/22.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import "SScreenInfoView.h"
#include "SCheckBox.h"
#include "SButtonView.h"

@implementation SScreenInfoViewDelegate
-(void)onScreenBindChanged:(NSString*)currentText
{
    
}
-(void)onSaveButtonClick
{
    
}
@end


@implementation SScreenInfoView
- (BOOL)isFlipped
{
    return YES;
}

-(void)setDelegage:(SScreenInfoViewDelegate*)delegage
{
    self.m_delegate = delegage;
}

-(void)clearModelData
{
    [self.m_tfScreenID setStringValue:@""];
    [self.m_tfBasicScreenID setStringValue:@""];
    [self.m_tfScreenName setStringValue:@""];
    [self.m_tfNote setStringValue:@""];
    
    if(!self.m_bCbBindScreenActiveFlag)
    {
        [self.m_cbBindScreen setStringValue:@""];
        [self.m_cbBindScreen removeAllItems];
    }
    
    for (int i=0; i<self.m_arrPageCheckBox.count; i++) {
        [self.m_arrPageCheckBox[i] setCheckFlag:false];
        [self.m_arrPageCheckBox[i] setHidden:true];
        [self.m_arrPageCheckBox[i] setText:@"Default"];
    }
//    [self.m_cbBindPage setStringValue:@""];
//    [self.m_cbBindPage removeAllItems];
}

-(void)setModelData:(NSMutableDictionary*)modelData
{
    [self clearModelData];
    
    int count = [modelData count];
    NSLog(@"modelData count： %d\n",count);
    NSLog(@"data=%@\n",modelData);
    
    // enum all key
    NSLog(@"allkey enum\n");
    NSEnumerator * enumeratorKey = [modelData keyEnumerator];
    for (NSObject *object in enumeratorKey) {
        NSString *key = object;
        NSObject *value = modelData[object];
        NSLog(@"    k:%@ v:%@\n",key, value);
        
        if (NSOrderedSame == [key compare:@"ScreenID"]) {
            [self.m_tfScreenID setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"BasicScreenID"]) {
            [self.m_tfBasicScreenID setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"ScreenName"]) {
            [self.m_tfScreenName setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"Note"]) {
            [self.m_tfNote setStringValue:value];
        }
        
        if(!self.m_bCbBindScreenActiveFlag)
        {
            if (NSOrderedSame == [key compare:@"BindScreen"]) {
                NSDictionary * bindScreen = value;
                NSString * cur= bindScreen[@"Current"];
                NSMutableArray *arr = bindScreen[@"List"];
                [self.m_cbBindScreen setStringValue:cur];
                for (int i = 0; i < arr.count; i++)
                {
                    [self.m_cbBindScreen addItemWithObjectValue:arr[i]];
                }
            }
        }
        
        
        if (NSOrderedSame == [key compare:@"BindPage"]) {
            NSDictionary * bindPage = value;
            NSEnumerator * enumeratorBPKey = [bindPage keyEnumerator];
            
            int indexOfCkb = 0;
            for (NSObject *bpObj in enumeratorBPKey) {
                NSString *pageName = bpObj;
                NSString *CheckFlag = bindPage[bpObj];
                
                if(indexOfCkb < self.m_arrPageCheckBox.count)
                {
                    if(self.m_bBindTargetDisplayFlag)
                    {
                        [self.m_arrPageCheckBox[indexOfCkb] setHidden:false];
                    }
                    if (NSOrderedSame == [CheckFlag compare:@"0"]) {
                        [self.m_arrPageCheckBox[indexOfCkb] setCheckFlag:false];
                    }
                    else
                    {
                        [self.m_arrPageCheckBox[indexOfCkb] setCheckFlag:true];
                    }
                    [self.m_arrPageCheckBox[indexOfCkb] setText:pageName];
                }
                
                indexOfCkb++;
            }
        }
        
//        if (NSOrderedSame == [key compare:@"BindPage"]) {
//            NSDictionary * bindPage = value;
//            NSString * cur= bindPage[@"Current"];
//            NSMutableArray *arr = bindPage[@"List"];
//            [self.m_cbBindPage setStringValue:cur];
//            for (int i = 0; i < arr.count; i++)
//            {
//                [self.m_cbBindPage addItemWithObjectValue:arr[i]];
//            }
//        }
        
//        // ---
//        if (NSOrderedSame == [key compare:@"Bind"]) {
//            NSDictionary * dictBind = value;
//            NSString * curScreen = dictBind[@"CurrentScreen"];
//            NSString * curPage = dictBind[@"CurrentPage"];
//            NSDictionary * dictData = dictBind[@"Data"];
//
//            NSMutableArray * arrScreen = [NSMutableArray array];
//            NSMutableArray * arrPage = nil;
//
//            NSArray *keys = [dictData allKeys];
//            for (int i=0; i<keys.count; i++) {
//                NSString * key = keys[i];
//                [arrScreen addObject:key];
//                if (NSOrderedSame == [curScreen compare:key]) {
//                    arrPage = dictData[key];
//                }
//            }
////            NSEnumerator * enumeratordData = [dictData keyEnumerator];
////            for (NSObject *object in enumeratorKey) {
////                NSString *screen = object;
////                [arrScreen addObject:screen];
////                if (NSOrderedSame == [curScreen compare:screen]) {
////                    arrPage = dictData[object];
////                }
////            }
//
//            NSDictionary *dictBindRawData = dictBind[@"Data"];
//
//            [self.m_cbTarget setStringValue:curScreen];
//            for (int i = 0; i < arrScreen.count; i++)
//            {
//                [self.m_cbTarget addItemWithObjectValue:arrScreen[i]];
//            }
//
//            [self.m_cbPage setStringValue:curPage];
//            for (int i = 0; i < arrPage.count; i++)
//            {
//                [self.m_cbPage addItemWithObjectValue:arrPage[i]];
//            }
//
//            self.m_bindRawData = [[NSMutableDictionary alloc] initWithDictionary:dictData copyItems:YES];
//        }
    }
}
-(NSMutableDictionary*)getModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    NSString * sScreenID = [self.m_tfScreenID stringValue];
    if (sScreenID) {
        [modelData setObject:sScreenID forKey:@"ScreenID"];
    }
    NSString * sBasicScreenID = [self.m_tfBasicScreenID stringValue];
    if (sBasicScreenID) {
        [modelData setObject:sBasicScreenID forKey:@"BasicScreenID"];
    }
    NSString * sScreenName = [self.m_tfScreenName stringValue];
    if (sScreenName) {
        [modelData setObject:sScreenName forKey:@"ScreenName"];
    }
    NSString * sNote = [self.m_tfNote stringValue];
    if (sNote) {
        [modelData setObject:sNote forKey:@"Note"];
    }
    
    NSMutableDictionary * dictBindScreen = [NSMutableDictionary dictionary];
    {
        NSString * cur = [self.m_cbBindScreen stringValue];
        if (cur) {
            [dictBindScreen setObject:cur forKey:@"Current"];
        }
        NSMutableArray* arr = [[NSMutableArray alloc] initWithArray:[self.m_cbBindScreen objectValues] copyItems:YES];
        if (arr) {
            [dictBindScreen setObject:arr forKey:@"List"];
        }
    }
    [modelData setObject:dictBindScreen forKey:@"BindScreen"];
    
    NSMutableDictionary * dictBindPage = [NSMutableDictionary dictionary];
    {
         for (int i=0; i<self.m_arrPageCheckBox.count; i++) {
             if (![self.m_arrPageCheckBox[i] isHidden]) {
                 NSString * pageName = [self.m_arrPageCheckBox[i] getText];
                 bool bCheckFlg = [self.m_arrPageCheckBox[i] getCheckFlag];
                 NSString * sCheckFlg = [NSString stringWithFormat:@"%d", bCheckFlg];
                 [dictBindPage setObject:sCheckFlg forKey:pageName];
                 NSLog(@"Page:%@", pageName);
             }
         }
    }
    [modelData setObject:dictBindPage forKey:@"BindPage"];
    
//    NSMutableDictionary * dictBind = [NSMutableDictionary dictionary];
//    {
//        NSString * curScreen = [self.m_cbTarget stringValue];
//        [dictBind setObject:curScreen forKey:@"CurrentScreen"];
//        NSString * curPage = [self.m_cbPage stringValue];
//        [dictBind setObject:curPage forKey:@"CurrentPage"];
//        NSMutableDictionary * data = [[NSMutableDictionary alloc] initWithDictionary:self.m_bindRawData copyItems:true];
//        [dictBind setObject:data forKey:@"Data"];
//    }
//    [modelData setObject:dictBind forKey:@"Bind"];
    
    return modelData;
}

-(NSMutableDictionary*)getTestModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    [modelData setObject:@"scrID1" forKey:@"ScreenID"];
    [modelData setObject:@"base_scrID1" forKey:@"BasicScreenID"];
    [modelData setObject:@"scrID1-name" forKey:@"ScreenName"];
    [modelData setObject:@"xxx notes" forKey:@"Note"];
    
    NSMutableDictionary * dictBindScreen = [NSMutableDictionary dictionary];
    {
        [dictBindScreen setObject:@"testscreen1" forKey:@"Current"];
        
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        [arr addObject:@"testscreen1"];
        [arr addObject:@"testscreen2"];
        [arr addObject:@"testscreen3"];
        [dictBindScreen setObject:arr forKey:@"List"];
    }
    [modelData setObject:dictBindScreen forKey:@"BindScreen"];
    
    NSMutableDictionary * dictBindPage = [NSMutableDictionary dictionary];
    {
        [dictBindPage setObject:@"1" forKey:@"Page1"];
        [dictBindPage setObject:@"0" forKey:@"Page2"];
        [dictBindPage setObject:@"1" forKey:@"Page3"];
        [dictBindPage setObject:@"1" forKey:@"Page4"];
        [dictBindPage setObject:@"1" forKey:@"Page5"];
        [dictBindPage setObject:@"1" forKey:@"Page6"];
        [dictBindPage setObject:@"1" forKey:@"Page7"];
        [dictBindPage setObject:@"1" forKey:@"Page8"];
        [dictBindPage setObject:@"1" forKey:@"Page9"];
        [dictBindPage setObject:@"1" forKey:@"Page10"];
    }
    [modelData setObject:dictBindPage forKey:@"BindPage"];
    
//    NSMutableDictionary * bindData = [[NSMutableDictionary alloc] init];
//    [bindData setObject:@"TestScr1" forKey:@"CurrentScreen"];
//    [bindData setObject:@"TestPage1" forKey:@"CurrentPage"];
    
//    NSMutableArray * arrPages1 = [NSMutableArray array];
//    [arrPages1 addObject:@"TestPage1"];
//    [arrPages1 addObject:@"TestPage2"];
//    NSMutableArray * arrPages2 = [NSMutableArray array];
//    [arrPages2 addObject:@"TestPage3"];
//    [arrPages2 addObject:@"TestPage4"];
//    [arrPages2 addObject:@"TestPage5"];
//    NSMutableDictionary * rawData = [[NSMutableDictionary alloc] init];
//    [rawData setObject:arrPages1 forKey:@"TestScr1"];
//    [rawData setObject:arrPages2 forKey:@"TestScr2"];
//    [bindData setObject:rawData forKey:@"Data"];
//
//    [modelData setObject:bindData forKey:@"Bind"];

    return modelData;
}

-(void)setBindTargetDisplay:(bool)flag
{
    self.m_bBindTargetDisplayFlag = flag;
    if (flag) {
        [self.m_cbBindScreen setHidden:false];
        //[self.m_cbBindPage setHidden:false];
        [self.m_lbTar setHidden:false];
        [self.m_lbPage setHidden:false];
        for (int i=0; i<self.m_arrPageCheckBox.count; i++) {
            if([self.m_arrPageCheckBox[i] getCheckFlag])
            {
                [self.m_arrPageCheckBox[i] setHidden:false];
            }
        }
    }
    else {
        [self.m_cbBindScreen setHidden:true];
        //[self.m_cbBindPage setHidden:true];
        [self.m_lbTar setHidden:true];
        [self.m_lbPage setHidden:true];
        for (int i=0; i<self.m_arrPageCheckBox.count; i++) {
            [self.m_arrPageCheckBox[i] setHidden:true];
        }
    }
}

-(void)awakeFromNib
{
    [self init];
}

-(instancetype)init {
    self = [super init];
    
    int iViewH = 600;
    int iViewW = 200;
    
    [super setFrame:NSMakeRect(250,20,iViewW,iViewH)];
    [super setWantsLayer:YES];
    CALayer * layer = [super layer];
    NSColor * tstNSColor = [NSColor colorWithRed:0.92549 green:0.92549 blue:0.92549 alpha:1.0];
    [layer setBackgroundColor:[tstNSColor CGColor]];
    
    int heightNow = 0;
    NSColor * colSplitLine = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.33];
    NSColor * colSubTitle = [NSColor colorWithRed:0.35 green:0.35 blue:0.35 alpha:1];
    
    // title & btnsync
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Screen"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica-Bold" size:13]];
        [lbTitle setFrame:NSMakeRect(5,heightNow+4,iViewW,20)];
        [super addSubview:lbTitle];
        
        SButtonView * btnSync = [[SButtonView alloc] init];
        [btnSync setTitle:@"sync"];
        //[btnSync setButtonType:NSMomentaryChangeButton];
        [btnSync setFrame:NSMakeRect(iViewW-20,heightNow+5,16,16)];
        [btnSync setFont:[NSFont fontWithName:@"Arial" size:11]];
        NSBundle *bundle = [NSBundle bundleForClass:[SScreenInfoView class]];
        NSImage * image = [bundle imageForResource:@"save"];
        [btnSync setImage:image];
        NSImage * imagePush = [bundle imageForResource:@"save3"];
        [btnSync setPushDownImage:imagePush];
        [btnSync setBordered:false];
        [btnSync setImageScaling:NSImageScaleAxesIndependently];
        [super addSubview:btnSync];
        [btnSync setTarget:self];
        [btnSync setAction:@selector(onSaveButtonClick:)];
        self.m_btnSave = btnSync;
    }
    heightNow=heightNow + 25;
    
    // split line
    {
        NSView * splitLine = [[NSView alloc] init];
        [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
        [splitLine setWantsLayer:true];
        [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
        [super addSubview:splitLine];
    }
    heightNow=heightNow + 10;
    
    // Screen ID
    {
        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"Screen ID"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow+20;
        
        NSTextField * tfContent = [[NSTextField alloc] init];
        [tfContent setBezeled:false];
        [tfContent setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfContent setFrame:NSMakeRect(2,heightNow,iViewW-2,20)];
        [tfContent setWantsLayer:true];
        [[tfContent layer] setCornerRadius:5];
        [super addSubview:tfContent];
        self.m_tfScreenID = tfContent;
        heightNow=heightNow+20;
    }
    
    heightNow=heightNow+5;
    // Basic Screen ID
    {
        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"Basic Screen ID"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow+20;
        
        NSTextField * tfContent = [[NSTextField alloc] init];
        [tfContent setBezeled:false];
        [tfContent setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfContent setFrame:NSMakeRect(2,heightNow,iViewW-2,20)];
        [tfContent setWantsLayer:true];
        [[tfContent layer] setCornerRadius:5];
        [super addSubview:tfContent];
        self.m_tfBasicScreenID = tfContent;
        heightNow=heightNow+20;
    }
    
    heightNow=heightNow+5;
    // Screen Name
    {
        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"Screen Name"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow+20;
        
        NSTextField * tfContent = [[NSTextField alloc] init];
        [tfContent setBezeled:false];
        [tfContent setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfContent setFrame:NSMakeRect(2,heightNow,iViewW-2,20)];
        [tfContent setWantsLayer:true];
        [[tfContent layer] setCornerRadius:5];
        [super addSubview:tfContent];
        self.m_tfScreenName = tfContent;
        heightNow=heightNow+20;
    }
    
    heightNow=heightNow+5;
    // Note
    {
        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"Note"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow+20;
        
        NSTextField * tfContent = [[NSTextField alloc] init];
        [tfContent setBezeled:false];
        [tfContent setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfContent setFrame:NSMakeRect(2,heightNow,iViewW-2,60)];
        [tfContent setWantsLayer:true];
        [[tfContent layer] setCornerRadius:5];
        [super addSubview:tfContent];
        self.m_tfNote = tfContent;
        heightNow=heightNow+60;
    }
    
    heightNow=heightNow+15;
    
    // Choose Target & Page
    {
        
//        self.m_bindRawData = [[NSMutableDictionary alloc] init];
//        NSMutableArray * arrPages1 = [NSMutableArray array];
//        [arrPages1 addObject:@"page1"];
//        [arrPages1 addObject:@"page2"];
//        NSMutableArray * arrPages2 = [NSMutableArray array];
//        [arrPages2 addObject:@"pagex"];
//        [arrPages2 addObject:@"pagey"];
//        [arrPages2 addObject:@"pagez"];
//        [self.m_bindRawData setObject:arrPages1 forKey:@"scr1"];
//        [self.m_bindRawData setObject:arrPages2 forKey:@"scr2"];
        
        
        NSTextField * lbTar = [[NSTextField alloc] init];
        [lbTar setBezeled:false];
        [lbTar setStringValue:@"Bind Spec Screen"];
        [lbTar setSelectable:false];
        [lbTar setEditable:false];
        [lbTar setDrawsBackground:false];
        [lbTar setTextColor:colSubTitle];
        [lbTar setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbTar setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbTar];
        self.m_lbTar = lbTar;
        heightNow=heightNow+20;
        
        NSComboBox * cbTarget = [[NSComboBox alloc] init];
        [cbTarget setSelectable:false];
        [cbTarget setStringValue:@"scr1"];
        [cbTarget addItemWithObjectValue:@"scr1"];
        [cbTarget addItemWithObjectValue:@"scr2"];
        [cbTarget setFrame:NSMakeRect(0,heightNow,iViewW,25)];
        [super addSubview:cbTarget];
        self.m_cbBindScreen = cbTarget;
        heightNow=heightNow+25;
        self.m_bCbBindScreenActiveFlag = false;
        
        NSTextField * lbPage = [[NSTextField alloc] init];
        [lbPage setBezeled:false];
        [lbPage setStringValue:@"Bind Page"];
        [lbPage setSelectable:false];
        [lbPage setEditable:false];
        [lbPage setDrawsBackground:false];
        [lbPage setTextColor:colSubTitle];
        [lbPage setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbPage setFrame:NSMakeRect(0,heightNow,iViewW,20)];
        [super addSubview:lbPage];
        self.m_lbPage = lbPage;
        heightNow=heightNow+20;
        
//        NSComboBox * cbPage = [[NSComboBox alloc] init];
//        [cbPage setSelectable:false];
//        //cbTarget.usesDataSource = YES;
//        //cbTarget.dataSource = self;
//        //cbTarget.delegate = self;
//        [cbPage setStringValue:@"page1"];
//        [cbPage addItemWithObjectValue:@"page1"];
//        [cbPage addItemWithObjectValue:@"page2"];
//        [cbPage setFrame:NSMakeRect(0,heightNow,iViewW,25)];
//        [super addSubview:cbPage];
//        //self.m_cbBindPage = cbPage;
//        heightNow=heightNow+25;
        
        self.m_arrPageCheckBox = [NSMutableArray array];
        for (int i=0; i<10; i++) {
            SCheckBox * ckb = [[SCheckBox alloc] init];
            [ckb setHidden:true];
            [ckb setFrame:NSMakeRect(10,heightNow + i*25,iViewW-50,25)];
            [super addSubview:ckb];
            
            [self.m_arrPageCheckBox addObject:ckb];
        }
        
        
        self.m_cbBindScreen.delegate = self;
    }
    
    return self;
}

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    
    self.m_bCbBindScreenActiveFlag = true;

    NSComboBox *comboBox = notification.object;
//    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
//    //NSMutableArray* arr = [[NSMutableArray alloc] initWithArray:[comboBox objectValues] copyItems:YES];
//    NSMutableArray* arr = [comboBox objectValues];
//    NSString * sSelectScreen = arr[selectedIndex];
    
    NSString * sSelectScreen = [comboBox objectValueOfSelectedItem];
    //NSString * sSel = [[NSString alloc]initWithString:[comboBox objectValueOfSelectedItem]];
    if (nil != sSelectScreen) {
        NSLog(@"comboBoxSelectionDidChange selected item %@",sSelectScreen);
        
            if (self.m_delegate) {
                //NSString * strVal = [comboBox stringValue];
                [self.m_delegate onBindScreenChanged:sSelectScreen];
            }
        
    }
    
    
    //NSMutableArray * pageArr = nil;
    
//    [self.m_cbBindPage removeAllItems];[self.m_cbBindPage setStringValue:@""];
//    NSEnumerator * enumeratorKey = [self.m_bindRawData keyEnumerator];
//    for (NSObject *object in enumeratorKey) {
//        NSString *key = object;
//        NSObject *value = self.m_bindRawData[object];
//
//        if (NSOrderedSame == [key compare:sSelectScreen]) {
//            pageArr = value;
//        }
//    }
//
//    if (nil != pageArr) {
//        [self.m_cbPage setStringValue:pageArr[0]];
//        for (int i = 0; i < pageArr.count; i++)
//        {
//            [self.m_cbPage addItemWithObjectValue:pageArr[i]];
//        }
//    }
    

    
    self.m_bCbBindScreenActiveFlag = false;
}

-(void)onSaveButtonClick:(id)sender
{
    NSLog(@"onSaveButtonClick");
    if (self.m_delegate) {
        [self.m_delegate onSaveButtonClick];
    }
}

@end
