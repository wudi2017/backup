//
//  ScreenAdoptionView.m
//  sketchPluginFramework
//
//  Created by nb on 2017/2/2.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ScreenAdoptionView.h"

//*************************************************************************
@implementation SAComboBoxCell
- (id) init
{
    self = [super init];
    
    return self;
}
@end

//*************************************************************************
@implementation SATableView
- (id) init
{
    self = [super init];
    
    return self;
}
@end

//*************************************************************************
@implementation ScreenAdoptionViewDelegate
-(void)onSaveButtonClick
{
    
}
-(void)onCancelButtonClick
{
    
}
@end

//*************************************************************************
@implementation ScreenAdoptionView

+ (id) instance
{
    static ScreenAdoptionView *inst = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        inst = [[ScreenAdoptionView alloc] init];
    });
    return inst;
}

-(void)setModelData:(NSMutableDictionary*)modelData
{
    [self clearModelData];
    
    self.m_modelData = [[NSMutableDictionary alloc] initWithDictionary:modelData copyItems:YES];
    
    // UI
    NSString * sCurrent = nil;
    NSMutableDictionary * dictRegionType = [self.m_modelData objectForKey:@"Region"];
    if (dictRegionType) {
        sCurrent = dictRegionType[@"Current"];
        [self.m_cbRegon setStringValue:sCurrent];
        NSMutableArray *sList = dictRegionType[@"List"];
        for (int i = 0; i < sList.count; i++)
        {
            [self.m_cbRegon addItemWithObjectValue:sList[i]];
        }
    }
    
    NSMutableDictionary * showDataDict = [self.m_modelData objectForKey:sCurrent];
    if (showDataDict) {
        NSMutableDictionary * toyotaData = [showDataDict objectForKey:@"Toyota"];
        if (toyotaData) {
            NSMutableDictionary * tAvailableData = [toyotaData objectForKey:@"Available"];
            if (tAvailableData) {
                [self.m_tableDataToyota setObject:tAvailableData forKey:@"Available"];
            }
            NSMutableDictionary * tUnvailableData = [toyotaData objectForKey:@"Unavailable"];
            if (tUnvailableData) {
                [self.m_tableDataToyota setObject:tUnvailableData forKey:@"Unavailable"];
            }
        }
        NSMutableDictionary * lexusData = [showDataDict objectForKey:@"Lexus"];
        if (lexusData) {
            NSMutableDictionary * lAvailableData = [lexusData objectForKey:@"Available"];
            if (lAvailableData) {
                [self.m_tableDataLexus setObject:lAvailableData forKey:@"Available"];
            }
            NSMutableDictionary * lUnvailableData = [lexusData objectForKey:@"Unavailable"];
            if (lUnvailableData) {
                [self.m_tableDataLexus setObject:lUnvailableData forKey:@"Unavailable"];
            }
        }
    }
    else
    {
        NSMutableDictionary * newData = [NSMutableDictionary dictionary];
        [self.m_modelData setObject:newData forKey:sCurrent];
        
        NSMutableDictionary * Toyota = [NSMutableDictionary dictionary];
        [Toyota setObject:[NSMutableDictionary dictionary] forKey:@"Available"];
        [Toyota setObject:[NSMutableDictionary dictionary] forKey:@"Unavailable"];
        [newData setObject:Toyota forKey:@"Toyota"];
        
        NSMutableDictionary * Lexus = [NSMutableDictionary dictionary];
        [Lexus setObject:[NSMutableDictionary dictionary] forKey:@"Available"];
        [Lexus setObject:[NSMutableDictionary dictionary] forKey:@"Unavailable"];
        [newData setObject:Lexus forKey:@"Lexus"];
    }
}
-(NSMutableDictionary*)getModelData
{
    NSMutableDictionary * modelData = nil;
    
    modelData = [[NSMutableDictionary alloc] initWithDictionary:self.m_modelData copyItems:YES];
    
//    // region type
//    NSMutableDictionary * dictRegionType = [NSMutableDictionary dictionary];
//    {
//        NSString * sCurrent = [self.m_cbRegon stringValue];
//        if (sCurrent) {
//            [dictRegionType setObject:sCurrent forKey:@"Current"];
//        }
//        NSMutableArray* sList = [[NSMutableArray alloc] initWithArray:[self.m_cbRegon objectValues] copyItems:YES];
//        if (sList) {
//            [dictRegionType setObject:sList forKey:@"List"];
//        }
//    }
//    [modelData setObject:dictRegionType forKey:@"Region"];
//
//    // Toyota
//    NSMutableDictionary * toyotaData = [NSMutableDictionary dictionary];
//    NSMutableDictionary* tAvailableData = [[NSMutableDictionary alloc] initWithDictionary:[self.m_tableDataToyota objectForKey:@"Available"] copyItems:YES];
//    [toyotaData setObject:tAvailableData forKey:@"Available"];
//    NSMutableDictionary* tUnavailableData = [[NSMutableDictionary alloc] initWithDictionary:[self.m_tableDataToyota objectForKey:@"Unavailable"] copyItems:YES];
//    [toyotaData setObject:tUnavailableData forKey:@"Unavailable"];
//    [modelData setObject:toyotaData forKey:@"Toyota"];
//
//    // Lexus
//    NSMutableDictionary * lexusData = [NSMutableDictionary dictionary];
//    NSMutableDictionary* lAvailableData = [[NSMutableDictionary alloc] initWithDictionary:[self.m_tableDataLexus objectForKey:@"Available"] copyItems:YES];
//    [lexusData setObject:lAvailableData forKey:@"Available"];
//    NSMutableDictionary* lUnavailableData = [[NSMutableDictionary alloc] initWithDictionary:[self.m_tableDataLexus objectForKey:@"Unavailable"] copyItems:YES];
//    [lexusData setObject:lUnavailableData forKey:@"Unavailable"];
//    [modelData setObject:lexusData forKey:@"Lexus"];
    
    return modelData;
    
}
-(void)clearModelData
{
    [self.m_modelData removeAllObjects];
    
    // UI
    [self.m_cbRegon removeAllItems];[self.m_cbRegon setStringValue:@""];
    
    [self clearTable];
    [self.m_tableViewToyota reloadData];
    [self.m_tableViewLexus reloadData];
}
-(void) clearTable
{
    [self.m_tableDataToyota setObject:[NSMutableDictionary dictionary] forKey:@"Available"];
    NSMutableDictionary* tAvailableData = [self.m_tableDataToyota objectForKey:@"Available"];
    [tAvailableData setObject:@"Available" forKey:@"Ais"];
    [tAvailableData setObject:@"" forKey:@"Entry DA"];
    [tAvailableData setObject:@"" forKey:@"T1"];
    [tAvailableData setObject:@"" forKey:@"T2"];
    [tAvailableData setObject:@"" forKey:@"T-EMVN"];
    
    [self.m_tableDataToyota setObject:[NSMutableDictionary dictionary] forKey:@"Unavailable"];
    NSMutableDictionary* tUnvailableData = [self.m_tableDataToyota objectForKey:@"Unavailable"];
    [tUnvailableData setObject:@"Unvailable" forKey:@"Ais"];
    [tUnvailableData setObject:@"" forKey:@"Entry DA"];
    [tUnvailableData setObject:@"" forKey:@"T1"];
    [tUnvailableData setObject:@"" forKey:@"T2"];
    [tUnvailableData setObject:@"" forKey:@"T-EMVN"];
    
    [self.m_tableDataLexus setObject:[NSMutableDictionary dictionary] forKey:@"Available"];
    NSMutableDictionary* lAvailableData = [self.m_tableDataLexus objectForKey:@"Available"];
    [lAvailableData setObject:@"Available" forKey:@"Ais"];
    [lAvailableData setObject:@"" forKey:@"L1"];
    [lAvailableData setObject:@"" forKey:@"L1.5"];
    [lAvailableData setObject:@"" forKey:@"L2"];
    
    [self.m_tableDataLexus setObject:[NSMutableDictionary dictionary] forKey:@"Unavailable"];
    NSMutableDictionary* lUnvailableData = [self.m_tableDataLexus objectForKey:@"Unavailable"];
    [lUnvailableData setObject:@"Unavailable" forKey:@"Ais"];
    [lUnvailableData setObject:@"" forKey:@"L1"];
    [lUnvailableData setObject:@"" forKey:@"L1.5"];
    [lUnvailableData setObject:@"" forKey:@"L2"];
}
-(NSMutableDictionary*)getTestModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    NSMutableDictionary * region = [NSMutableDictionary dictionary];
    [region setObject:@"CN" forKey:@"Current"];
    NSMutableArray * arrListRegion = [NSMutableArray array];
    {
        [arrListRegion addObject:@""];
        [arrListRegion addObject:@"CN"];
        [arrListRegion addObject:@"JP"];
        [arrListRegion addObject:@"US"];
    }
    [region setObject:arrListRegion forKey:@"List"];
    [modelData setObject:region forKey:@"Region"];
    
    {
        NSMutableDictionary * CNData = [NSMutableDictionary dictionary];
        [modelData setObject:CNData forKey:@"CN"];
        
        NSMutableDictionary * toyota = [NSMutableDictionary dictionary];
        NSMutableDictionary * tAvailable = [NSMutableDictionary dictionary];
        [tAvailable setObject:@"X" forKey:@"T1"];
        [toyota setObject:tAvailable forKey:@"Available"];
        [CNData setObject:toyota forKey:@"Toyota"];
    }
    
    {
        NSMutableDictionary * JPData = [NSMutableDictionary dictionary];
        [modelData setObject:JPData forKey:@"JP"];
        
        NSMutableDictionary * toyota = [NSMutableDictionary dictionary];
        NSMutableDictionary * tAvailable = [NSMutableDictionary dictionary];
        [tAvailable setObject:@"-" forKey:@"T1"];
        [toyota setObject:tAvailable forKey:@"Available"];
        [JPData setObject:toyota forKey:@"Toyota"];
    }
    
     
    return modelData;
}

-(void)setDelegage:(ScreenAdoptionViewDelegate*)delegage
{
    self.m_delegate = delegage;
}

-(instancetype)init {
    self = [super init];

    int iViewH = 350;
    int iViewW = 600;

    [super setFrame:NSMakeRect(0,0,iViewW,iViewH)];
    [super setWantsLayer:YES];
//    CALayer * layer = [super layer];
//    NSColor * tstNSColor = [NSColor colorWithRed:0.92549 green:0.92549 blue:0.92549 alpha:1.0];//[NSColor colorWithRed:1 green:1 blue:0 alpha:1.0];//
//    [layer setBackgroundColor:[tstNSColor CGColor]];

    int heightNow = iViewH;
//    NSColor * colSplitLineTitle = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3];
//    NSColor * colSplitLine = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.1];
//    NSColor * colSubTitle = [NSColor colorWithRed:0.35 green:0.35 blue:0.35 alpha:1];

    // region lb & regon cb
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Region"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica-Bold" size:15]];
        [lbTitle setFrame:NSMakeRect(20,heightNow-45,100,25)];
        [super addSubview:lbTitle];
        
        NSComboBox * cbRegion = [[NSComboBox alloc] init];
        [cbRegion setSelectable:true];
        [cbRegion setSelectable:false];
        for (int i=0; i<5; i++) {
            [cbRegion addItemWithObjectValue:([NSString stringWithFormat:@"cbPartsType-%d", i])];
        }
        [cbRegion setFrame:NSMakeRect(120,heightNow-45,400,25)];
        [super addSubview:cbRegion];
        cbRegion.delegate = self;
        self.m_cbRegon = cbRegion;
    }
    heightNow=heightNow-40;
    
    
    NSComboBoxCell * cell = [[SAComboBoxCell alloc] init];
    //[cell setEditable:true];
    [cell addItemWithObjectValue:@"X"];
    [cell addItemWithObjectValue:@"-"];
    [cell addItemWithObjectValue:@""];
//    cell = [[NSTextFieldCell alloc] init];
//    [cell setEditable:true];
    
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Toyota"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica" size:15]];
        [lbTitle setFrame:NSMakeRect(20,heightNow-40,100,25)];
        [super addSubview:lbTitle];

        NSScrollView * scrollView    = [[NSScrollView alloc] init];
        //scrollView.hasVerticalScroller  = YES;
        [scrollView setFrame:NSMakeRect(20,heightNow-125,500,82)];
        [self addSubview:scrollView];

        SATableView * tableView = [[SATableView alloc] init];
        self.m_tableViewToyota = tableView;
        tableView.name = @"Toyota";
        [tableView setAllowsColumnSelection:true];
        [tableView setRowHeight:30];
        //[tableView setBackgroundColor:[NSColor colorWithRed:0 green:0 blue:0 alpha:0.3]];
        tableView.gridColor = [NSColor greenColor];
        [tableView setIntercellSpacing:NSMakeSize(0, -1)];
        scrollView.contentView.documentView = tableView;

        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"Ais"];
            [column setTitle:@"Ais"];
            [column setEditable:false];
            //[column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"Entry DA"];
            [column setTitle:@"Entry DA"];
            [column setEditable:true];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"T1"];
            [column setTitle:@"T1"];
            [column setEditable:true];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"T2"];
            [column setTitle:@"T2"];
            [column setEditable:true];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"T-EMVN"];
            [column setTitle:@"T-EMVN"];
            [column setEditable:true];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }

        tableView.delegate = self;
        tableView.dataSource = self;

        self.m_tableDataToyota = [NSMutableDictionary dictionary];

        NSMutableDictionary * AvailableObj = [NSMutableDictionary dictionary];
        [AvailableObj setObject:@"Available" forKey:@"Ais"];
        [AvailableObj setObject:@"" forKey:@"Entry DA"];
        [AvailableObj setObject:@"" forKey:@"T1"];
        [AvailableObj setObject:@"" forKey:@"T2"];
        [AvailableObj setObject:@"" forKey:@"T-EMVN"];
        [self.m_tableDataToyota setObject:AvailableObj forKey:@"Available"];

        NSMutableDictionary * UnavailableObj = [NSMutableDictionary dictionary];
        [UnavailableObj setObject:@"Unavailable" forKey:@"Ais"];
        [UnavailableObj setObject:@"" forKey:@"Entry DA"];
        [UnavailableObj setObject:@"" forKey:@"T1"];
        [UnavailableObj setObject:@"" forKey:@"T2"];
        [UnavailableObj setObject:@"" forKey:@"T-EMVN"];
        [self.m_tableDataToyota setObject:UnavailableObj forKey:@"Unavailable"];

        [tableView reloadData];
    }
    heightNow=heightNow-125;
    
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Lexus"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica" size:15]];
        [lbTitle setFrame:NSMakeRect(20,heightNow-40,100,25)];
        [super addSubview:lbTitle];
        
        NSScrollView * scrollView    = [[NSScrollView alloc] init];
        //scrollView.hasVerticalScroller  = YES;
        [scrollView setFrame:NSMakeRect(20,heightNow-125,500,82)];
        [self addSubview:scrollView];
        
        SATableView * tableView = [[SATableView alloc] init];
        self.m_tableViewLexus = tableView;
        tableView.name = @"Lexus";
        //[tableView setAllowsColumnSelection:true];
        [tableView setRowHeight:30];
        //[tableView setBackgroundColor:[NSColor colorWithRed:0 green:0 blue:0 alpha:0.3]];
        tableView.gridColor = [NSColor greenColor];
        [tableView setIntercellSpacing:NSMakeSize(0, -1)];
        scrollView.contentView.documentView = tableView;
        
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"Ais"];
            [column setTitle:@"Ais"];
            [column setEditable:true];
            [column setWidth:125];
            //[column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"L1"];
            [column setTitle:@"L1"];
            [column setEditable:true];
            [column setWidth:125];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"L1.5"];
            [column setTitle:@"L1.5"];
            [column setEditable:true];
            [column setWidth:125];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        {
            NSTableColumn * column = [[NSTableColumn alloc]initWithIdentifier:@"L2"];
            [column setTitle:@"L2"];
            [column setEditable:true];
            [column setWidth:125];
            [column setDataCell:cell];
            [tableView addTableColumn:column];
        }
        
        tableView.delegate = self;
        tableView.dataSource = self;
        
        self.m_tableDataLexus = [NSMutableDictionary dictionary];
        
        NSMutableDictionary * AvailableObj = [NSMutableDictionary dictionary];
        [AvailableObj setObject:@"Available" forKey:@"Ais"];
        [AvailableObj setObject:@"" forKey:@"L1"];
        [AvailableObj setObject:@"" forKey:@"L1.5"];
        [AvailableObj setObject:@"" forKey:@"L2"];
        [self.m_tableDataLexus setObject:AvailableObj forKey:@"Available"];
        
        NSMutableDictionary * UnavailableObj = [NSMutableDictionary dictionary];
        [UnavailableObj setObject:@"Unavailable" forKey:@"Ais"];
        [UnavailableObj setObject:@"" forKey:@"L1"];
        [UnavailableObj setObject:@"" forKey:@"L1.5"];
        [UnavailableObj setObject:@"" forKey:@"L2"];
        [self.m_tableDataLexus setObject:UnavailableObj forKey:@"Unavailable"];
        
        [tableView reloadData];
    }
    heightNow=heightNow-125;

    
    NSButton * saveBtn = [[NSButton alloc] init];
    [saveBtn setTitle:@"Save"];
    [saveBtn setFrame:NSMakeRect(310,heightNow-40,100,25)];
    [saveBtn setTarget:self];
    [saveBtn setAction:@selector(onSaveButtonClick:)];
    [super addSubview:saveBtn];
    
    NSButton * cancelBtn = [[NSButton alloc] init];
    [cancelBtn setTitle:@"Cancel"];
    [cancelBtn setFrame:NSMakeRect(420,heightNow-40,100,25)];
    [cancelBtn setTarget:self];
    [cancelBtn setAction:@selector(onCancelButtonClick:)];
    [super addSubview:cancelBtn];
    
    return self;
}

-(void)onSaveButtonClick:(id)sender
{
    NSButton * btnSele = sender;
    NSString * btnTitle = [btnSele title];
    NSLog(@"%@-Btn clicked!", btnTitle);
    if (self.m_delegate) {
        [self.m_delegate onSaveButtonClick];
    }
}

-(void)onCancelButtonClick:(id)sender
{
    NSButton * btnSele = sender;
    NSString * btnTitle = [btnSele title];
    NSLog(@"%@-Btn clicked!", btnTitle);
    if (self.m_delegate) {
        [self.m_delegate onCancelButtonClick];
    }
}

-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    NSInteger returnCount = 0;
    SATableView * table = (SATableView *)tableView;
    if ([table.name isEqualToString:@"Toyota"]) {
        returnCount=[[[self.m_tableDataToyota keyEnumerator] allObjects] count];
    }
    if ([table.name isEqualToString:@"Lexus"]) {
        returnCount=[[[self.m_tableDataLexus keyEnumerator] allObjects] count];
    }
    return returnCount;
}
-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row{
    
    [[tableColumn dataCell] setDrawsBackground: YES];
    
    NSString* colID = [tableColumn identifier];
    
    if([colID isEqualToString:@"Ais"])
    {
        if (0 == row) {
            return @"Available";
        }
        if (1 == row) {
            return @"Unvailable";
        }
    }
    
    NSString * retStr = [NSString stringWithFormat:@"%d-%d", row, row];
    SATableView * table = (SATableView *)tableView;
    if ([table.name isEqualToString:@"Toyota"]) {
        if (0 == row) {
            retStr = [[self.m_tableDataToyota objectForKey:@"Available"] objectForKey:colID];
        }
        if (1 == row) {
            retStr = [[self.m_tableDataToyota objectForKey:@"Unavailable"] objectForKey:colID];
        }
    }
    if ([table.name isEqualToString:@"Lexus"]) {
        if (0 == row) {
            retStr = [[self.m_tableDataLexus objectForKey:@"Available"] objectForKey:colID];
        }
        if (1 == row) {
            retStr = [[self.m_tableDataLexus objectForKey:@"Unavailable"] objectForKey:colID];
        }
    }
    //str = [self.m_tableData objectAtIndex:row];
    return retStr;
}


-(void)tableView:(NSTableView*)tableView setObjectValue:(nullable id)object forTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row
{
    SATableView * table = (SATableView *)tableView;
    NSString* colID = [tableColumn identifier];
    
    // model update
    NSString * sCurrent = [self.m_cbRegon stringValue];
    NSMutableDictionary * RegionData = [self.m_modelData objectForKey:sCurrent];
    if (RegionData) {
        NSMutableDictionary * toyota = [RegionData objectForKey:@"Toyota"];
        NSMutableDictionary * tAvailable = [toyota objectForKey:@"Available"];
        NSMutableDictionary * tUnavailable = [toyota objectForKey:@"Unavailable"];
        NSMutableDictionary * lexus = [RegionData objectForKey:@"Lexus"];
        NSMutableDictionary * lAvailable = [lexus objectForKey:@"Available"];
        NSMutableDictionary * lUnavailable = [lexus objectForKey:@"Unavailable"];
        if ([table.name isEqualToString:@"Toyota"]) {
            if (0 == row) {
                [tAvailable setObject:object forKey:colID];
            }
            if (1 == row) {
                [tUnavailable setObject:object forKey:colID];
            }
        }
        if ([table.name isEqualToString:@"Lexus"]) {
            if (0 == row) {
                [lAvailable setObject:object forKey:colID];
            }
            if (1 == row) {
                [lUnavailable setObject:object forKey:colID];
            }
        }
    }
    
    // UI update
    if ([table.name isEqualToString:@"Toyota"]) {
        if (0 == row) {
            [[self.m_tableDataToyota objectForKey:@"Available"] setObject:object forKey:colID];
        }
        if (1 == row) {
            [[self.m_tableDataToyota objectForKey:@"Unavailable"] setObject:object forKey:colID];
        }
    }
    if ([table.name isEqualToString:@"Lexus"]) {
        if (0 == row) {
            [[self.m_tableDataLexus objectForKey:@"Available"] setObject:object forKey:colID];
        }
        if (1 == row) {
            [[self.m_tableDataLexus objectForKey:@"Unavailable"] setObject:object forKey:colID];
        }
    }
    //[self.m_tableData replaceObjectAtIndex:0 withObject:object];
}

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    
    NSComboBox *comboBox = notification.object;
    NSString * sSelection = [comboBox objectValueOfSelectedItem];
    
    [self clearTable];
    
    if (sSelection) {
        NSMutableDictionary * showDataDict = [self.m_modelData objectForKey:sSelection];
        if (!showDataDict) {
            NSMutableDictionary * newData = [NSMutableDictionary dictionary];
            [self.m_modelData setObject:newData forKey:sSelection];
            
            NSMutableDictionary * Toyota = [NSMutableDictionary dictionary];
            [Toyota setObject:[NSMutableDictionary dictionary] forKey:@"Available"];
            [Toyota setObject:[NSMutableDictionary dictionary] forKey:@"Unavailable"];
            [newData setObject:Toyota forKey:@"Toyota"];
            
            NSMutableDictionary * Lexus = [NSMutableDictionary dictionary];
            [Lexus setObject:[NSMutableDictionary dictionary] forKey:@"Available"];
            [Lexus setObject:[NSMutableDictionary dictionary] forKey:@"Unavailable"];
            [newData setObject:Lexus forKey:@"Lexus"];
            
            showDataDict = newData;
        }
        if (showDataDict) {
            NSMutableDictionary * toyotaData = [showDataDict objectForKey:@"Toyota"];
            if (toyotaData) {
                NSMutableDictionary * tAvailableData = [toyotaData objectForKey:@"Available"];
                if (tAvailableData) {
                    [self.m_tableDataToyota setObject:tAvailableData forKey:@"Available"];
                }
                NSMutableDictionary * tUnvailableData = [toyotaData objectForKey:@"Unavailable"];
                if (tUnvailableData) {
                    [self.m_tableDataToyota setObject:tUnvailableData forKey:@"Unavailable"];
                }
            }
            NSMutableDictionary * lexusData = [showDataDict objectForKey:@"Lexus"];
            if (lexusData) {
                NSMutableDictionary * lAvailableData = [lexusData objectForKey:@"Available"];
                if (lAvailableData) {
                    [self.m_tableDataLexus setObject:lAvailableData forKey:@"Available"];
                }
                NSMutableDictionary * lUnvailableData = [lexusData objectForKey:@"Unavailable"];
                if (lUnvailableData) {
                    [self.m_tableDataLexus setObject:lUnvailableData forKey:@"Unavailable"];
                }
            }
        }
    }
    
    // reset table
    [self.m_tableViewToyota reloadData];
    [self.m_tableViewLexus reloadData];
    
}

//-(BOOL)selectionShouldChangeInTableView:(NSTableView*)tableView
//{
//    return true;
//}
//
//-(BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row
//{
//    return true;
//}
//
//-(void)tableViewSelectionDidChange:(nonnull NSNotification *)notification{
//
//    NSTableView* tableView = notification.object;
//    NSLog(@"tableViewSelectionDidChange: %@", notification.userInfo);
//    //[super tableViewSelectionDidChange:notification];
//}
//
//-(void)tableViewSelectionIsChanging:(nonnull NSNotification *)notification{
//
//    NSLog(@"tableViewSelectionIsChanging: %@", notification.userInfo);
//}



@end
