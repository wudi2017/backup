//
//  SIAUTOMainView.h
//  TMNAFramework
//
//  Created by nb on 2018/12/18.
//

#ifndef SIAUTOMainView_h
#define SIAUTOMainView_h

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>

#import "SPartsInfoView.h"

@interface SIAUTOMainView : NSScrollView

+(id)instance;

-(instancetype)init;
-(void)showPartsInfoView;
-(NSView*)getPartsInfoView;

@property SPartsInfoView* m_partsInfoView;

@end

#endif /* SIAUTOMainView_h */
