//
//  ScreenInfoView.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/21.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef ScreenInfoView_h
#define ScreenInfoView_h

#import <Cocoa/Cocoa.h>

#import "SConPaneView.h"

@interface SPartsInfoViewDelegate : NSObject
-(void)onSaveButtonClick;
@end

@interface SPartsInfoView : NSView

-(instancetype)init;

-(void)setModelData:(NSMutableDictionary*)modelData;
-(NSMutableDictionary*)getModelData;
-(void)clearModelData;
-(NSMutableDictionary*)getTestModelData;
-(void)setDelegage:(SPartsInfoViewDelegate*)delegage;

@property NSTextField * m_tfPartsID;
@property NSComboBox * m_cbPartsType;
@property NSTextField * m_tfName;

@property NSComboBox * m_cbCon;
@property SConPaneView * m_SCPVCurrent;
@property SConPaneView * m_SCPVDisplay;
@property SConPaneView * m_SCPVSWSelect;
@property SConPaneView * m_SCPVSWToneDownMotion;
@property SConPaneView * m_SCPVSWToneDownExceptInMotion;
@property SConPaneView * m_SCPVTextOrImageDeleteInMotion;
@property NSArray * conditionsList;
@property NSArray * conditionsViews;

@property NSTextField * m_tfJPWords;
@property NSTextField * m_tfJPFixedWords;
@property NSTextField * m_tfJPVRWords;
@property NSTextField * m_tfUSWords;
@property NSTextField * m_tfUSFixedWords;
@property NSTextField * m_tfUSVRWords;
@property NSTextField * m_tfUKWords;
@property NSTextField * m_tfUKFixedWords;
@property NSTextField * m_tfUKVRWords;

@property NSTextField * m_tfDisplayContent;
@property NSTextField * m_tfFormat;
@property NSTextField * m_tfRange;
@property NSTextField * m_tfValidation;

@property NSComboBox * m_cbSWOpePattern;
@property NSTextField * m_tfSWOpeResScreenTransition;
@property NSTextField * m_tfSWOpeResStartFunction;
@property NSTextField * m_tfSWOpeResSetValChange;
@property NSTextField * m_tfSWOpeResOther;

@property NSComboBox * m_cbBeep;

@property SPartsInfoViewDelegate * m_delegate;

@end

/*
model data (NSMutableDictionary NSMutableArray)
 
modelData =
{
    "PartsID": "xx"
    "PartsType":
     {
        "Current":"type1",
        "List":["type1","type2"]
     }
    "PartsName":"Name"
 
    "Conditions":
    {
        "Display":{
            "A":"xxx1",
            "B":"xxx1",
            "C":"xxx1",
             "Formula":"xx",
             "SamePartsID":"xx",
             "SameScreenID:"xx",
             "Else":"xx"
         },
        "TextOrImageDeleteInMotion":{
        },
        "SWToneDownMotion":{
         },
        "SWToneDownExceptInMotion":{
        },
        "SWSelect":{
        },
    }
 
    "JPWords":""
    "JPFixedWords":""
    "JPVRWords":""
    "USWords":""
    "USFixedWords":""
    "USVRWords":""
    "UKWords":""
    "UKFixedWords":""
    "UKVRWords":""
 
    "DisplayContent":""
    "Format":""
    "Range":""
    "Validation":""
 
    "SWOpePattern":
     {
        "Current":"op1",
        "List":["op1","op2"]
     }
    "SWOpeResScreenTransition":"xx"
    "SWOpeResStartFunction":"xx"
    "SWOpeResSetValChange":"xx"
    "SWOpeResOther":"xx"
 
     "Beep":
     {
         "Current":"op1",
         "List":["op1","op2"]
     }
}
 
 */
#endif /* ScreenInfoView_h */
