//
//  SIAUTOMainView.m
//  TMNAFramework
//
//  Created by nb on 2018/12/18.
//

#import <Foundation/Foundation.h>

#import "SIAUTOMainView.h"

@implementation SIAUTOMainView

+(id)instance
{
    static SIAUTOMainView *inst = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        inst = [[SIAUTOMainView alloc] init];
    });
    return inst;
}

-(instancetype)init
{
    self = [super init];

    [self setHasVerticalScroller:YES];
    //[self setHasHorizontalScroller:YES];
    [self setFrame:NSMakeRect(0, 0, 205, 800)];
    
    SPartsInfoView * partsInfoView = [[SPartsInfoView alloc] init];
    //[partsInfoView setFrame:NSMakeRect(0, 0, 200, )];
    [self setDocumentView:partsInfoView];
    
    return self;
}

-(NSView*)getPartsInfoView
{
    return self.m_partsInfoView;
}
-(void)showPartsInfoView
{
    
}

@end
