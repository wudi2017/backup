//
//  SCheckBox.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/29.
//  Copyright © 2018年 iauto. All rights reserved.
//

#include "SCheckBox.h"

@implementation SCheckBoxDelegate
-(void)onClick:(bool)bCheck
{
    
}
@end

@implementation SCheckBox
-(void)setDelegage:(SCheckBoxDelegate*)delegage
{
    self.m_delegate = delegage;
}

-(instancetype)init {
    self = [super init];
    
    int iViewH = 100;
    int iViewW = 100;
    
    NSColor * colSubTitle = [NSColor colorWithRed:0.35 green:0.35 blue:0.35 alpha:1];
    
    self.m_bCheckFlag = false;
    
    [super setFrame:NSMakeRect(0,0,iViewW,iViewH)];
    [super setWantsLayer:YES];
    CALayer * layer = [super layer];
    NSColor * tstNSColor = [NSColor colorWithRed:1.0 green:0 blue:0 alpha:0.0];
    [layer setBackgroundColor:[tstNSColor CGColor]];
    
    NSButton * btnCheckBox = [[NSButton alloc] init];
    [btnCheckBox setFrame:NSMakeRect(3,3,18,18)];
    NSBundle *bundle = [NSBundle bundleForClass:[SCheckBox class]];
    NSImage * image0 = [bundle imageForResource:@"Checkbox@2x"];
    NSImage * image1 = [bundle imageForResource:@"Checkbox_S"];
    [btnCheckBox setImage:image0];
    [btnCheckBox setBordered:false];
    [[btnCheckBox cell] setImageScaling:NSImageScaleAxesIndependently];
    [btnCheckBox setTarget:self];
    [btnCheckBox setAction:@selector(onSaveButtonClick:)];
    [self addSubview:btnCheckBox];
    self.m_btnCheckBox = btnCheckBox;
    self.m_image0 = image0;
    self.m_image1 = image1;
    
    NSTextField * tfLBText = [[NSTextField alloc] init];
    [tfLBText setBezeled:false];
    [tfLBText setDrawsBackground:false];
    [tfLBText setEditable:false];
    [tfLBText setSelectable:false];
    [tfLBText setStringValue:@"default"];
    [tfLBText setFont:[NSFont fontWithName:@"Arial" size:12]];
    [tfLBText setTextColor:colSubTitle];
    //[tfLBText setAlignment:NSCenterTextAlignment];
    [tfLBText setFrame:NSMakeRect(25,2,100,20)];
    [self addSubview:tfLBText];
    self.m_tfLBText = tfLBText;
    
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    int iViewW = frame.size.width;
    int iViewH = frame.size.height;
    [self.m_tfLBText setFrame:NSMakeRect(25,2,iViewW-25,20)];
}

- (void)setCheckFlag:(bool)bCheck
{
    NSLog(@"setCheckFlag");
    self.m_bCheckFlag = bCheck;
    if (self.m_bCheckFlag) {
        [self.m_btnCheckBox setImage:self.m_image1];
        NSLog(@"  Flag=1");
    }
    else
    {
        [self.m_btnCheckBox setImage:self.m_image0];
        NSLog(@"  Flag=0");
    }
}

- (bool)getCheckFlag
{
    return self.m_bCheckFlag;
}

- (void)setText:(NSString *)text
{
    [self.m_tfLBText setStringValue:text];
}

- (NSString*)getText
{
    return [self.m_tfLBText stringValue];
}

-(void)onSaveButtonClick:(id)sender
{
    NSLog(@"onSaveButtonClick");
    [self setCheckFlag:!self.m_bCheckFlag];
    
    if(self.m_delegate)
    {
        [self.m_delegate onClick:self.m_bCheckFlag];
    }
}

@end
