//
//  SScreenInfoView.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/22.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef SScreenInfoView_h
#define SScreenInfoView_h

#import <Cocoa/Cocoa.h>

@interface SScreenInfoViewDelegate : NSObject
-(void)onBindScreenChanged:(NSString*)currentText;
-(void)onSaveButtonClick;
@end

@interface SScreenInfoView : NSView

-(instancetype)init;
-(void)setModelData:(NSMutableDictionary*)modelData;
-(NSMutableDictionary*)getModelData;
-(void)clearModelData;
-(NSMutableDictionary*)getTestModelData;
-(void)setBindTargetDisplay:(bool)flag;
-(void)setDelegage:(SScreenInfoViewDelegate*)delegage;

@property NSButton * m_btnSave;
@property NSTextField * m_tfScreenID;
@property NSTextField * m_tfBasicScreenID;
@property NSTextField * m_tfScreenName;
@property NSTextField * m_tfNote;

@property bool m_bBindTargetDisplayFlag;
@property NSTextField * m_lbTar;
@property NSComboBox * m_cbBindScreen;
@property bool * m_bCbBindScreenActiveFlag;

@property NSTextField * m_lbPage;
@property NSMutableArray* m_arrPageCheckBox;

@property SScreenInfoViewDelegate * m_delegate;

/*
 model data (NSMutableDictionary NSMutableArray)
 
 modelData =
 {
    "ScreenID":"xx"
    "BasicScreenID":"xx"
    "ScreenName":"xx"
    "Note":"xx"
     "BindScreen":
     {
         "Current":"screen1",
         "List":["screen1","screen2"]
     }
     "BindPage":
     {
         "Page1":"1",
         "Page2":"0"
         "Page3":"1"
     }
 }
 
*/

@end

#endif /* SScreenInfoView_h */
