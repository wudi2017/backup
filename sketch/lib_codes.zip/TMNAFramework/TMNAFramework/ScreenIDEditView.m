//
//  ScreenIDEditView.m
//  TestTMNAFrameworkApp
//
//  Created by nb on 2017/11/28.
//  Copyright © 2017年 nb. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ScreenIDEditView.h"

//*************************************************************************
@implementation ScreenIDEditViewDelegate
-(void)onSaveButtonClick
{
    
}
-(void)onCancelButtonClick
{
    
}
@end

//*************************************************************************
@implementation ScreenIDEditView

+ (id) instance
{
    static ScreenIDEditView *inst = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        inst = [[ScreenIDEditView alloc] init];
    });
    return inst;
}

-(void)setModelData:(NSMutableDictionary*)modelData
{
    [self clearModelData];
    
    //self.m_modelData = [[NSMutableDictionary alloc] initWithDictionary:modelData copyItems:YES];
    self.m_modelData = [modelData mutableCopy];
    // UI
    // Func
    {
        NSString * sCurrent = nil;
        NSMutableDictionary * dictCBData = [self.m_modelData objectForKey:@"Func"];
        if (dictCBData) {
            sCurrent = dictCBData[@"Current"];
            [self.m_cbFunc setStringValue:sCurrent];
            NSMutableArray *sList = dictCBData[@"List"];
            for (int i = 0; i < sList.count; i++)
            {
                NSString * itemVal = [NSString stringWithString:sList[i]];
                [self.m_cbFunc addItemWithObjectValue:itemVal];
            }
            [self.m_cbFunc setStringValue:sCurrent];
            NSString* sEnable = dictCBData[@"Enable"];
            [self.m_cbFunc setEnabled:true];
            if (sEnable) {
                if ([sEnable isEqualToString:@"0"]) {
                    [self.m_cbFunc setEnabled:false];
                }
            }
        }
    }
    // Region
    {
        NSString * sCurrent = nil;
        NSMutableDictionary * dictCBData = [self.m_modelData objectForKey:@"Region"];
        if (dictCBData) {
            sCurrent = dictCBData[@"Current"];
            [self.m_cbRegon setStringValue:sCurrent];
            NSMutableArray *sList = dictCBData[@"List"];
            for (int i = 0; i < sList.count; i++)
            {
                NSString * itemVal = [NSString stringWithString:sList[i]];
                [self.m_cbRegon addItemWithObjectValue:itemVal];
            }
            [self.m_cbRegon setStringValue:sCurrent];
            [self.m_cbRegon setEnabled:true];
            NSString* sEnable = dictCBData[@"Enable"];
            if (sEnable) {
                if ([sEnable isEqualToString:@"0"]) {
                    [self.m_cbRegon setEnabled:false];
                }
            }
            
            [self.m_tfRegon setStringValue:sCurrent];
        }
    }
    // ArtboardValue
    {
        NSString * sCurrent = [self.m_modelData objectForKey:@"ArtboardVal"];
        if (sCurrent) {
            [self.m_tfArtboardVal setStringValue:sCurrent];
        }
    }
    
    [self updateDisplayScreenID:@"" ChangedVal:@""];
}

- (void) updateDisplayScreenID: (NSString*)cbID ChangedVal:(NSString*)changedVal
{
    // preview
    NSString * display = @"";
    {
        NSString * sFunc = [self.m_cbFunc stringValue];
        if ([cbID isEqualToString:@"Func"]) {
            sFunc = changedVal;
        }
        NSString * sRegionStr = [self.m_cbRegon stringValue];
        if ([cbID isEqualToString:@"Region"]) {
            sRegionStr = changedVal;
        }
        NSString * sFuncCodeStr = [self getFuncCodeString:sFunc];
        NSString * sRegionCodeStr = [self getRegionCodeString:sRegionStr];
        NSString * sArtboardVal = [self.m_tfArtboardVal stringValue];

        display = [NSString stringWithFormat:@"%@.%@.%@",sFuncCodeStr,sRegionCodeStr,sArtboardVal];
        display = [NSString stringWithFormat:@"%@.%@.****",sFuncCodeStr,sRegionCodeStr];
        [self.m_tfDisplayScreenID setStringValue:display];
    }

    // update modeldata
    if (self.m_modelData) {
        [self.m_modelData setObject:display forKey:@"PreviewScreenID"];
    }
}
-(NSMutableDictionary*)getModelData
{
   // NSMutableDictionary * modelData = [[NSMutableDictionary alloc] initWithDictionary:self.m_modelData copyItems:YES];
    NSMutableDictionary * modelData = [self.m_modelData mutableCopy];
    if (modelData) {
        NSMutableDictionary* funcDic = [modelData objectForKey:@"Func"];
        if (funcDic) {
            NSString * curFunc = [self.m_cbFunc stringValue];
            [funcDic setObject:curFunc forKey:@"Current"];
        }
        NSMutableDictionary* regionDic = [modelData objectForKey:@"Region"];
        if (regionDic) {
            NSString * curRegion = [self.m_cbRegon stringValue];
            [regionDic setObject:curRegion forKey:@"Current"];
        }
    }
    return modelData;
}
-(void)clearModelData
{
    // UI
    [self.m_cbFunc setStringValue:@""];
    if([self.m_cbFunc numberOfItems] > 0)
    {
        [self.m_cbFunc removeAllItems];
    }
    
    [self.m_cbRegon setStringValue:@""];
    if([self.m_cbRegon numberOfItems] > 0)
    {
        [self.m_cbRegon removeAllItems];
    }

    [self.m_tfArtboardVal setStringValue:@""];

    [self.m_modelData removeAllObjects];
}

-(NSMutableDictionary*)getTestModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    {
        NSMutableDictionary * cbData = [NSMutableDictionary dictionary];
        [cbData setObject:@"setting01" forKey:@"Current"];
        NSMutableArray * arrListCB = [NSMutableArray array];
        [arrListCB addObject:@"smartphone cooperation coopereation"];
        [arrListCB addObject:@"setting02"];
        [arrListCB addObject:@"setting03"];
        [arrListCB addObject:@"setting04"];
        [arrListCB addObject:@"setting05"];
        [arrListCB addObject:@"setting06"];
        [arrListCB addObject:@"setting07"];
        [arrListCB addObject:@"setting08"];
        [arrListCB addObject:@"setting09"];
        [arrListCB addObject:@"setting10"];
        [cbData setObject:arrListCB forKey:@"List"];
        [modelData setObject:cbData forKey:@"Func"];
    }
    {
        NSMutableDictionary * cbData = [NSMutableDictionary dictionary];
        [cbData setObject:@"S1" forKey:@"setting01"];
        [cbData setObject:@"S2" forKey:@"setting02"];
        [cbData setObject:@"S3" forKey:@"setting03"];
        [cbData setObject:@"S4" forKey:@"setting04"];
        [cbData setObject:@"S5" forKey:@"setting05"];
        [cbData setObject:@"S6" forKey:@"setting06"];
        [cbData setObject:@"S7" forKey:@"setting07"];
        [cbData setObject:@"S8" forKey:@"setting08"];
        [cbData setObject:@"S9" forKey:@"setting09"];
        [cbData setObject:@"S10" forKey:@"setting10"];
        [modelData setObject:cbData forKey:@"FuncMap"];
    }
    
    {
        NSMutableDictionary * cbData = [NSMutableDictionary dictionary];
        [cbData setObject:@"CN" forKey:@"Current"];
        NSMutableArray * arrListCB = [NSMutableArray array];
        [arrListCB addObject:@""];
        [arrListCB addObject:@"CN"];
        [arrListCB addObject:@"JP"];
        [arrListCB addObject:@"US"];
        [arrListCB addObject:@"KO"];
        [arrListCB addObject:@"UK"];
        [arrListCB addObject:@"ID"];
        [cbData setObject:arrListCB forKey:@"List"];
        [modelData setObject:cbData forKey:@"Region"];
        [cbData setObject:@"0" forKey:@"Enable"];
    }
    {
        NSMutableDictionary * cbData = [NSMutableDictionary dictionary];
        [cbData setObject:[NSNumber numberWithInt:100] forKey:@"CN"];
        [cbData setObject:[NSNumber numberWithInt:101] forKey:@"JP"];
        [cbData setObject:[NSNumber numberWithInt:102] forKey:@"US"];
        [cbData setObject:[NSNumber numberWithInt:103] forKey:@"KO"];
        [cbData setObject:[NSNumber numberWithInt:104] forKey:@"UK"];
        [cbData setObject:[NSNumber numberWithInt:105] forKey:@"ID"];
        [modelData setObject:cbData forKey:@"RegionMap"];
    }
    
    [modelData setObject:@"24BCD" forKey:@"ArtboardVal"];

    return modelData;
}

- (NSString*)getRegionCodeString:(NSString*)regionStr
{
    NSNumber * code = [NSNumber numberWithInt:0];
    if (self.m_modelData && [self.m_modelData objectForKey:@"RegionMap"]) {
        NSMutableDictionary * regionMap = [self.m_modelData objectForKey:@"RegionMap"];
        code = [regionMap objectForKey:regionStr];
    }
    
    NSString * codeStr = [NSString stringWithFormat:@"%d", [code integerValue]];
    return codeStr;
}
- (NSString*)getFuncCodeString:(NSString*)FuncStr
{
    NSString * FuncCode = @"";
    if (self.m_modelData && [self.m_modelData objectForKey:@"FuncMap"]) {
        NSMutableDictionary * funcMap = [self.m_modelData objectForKey:@"FuncMap"];
        FuncCode = [funcMap objectForKey:FuncStr];
    }
    return FuncCode;
}

-(instancetype)init {
    self = [super init];
    
    int iViewH = 180;
    int iViewW = 540;
    
    [super setFrame:NSMakeRect(0,0,iViewW,iViewH)];
    [super setWantsLayer:YES];
    //CALayer * layer = [super layer];
    //NSColor * tstNSColor = [NSColor colorWithRed:0.92549 green:0.92549 blue:0.92549 alpha:1.0];//[NSColor colorWithRed:1 green:1 blue:0 alpha:1.0];//
    //[layer setBackgroundColor:[tstNSColor CGColor]];
    
    int heightNow = iViewH;
    //    NSColor * colSplitLineTitle = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3];
    //    NSColor * colSplitLine = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.1];
    //    NSColor * colSubTitle = [NSColor colorWithRed:0.35 green:0.35 blue:0.35 alpha:1];
    
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Function"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica" size:15]];
        [lbTitle setFrame:NSMakeRect(20,heightNow-45,200,25)];
        [super addSubview:lbTitle];
        
        NSComboBox * cbCtrl = [[NSComboBox alloc] init];
        [cbCtrl setIdentifier:@"Func"];
        [cbCtrl setSelectable:true];
        [cbCtrl setSelectable:false];
        for (int i=0; i<5; i++) {
            [cbCtrl addItemWithObjectValue:([NSString stringWithFormat:@"cbPartsType-%d", i])];
        }
        [cbCtrl setFrame:NSMakeRect(20,heightNow-65,280,25)];
        [super addSubview:cbCtrl];
        self.m_cbFunc = cbCtrl;
        cbCtrl.delegate = self;
    }
    
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Region"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica" size:15]];
        [lbTitle setFrame:NSMakeRect(310,heightNow-45,200,25)];
        [super addSubview:lbTitle];
        
        NSComboBox * cbCtrl = [[NSComboBox alloc] init];
        [cbCtrl setIdentifier:@"Region"];
        [cbCtrl setSelectable:true];
        [cbCtrl setSelectable:false];
        [cbCtrl setHidden:true];
        for (int i=0; i<5; i++) {
            [cbCtrl addItemWithObjectValue:([NSString stringWithFormat:@"cbPartsType-%d", i])];
        }
        [cbCtrl setFrame:NSMakeRect(310,heightNow-65,200,25)];
        [super addSubview:cbCtrl];
        self.m_cbRegon = cbCtrl;
        cbCtrl.delegate = self;
        
        NSTextField * tfCtrl = [[NSTextField alloc] init];
        [tfCtrl setBezeled:false];
        [tfCtrl setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfCtrl setFrame:NSMakeRect(310,heightNow-63,200,20)];
        //[tfCtrl setWantsLayer:true];
        [tfCtrl setEditable:false];
        //[[tfCtrl layer] setCornerRadius:5];
        [super addSubview:tfCtrl];
        self.m_tfRegon = tfCtrl;
    }
    
    {
        NSTextField * tfCtrl = [[NSTextField alloc] init];
        [tfCtrl setBezeled:false];
        [tfCtrl setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfCtrl setFrame:NSMakeRect(340,heightNow-65,100,25)];
        //[tfCtrl setWantsLayer:true];
        [tfCtrl setEditable:false];
        //[[tfCtrl layer] setCornerRadius:5];
        [super addSubview:tfCtrl];
        self.m_tfArtboardVal = tfCtrl;
    }
    heightNow=heightNow-65;
    
    {
        
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Preview:"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbTitle setFrame:NSMakeRect(20,heightNow-40,55,25)];
        [super addSubview:lbTitle];
        
        NSTextField * tfCtrl = [[NSTextField alloc] init];
        [tfCtrl setBezeled:false];
        [tfCtrl setStringValue:@"XXXXX.0.XXXX"];
        [tfCtrl setSelectable:false];
        [tfCtrl setEditable:false];
        [tfCtrl setDrawsBackground:false];
        [tfCtrl setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfCtrl setFrame:NSMakeRect(80,heightNow-40,300,25)];
        //[tfCtrl setWantsLayer:true];
        [tfCtrl setEditable:false];
        //[[tfCtrl layer] setCornerRadius:5];
        [super addSubview:tfCtrl];
        self.m_tfDisplayScreenID = tfCtrl;
    }
     heightNow=heightNow-30;
    
    NSButton * saveBtn = [[NSButton alloc] init];
    [saveBtn setTitle:@"Generate"];
    [saveBtn setFrame:NSMakeRect(100,heightNow-50,150,25)];
    [saveBtn setTarget:self];
    [saveBtn setAction:@selector(onSaveButtonClick:)];
    [super addSubview:saveBtn];
    self.m_saveBtn = saveBtn;
    
    NSButton * cancelBtn = [[NSButton alloc] init];
    [cancelBtn setTitle:@"Cancel"];
    [cancelBtn setFrame:NSMakeRect(280,heightNow-50,150,25)];
    [cancelBtn setTarget:self];
    [cancelBtn setAction:@selector(onCancelButtonClick:)];
    [super addSubview:cancelBtn];
    
    // hide no use control
    [self.m_tfArtboardVal setHidden:true];
    
    return self;
}

-(void)setDelegage:(ScreenIDEditViewDelegate*)delegage
{
    self.m_delegate = delegage;
}

-(void)onSaveButtonClick:(id)sender
{
    NSButton * btnSele = sender;
    NSString * btnTitle = [btnSele title];
    NSLog(@"%@-Btn clicked!", btnTitle);
    if (self.m_delegate) {
        [self.m_delegate onSaveButtonClick];
    }
}

-(void)onCancelButtonClick:(id)sender
{
    NSButton * btnSele = sender;
    NSString * btnTitle = [btnSele title];
    NSLog(@"%@-Btn clicked!", btnTitle);
    if (self.m_delegate) {
        [self.m_delegate onCancelButtonClick];
    }
}

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    
    NSComboBox *comboBox = notification.object;
    NSString * sID = [comboBox identifier];
    NSString * sSelection = [comboBox objectValueOfSelectedItem];
    
    NSLog(@"comboBoxSelectionDidChange id=%@ sSelection=%@", sID, sSelection);
    //[comboBox setStringValue:sSelection];
    
    // update model data
//    if (self.m_modelData) {
//        NSMutableDictionary * dictCBData = [self.m_modelData objectForKey:sID];
//        if (dictCBData) {
//            NSString * nStr = [NSString stringWithString:sSelection];
//            [dictCBData setObject:nStr forKey:@"Current"];
//        }
//    }

    [self updateDisplayScreenID:sID ChangedVal:sSelection];
}
@end
