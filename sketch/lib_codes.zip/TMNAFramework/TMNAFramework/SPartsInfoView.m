//
//  ScreenInfoView.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/21.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import "SPartsInfoView.h"
#import "SConPaneView.h"
#include "SButtonView.h"

@implementation SPartsInfoViewDelegate
-(void)onSaveButtonClick
{
    
}
@end


@implementation SPartsInfoView

-(void)awakeFromNib
{
    [self init];
}

-(void)setDelegage:(SPartsInfoViewDelegate*)delegage
{
    self.m_delegate = delegage;
}

-(void)clearModelData
{
    [self.m_tfPartsID setStringValue:@""];
    [self.m_cbPartsType removeAllItems];[self.m_cbPartsType setStringValue:@""];
    [self.m_tfName setStringValue:@""];
    
    int defaultCondIndex = 0;
    [self.m_SCPVCurrent setHidden:true];
    self.m_SCPVCurrent = self.conditionsViews[defaultCondIndex];
    [self.m_SCPVCurrent setHidden:false];
    [self.m_cbCon setStringValue:self.conditionsList[defaultCondIndex]];
    
    [self.m_SCPVDisplay clearModelData];
    [self.m_SCPVSWSelect clearModelData];
    [self.m_SCPVSWToneDownMotion clearModelData];
    [self.m_SCPVSWToneDownExceptInMotion clearModelData];
    [self.m_SCPVTextOrImageDeleteInMotion clearModelData];
    
    [self.m_tfJPWords setStringValue:@""];
    [self.m_tfJPFixedWords setStringValue:@""];
    [self.m_tfJPVRWords setStringValue:@""];
    [self.m_tfUSWords setStringValue:@""];
    [self.m_tfUSFixedWords setStringValue:@""];
    [self.m_tfUSVRWords setStringValue:@""];
    [self.m_tfUKWords setStringValue:@""];
    [self.m_tfUKFixedWords setStringValue:@""];
    [self.m_tfUKVRWords setStringValue:@""];
    
    [self.m_tfDisplayContent setStringValue:@""];
    [self.m_tfFormat setStringValue:@""];
    [self.m_tfRange setStringValue:@""];
    [self.m_tfValidation setStringValue:@""];
    
    [self.m_cbSWOpePattern removeAllItems];[self.m_cbSWOpePattern setStringValue:@""];
    [self.m_tfSWOpeResScreenTransition setStringValue:@""];
    [self.m_tfSWOpeResStartFunction setStringValue:@""];
    [self.m_tfSWOpeResSetValChange setStringValue:@""];
    [self.m_tfSWOpeResOther setStringValue:@""];
    
    [self.m_cbBeep removeAllItems];[self.m_cbBeep setStringValue:@""];
}

-(void)setModelData:(NSMutableDictionary*)modelData
{
    [self clearModelData];
    
    int count = [modelData count];
    NSLog(@"modelData count： %d\n",count);
    NSLog(@"data=%@\n",modelData);
    
    // enum all key
    NSLog(@"allkey enum\n");
    NSEnumerator * enumeratorKey = [modelData keyEnumerator];
    for (NSObject *object in enumeratorKey) {
        NSString *key = object;
        NSObject *value = modelData[object];
        NSLog(@"    k:%@ v:%@\n",key, value);

        // ---
        if (NSOrderedSame == [key compare:@"PartsID"]) {
            [self.m_tfPartsID setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"PartsType"]) {
            NSDictionary * partsType = value;
            NSString * partsTypeCurrent = partsType[@"Current"];
            NSMutableArray *partsTypeList = partsType[@"List"];
            [self.m_cbPartsType setStringValue:partsTypeCurrent];
            for (int i = 0; i < partsTypeList.count; i++)
            {
                [self.m_cbPartsType addItemWithObjectValue:partsTypeList[i]];
            }
        }
        if (NSOrderedSame == [key compare:@"PartsName"]) {
            [self.m_tfName setStringValue:value];
        }
        
        //--
        if (NSOrderedSame == [key compare:@"Conditions"]) {
            NSDictionary * dictConds = value;

            NSDictionary * dictDisplay = dictConds[@"Display"];
            if(dictDisplay)
            {
                [self.m_SCPVDisplay setModelData:dictDisplay];
            }
            NSDictionary * dictSWSelect = dictConds[@"SWSelect"];
            if(dictSWSelect)
            {
                [self.m_SCPVSWSelect setModelData:dictSWSelect];
            }
            NSDictionary * dictSWToneDownMotion = dictConds[@"SWToneDownMotion"];
            if(dictSWToneDownMotion)
            {
                [self.m_SCPVSWToneDownMotion setModelData:dictSWToneDownMotion];
            }
            NSDictionary * dictSWToneDownExceptInMotion = dictConds[@"SWToneDownExceptInMotion"];
            if(dictSWToneDownExceptInMotion)
            {
                [self.m_SCPVSWToneDownExceptInMotion setModelData:dictSWToneDownExceptInMotion];
            }
            NSDictionary * dictTextOrImageDeleteInMotion = dictConds[@"TextOrImageDeleteInMotion"];
            if(dictTextOrImageDeleteInMotion)
            {
                [self.m_SCPVTextOrImageDeleteInMotion setModelData:dictTextOrImageDeleteInMotion];
            }
        }
        
        //---
        if (NSOrderedSame == [key compare:@"JPWords"]) {
            [self.m_tfJPWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"JPFixedWords"]) {
            [self.m_tfJPFixedWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"JPVRWords"]) {
            [self.m_tfJPVRWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"USWords"]) {
            [self.m_tfUSWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"USFixedWords"]) {
            [self.m_tfUSFixedWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"USVRWords"]) {
            [self.m_tfUSVRWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"UKWords"]) {
            [self.m_tfUKWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"UKFixedWords"]) {
            [self.m_tfUKFixedWords setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"UKVRWords"]) {
            [self.m_tfUKVRWords setStringValue:value];
        }
        
        //---
        if (NSOrderedSame == [key compare:@"DisplayContent"]) {
            [self.m_tfDisplayContent setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"Format"]) {
            [self.m_tfFormat setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"Range"]) {
            [self.m_tfRange setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"Validation"]) {
            [self.m_tfValidation setStringValue:value];
        }

        //---
        if (NSOrderedSame == [key compare:@"SWOpePattern"]) {
            NSDictionary * dictSWOpePattern = value;
            NSString * sCurrent = dictSWOpePattern[@"Current"];
            NSMutableArray *sList = dictSWOpePattern[@"List"];
            [self.m_cbSWOpePattern setStringValue:sCurrent];
            for (int i = 0; i < sList.count; i++)
            {
                [self.m_cbSWOpePattern addItemWithObjectValue:sList[i]];
            }
        }
        if (NSOrderedSame == [key compare:@"SWOpeResScreenTransition"]) {
            [self.m_tfSWOpeResScreenTransition setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"SWOpeResStartFunction"]) {
            [self.m_tfSWOpeResStartFunction setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"SWOpeResSetValChange"]) {
            [self.m_tfSWOpeResSetValChange setStringValue:value];
        }
        if (NSOrderedSame == [key compare:@"SWOpeResOther"]) {
            [self.m_tfSWOpeResOther setStringValue:value];
        }
        
        //---
        if (NSOrderedSame == [key compare:@"Beep"]) {
            NSDictionary * dictSWOpePattern = value;
            NSString * sCurrent = dictSWOpePattern[@"Current"];
            NSMutableArray *sList = dictSWOpePattern[@"List"];
            [self.m_cbBeep setStringValue:sCurrent];
            for (int i = 0; i < sList.count; i++)
            {
                [self.m_cbBeep addItemWithObjectValue:sList[i]];
            }
        }
    }
}

-(NSMutableDictionary*)getModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    NSString * sPartsID = [self.m_tfPartsID stringValue];
    if (sPartsID) {
        [modelData setObject:sPartsID forKey:@"PartsID"];
    }
    
    NSMutableDictionary * dictPartsType = [NSMutableDictionary dictionary];
    {
        NSString * sPartsType = [self.m_cbPartsType stringValue];
        if (sPartsType) {
            [dictPartsType setObject:sPartsType forKey:@"Current"];
        }
        NSMutableArray* arrPartsTypeSelectList = [[NSMutableArray alloc] initWithArray:[self.m_cbPartsType objectValues] copyItems:YES];
        if (arrPartsTypeSelectList) {
            [dictPartsType setObject:arrPartsTypeSelectList forKey:@"List"];
        }
    }
    [modelData setObject:dictPartsType forKey:@"PartsType"];
   
    NSString * sPartsName = [self.m_tfName stringValue];
    if (sPartsName) {
        [modelData setObject:sPartsName forKey:@"PartsName"];
    }
    
    // conditions
    NSMutableDictionary * dictConditions = [NSMutableDictionary dictionary];
    NSMutableDictionary * dictCondDisplay = [self.m_SCPVDisplay getModelData];
    if (dictCondDisplay) {
        [dictConditions setObject:dictCondDisplay forKey:@"Display"];
    }
    NSMutableDictionary * dictCondSWSelect = [self.m_SCPVSWSelect getModelData];
    if (dictCondSWSelect) {
        [dictConditions setObject:dictCondSWSelect forKey:@"SWSelect"];
    }
    NSMutableDictionary * dictCondSWToneDownMotion = [self.m_SCPVSWToneDownMotion getModelData];
    if (dictCondSWToneDownMotion) {
        [dictConditions setObject:dictCondSWToneDownMotion forKey:@"SWToneDownMotion"];
    }
    NSMutableDictionary * dictCondSWToneDownExceptInMotion = [self.m_SCPVSWToneDownExceptInMotion getModelData];
    if (dictCondSWToneDownExceptInMotion) {
        [dictConditions setObject:dictCondSWToneDownExceptInMotion forKey:@"SWToneDownExceptInMotion"];
    }
    NSMutableDictionary * dictCondTextOrImageDeleteInMotion = [self.m_SCPVTextOrImageDeleteInMotion getModelData];
    if (dictCondTextOrImageDeleteInMotion) {
        [dictConditions setObject:dictCondTextOrImageDeleteInMotion forKey:@"TextOrImageDeleteInMotion"];
    }
    [modelData setObject:dictConditions forKey:@"Conditions"];
    
    NSString * sJPWords = [self.m_tfJPWords stringValue];
    if (sJPWords) {
        [modelData setObject:sJPWords forKey:@"JPWords"];
    }
    NSString * sJPFixedWords = [self.m_tfJPFixedWords stringValue];
    if (sJPFixedWords) {
        [modelData setObject:sJPFixedWords forKey:@"JPFixedWords"];
    }
    NSString * sJPVRWords = [self.m_tfJPVRWords stringValue];
    if (sJPVRWords) {
        [modelData setObject:sJPVRWords forKey:@"JPVRWords"];
    }
    NSString * sUSWords = [self.m_tfUSWords stringValue];
    if (sUSWords) {
        [modelData setObject:sUSWords forKey:@"USWords"];
    }
    NSString * sUSFixedWords = [self.m_tfUSFixedWords stringValue];
    if (sUSFixedWords) {
        [modelData setObject:sUSFixedWords forKey:@"USFixedWords"];
    }
    NSString * sUSVRWords = [self.m_tfUSVRWords stringValue];
    if (sUSVRWords) {
        [modelData setObject:sUSVRWords forKey:@"USVRWords"];
    }
    NSString * sUKWords = [self.m_tfUKWords stringValue];
    if (sUKWords) {
        [modelData setObject:sUKWords forKey:@"UKWords"];
    }
    NSString * sUKFixedWords = [self.m_tfUKFixedWords stringValue];
    if (sUKFixedWords) {
        [modelData setObject:sUKFixedWords forKey:@"UKFixedWords"];
    }
    NSString * sUKVRWords = [self.m_tfUKVRWords stringValue];
    if (sUKVRWords) {
        [modelData setObject:sUKVRWords forKey:@"UKVRWords"];
    }
    
    NSString * sDisplayContent = [self.m_tfDisplayContent stringValue];
    if (sDisplayContent) {
        [modelData setObject:sDisplayContent forKey:@"DisplayContent"];
    }
    NSString * sFormat = [self.m_tfFormat stringValue];
    if (sFormat) {
        [modelData setObject:sFormat forKey:@"Format"];
    }
    NSString * sRange = [self.m_tfRange stringValue];
    if (sRange) {
        [modelData setObject:sRange forKey:@"Range"];
    }
    NSString * sValidation = [self.m_tfValidation stringValue];
    if (sUKVRWords) {
        [modelData setObject:sValidation forKey:@"Validation"];
    }
    
    
    NSMutableDictionary * dictSWOpePattern = [NSMutableDictionary dictionary];
    {
        NSString * sCurrent = [self.self.m_cbSWOpePattern stringValue];
        if (sCurrent) {
            [dictSWOpePattern setObject:sCurrent forKey:@"Current"];
        }
        NSMutableArray* arr = [[NSMutableArray alloc] initWithArray:[self.m_cbSWOpePattern objectValues] copyItems:YES];
        if (arr) {
            [dictSWOpePattern setObject:arr forKey:@"List"];
        }
    }
    [modelData setObject:dictSWOpePattern forKey:@"SWOpePattern"];
    NSString * sSWOpeResScreenTransition = [self.m_tfSWOpeResScreenTransition stringValue];
    if (sSWOpeResScreenTransition) {
        [modelData setObject:sSWOpeResScreenTransition forKey:@"SWOpeResScreenTransition"];
    }
    NSString * sSWOpeResStartFunction = [self.m_tfSWOpeResStartFunction stringValue];
    if (sSWOpeResStartFunction) {
        [modelData setObject:sSWOpeResStartFunction forKey:@"SWOpeResStartFunction"];
    }
    NSString * sSWOpeResSetValChange = [self.m_tfSWOpeResSetValChange stringValue];
    if (sSWOpeResSetValChange) {
        [modelData setObject:sSWOpeResSetValChange forKey:@"SWOpeResSetValChange"];
    }
    NSString * sSWOpeResOther = [self.m_tfSWOpeResOther stringValue];
    if (sSWOpeResOther) {
        [modelData setObject:sSWOpeResOther forKey:@"SWOpeResOther"];
    }
    
    NSMutableDictionary * dictBeep = [NSMutableDictionary dictionary];
    {
        NSString * sCurrent = [self.self.self.m_cbBeep stringValue];
        if (sCurrent) {
            [dictBeep setObject:sCurrent forKey:@"Current"];
        }
        NSMutableArray* arr = [[NSMutableArray alloc] initWithArray:[self.m_cbBeep objectValues] copyItems:YES];
        if (arr) {
            [dictBeep setObject:arr forKey:@"List"];
        }
    }
    [modelData setObject:dictBeep forKey:@"Beep"];

    NSLog(@"GetModelData=%@", modelData);
    return modelData;
}

-(NSMutableDictionary*)getTestModelData
{
    NSMutableDictionary * modelData = [NSMutableDictionary dictionary];
    
    [modelData setObject:@"parts_02" forKey:@"PartsID"];
    
    NSMutableDictionary * dictPartsType = [NSMutableDictionary dictionary];
    {
        [dictPartsType setObject:@"parts_type8" forKey:@"Current"];
        
        NSMutableArray *arrPartsTypeSelectList = [[NSMutableArray alloc]init];
        [arrPartsTypeSelectList addObject:@"pats_type8"];
        [arrPartsTypeSelectList addObject:@"parts_02"];
        [arrPartsTypeSelectList addObject:@"pats_type66"];
        [dictPartsType setObject:arrPartsTypeSelectList forKey:@"List"];
    }
    [modelData setObject:dictPartsType forKey:@"PartsType"];
        
    [modelData setObject:@"name234" forKey:@"PartsName"];
    
    NSMutableDictionary * dictConditions = [NSMutableDictionary dictionary];
    {
        NSMutableDictionary * dictDisplayCond = [NSMutableDictionary dictionary];
        [dictDisplayCond setObject:@"Disp AConditionAAA test98" forKey:@"A"];
        [dictDisplayCond setObject:@"Disp BConditionBBB test98" forKey:@"B"];
        [dictDisplayCond setObject:@"Disp CConditionCCC test98" forKey:@"C"];
        [dictDisplayCond setObject:@"Disp Formula test98" forKey:@"Formula"];
        [dictDisplayCond setObject:@"Disp SamePartsID test98" forKey:@"SamePartsID"];
        [dictDisplayCond setObject:@"Disp SameScreenID test98" forKey:@"SameScreenID"];
        [dictDisplayCond setObject:@"Disp Else test98" forKey:@"Else"];
        [dictConditions setObject:dictDisplayCond forKey:@"Display"];
        
        NSMutableDictionary * swCond = [NSMutableDictionary dictionary];
        [swCond setObject:@"SW ACondition test98" forKey:@"A"];
        [swCond setObject:@"SW BCondition test98" forKey:@"B"];
        [swCond setObject:@"SW CCondition test98" forKey:@"C"];
        [swCond setObject:@"SW Formula test98" forKey:@"Formula"];
        [swCond setObject:@"SW SamePartsID test98" forKey:@"SamePartsID"];
        [swCond setObject:@"SW SameScreenID test98" forKey:@"SameScreenID"];
        [swCond setObject:@"SW Else test98" forKey:@"Else"];
        [dictConditions setObject:swCond forKey:@"SWSelect"];
        
    }
    [modelData setObject:dictConditions forKey:@"Conditions"];
    
    [modelData setObject:@"japan Words" forKey:@"JPWords"];
    [modelData setObject:@"japan Fixed Words x" forKey:@"JPFixedWords"];
    [modelData setObject:@"japanVR Words" forKey:@"JPVRWords"];
    [modelData setObject:@"US Words" forKey:@"USWords"];
    [modelData setObject:@"US Fixed Words x" forKey:@"USFixedWords"];
    [modelData setObject:@"USVR Words" forKey:@"USVRWords"];
    [modelData setObject:@"UK Words" forKey:@"UKWords"];
    [modelData setObject:@"UK Fixed Words x" forKey:@"UKFixedWords"];
    [modelData setObject:@"UKVR Words" forKey:@"UKVRWords"];
    
    [modelData setObject:@"Display Content Ds" forKey:@"DisplayContent"];
    [modelData setObject:@"FormatZZ" forKey:@"Format"];
    [modelData setObject:@"Range34" forKey:@"Range"];
    [modelData setObject:@"Validation6" forKey:@"Validation"];
    
    NSMutableDictionary * dictSWOpePattern = [NSMutableDictionary dictionary];
    {
        [dictSWOpePattern setObject:@"ope1" forKey:@"Current"];
        
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        [arr addObject:@"ope1"];
        [arr addObject:@"ope2"];
        [dictSWOpePattern setObject:arr forKey:@"List"];
    }
    [modelData setObject:dictSWOpePattern forKey:@"SWOpePattern"];
    [modelData setObject:@"SWOpeResScreenTransition888" forKey:@"SWOpeResScreenTransition"];
    [modelData setObject:@"SWOpeResStartFunction333" forKey:@"SWOpeResStartFunction"];
    [modelData setObject:@"SWOpeResSetValChange444" forKey:@"SWOpeResSetValChange"];
    [modelData setObject:@"SWOpeResOther555" forKey:@"SWOpeResOther"];
    
    NSMutableDictionary * dictBeep = [NSMutableDictionary dictionary];
    {
        [dictBeep setObject:@"beep1" forKey:@"Current"];
        
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        [arr addObject:@"beep1"];
        [arr addObject:@"beep2"];
        [arr addObject:@"beep3"];
        [dictBeep setObject:arr forKey:@"List"];
    }
    [modelData setObject:dictBeep forKey:@"Beep"];
    
    return modelData;
}

-(instancetype)init {
    self = [super init];
    
    int iViewH = 1025;//965;
    int iViewW = 190;
    
    [super setFrame:NSMakeRect(20,20,iViewW,iViewH)];
    [super setWantsLayer:YES];
    CALayer * layer = [super layer];
    NSColor * tstNSColor = [NSColor colorWithRed:0.92549 green:0.92549 blue:0.92549 alpha:1.0];
    [layer setBackgroundColor:[tstNSColor CGColor]];
    
    int heightNow = iViewH;
    NSColor * colSplitLineTitle = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.3];
    NSColor * colSplitLine = [NSColor colorWithRed:0 green:0.0 blue:0.0 alpha:0.1];
    NSColor * colSubTitle = [NSColor colorWithRed:0.35 green:0.35 blue:0.35 alpha:1];
    
    
    // title & btnsync
    {
        NSTextField * lbTitle = [[NSTextField alloc] init];
        [lbTitle setBezeled:false];
        [lbTitle setStringValue:@"Parts"];
        [lbTitle setSelectable:false];
        [lbTitle setEditable:false];
        [lbTitle setDrawsBackground:false];
        [lbTitle setFont:[NSFont fontWithName:@"Helvetica-Bold" size:13]];
        [lbTitle setFrame:NSMakeRect(5,heightNow-24,iViewW,20)];
        [super addSubview:lbTitle];
        
        SButtonView * btnSync = [[SButtonView alloc] init];
        [btnSync setTitle:@"sync"];
        //[btnSync setButtonType:NSMomentaryChangeButton];
        [btnSync setFrame:NSMakeRect(iViewW-20,heightNow-21,16,16)];
        [btnSync setFont:[NSFont fontWithName:@"Arial" size:11]];
        NSBundle *bundle = [NSBundle bundleForClass:[SPartsInfoView class]];
        NSImage * image = [bundle imageForResource:@"save"];
        [btnSync setImage:image];
        NSImage * imagePush = [bundle imageForResource:@"save3"];
        [btnSync setPushDownImage:imagePush];
        [btnSync setBordered:false];
        [btnSync setImageScaling:NSImageScaleAxesIndependently];
        [btnSync setTarget:self];
        [btnSync setAction:@selector(onSaveButtonClick:)];
        [super addSubview:btnSync];
    }
    heightNow=heightNow-26;
    
    // split line
    {
        NSView * splitLine = [[NSView alloc] init];
        [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
        [splitLine setWantsLayer:true];
        [[splitLine layer] setBackgroundColor:[colSplitLineTitle CGColor]];
        [super addSubview:splitLine];
    }
    heightNow=heightNow-1;
    
    // parts ID & parts Type
    {
        heightNow=heightNow-5;
        
        // ID
        NSTextField * lbPartsID = [[NSTextField alloc] init];
        [lbPartsID setBezeled:false];
        [lbPartsID setStringValue:@"Parts ID:"];
        [lbPartsID setSelectable:false];
        [lbPartsID setEditable:false];
        [lbPartsID setDrawsBackground:false];
        [lbPartsID setTextColor:colSubTitle];
        [lbPartsID setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbPartsID setFrame:NSMakeRect(0,heightNow-22,iViewW,20)];
        [super addSubview:lbPartsID];
        
        NSTextField * tfPartsID = [[NSTextField alloc] init];
        [tfPartsID setBezeled:false];
        [tfPartsID setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfPartsID setFrame:NSMakeRect(iViewW/2-20,heightNow-22,iViewW/2+20,20)];
        [tfPartsID setWantsLayer:true];
        [[tfPartsID layer] setCornerRadius:5];
        [super addSubview:tfPartsID];
        self.m_tfPartsID = tfPartsID;
        
        /*NSComboBox * cbPartsID = [[NSComboBox alloc] init];
        [cbPartsID setSelectable:false];
        for (int i=0; i<100; i++) {
            [cbPartsID addItemWithObjectValue:([NSString stringWithFormat:@"PartsID-%d", i])];
        }
        [cbPartsID setFrame:NSMakeRect(0,heightNow-25,iViewW,25)];
        [super addSubview:cbPartsID];
        heightNow=heightNow-25;*/
        
        // Type
        
        NSTextField * lbPartsType = [[NSTextField alloc] init];
        [lbPartsType setBezeled:false];
        [lbPartsType setStringValue:@"Parts Type:"];
        [lbPartsType setSelectable:false];
        [lbPartsType setEditable:false];
        [lbPartsType setDrawsBackground:false];
        [lbPartsType setTextColor:colSubTitle];
        [lbPartsType setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbPartsType setFrame:NSMakeRect(0,heightNow-47,iViewW,20)];
        [super addSubview:lbPartsType];
        
        NSComboBox * cbPartsType = [[NSComboBox alloc] init];
        [cbPartsType setSelectable:false];
        for (int i=0; i<100; i++) {
            [cbPartsType addItemWithObjectValue:([NSString stringWithFormat:@"cbPartsType-%d", i])];
        }
        [cbPartsType setFrame:NSMakeRect(iViewW/2-20,heightNow-50,iViewW/2+20,25)];
        [super addSubview:cbPartsType];
        self.m_cbPartsType = cbPartsType;

        // Name
        NSTextField * lbPartsName = [[NSTextField alloc] init];
        [lbPartsName setBezeled:false];
        [lbPartsName setStringValue:@"Parts Name:"];
        [lbPartsName setSelectable:false];
        [lbPartsName setEditable:false];
        [lbPartsName setDrawsBackground:false];
        [lbPartsName setTextColor:colSubTitle];
        [lbPartsName setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbPartsName setFrame:NSMakeRect(0,heightNow-72,iViewW,20)];
        [super addSubview:lbPartsName];
        
        NSTextField * tfName = [[NSTextField alloc] init];
        [tfName setBezeled:false];
        [tfName setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfName setWantsLayer:true];
        [[tfName layer] setCornerRadius:5];
        [tfName setFrame:NSMakeRect(iViewW/2-20,heightNow-72,iViewW/2+20,20)];
        [super addSubview:tfName];
        self.m_tfName = tfName;
    }
    heightNow=heightNow-85;
    
    
    // Conditions
    {
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        heightNow=heightNow-1;
        
        // select
        NSTextField * lbCon = [[NSTextField alloc] init];
        [lbCon setBezeled:false];
        [lbCon setStringValue:@"Conditions"];
        [lbCon setSelectable:false];
        [lbCon setEditable:false];
        [lbCon setDrawsBackground:false];
        [lbCon setTextColor:colSubTitle];
        [lbCon setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbCon setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbCon];
        heightNow=heightNow-20;
        
        //conditions
        int defaultIndex = 0;
        self.conditionsList = @[
                                @"Display",
                                @"SW Select",
                                @"SW ToneDown-Motion",
                                @"SW ToneDown-Except In Motion",
                                @"Text/Image Delete In Motion",
                                ];
        NSComboBox * cbCon = [[NSComboBox alloc] init];
        [cbCon setSelectable:false];
        cbCon.usesDataSource = YES;
        cbCon.dataSource = self;
        cbCon.delegate = self;
        [cbCon setFrame:NSMakeRect(0,heightNow-25,iViewW,25)];
        [super addSubview:cbCon];
        self.m_cbCon = cbCon;
        heightNow=heightNow-25;
        
        self.m_SCPVDisplay = [[SConPaneView alloc] init];
        [self.m_SCPVDisplay setFrame:NSMakeRect(0,heightNow-233,iViewW-3,235)];
        [self.m_SCPVDisplay setHidden:true];
        [super addSubview:self.m_SCPVDisplay];
        
        self.m_SCPVSWSelect = [[SConPaneView alloc] init];
        [self.m_SCPVSWSelect setFrame:NSMakeRect(0,heightNow-233,iViewW-3,235)];
        [self.m_SCPVSWSelect setHidden:true];
        [super addSubview:self.m_SCPVSWSelect];
        
        self.m_SCPVSWToneDownMotion = [[SConPaneView alloc] init];
        [self.m_SCPVSWToneDownMotion setFrame:NSMakeRect(0,heightNow-233,iViewW-3,235)];
        [self.m_SCPVSWToneDownMotion setHidden:true];
        [super addSubview:self.m_SCPVSWToneDownMotion];
        
        self.m_SCPVSWToneDownExceptInMotion = [[SConPaneView alloc] init];
        [self.m_SCPVSWToneDownExceptInMotion setFrame:NSMakeRect(0,heightNow-233,iViewW-3,235)];
        [self.m_SCPVSWToneDownExceptInMotion setHidden:true];
        [super addSubview:self.m_SCPVSWToneDownExceptInMotion];
        
        self.m_SCPVTextOrImageDeleteInMotion = [[SConPaneView alloc] init];
        [self.m_SCPVTextOrImageDeleteInMotion setFrame:NSMakeRect(0,heightNow-233,iViewW-3,235)];
        [self.m_SCPVTextOrImageDeleteInMotion setHidden:true];
        [super addSubview:self.m_SCPVTextOrImageDeleteInMotion];
        
        self.conditionsViews = @[
                                self.m_SCPVDisplay,
                                self.m_SCPVSWSelect,
                                self.m_SCPVSWToneDownMotion,
                                self.m_SCPVSWToneDownExceptInMotion,
                                self.m_SCPVTextOrImageDeleteInMotion,
                                ];
    
        self.m_SCPVCurrent = self.conditionsViews[defaultIndex];
        [self.m_SCPVCurrent setHidden:false];
        [cbCon setStringValue:self.conditionsList[defaultIndex]];
        
    }
    heightNow=heightNow-250;
    
    
    // Test or Image
    {
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        
        NSTextField * lbTI = [[NSTextField alloc] init];
        [lbTI setBezeled:false];
        [lbTI setStringValue:@"Text or Image info"];
        [lbTI setSelectable:false];
        [lbTI setEditable:false];
        [lbTI setDrawsBackground:false];
        [lbTI setTextColor:colSubTitle];
        [lbTI setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbTI setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbTI];
        heightNow=heightNow-20;
        
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        heightNow=heightNow-1;
        
        // Japanese
        {
            NSTextField * lbJP = [[NSTextField alloc] init];
            [lbJP setBezeled:false];
            [lbJP setStringValue:@"Japanese"];
            [lbJP setSelectable:false];
            [lbJP setEditable:false];
            [lbJP setDrawsBackground:false];
            [lbJP setFont:[NSFont fontWithName:@"Arial" size:11]];
            [lbJP setTextColor:colSubTitle];
            [lbJP setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:lbJP];
            heightNow=heightNow-15;
            
            NSTextField * tfContent1 = [[NSTextField alloc] init];
            [tfContent1 setBezeled:false];
            [tfContent1 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfContent1 setPlaceholderString:@"Japanese Words"];
            [tfContent1 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfContent1];
            self.m_tfJPWords = tfContent1;
            heightNow=heightNow-17;
            
            NSTextField * tfDisplayContent1 = [[NSTextField alloc] init];
            [tfDisplayContent1 setBezeled:false];
            [tfDisplayContent1 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfDisplayContent1 setPlaceholderString:@"Fixed Words"];
            [tfDisplayContent1 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfDisplayContent1];
            self.m_tfJPFixedWords = tfDisplayContent1;
            heightNow=heightNow-17;
            
            NSTextField * tfDisplayContent2 = [[NSTextField alloc] init];
            [tfDisplayContent2 setBezeled:false];
            [tfDisplayContent2 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfDisplayContent2 setPlaceholderString:@"VUI recognition Word"];
            [tfDisplayContent2 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfDisplayContent2];
            self.m_tfJPVRWords = tfDisplayContent2;
            heightNow=heightNow-17;
        }
        
        // U.S.English
        {
            NSTextField * lbUSE = [[NSTextField alloc] init];
            [lbUSE setBezeled:false];
            [lbUSE setStringValue:@"U.S.English"];
            [lbUSE setSelectable:false];
            [lbUSE setEditable:false];
            [lbUSE setDrawsBackground:false];
            [lbUSE setFont:[NSFont fontWithName:@"Arial" size:11]];
            [lbUSE setTextColor:colSubTitle];
            [lbUSE setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:lbUSE];
            heightNow=heightNow-15;
            
            NSTextField * tfContent1 = [[NSTextField alloc] init];
            [tfContent1 setBezeled:false];
            [tfContent1 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfContent1 setPlaceholderString:@"U.S.English Words"];
            [tfContent1 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfContent1];
            self.m_tfUSWords = tfContent1;
            heightNow=heightNow-17;
            
            NSTextField * tfDisplayContent1 = [[NSTextField alloc] init];
            [tfDisplayContent1 setBezeled:false];
            [tfDisplayContent1 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfDisplayContent1 setPlaceholderString:@"Fixed Words"];
            [tfDisplayContent1 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfDisplayContent1];
            self.m_tfUSFixedWords = tfDisplayContent1;
            heightNow=heightNow-17;
            
            NSTextField * tfDisplayContent2 = [[NSTextField alloc] init];
            [tfDisplayContent2 setBezeled:false];
            [tfDisplayContent2 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfDisplayContent2 setPlaceholderString:@"VUI recognition Word"];
            [tfDisplayContent2 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfDisplayContent2];
            self.m_tfUSVRWords = tfDisplayContent2;
            heightNow=heightNow-17;
        }

        // U.K.English
        {
            NSTextField * lbUKE = [[NSTextField alloc] init];
            [lbUKE setBezeled:false];
            [lbUKE setStringValue:@"U.K.English"];
            [lbUKE setSelectable:false];
            [lbUKE setEditable:false];
            [lbUKE setDrawsBackground:false];
            [lbUKE setFont:[NSFont fontWithName:@"Arial" size:11]];
            [lbUKE setTextColor:colSubTitle];
            [lbUKE setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:lbUKE];
            heightNow=heightNow-15;
            
            NSTextField * tfContent1 = [[NSTextField alloc] init];
            [tfContent1 setBezeled:false];
            [tfContent1 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfContent1 setPlaceholderString:@"U.K.English Words"];
            [tfContent1 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfContent1];
            self.m_tfUKWords = tfContent1;
            heightNow=heightNow-17;
            
            NSTextField * tfDisplayContent1 = [[NSTextField alloc] init];
            [tfDisplayContent1 setBezeled:false];
            [tfDisplayContent1 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfDisplayContent1 setPlaceholderString:@"Fixed Words"];
            [tfDisplayContent1 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfDisplayContent1];
            self.m_tfUKFixedWords = tfDisplayContent1;
            heightNow=heightNow-17;
            
            NSTextField * tfDisplayContent2 = [[NSTextField alloc] init];
            [tfDisplayContent2 setBezeled:false];
            [tfDisplayContent2 setFont:[NSFont fontWithName:@"Arial" size:11]];
            [tfDisplayContent2 setPlaceholderString:@"VUI recognition Word"];
            [tfDisplayContent2 setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
            [super addSubview:tfDisplayContent2];
            self.m_tfUKVRWords = tfDisplayContent2;
            heightNow=heightNow-17;
        }
    }

    heightNow=heightNow-10;
    // Outside Input
    {
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        
        NSTextField * lbTI = [[NSTextField alloc] init];
        [lbTI setBezeled:false];
        [lbTI setStringValue:@"Outside Input"];
        [lbTI setSelectable:false];
        [lbTI setEditable:false];
        [lbTI setDrawsBackground:false];
        [lbTI setTextColor:colSubTitle];
        [lbTI setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbTI setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbTI];
        heightNow=heightNow-20;
        
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        heightNow=heightNow-6;
        
        // Display Content
        NSTextField * lbDispCon = [[NSTextField alloc] init];
        [lbDispCon setBezeled:false];
        [lbDispCon setStringValue:@"Display Content"];
        [lbDispCon setSelectable:false];
        [lbDispCon setEditable:false];
        [lbDispCon setDrawsBackground:false];
        [lbDispCon setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbDispCon setTextColor:colSubTitle];
        [lbDispCon setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:lbDispCon];
        heightNow=heightNow-15;
        
        NSTextField * tfDispCon = [[NSTextField alloc] init];
        [tfDispCon setBezeled:false];
        [tfDispCon setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfDispCon setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:tfDispCon];
        self.m_tfDisplayContent = tfDispCon;
        heightNow=heightNow-15;
        
        // Format
        NSTextField * lbFormat = [[NSTextField alloc] init];
        [lbFormat setBezeled:false];
        [lbFormat setStringValue:@"Format"];
        [lbFormat setSelectable:false];
        [lbFormat setEditable:false];
        [lbFormat setDrawsBackground:false];
        [lbFormat setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbFormat setTextColor:colSubTitle];
        [lbFormat setFrame:NSMakeRect(0,heightNow-17,iViewW,15)];
        [super addSubview:lbFormat];
        
        NSTextField * tfFormat = [[NSTextField alloc] init];
        [tfFormat setBezeled:false];
        [tfFormat setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfFormat setFrame:NSMakeRect(iViewW/3,heightNow-17,iViewW/3*2,15)];
        [super addSubview:tfFormat];
        self.m_tfFormat = tfFormat;
        heightNow=heightNow-17;
        
        // Range
        NSTextField * lbRange = [[NSTextField alloc] init];
        [lbRange setBezeled:false];
        [lbRange setStringValue:@"Range"];
        [lbRange setSelectable:false];
        [lbRange setEditable:false];
        [lbRange setDrawsBackground:false];
        [lbRange setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbRange setTextColor:colSubTitle];
        [lbRange setFrame:NSMakeRect(0,heightNow-17,iViewW,15)];
        [super addSubview:lbRange];
        
        NSTextField * tfRange = [[NSTextField alloc] init];
        [tfRange setBezeled:false];
        [tfRange setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfRange setFrame:NSMakeRect(iViewW/3,heightNow-17,iViewW/3*2,15)];
        [super addSubview:tfRange];
        self.m_tfRange = tfRange;
        heightNow=heightNow-17;
        
        // Validation
        NSTextField * lbValidation = [[NSTextField alloc] init];
        [lbValidation setBezeled:false];
        [lbValidation setStringValue:@"Validation"];
        [lbValidation setSelectable:false];
        [lbValidation setEditable:false];
        [lbValidation setDrawsBackground:false];
        [lbValidation setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbValidation setTextColor:colSubTitle];
        [lbValidation setFrame:NSMakeRect(0,heightNow-17,iViewW,15)];
        [super addSubview:lbValidation];
        
        NSTextField * tfValidation = [[NSTextField alloc] init];
        [tfValidation setBezeled:false];
        [tfValidation setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfValidation setFrame:NSMakeRect(iViewW/3,heightNow-17,iViewW/3*2,15)];
        [super addSubview:tfValidation];
        self.m_tfValidation = tfValidation;
        heightNow=heightNow-20;
        
        /*// Text/Image Validation
        NSTextField * lbTIValid = [[NSTextField alloc] init];
        [lbTIValid setBezeled:false];
        [lbTIValid setStringValue:@"Text/Image Validation"];
        [lbTIValid setSelectable:false];
        [lbTIValid setEditable:false];
        [lbTIValid setDrawsBackground:false];
        [lbTIValid setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbTIValid setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbTIValid];
        heightNow=heightNow-20;
        
        NSTextField * tfTIValid = [[NSTextField alloc] init];
        [tfTIValid setBezeled:false];
        [tfTIValid setFont:[NSFont fontWithName:@"Arial" size:12]];
        [tfTIValid setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:tfTIValid];
        heightNow=heightNow-30;*/
    }
    
    heightNow=heightNow-10;
    // SW Operation Pattern
    {
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        
        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"SW Operation Pattern"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow-20;
        
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];
            
        }
        heightNow=heightNow-6;
        
        NSComboBox * cbSWOP= [[NSComboBox alloc] init];
        [cbSWOP setSelectable:false];
        for (int i=0; i<100; i++) {
            [cbSWOP addItemWithObjectValue:([NSString stringWithFormat:@"cbSWOP-%d", i])];
        }
        //[cbSWOP setFont:[NSFont fontWithName:@"Arial" size:10]];
        [cbSWOP setFrame:NSMakeRect(2,heightNow-20,iViewW-4,25)];
        self.m_cbSWOpePattern = cbSWOP;
        [super addSubview:cbSWOP];
        heightNow=heightNow-25;
    }

    // SW Operation Result
    {
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];

        }

        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"SW Operation Result"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow-20;

        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];

        }
        heightNow=heightNow-6;

        // Screen Transition
        NSTextField * lbScreenTran = [[NSTextField alloc] init];
        [lbScreenTran setBezeled:false];
        [lbScreenTran setStringValue:@"Screen Transition"];
        [lbScreenTran setSelectable:false];
        [lbScreenTran setEditable:false];
        [lbScreenTran setDrawsBackground:false];
        [lbScreenTran setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbScreenTran setTextColor:colSubTitle];
        [lbScreenTran setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:lbScreenTran];
        heightNow=heightNow-15;

        NSTextField * tfScreenTran = [[NSTextField alloc] init];
        [tfScreenTran setBezeled:false];
        [tfScreenTran setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfScreenTran setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:tfScreenTran];
        self.m_tfSWOpeResScreenTransition = tfScreenTran;
        heightNow=heightNow-15;

        // Start Function
        NSTextField * lbStartFunc = [[NSTextField alloc] init];
        [lbStartFunc setBezeled:false];
        [lbStartFunc setStringValue:@"Start Function"];
        [lbStartFunc setSelectable:false];
        [lbStartFunc setEditable:false];
        [lbStartFunc setDrawsBackground:false];
        [lbStartFunc setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbStartFunc setTextColor:colSubTitle];
        [lbStartFunc setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:lbStartFunc];
        heightNow=heightNow-15;

        NSTextField * tfStartFunc = [[NSTextField alloc] init];
        [tfStartFunc setBezeled:false];
        [tfStartFunc setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfStartFunc setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:tfStartFunc];
        self.m_tfSWOpeResStartFunction = tfStartFunc;
        heightNow=heightNow-15;

        // Setting Value Change
        NSTextField * lbSetValChange = [[NSTextField alloc] init];
        [lbSetValChange setBezeled:false];
        [lbSetValChange setStringValue:@"Setting Value Change"];
        [lbSetValChange setSelectable:false];
        [lbSetValChange setEditable:false];
        [lbSetValChange setDrawsBackground:false];
        [lbSetValChange setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbSetValChange setTextColor:colSubTitle];
        [lbSetValChange setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:lbSetValChange];
        heightNow=heightNow-15;

        NSTextField * tfSetValChange = [[NSTextField alloc] init];
        [tfSetValChange setBezeled:false];
        [tfSetValChange setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfSetValChange setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:tfSetValChange];
        self.m_tfSWOpeResSetValChange = tfSetValChange;
        heightNow=heightNow-15;

        // Setting Value Change
        NSTextField * lbOther = [[NSTextField alloc] init];
        [lbOther setBezeled:false];
        [lbOther setStringValue:@"Other"];
        [lbOther setSelectable:false];
        [lbOther setEditable:false];
        [lbOther setDrawsBackground:false];
        [lbOther setFont:[NSFont fontWithName:@"Arial" size:11]];
        [lbOther setTextColor:colSubTitle];
        [lbOther setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:lbOther];
        heightNow=heightNow-15;

        NSTextField * tfOther = [[NSTextField alloc] init];
        [tfOther setBezeled:false];
        [tfOther setFont:[NSFont fontWithName:@"Arial" size:11]];
        [tfOther setFrame:NSMakeRect(0,heightNow-15,iViewW,15)];
        [super addSubview:tfOther];
        self.m_tfSWOpeResOther = tfOther;
        heightNow=heightNow-15;
    }

    heightNow=heightNow-10;
    // Beep
    {
        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];

        }

        NSTextField * lbSubTitle = [[NSTextField alloc] init];
        [lbSubTitle setBezeled:false];
        [lbSubTitle setStringValue:@"Beep"];
        [lbSubTitle setSelectable:false];
        [lbSubTitle setEditable:false];
        [lbSubTitle setDrawsBackground:false];
        [lbSubTitle setTextColor:colSubTitle];
        [lbSubTitle setFont:[NSFont fontWithName:@"Arial" size:12]];
        [lbSubTitle setFrame:NSMakeRect(0,heightNow-20,iViewW,20)];
        [super addSubview:lbSubTitle];
        heightNow=heightNow-20;

        // split line
        {
            NSView * splitLine = [[NSView alloc] init];
            [splitLine setFrame:NSMakeRect(0,heightNow,iViewW,1)];
            [splitLine setWantsLayer:true];
            [[splitLine layer] setBackgroundColor:[colSplitLine CGColor]];
            [super addSubview:splitLine];

        }
        heightNow=heightNow-6;

        NSComboBox * cbBeep = [[NSComboBox alloc] init];
        [cbBeep setSelectable:false];
        for (int i=0; i<100; i++) {
            [cbBeep addItemWithObjectValue:([NSString stringWithFormat:@"cbBeep-%d", i])];
        }
        [cbBeep setFrame:NSMakeRect(2,heightNow-25,iViewW-4,25)];
        [super addSubview:cbBeep];
        self.m_cbBeep = cbBeep;
        heightNow=heightNow-25;
    }
    
    // test data set
    
    return self;
}

- (NSInteger)numberOfItemsInComboBox:(NSComboBox *)aComboBox {
    
    return [self.conditionsList count];
}

- (id)comboBox:(NSComboBox *)aComboBox objectValueForItemAtIndex:(NSInteger)index {
    
    return self.conditionsList[index];
}

- (void)comboBoxSelectionDidChange:(NSNotification *)notification {
    
    
    NSComboBox *comboBox = notification.object;
    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
    
    NSLog(@"comboBoxSelectionDidChange selected item %@",self.conditionsList[selectedIndex]);
    
    [self.m_SCPVCurrent setHidden:true];
    self.m_SCPVCurrent = self.conditionsViews[selectedIndex];
//    if (self.conditionsList[selectedIndex] == @"Display") {
//        self.m_SCPVCurrent = self.m_SCPVDisplay;
//    }
//    if (self.conditionsList[selectedIndex] == @"SW Select") {
//        self.m_SCPVCurrent = self.m_SCPVSWSelect;
//    }
//    if (self.conditionsList[selectedIndex] == @"SW ToneDown-Motion") {
//        self.m_SCPVCurrent = self.m_SCPVSWToneDownMotion;
//    }
//    if (self.conditionsList[selectedIndex] == @"SW ToneDown-Except In Motion") {
//        self.m_SCPVCurrent = self.m_SCPVSWToneDownExceptInMotion;
//    }
//    if (self.conditionsList[selectedIndex] == @"Test/Image Delete In Motion") {
//        self.m_SCPVCurrent = self.m_SCPVTestOrImageDeleteInMotion;
//    }
    [self.m_SCPVCurrent setHidden:false];
}

- (void)comboBoxSelectionIsChanging:(NSNotification *)notification {
//    NSComboBox *comboBox = notification.object;
//    NSInteger selectedIndex = comboBox.indexOfSelectedItem;
//    
//    NSLog(@"comboBoxSelectionIsChanging selected item %@",self.datas[selectedIndex]);
}


- (void)drawRect:(NSRect)dirtyRect
{
    [super drawRect:dirtyRect];
    //NSRectFill(dirtyRect);
}

-(void)onSaveButtonClick:(id)sender
{
    NSLog(@"onSaveButtonClick");
    if (self.m_delegate) {
        [self.m_delegate onSaveButtonClick];
    }
}

@end

