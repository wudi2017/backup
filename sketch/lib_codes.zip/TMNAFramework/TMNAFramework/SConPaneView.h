//
//  SConPaneView.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/21.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef SConPaneView_h
#define SConPaneView_h

#import <Cocoa/Cocoa.h>

@interface SConPaneView : NSView

-(instancetype)init;
-(void)setModelData:(NSMutableDictionary*)modelData;
-(NSMutableDictionary*)getModelData;
-(void)clearModelData;

@property NSTextField * m_tfA;
@property NSTextField * m_tfB;
@property NSTextField * m_tfC;
@property NSTextField * m_tfFormula;
@property NSTextField * m_tfSamePartsID;
@property NSTextField * m_tfSameScreenID;
@property NSTextField * m_tfElse;
/*
 model data (NSMutableDictionary NSMutableArray)
 
 modelData =
 {
    "A":"xx",
    "B":"xx",
    "C":"xx",
    "Formula":"xx",
    "SamePartsID":"xx",
    "SameScreenID":"xx",
    "Else":"xx",
 }
*/

@end

#endif /* SConPaneView_h */
