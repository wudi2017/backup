//
//  SCommon.m
//  sketchPluginFramework
//
//  Created by navibase on 2018/6/26.
//  Copyright © 2018年 iauto. All rights reserved.
//

#import "SCommon.h"

@implementation SCommon

+ (instancetype)shared {
    NSLog(@"share SCommon begin");
    static SCommon *scommon = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        scommon = [[SCommon alloc] init];
        scommon.m_memPropMap = [NSMutableDictionary dictionary];
    });
    NSLog(@"share SCommon end");
    
    return scommon;
}
-(NSString *)TaskRun:(NSString *)exefile param:(NSString*)args
{
    NSTask *task;
    task = [[NSTask alloc] init];
    // [task setCurrentDirectoryPath: @"/bin/bash"];
    [task setLaunchPath: exefile];
    
    if (nil != args) {
        NSArray *arguments;
        arguments = [NSArray arrayWithObjects:args,nil];
        [task setArguments: arguments];
    }
    
    NSPipe *pipe;
    pipe = [NSPipe pipe];
    [task setStandardOutput: pipe];
    
    NSFileHandle *file;
    file = [pipe fileHandleForReading];
    
    [task launch];
    
    NSData *data;
    data = [file readDataToEndOfFile];
    
    NSString *string;
    string = [[NSString alloc] initWithData: data
                                   encoding: NSUTF8StringEncoding];
    NSLog (@"got%@\n", string);
    
    return string;
}

-(bool)setMemProperty:(NSString *)key Value:(NSObject*)val
{
    [self.m_memPropMap setObject:val forKey:key];
    return true;
}
-(NSObject *)getMemProperty:(NSString *)key
{
    return [self.m_memPropMap objectForKey:key];
}



@end
