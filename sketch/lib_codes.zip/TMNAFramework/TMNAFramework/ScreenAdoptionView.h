//
//  ScreenAdoptionView.h
//  sketchPluginFramework
//
//  Created by nb on 2017/2/2.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef ScreenAdoptionView_h
#define ScreenAdoptionView_h

#import <Cocoa/Cocoa.h>

@interface SAComboBoxCell: NSComboBoxCell
- (id) init;
@end

@interface SATableView : NSTableView
- (id) init;
@property NSString* name;
@end

@interface ScreenAdoptionViewDelegate : NSObject
-(void)onSaveButtonClick;
-(void)onCancelButtonClick;
@end

@interface ScreenAdoptionView : NSView

+ (id) instance;

-(void)setModelData:(NSMutableDictionary*)modelData;
-(NSMutableDictionary*)getModelData;
-(void)clearModelData;
-(NSMutableDictionary*)getTestModelData;
-(void)setDelegage:(ScreenAdoptionViewDelegate*)delegage;

@property NSMutableDictionary* m_modelData;
/*
 data={
    "Region":{"Current":"X","List":["Y","X"]},
    "X":{
        "Toyota":{
            "Available":{"Entry DA":"1", "T1":"2", "T2":"3", "T-EMVN":"4"},
            "Unavailable":{"Entry DA":"5", "T1":"6", "T2":"7", "T-EMVN":"8"}
        },
        "Lexus":{
            "Available":{"L1":"2", "L1.5":"3", "L2":"4"},
            "Unavailable":{"L1":"6", "L1.5":"7", "L2":"8"}
        }
    },
    "Y":{
        "Toyota":{
            "Available":{"Entry DA":"1", "T1":"2", "T2":"3", "T-EMVN":"4"},
            "Unavailable":{"Entry DA":"5", "T1":"6", "T2":"7", "T-EMVN":"8"}
        },
        "Lexus":{
            "Available":{"L1":"2", "L1.5":"3", "L2":"4"},
            "Unavailable":{"L1":"6", "L1.5":"7", "L2":"8"}
        }
    }
 }
 */

@property NSComboBox * m_cbRegon;
@property SATableView * m_tableViewToyota;
@property SATableView * m_tableViewLexus;
@property NSMutableDictionary *m_tableDataToyota;
@property NSMutableDictionary *m_tableDataLexus;
@property ScreenAdoptionViewDelegate * m_delegate;

@end


#endif /* ScreenAdoptionView_h */
