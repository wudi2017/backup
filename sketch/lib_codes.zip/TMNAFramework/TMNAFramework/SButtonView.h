//
//  SButton.h
//  sketchPluginFramework
//
//  Created by navibase on 2018/7/5.
//  Copyright © 2018年 iauto. All rights reserved.
//

#ifndef SButton_h
#define SButton_h

#import <Cocoa/Cocoa.h>

@interface SButtonView : NSButton

-(instancetype)init;
-(void)setImage:(NSImage *)img;
-(void)setPushDownImage:(NSImage *)img;

@property NSImageView * m_imageView;
@property NSImage * m_defaultImg;
@property NSImage * m_pushDownImg;

@end

#endif /* SButton_h */
