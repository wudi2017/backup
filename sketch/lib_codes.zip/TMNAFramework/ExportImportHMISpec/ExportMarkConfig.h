//
//  ExportMarkConfig.h
//  TMNAFramework
//
//  Created by wuyuchi on 2019/1/21.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface ExportMarkConfig : NSObject

-(void) exportMarkConfig:(NSString*)filePath;
-(BOOL) importMarkConfig:(NSString*)fileName;
-(void) resetExportMarkConfig;

@property NSMutableDictionary* m_exportMarkInfo;
@property NSString*            m_imagePath;

@end

NS_ASSUME_NONNULL_END
