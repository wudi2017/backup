//
//  ExportHMISpec.h
//  TMNAFramework
//
//  Created by wuyuchi on 2018/12/27.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "Sketch.h"
#import "CLog.h"
#import "SketchCommon.h"
#import "CFileUtils.h"

NS_ASSUME_NONNULL_BEGIN

@interface ExportHMISpec : NSObject

-(instancetype)init;
-(BOOL) startExportHMISpec;
-(void) setPageSelectConfig:(NSMutableDictionary*) config;

-(BOOL)checkIsNeedExport:(id<MSLayer>)targetLayer correspondLayer:(id<MSLayer>)correspondLayer level:(NSInteger)level;
-(BOOL) checkIsContinue:(NSInteger)level correspondLayer:(id<MSLayer>)correspondLayer layer:(id<MSLayer>)targetLayer;
-(BOOL) isLayerIgnored:(id<MSLayer>)layer;
    
@property NSUInteger             m_maxArtboardNum;
@property NSMutableDictionary*   m_correspondingDic; // correspondID --> {"originLayer":xx,level:xx}
@property NSMutableDictionary*   m_jsonContentInfo;
@property NSMutableDictionary*   m_pageSelectConfig;
@property NSString*              m_resFilePath;
@property BOOL                   m_debugFlag;
@property NSString*              m_debugTag;
@property NSMutableArray*        m_linkedObjectId;

@end

NS_ASSUME_NONNULL_END
