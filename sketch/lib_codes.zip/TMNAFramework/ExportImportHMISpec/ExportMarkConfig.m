//
//  ExportMarkConfig.m
//  TMNAFramework
//
//  Created by wuyuchi on 2019/1/21.
//

#import "ExportMarkConfig.h"
#import "SketchCommon.h"
#import "CFileUtils.h"

@implementation ExportMarkConfig

-(void) exportMarkConfig:(NSString*)filePath
{
    //init
    self.m_imagePath = [filePath stringByAppendingString:@"/images"];
    self.m_exportMarkInfo = [NSMutableDictionary dictionary];
    
    NSArray* pages = [SketchCommon.document pages];
    for(NSInteger pagenum=0;pagenum<[pages count];pagenum++){
        id<MSPage> curPage = [pages objectAtIndex:pagenum];
        for(NSInteger num=0;num<[[curPage layers] count];num++){
            id<MSLayer> curLayer = [[curPage layers] objectAtIndex:num];
            if([self isRootIgnore:curLayer]){
                continue;
            }
            [self makeExportMarkInfo4Node:curLayer prex:@""];
        }
    }
    NSString* sketchfileName = [SketchCommon getSketchDocumentNameWithoutVersion];
    NSString* fileName = [sketchfileName stringByAppendingString:@".json"];
    [CFileUtils writeArrayToFile:filePath FileName:fileName FileContent:self.m_exportMarkInfo];
}

-(BOOL) importMarkConfig:(NSString*)fileName
{
    self.m_imagePath = fileName;
    if(![CFileUtils fileExists:fileName]){
        return false;
    }
    self.m_exportMarkInfo = [CFileUtils readDictinaryFromJsonFile:fileName];
    id<MSDocumentData> documentData =  [[SketchCommon document] documentData];
    for(NSString* objIDKey in self.m_exportMarkInfo){
        id<MSLayer> curLayer = [documentData layerWithID:objIDKey];
        if(curLayer){
            NSDictionary* curLayerMarkInfo = [self.m_exportMarkInfo objectForKey:objIDKey];
            if(curLayerMarkInfo && [curLayerMarkInfo count]>0){
                NSString* isExportable = [curLayerMarkInfo valueForKey:@"isExportable"];
                NSString* isExpandable = [curLayerMarkInfo valueForKey:@"isExpandable"];
                NSString* isCommonSymbol = [curLayerMarkInfo valueForKey:@"isCommonSymbol"];
                NSString* isTouchable = [curLayerMarkInfo valueForKey:@"isTouchable"];
                if(isExportable){
                    if([isExportable isEqualToString:@"N"]){
                        [SketchCommon writeLayerInfo:@"iauto_export_flag" value:[NSNumber numberWithBool:false] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                    else if([isExportable isEqualToString:@"Y"]){
                        [SketchCommon writeLayerInfo:@"iauto_export_flag" value:[NSNumber numberWithBool:true] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                }
                if(isExpandable){
                    if([isExpandable isEqualToString:@"N"]){
                        [SketchCommon writeLayerInfo:@"iauto_expand_flag" value:[NSNumber numberWithBool:false] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                    else if([isExpandable isEqualToString:@"Y"]){
                        [SketchCommon writeLayerInfo:@"iauto_expand_flag" value:[NSNumber numberWithBool:true] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                }
                if(isCommonSymbol){
                    if([isCommonSymbol isEqualToString:@"N"]){
                        [SketchCommon writeLayerInfo:@"iauto_common_symbol_flag" value:[NSNumber numberWithBool:false] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                    else if([isCommonSymbol isEqualToString:@"Y"]){
                        [SketchCommon writeLayerInfo:@"iauto_common_symbol_flag" value:[NSNumber numberWithBool:true] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                }
                if(isTouchable){
                    if([isTouchable isEqualToString:@"N"]){
                        [SketchCommon writeLayerInfo:@"iauto_touchable_flag" value:[NSNumber numberWithBool:false] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                    else if([isTouchable isEqualToString:@"Y"]){
                        [SketchCommon writeLayerInfo:@"iauto_touchable_flag" value:[NSNumber numberWithBool:true] layer:curLayer keyWord:@"iautoExportConfig"];
                    }
                }
            }
        }
    }
    //self.m_exportMarkInfo
    return true;
}

-(void) makeExportMarkInfo4Node :(id<MSLayer>)layer prex:(NSString*)prex
{
    if(![self isLayerIgnored:layer]){
        NSString* imagePath = @"";
        NSString* curLayerName = [layer name];
        NSString* curLayerID = [layer objectID];
        NSString* namePath = @"";
        if([namePath isEqualToString:@""]){
            namePath = curLayerName;
        }
        else{
            namePath = [[prex stringByAppendingString:@"->"] stringByAppendingString:curLayerName];
        }
        
        NSString* symbolMasterName = [[layer parentRoot] name];
        if(![self.m_imagePath isEqualToString:@""]){
            NSString* objectID = [layer objectID];
            [SketchCommon exportLayerTofile:layer filePath:self.m_imagePath fileName:objectID];
            imagePath = [[[self.m_imagePath stringByAppendingString:@"/"] stringByAppendingString:objectID] stringByAppendingString:@".png"];
        }
        NSString* isExportable = @"default";
        NSString* isExpandable = @"default";
        NSString* isCommonSymbol = @"default";
        NSString* isTouchable = @"default";
        id iauto_flag_export = [SketchCommon readLayerInfo:@"iauto_export_flag" layer:layer keyWord:@"iautoExportConfig"];
        id iauto_isExpandable = [SketchCommon readLayerInfo:@"iauto_expand_flag" layer:layer keyWord:@"iautoExportConfig"];
        id iauto_isCommonSymbol = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:layer keyWord:@"iautoExportConfig"];
        id iauto_isTouchable = [SketchCommon readLayerInfo:@"iauto_touchable_flag" layer:layer keyWord:@"iautoExportConfig"];
        if(iauto_flag_export){
            if([iauto_flag_export boolValue] == true){
                isExportable = @"Y";
            }
            else{
                isExportable = @"N";
            }
        }
        if(iauto_isExpandable){
            if([iauto_isExpandable boolValue] == false){
                isExpandable = @"N";
            }
            else{
                isExpandable = @"Y";
            }
        }
        if(iauto_isCommonSymbol){
            if([iauto_isCommonSymbol boolValue] == true){
                isCommonSymbol = @"Y";
            }
            else{
                isCommonSymbol = @"N";
            }
        }
        if(iauto_isTouchable){
            if([iauto_isTouchable boolValue] == true){
                isTouchable = @"Y";
            }
            else{
                isTouchable = @"N";
            }
        }
        NSMutableDictionary* curInfo = [NSMutableDictionary dictionary];
        [curInfo setValue:namePath forKey:@"namePath"];
        [curInfo setValue:symbolMasterName forKey:@"symbolMasterName"];
        [curInfo setValue:imagePath forKey:@"imagePath"];
        [curInfo setValue:isExportable forKey:@"isExportable"];
        [curInfo setValue:isExpandable forKey:@"isExpandable"];
        [curInfo setValue:isCommonSymbol forKey:@"isCommonSymbol"];
        [curInfo setValue:isTouchable forKey:@"isTouchable"];
        [self.m_exportMarkInfo setObject:curInfo forKey:curLayerID];
        
        if([layer containsLayers] && [self checkIsContinue:layer]){
            for (NSInteger childNum=0; childNum<[[layer layers] count]; childNum++) {
                id<MSLayer> childLayer = [[layer layers] objectAtIndex:childNum];
                [self makeExportMarkInfo4Node:childLayer prex:namePath];
            }
        }
    }
}

-(BOOL) isRootIgnore:(id<MSLayer>)layer
{
    NSString* layerClassName = [layer className];
    //id<MSSymbolMaster>
    if([layerClassName isEqualToString:@"MSSymbolMaster"]){
        return false;
    }
    return true;
}

-(BOOL) isLayerIgnored:(id<MSLayer>)layer{
    
    if(![layer isVisible]){
        return true;
    }
    if([self checkIsAllSubsymbolIsInvisable:layer]){
        return true;
    }
    NSString* layerName = [layer name];
    NSString* className = [layer className];
    NSString* lowercaselayerName = [layerName lowercaseString];
    
    if([className containsString:@"Shape"]){
        return true;
    }
    
    if( [lowercaselayerName isEqualToString:@"ignore redline"] || [lowercaselayerName isEqualToString:@"ignore redlines"])
    {
        return true;
    }
    if( [lowercaselayerName containsString:@"elevations"] || [lowercaselayerName containsString:@"elevation"]
       || [lowercaselayerName containsString:@"~shapes/"] || [lowercaselayerName containsString:@"Route Preview"]
       || [lowercaselayerName containsString:@"blank"] || [lowercaselayerName containsString:@"fade"]
       || [lowercaselayerName containsString:@"guide"] || [lowercaselayerName containsString:@"color"]
       || [lowercaselayerName containsString:@"shapes/rectangle"] || [lowercaselayerName containsString:@"bitmap"])
    {
        return true;
    }
    if ( [layerName containsString:@"🎨/Fill/"] || [layerName containsString:@"🎨/fill/"]
        || [layerName containsString:@"Spec/Tap Area"] || [layerName containsString:@"Map Gradient"])
    {
        return true;
    }
    if([self checkIsTextInstance:layer]){
        NSString* text = [self getTextInstanceValue:layer];
        //[[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0
        if([text isEqualToString:@""] || [[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] == 0){
            return true;
        }
    }
    
    return false;
}

-(BOOL) checkIsContinue:(id<MSLayer>)layer
{
    if(layer){
        NSString* name = [layer name];
        NSString* className = [layer className];
        //id<MSSymbolMaster>
        if([className isEqualToString:@"MSSymbolMaster"]){
            if([name containsString:@"Icon/"] || [name containsString:@"text/"] || [name containsString:@"Images/"]){
                return false;
            }
        }
        return true;
    }
    return false;
}

- (BOOL) checkIsAllSubsymbolIsInvisable:(id<MSLayer>)layer
{
    if(layer){
        if([layer containsLayers]){
            NSArray* allLayers = [layer layers];
            for(NSInteger num=0;num<[allLayers count];num++){
                id<MSLayer> childLayer = [allLayers objectAtIndex:num];
                if([childLayer isVisible]){
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    return true;
}

-(BOOL) checkIsTextInstance:(id<MSLayer>)layer
{
    if ([[layer className] isEqualToString:@"MSTextLayer"]) {
        return true;
    }
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        id<MSSymbolInstance> instance = layer;
        NSMutableArray* overridesPoints = [instance overridePoints];
        if (nil != overridesPoints && 1 == [overridesPoints count]) {
            id<MSOverridePoint> overridePoint = [overridesPoints objectAtIndex:0];
            if (nil != overridePoint) {
                NSString* overridesVal = [overridePoint name];
                if (nil != overridesVal && [overridesVal rangeOfString:@"_stringValue"].location != NSNotFound) {
                    if (48 == [overridesVal length]) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}
-(NSString*) getTextInstanceValue:(id<MSLayer>)layer
{
    NSString* contentValue = @"";
    if ([[layer className] isEqualToString:@"MSTextLayer"]) {
        id<MSTextLayer> textLayer = layer;
        contentValue = [textLayer stringValue];
    }
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        id<MSSymbolInstance> instance = layer;
        NSMutableDictionary* overrides = [instance overrides];
        if (nil != overrides && [overrides count] > 0) {
            for (NSString* key in overrides) {
                contentValue = [overrides objectForKey:key];
                break;
            }
        }
    }
    return contentValue;
}

-(void) resetExportMarkConfig
{
//    NSArray* pages = [SketchCommon.document pages];
//    for(NSInteger pagenum=0;pagenum<[pages count];pagenum++){
//        id<MSPage> curPage = [pages objectAtIndex:pagenum];
//        for(NSInteger num=0;num<[[curPage layers] count];num++){
//            id<MSLayer> curLayer = [[curPage layers] objectAtIndex:num];
//            [self resetExportMarkConfig4Node:curLayer];
//        }
//    }
    if([[SketchCommon selection] count] > 0){
        NSArray* selections = [SketchCommon selection];
        for(NSInteger num=0;num<[selections count];num++){
            id<MSLayer> curLayer = [selections objectAtIndex:num];
            [self resetExportMarkConfig4Node:curLayer];
        }
    }
}

-(void) resetExportMarkConfig4Node:(id<MSLayer>)layer
{
    if(layer){
        [SketchCommon writeLayerInfo:@"iauto_expand_flag" value:nil layer:layer keyWord:@"iautoExportConfig"];
        [SketchCommon writeLayerInfo:@"iauto_export_flag" value:nil layer:layer keyWord:@"iautoExportConfig"];
        [SketchCommon writeLayerInfo:@"iauto_touchable_flag" value:nil layer:layer keyWord:@"iautoExportConfig"];
        [SketchCommon writeLayerInfo:@"iauto_common_symbol_flag" value:nil layer:layer keyWord:@"iautoExportConfig"];
//        if([layer containsLayers]){
//            for(NSInteger childNum=0; childNum<[[layer layers] count]; childNum++){
//                id<MSLayer> childLayer = [[layer layers] objectAtIndex:childNum];
//                [self resetExportMarkConfig4Node:childLayer];
//            }
//        }
    }
}
@end
