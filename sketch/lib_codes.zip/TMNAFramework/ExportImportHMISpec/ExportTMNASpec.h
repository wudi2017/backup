//
//  ExportTMNASpec.h
//  TMNAFramework
//
//  Created by wuyuchi on 2019/1/26.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "Sketch.h"
#import "CLog.h"
#import "SketchCommon.h"
#import "CFileUtils.h"
#import "CoreDataEngine.h"

NS_ASSUME_NONNULL_BEGIN

@interface ExportTMNASpec : NSObject

-(instancetype)init;
-(BOOL) startExportHMISpec;
-(void) setPageSelectConfig:(NSMutableDictionary*) config;

-(BOOL)checkIsNeedExport:(CoreDataIterator *)treeNode;
-(BOOL)checkIsNodeIgnore:(CoreDataIterator*)treeNode;
-(BOOL) isLayerIgnored:(id<MSLayer>)layer;

@property NSUInteger             m_maxArtboardNum;
@property NSMutableDictionary*   m_jsonContentInfo;
@property NSMutableDictionary*   m_pageSelectConfig;
@property NSString*              m_resFilePath;
@property NSMutableDictionary*   m_allMetadata;
@property NSMutableDictionary*   m_allConditionData;
@property NSMutableArray*        m_conDatakeyArray;
@property NSMutableArray*        m_metaDatakeyArray;

@end

NS_ASSUME_NONNULL_END
