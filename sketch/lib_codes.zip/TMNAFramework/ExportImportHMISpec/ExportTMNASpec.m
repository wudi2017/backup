//
//  ExportTMNASpec.m
//  TMNAFramework
//
//  Created by wuyuchi on 2019/1/26.
//

#import "ExportTMNASpec.h"
#import "MetadataUtils.h"
#import "CStringUtils.h"

@implementation ExportTMNASpec

/*******************************************************************************************************************************************************************************/
/*                                                                                                                                                                             */
/*                                                                       public interface                                                                                      */
/*                                                                                                                                                                             */
/*******************************************************************************************************************************************************************************/
-(instancetype)init {
    self = [super init];
    self.m_jsonContentInfo = [NSMutableDictionary dictionary];
    self.m_pageSelectConfig = [NSMutableDictionary dictionary];
    self.m_allMetadata = [NSMutableDictionary dictionary];
    self.m_allConditionData = [NSMutableDictionary dictionary];
    return self;
}

-(BOOL) startExportHMISpec
{
    NSOpenPanel* openPanel = [NSOpenPanel openPanel];
    [openPanel setCanChooseDirectories:true];
    [openPanel setCanChooseFiles:true];
    //[openPanel setDirectoryURL:NSHomeDirectory()];
    [openPanel setPrompt:@"Export"];
    if([openPanel runModal] != NSModalResponseOK){
        return false;
    }
    NSString* result_full_path = [[openPanel URL] path];
    self.m_resFilePath = result_full_path;
    NSString* work_result_dir = [result_full_path stringByAppendingString:@"/___exportspecs___"];
    if([CFileUtils fileExists:work_result_dir]){
        [CFileUtils removeFile:work_result_dir];
    }
    //    [CFileUtils createDirectory:work_result_dir];
    //    [CFileUtils createDirectory:imagePath];

    SketchTreeExpandPolicyHMISpec* expandPolicy = [[SketchTreeExpandPolicyHMISpec alloc] init];
    [[CoreDataEngine instance] setSketchTreeExpandPolicy:expandPolicy];
    NSMutableArray<CoreDataTree*>* CoreDataTrees = [[CoreDataEngine instance] coreDataPageTrees];
    for (int iCoreDataTree = 0; iCoreDataTree < [CoreDataTrees count] ;iCoreDataTree++) {
        CoreDataTree* coreDataTree = [CoreDataTrees objectAtIndex:iCoreDataTree];
        NSString* pageName = [coreDataTree pageName];
//        if([SketchCommon isPageIgnored:curPage]){
//            continue;
//        }
        if(![self checkPageIsIgnore:pageName]){
            [coreDataTree load];
            CoreDataIterator* it = [coreDataTree rootIterator];
            [self generatePartID:it];
            id<MSPage> curPage = [it originLayer];
            [self distributeMetadata:curPage];
            [self distributeConditionData:curPage];

            [self makeJsonInfo4Page:it];
            [coreDataTree unload];
        }
    }
    return true;
}

-(void)setPageSelectConfig:(NSMutableDictionary*) config
{
    [self.m_pageSelectConfig setDictionary:config];
}

/*******************************************************************************************************************************************************************************/
/*                                                                                                                                                                             */
/*                                                                       check interface                                                                                       */
/*                                                                                                                                                                             */
/*******************************************************************************************************************************************************************************/
-(BOOL)checkPageIsIgnore:(NSString*)pageName
{
    if(self.m_pageSelectConfig){
        if([self.m_pageSelectConfig valueForKey:pageName]){
            if(![[self.m_pageSelectConfig valueForKey:pageName] boolValue]){
                return true;
            }
        }
    }
    return false;
}

-(BOOL)checkIsNodeIgnore:(CoreDataIterator*)treeNode
{
    if(treeNode){
        NSString* treeNodeName = [treeNode name];
        NSString* treeNodeClass = [treeNode className];
        if([treeNodeClass isEqualToString:@"MSPage"]){
            return true;
        }
        else if([treeNodeClass isEqualToString:@"MSArtboardGroup"]){
            if([treeNodeName containsString:@"User Flows"]){
                return  true;
            }
            CGFloat width = [treeNode rect].size.width;
            CGFloat heigth = [treeNode rect].size.height;
            if(width < 960.00 || heigth < 540.00){
                return true;
            }
            return false;
        }
        else{
            NSString* lowercaselayerName = [treeNodeName lowercaseString];
            if( [lowercaselayerName isEqualToString:@"ignore redline"] || [lowercaselayerName isEqualToString:@"ignore redlines"])
            {
                return true;
            }

            if( [lowercaselayerName containsString:@"elevations"] || [lowercaselayerName containsString:@"elevation"]
               || [lowercaselayerName containsString:@"~shapes/"] || [lowercaselayerName containsString:@"Route Preview"]
               || [lowercaselayerName containsString:@"blank"] || [lowercaselayerName containsString:@"fade"]
               || [lowercaselayerName containsString:@"guide"] || [lowercaselayerName containsString:@"color"]
               || [lowercaselayerName containsString:@"shapes/rectangle"] || [lowercaselayerName containsString:@"bitmap"])
            {
                return true;
            }

            if ( [treeNodeName containsString:@"🎨/Fill/"] || [treeNodeName containsString:@"🎨/fill/"]
                || [treeNodeName containsString:@"Spec/Tap Area"] || [treeNodeName containsString:@"Map Gradient"]
                 || [treeNodeName containsString:@"TODO"])
            {
                return true;
            }
            id<MSLayer> layer = [treeNode expandLayer];
            if(layer){
                if([self isTextLayerIgnored: layer]){
                    return true;
                }
                if([self isPositionIgnore: layer]){
                    return true;
                }
            }
        }
    }
    return false;
}

-(BOOL)checkIsNeedExport:(CoreDataIterator *)treeNode
{
    if(!treeNode){
        return false;
    }
    NSString* targetLayerName = [treeNode name];
    id<MSLayer> correspondLayer = [treeNode expandLayer];
    id<MSLayer> originLayer = [treeNode originLayer];
    if([[treeNode type] isEqualToString:CoreDataIteratorType_Replaced]){
        originLayer = [treeNode replacedLayerMaster];
    }
    NSString* targetLayerClassName = [originLayer className];
    if(![correspondLayer isVisible]){
        return false;
    }
    if([targetLayerClassName isEqualToString:@"MSArtboardGroup"]){
        return true;
    }
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_export_flag" layer:originLayer keyWord:@"iautoExportConfig"];
    BOOL export_flag = false;
    if(flag){
        if([flag integerValue] == 1){
            export_flag = true;
        }
    }
    else {
        NSString* masterflag = nil;
        if([targetLayerClassName isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = originLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            masterflag = [SketchCommon readLayerInfo:@"iauto_export_flag" layer:master keyWord:@"iautoExportConfig"];
            if(masterflag){
                if([masterflag integerValue] == 1){
                    export_flag = true;
                }
            }
        }
        if(!masterflag){
            if([self checkIsNodeIgnore:treeNode]){
                return false;
            }
            if([targetLayerClassName isEqualToString:@"MSSymbolInstance"] || [targetLayerClassName isEqualToString:@"MSSymbolMaster"]){
                if([targetLayerName containsString:@"Images/"] || [targetLayerName containsString:@"Icon/"]){
                    return true;
                }
                else if([SketchCommon checkIsTextInstance:correspondLayer]){
                    NSString* text = [SketchCommon getTextInstanceValue:correspondLayer];
                    if([text isEqualToString:@""] || [[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] == 0){
                        return false;
                    }
                    return true;
                }
            }
        }
    }
    return export_flag;
}

-(BOOL) checkIsContinue:(CoreDataIterator *)treeNode
{
    if(!treeNode || ![treeNode originLayer] || ![treeNode expandLayer]){
        return false;
    }

    NSString* targetLayerName = [treeNode name];
    id<MSLayer> correspondLayer = [treeNode expandLayer];
    id<MSLayer> originLayer = [treeNode originLayer];
    if([[treeNode type] isEqualToString:CoreDataIteratorType_Replaced]){
        originLayer = [treeNode replacedLayerMaster];
    }
    NSString* targetLayerClassName = [originLayer className];
    if(![correspondLayer isVisible]){
        return false;
    }
    if([targetLayerClassName isEqualToString:@"MSArtboardGroup"]){
        return true;
    }
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_expand_flag" layer:originLayer keyWord:@"iautoExportConfig"];
    BOOL expand_flag = true;
    if(flag){
        if([flag integerValue] == 0){
            expand_flag = false;
        }
    }
    else{
        NSString* masterflag = nil;
        if([targetLayerClassName isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = originLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            masterflag = [SketchCommon readLayerInfo:@"iauto_expand_flag" layer:master keyWord:@"iautoExportConfig"];
            if(masterflag){
                if([masterflag integerValue] == 0){
                    return false;
                }
            }
        }
        if(!masterflag){
            if([self checkIsNodeIgnore:treeNode]){
                return false;
            }
            if([targetLayerClassName isEqualToString:@"MSSymbolInstance"] || [targetLayerClassName isEqualToString:@"MSSymbolMaster"]){
                if([targetLayerName containsString:@"Images/"] || [targetLayerName containsString:@"Icon/"] || [targetLayerName containsString:@"text/"]){
                    return false;
                }
            }
        }
    }
    return expand_flag;
}

-(BOOL) checkIsCommonSymbol:(id<MSLayer>)targetLayer
{
    BOOL commonFlag = false;
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:targetLayer keyWord:@"iautoExportConfig"];
    if(!flag){
        NSString* className = [targetLayer className];
        if([className isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = targetLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            if(master){
                flag = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:master keyWord:@"iautoExportConfig"];
            }
        }
    }
    if(flag && [flag integerValue] == 1){
        return true;
    }
    return commonFlag;
    //NSString* commomFlag = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:curnode_origin keyWord:@"iautoExportConfig"];
}

-(BOOL) checkIsTouchable:(id<MSLayer>)targetLayer
{
    BOOL touchFlag = false;
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_touchable_flag" layer:targetLayer keyWord:@"iautoExportConfig"];
    if(!flag){
        NSString* className = [targetLayer className];
        if([className isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = targetLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            if(master){
                flag = [SketchCommon readLayerInfo:@"iauto_touchable_flag" layer:master keyWord:@"iautoExportConfig"];
            }
        }
    }
    if(flag && [flag integerValue] == 1){
        return true;
    }
    return touchFlag;
    //
}

-(BOOL) isLayerIgnored:(id<MSLayer>)layer{

    NSString* layerName = [layer name];
    NSString* lowercaselayerName = [layerName lowercaseString];
    if( [lowercaselayerName isEqualToString:@"ignore redline"] || [lowercaselayerName isEqualToString:@"ignore redlines"])
    {
        return true;
    }

    if( [lowercaselayerName containsString:@"elevations"] || [lowercaselayerName containsString:@"elevation"]
       || [lowercaselayerName containsString:@"~shapes/"] || [lowercaselayerName containsString:@"Route Preview"]
       || [lowercaselayerName containsString:@"blank"] || [lowercaselayerName containsString:@"fade"]
       || [lowercaselayerName containsString:@"guide"] || [lowercaselayerName containsString:@"color"]
       || [lowercaselayerName containsString:@"shapes/rectangle"] || [lowercaselayerName containsString:@"bitmap"])
    {
        return true;
    }

    if ( [layerName containsString:@"🎨/Fill/"] || [layerName containsString:@"🎨/fill/"]
        || [layerName containsString:@"Spec/Tap Area"] || [layerName containsString:@"Map Gradient"])
    {
        return true;
    }
    return false;
}

-(BOOL) isTextLayerIgnored:(id<MSLayer>)targetLayer
{
    NSString* textLayerID = nil;
    NSString* textOverridesContent = @"";
    NSString* targetLayerName = [targetLayer name];

    if(![targetLayerName containsString:@"text/"]){
        return false;
    }

    id<MSSymbolMaster> master = nil;

    NSString* targetLayerClass = [targetLayer className];

    if([targetLayerClass isEqualToString:@"MSSymbolInstance"] ){
        id<MSSymbolInstance> instance = targetLayer;
        master = [instance symbolMaster];
    }
    else if([targetLayerClass isEqualToString:@"MSSymbolMaster"]){
        master = targetLayer;
    }else{
        return false;
    }

    if(master != nil){
        NSArray* layerChildern = [master children];
        for(int i= 0; i<[layerChildern count]; i++){
            if([[layerChildern[i] className] isEqualToString:@"MSTextLayer"] ){
                textLayerID = [layerChildern[i] objectID];
                break;
            }
        }
    }

    if(textLayerID != nil && [targetLayerClass isEqualToString:@"MSSymbolInstance"]){
        NSDictionary* overrides = [targetLayer overrides];
        if(overrides && [overrides valueForKey: textLayerID]){
            textOverridesContent = [overrides valueForKey: textLayerID];
        }
        if([textOverridesContent isEqualToString:@""] || [textOverridesContent isEqualToString:@" "] || [textOverridesContent isEqualToString:@"  "] ){
            return true;
        }
        else {
            return false;
        }
    }
    return false;

}

-(BOOL) isPositionIgnore:(id<MSLayer>)layer
{
    id<MSLayer> artboard = [layer parentRoot];

    CGRect layerObjAbsRect = [[layer absoluteRect] absoluteRect];
    CGRect artboardAbsRect = [[artboard absoluteRect] absoluteRect];

    int layerX = layerObjAbsRect.origin.x;
    int layerY = layerObjAbsRect.origin.y;
    int layerW = layerObjAbsRect.size.width;
    int layerH = layerObjAbsRect.size.height;

    int artboardX = artboardAbsRect.origin.x;
    int artboardY = artboardAbsRect.origin.y;
    int artboardW = artboardAbsRect.size.width;
    int artboardH = artboardAbsRect.size.height;

    if ( layerX > artboardX +artboardW ) {
        return true;
    }
    if ( layerY > artboardY + artboardH) {
        return true;
    }

    if ( layerX + layerW < artboardX ) {
        return true;
    }
    if ( layerY + layerH < artboardY ) {
        return true;
    }

    return false;
}


/*******************************************************************************************************************************************************************************/
/*                                                                                                                                                                             */
/*                                                                       some  interface                                                                                       */
/*                                                                                                                                                                             */
/*******************************************************************************************************************************************************************************/

-(void) makeJsonInfo4Page:(CoreDataIterator*) treeNode
{
    NSString* fileName = [treeNode name];
    for(NSInteger artboardNum=0;artboardNum<[[treeNode childrens] count];artboardNum++){
        CoreDataIterator* curTreeNode = [[treeNode childrens] objectAtIndex:artboardNum];
        if(![self checkIsNodeIgnore:curTreeNode]){
            NSMutableDictionary* curNodeJsonInfo = [NSMutableDictionary dictionary];
            NSString* curNodeObjectID = [curTreeNode objectID];
//            NSMutableDictionary* curNodeSketchJsonInfo = [NSMutableDictionary dictionary];
//            NSString* curNodeName = [curTreeNode name];
//            [curNodeSketchJsonInfo setObject:curNodeObjectID forKey:@"uuid"];
//            [curNodeJsonInfo setObject:curNodeSketchJsonInfo forKey:@"sketchInfo"];
//            [curNodeJsonInfo setObject:curNodeName forKey:@"Parts Name"];
            id<MSLayer> artboard_origin = [curTreeNode originLayer];
            id<MSLayer> artboard_correspond = [curTreeNode expandLayer];
            id<MSPluginCommand> command = [SketchCommon command];
            NSMutableArray* metaData = [command valueForKey:@"metadata" onLayer:artboard_origin forPluginIdentifier:@"tmnaMM"];
            NSMutableDictionary * metaDic = [self makeMetadata: metaData];
            NSMutableDictionary* screenInfoJsonIndo = [NSMutableDictionary dictionary];
            [curNodeJsonInfo setValue:screenInfoJsonIndo forKey:@"ScreenInfo"];
            [self makeJsonExcelInfo4Node: artboard_origin toCurInfo :screenInfoJsonIndo byMeta: metaDic];
            [self makeJsonSketchInfo4Artboard: artboard_correspond originLayer:artboard_origin toCurInfo:screenInfoJsonIndo];
            NSMutableDictionary* destGradeInfoIndo = [NSMutableDictionary dictionary];
            [curNodeJsonInfo setValue:destGradeInfoIndo forKey:@"DestGradeInfo"];
            [self makeJsonDestGradeInfo4Node: artboard_origin toCurInfo :destGradeInfoIndo byMeta: metaDic];

            NSMutableDictionary* curNodeChildJsonInfo = [NSMutableDictionary dictionary];
            [curNodeJsonInfo setObject:curNodeChildJsonInfo forKey:@"PartsList"];
            [self.m_jsonContentInfo setValue:curNodeJsonInfo forKey:curNodeObjectID];
            if([curTreeNode hasChildrens]){
                for(NSInteger num=0;num<[[curTreeNode childrens] count];num++){
                    CoreDataIterator* curChildTreeNode = [[curTreeNode childrens] objectAtIndex:num];
                    [self makeJsonInfo4Node:curChildTreeNode infoContent:curNodeChildJsonInfo];
                }
            }
        }
    }

    NSString* writhFilePth = [self.m_resFilePath stringByAppendingString:@"/___exportspecs___"];
    [CFileUtils writeArrayToFile:writhFilePth FileName:[fileName stringByAppendingString:@".json"] FileContent:self.m_jsonContentInfo];
    [self.m_jsonContentInfo removeAllObjects];
}

-(void) makeJsonInfo4Node:(CoreDataIterator*)treeNode infoContent:(NSMutableDictionary*)infoContent
{
//        NSMutableDictionary* curNodeJsonInfo = [NSMutableDictionary dictionary];
//        NSMutableDictionary* curNodeSketchJsonInfo = [NSMutableDictionary dictionary];
//        NSString* curNodeObjectID = [treeNode objectID];
//        NSString* curNodeName = [treeNode name];
//        [curNodeSketchJsonInfo setObject:curNodeObjectID forKey:@"uuid"];
//        [curNodeJsonInfo setObject:curNodeSketchJsonInfo forKey:@"sketchInfo"];
//        [curNodeJsonInfo setObject:curNodeName forKey:@"Parts Name"];

    id<MSLayer> layer_correspond = [treeNode expandLayer];
    id<MSLayer> curnode_origin = [treeNode originLayer];
    id<MSPluginCommand> command = [SketchCommon command];
    NSMutableArray * metaData = [command valueForKey:@"metadata" onLayer:layer_correspond forPluginIdentifier:@"tmnaMM"];
    NSString* name_origin = [curnode_origin name];
    NSString* nodeType = [treeNode type];
    if([nodeType isEqualToString:@"DirectCorrespond"]){
        [self getChildrenMetaData: metaData originLayer: curnode_origin correspond:layer_correspond];
    }

    NSEnumerator* metaEnumKey = [self.m_allMetadata keyEnumerator];
    self.m_metaDatakeyArray = [NSMutableArray array];
    for (NSString* key in metaEnumKey) {
        [self.m_metaDatakeyArray addObject:key];
    }
    for(NSUInteger i = 0; i < [_m_metaDatakeyArray count]; ++i) {
        if([_m_metaDatakeyArray[i] containsString:@"_state_"]) {
            NSArray* sepMeta = [_m_metaDatakeyArray[i] componentsSeparatedByString:@"_state_"];
            _m_metaDatakeyArray[i] = sepMeta[0];
        }
    }
    NSString* absoluteObjectID = [treeNode absoluteObjectID];
    NSInteger ms = -1;
    for(NSString* key in _m_metaDatakeyArray) {
        if([key isEqualToString:absoluteObjectID]) {
            ms++;
        }
    }

    if(ms > 0) {
        NSLog(@"");
    }
    NSString* layeruuid = absoluteObjectID;
    do{
        if([self checkIsNeedExport:treeNode]){
            NSMutableDictionary* curNodeJsonInfo = [NSMutableDictionary dictionary];
            [curNodeJsonInfo setValue:name_origin forKey:@"Parts Name"];
            [curNodeJsonInfo setValue:name_origin forKey:@"Display image"];
            
            NSString* partIdSufix = [NSString stringWithFormat:@"%ld", ms+1];
            NSString* curPartID = [treeNode getCustomData:@"partID"];
            if (![absoluteObjectID isEqualToString:layeruuid]) {
                curPartID = [curPartID stringByAppendingString:@"_"];
                curPartID = [curPartID stringByAppendingString:partIdSufix];
            }
            [curNodeJsonInfo setValue:curPartID forKey:@"Parts ID"];
            if([self checkIsCommonSymbol:curnode_origin]){
                [curNodeJsonInfo setValue:[NSNumber numberWithInteger:1] forKey:@"common symbol"];
            }
            else{
                [curNodeJsonInfo setValue:[NSNumber numberWithInteger:0] forKey:@"common symbol"];
            }
            [curNodeJsonInfo setValue:[treeNode getCustomData:@"iautoTouchFlag"] forKey:@"touch symbol"];


            //        if ([absoluteObjectID isEqualToString:@"38B1FAF2-76F4-40D2-A2B9-A2C8AB081142_7636796A-0D92-4AF6-A3D0-1B53E7CB43CA_state_1"]) {
            //            NSLog(@"");
            //        }

            NSMutableArray* curMetadata = [self.m_allMetadata valueForKey:absoluteObjectID];

            NSMutableDictionary* curmetaDic = [NSMutableDictionary dictionary];
            if (curMetadata) {
                curmetaDic = [self makeMetadata: curMetadata];
            }

            NSEnumerator* conEnumKey = [self.m_allConditionData keyEnumerator];
            self.m_conDatakeyArray = [NSMutableArray array];
            for (NSString* key in conEnumKey) {
                [self.m_conDatakeyArray addObject:key];
            }
            for (NSUInteger i = 0; i < [self.m_conDatakeyArray count]; ++i) {
                if ([_m_conDatakeyArray[i] containsString:@"_state_"]) {
                    NSArray* sepKey = [_m_conDatakeyArray[i] componentsSeparatedByString:@"_state_"];
                    _m_conDatakeyArray[i] = sepKey[0];
                }
            }

            [curNodeJsonInfo setValue:[self getPartsTypeforJson: curmetaDic] forKey:@"Parts Type"];
            [curNodeJsonInfo setValue:[self getTargetIDformMetaforJson: curmetaDic] forKey:@"choose target"];

            NSString* displayConditionKey = [@"displayCondition__" stringByAppendingString:absoluteObjectID];
            NSString* textImageDeleteInMotionKey = [@"textImageDeleteInMotion__" stringByAppendingString:absoluteObjectID];
            [self getMultiStateConditionDict:curNodeJsonInfo dictKey:@"Display Condition" msKey:displayConditionKey];
            [curNodeJsonInfo setValue:[self getTextOrImageInformation: curmetaDic curLayer: textImageDeleteInMotionKey] forKey:@"Text or Image information"];
            [curNodeJsonInfo setValue:[self getSWInformation: curmetaDic curLayer: absoluteObjectID ] forKey:@"SW Information"];

            [self makeJsonSketchInfo4Node:treeNode toCurInfo:curNodeJsonInfo uuid:absoluteObjectID];

            [infoContent setValue:curNodeJsonInfo forKey:absoluteObjectID];

            NSString* sufix = [NSString stringWithFormat:@"%ld", ms];
            absoluteObjectID = [layeruuid stringByAppendingString:@"_state_"];
            absoluteObjectID = [absoluteObjectID stringByAppendingString:sufix];
            ms--;
        }
        else{
            break;
        }
    }while(ms > -1);

    if([self checkIsContinue:treeNode] && [treeNode hasChildrens]){
        for(NSInteger childNum=0;childNum<[[treeNode childrens] count];childNum++){
            CoreDataIterator* curChildTreeNode = [[treeNode childrens] objectAtIndex:childNum];
            [self makeJsonInfo4Node:curChildTreeNode infoContent:infoContent];
        }
    }
}

-(void) getMultiStateConditionDict:(NSMutableDictionary*)dict dictKey:(NSString*)dictKey msKey:(NSString*)msKey
{
    NSInteger multiStateCount = -1;
    for (NSString* item in _m_conDatakeyArray) {
        if ([item isEqualToString:msKey]) {
            multiStateCount++;
        }
    }

    if (multiStateCount > 0) {
        sleep(1);
    }

    do{
        NSString* key = msKey;
        [dict setValue:[self getConditionDict:key] forKey:dictKey];
        NSString* sufix = [NSString stringWithFormat:@"%ld", multiStateCount];
        key = [key stringByAppendingString:@"_state_"];
        key = [key stringByAppendingString:sufix];
        multiStateCount--;
    }while(multiStateCount > -1);
}

-(void) generatePartID:(CoreDataIterator*) treeNode
{
    if([treeNode hasChildrens]){
        for(NSInteger artboardNum=0;artboardNum<[[treeNode childrens] count];artboardNum++){
            CoreDataIterator* artboard_correspond = [[treeNode childrens] objectAtIndex:artboardNum];
            if(![[artboard_correspond className] isEqualToString:@"MSArtboardGroup"]){
                continue;
            }
            if([self checkIsNodeIgnore:artboard_correspond]){
                continue;
            }
            if([artboard_correspond hasChildrens]){
                NSMutableArray* startNum = [NSMutableArray array]; // index:num index:char
                [startNum addObject:[NSNumber numberWithInt:1]];
                [startNum addObject:[NSNumber numberWithInt:1]];
                id<MSLayer> artboard_origin = [artboard_correspond originLayer];
                for(NSInteger num=0;num<[[artboard_correspond childrens] count];num++){
                    CoreDataIterator* curLayer = [[artboard_correspond childrens] objectAtIndex:num];
                    [self generatePartID4Node:curLayer prex:@"" artboard:artboard_origin];
                }
            }
        }
    }
}

-(void) generatePartID4Node:(CoreDataIterator *)treeNode prex:(NSString*)prex artboard:(id<MSArtboardGroup>)artboard
{
//    NSInteger index_num = [[startNum objectAtIndex:0] integerValue];
//    NSInteger char_num = [[startNum objectAtIndex:1] integerValue];
    id<MSLayer> layer_correspond = [treeNode expandLayer];
    id<MSLayer> curnode_origin = [treeNode originLayer];
    NSString* absObjectID = [treeNode absoluteObjectID];
    NSString* tempPartID = [SketchCommon readLayerInfo:absObjectID layer:artboard keyWord:@"partID"];
    if([self checkIsNeedExport:treeNode]){
        NSString* curpartID = nil;
        if(tempPartID && ![tempPartID isEqualToString:@""]){
            curpartID = tempPartID;
        }
        else{
            if([self checkIsTouchable:curnode_origin]){
                if([prex isEqualToString:@""]){
                    id tempID = [SketchCommon readLayerInfo:@"Spect_char" layer:artboard keyWord:@"Spect"];
                    if(tempID){
                        NSInteger curMax = [tempID integerValue];
                        curpartID = [CStringUtils convertNumToStr:curMax+1];
                        [SketchCommon writeLayerInfo:@"Spect_char" value:[NSNumber numberWithInteger:curMax+1] layer:artboard keyWord:@"Spect"];
                    }
                    else{
                        curpartID = [CStringUtils convertNumToStr:1];
                        [SketchCommon writeLayerInfo:@"Spect_char" value:[NSNumber numberWithInteger:1] layer:artboard keyWord:@"Spect"];
                    }
                }
                else{
                    id tempID = [SketchCommon readLayerInfo:prex layer:artboard keyWord:@"Spect"];
                    if(tempID){
                        NSInteger curMax = [tempID integerValue];
                        NSString* temp_partID = [CStringUtils convertNumToStr:curMax+1];
                        curpartID = [[prex stringByAppendingString:@"_"] stringByAppendingString:temp_partID];
                        [SketchCommon writeLayerInfo:prex value:[NSNumber numberWithInteger:curMax+1] layer:artboard keyWord:@"Spect"];
                    }
                    else{
                        NSString* temp_partID = [CStringUtils convertNumToStr:1];
                        curpartID = [[prex stringByAppendingString:@"_"] stringByAppendingString:temp_partID];
                        [SketchCommon writeLayerInfo:prex value:[NSNumber numberWithInteger:1] layer:artboard keyWord:@"Spect"];
                    }
                }
                [treeNode setCustomData:@"iautoTouchFlag" CustomData:@"1"];
                //[SketchCommon writeLayerInfo:@"iautoTouchFlag" value:[NSNumber numberWithBool:true] layer:layer_correspond keyWord:@"iautoExportConfig"];
            }
            else{
                if([prex isEqualToString:@""]){
                    id tempID = [SketchCommon readLayerInfo:@"Spect_int" layer:artboard keyWord:@"Spect"];
                    if(tempID){
                        NSInteger curMax = [tempID integerValue];
                        curpartID = [NSString stringWithFormat:@"%ld",(long)(curMax+1)];
                        [SketchCommon writeLayerInfo:@"Spect_int" value:[NSNumber numberWithInteger:curMax+1] layer:artboard keyWord:@"Spect"];
                    }
                    else{
                        curpartID = [NSString stringWithFormat:@"%ld",(long)(1)];
                        [SketchCommon writeLayerInfo:@"Spect_int" value:[NSNumber numberWithInteger:1] layer:artboard keyWord:@"Spect"];
                    }
                }
                else{
                    id tempID = [SketchCommon readLayerInfo:prex layer:artboard keyWord:@"Spect"];
                    if(tempID){
                        NSInteger curMax = [tempID integerValue];
                        NSString* temp_partID = [NSString stringWithFormat:@"%ld",(long)(curMax+1)];
                        curpartID = [[prex stringByAppendingString:@"_"] stringByAppendingString:temp_partID];
                        [SketchCommon writeLayerInfo:prex value:[NSNumber numberWithInteger:curMax+1] layer:artboard keyWord:@"Spect"];
                    }
                    else{
                        NSString* temp_partID = [NSString stringWithFormat:@"%ld",(long)(1)];
                        curpartID = [[prex stringByAppendingString:@"_"] stringByAppendingString:temp_partID];
                        [SketchCommon writeLayerInfo:prex value:[NSNumber numberWithInteger:1] layer:artboard keyWord:@"Spect"];
                    }
                }
                //[SketchCommon writeLayerInfo:@"iautoTouchFlag" value:[NSNumber numberWithBool:false] layer:layer_correspond keyWord:@"iautoExportConfig"];
            }
            [treeNode setCustomData:@"iautoTouchFlag" CustomData:@"0"];
            //NSString* partID = [treeNode getCustomData:@"partID"];
            [SketchCommon writeLayerInfo:absObjectID value:curpartID layer:artboard keyWord:@"partID"];
            NSString* ccc = [[SketchCommon command] valueForKey:absObjectID onLayer:artboard forPluginIdentifier:@"partID"];
        }

        [treeNode setCustomData:@"partID" CustomData:curpartID];
        if([self checkIsContinue:treeNode] && [treeNode hasChildrens]){
            for(NSInteger childNum=0;childNum<[[treeNode childrens] count];childNum++){
                CoreDataIterator* curLayer = [[treeNode childrens] objectAtIndex:childNum];
                [self generatePartID4Node:curLayer prex:curpartID artboard:artboard];
            }
        }
    }
    else if([self checkIsContinue:treeNode] && [treeNode hasChildrens]){
        for(NSInteger childNum=0;childNum<[[treeNode childrens] count];childNum++){
            CoreDataIterator* curLayer = [[treeNode childrens] objectAtIndex:childNum];
            [self generatePartID4Node:curLayer prex:prex artboard:artboard];
        }
    }
}

-(void) distributeMetadata:(id<MSPage>)curPage
{
    [self.m_allMetadata removeAllObjects];
    if(curPage){
        NSArray* artboards = [curPage artboards];
        for(NSInteger artboardNum=0;artboardNum<[artboards count];artboardNum++){
            id<MSArtboardGroup> curartboard = [artboards objectAtIndex:artboardNum];
            if([curartboard containsLayers]){
                for(NSInteger num=0;num<[[curartboard layers] count];num++){
                    id<MSLayer> curLayer = [[curartboard layers] objectAtIndex:num];
                    [self distributeMetadata4Node:curLayer];
                }
            }
        }
    }
}

-(void) distributeMetadata4Node:(id<MSLayer>)targetLayer
{
    NSArray* curMetadata = [SketchCommon readLayerInfo:@"metadata" layer:targetLayer keyWord:@"tmnaMM"];
    if(curMetadata){
        NSMutableArray* curNodeMetadata = [NSMutableArray array];
        for(NSInteger num=0;num<[curMetadata count];num++){
            NSMutableDictionary* childInfo = [curMetadata objectAtIndex:num];
            if(childInfo){
                if([childInfo valueForKey:@"type"] && [[childInfo valueForKey:@"type"] isEqualToString:@"child"]){
                    if([childInfo valueForKey:@"content"]){
                        NSMutableDictionary* childNodeNodeMetadata = [childInfo valueForKey:@"content"];
                        if([childNodeNodeMetadata valueForKey:@"id"] && [childNodeNodeMetadata valueForKey:@"metadata"]){
                            NSString* key = [childNodeNodeMetadata valueForKey:@"id"];
                            NSMutableArray* value = [childNodeNodeMetadata valueForKey:@"metadata"];
                            [self.m_allMetadata setValue:value forKey:key];
                        }
                    }
                }
                else{
                    [curNodeMetadata addObject:childInfo];
                }
            }
        }
        NSString* targetLayerObjectID = [targetLayer objectID];
        [self.m_allMetadata setValue:curNodeMetadata forKey:targetLayerObjectID];
    }

    if([targetLayer containsLayers]){
        for(NSInteger childNum=0;childNum<[[targetLayer layers] count];childNum++){
            id<MSLayer> childLayer = [[targetLayer layers] objectAtIndex:childNum];
            [self distributeMetadata4Node:childLayer];
        }
    }
}

-(void) distributeConditionData:(id<MSPage>)curPage
{
    if (self.m_allConditionData) {
        [self.m_allConditionData removeAllObjects];
    }

    if(curPage){
        NSArray* artboards = [curPage artboards];
        for(NSInteger artboardNum=0;artboardNum<[artboards count];artboardNum++){
            id<MSArtboardGroup> curartboard = [artboards objectAtIndex:artboardNum];
            if([curartboard containsLayers]){
                for(NSInteger num=0;num<[[curartboard layers] count];num++){
                    id<MSLayer> curLayer = [[curartboard layers] objectAtIndex:num];
                    [self distributeConditionData4Node:curLayer];
                }
            }
        }
    }
}

-(void) distributeConditionData4Node:(id<MSLayer>)targetLayer
{
//    NSDictionary* curConditionData = [SketchCommon readLayerInfo:@"screenSpecConditions" layer:targetLayer keyWord:@"tmnaMM"];
    id<MSPluginCommand> command = [SketchCommon command];
    NSDictionary* curConditionData = [command valueForKey:@"screenSpecConditions" onLayer:targetLayer forPluginIdentifier:@"tmnaMM"];
    for (NSString* key in curConditionData) {
        NSDictionary* content = [curConditionData objectForKey:key];
        [self.m_allConditionData setObject:content forKey:key];
    }
//    if(curConditionData){
//        NSMutableArray* curNodeMetadata = [NSMutableArray array];
//        for(NSInteger num=0;num<[curConditionData count];num++){
//            NSMutableDictionary* childInfo = [curConditionData objectAtIndex:num];
//            if(childInfo){
//                if([childInfo valueForKey:@"type"] && [[childInfo valueForKey:@"type"] isEqualToString:@"child"]){
//                    if([childInfo valueForKey:@"content"]){
//                        NSMutableDictionary* childNodeNodeMetadata = [childInfo valueForKey:@"content"];
//                        if([childNodeNodeMetadata valueForKey:@"id"] && [childNodeNodeMetadata valueForKey:@"metadata"]){
//                            NSString* key = [childNodeNodeMetadata valueForKey:@"id"];
//                            NSMutableArray* value = [childNodeNodeMetadata valueForKey:@"metadata"];
//                            [self.m_allMetadata setValue:value forKey:key];
//                        }
//                    }
//                }
//                else{
//                    [curNodeMetadata addObject:childInfo];
//                }
//            }
//        }
//        NSString* targetLayerObjectID = [targetLayer objectID];
//        [self.m_allMetadata setValue:curNodeMetadata forKey:targetLayerObjectID];
//    }

    if([targetLayer containsLayers]){
        for(NSInteger childNum=0;childNum<[[targetLayer layers] count];childNum++){
            id<MSLayer> childLayer = [[targetLayer layers] objectAtIndex:childNum];
            [self distributeConditionData4Node:childLayer];
        }
    }
}

/*******************************************************************************************************************************************************************************/
/*                                                                                                                                                                             */
/*                                                                  some  interface for metadata                                                                               */
/*                                                                                                                                                                             */
/*******************************************************************************************************************************************************************************/

-(NSMutableDictionary*) makeMetadata:(NSMutableArray*)originData
{
    NSMutableDictionary * ret = [NSMutableDictionary dictionary];
    for(NSInteger i = 0; i < [originData count]; i++){
        NSDictionary* data = [originData objectAtIndex:i];
        NSString* type = [data objectForKey:@"type"];
        id content = [data objectForKey:@"content"];
        if ([type isEqualToString:@"text-image-outside-input"] || [type isEqualToString:@"sw-operation-result"] || [type isEqualToString:@"Japanese"] || [type isEqualToString:@"U.S.English"] || [type isEqualToString:@"U.K.English"]) {
            NSString* contentType = [content objectForKey:@"type"];
            type = [type stringByAppendingString:@"-"];
            type = [type stringByAppendingString:contentType];
            content = [content objectForKey:@"value"];
        }

        [ret setValue: content forKey:type];
    }
    return ret;
}

-(void) makeJsonExcelInfo4Node: (id<MSLayer>)curArtboard_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo byMeta:(NSMutableDictionary *) metaData
{
    //make excel Info
    NSMutableDictionary* excelInfoJsonIndo = [NSMutableDictionary dictionary];
    [curnodeJsonIndo setValue:excelInfoJsonIndo forKey:@"excelInfo"];

    NSString* ScreenID = @"";
    NSString* ScreenName = [curArtboard_origin name];
    NSRange range =  [ScreenName rangeOfString: @"-"];
    if(range.length != 0){
        ScreenID = [ScreenName substringWithRange:NSMakeRange(0, range.location)];
        // NSCharacterSet * whitespace = [NSCharacterSet  whitespaceCharacterSet];
        ScreenID = [ScreenID stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        // [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]
    }

    [excelInfoJsonIndo setValue: ScreenID forKey:@"Screen ID"];
    [excelInfoJsonIndo setValue: [curArtboard_origin objectID] forKey:@"Basic Screen ID"];
    [excelInfoJsonIndo setValue:[ curArtboard_origin name] forKey:@"Screen Name"];
    [excelInfoJsonIndo setValue:[self getMetaRemarksforJson: metaData] forKey:@"Note"];

}

-(void) makeJsonSketchInfo4Artboard: (id<MSLayer>)curnode_correspond originLayer:(id<MSLayer>)curnode_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo
{
    NSString* objectID_origin = [curnode_origin objectID];

    NSMutableDictionary* curnodeSketchJsonInfo = [NSMutableDictionary dictionary];

    //make UUID
    [curnodeSketchJsonInfo setValue:objectID_origin forKey:@"uuid"];

    //make Rect
    NSMutableDictionary* curnodeRectJsonInfo = [NSMutableDictionary dictionary];
    CGRect currentObjAbsRect = [[curnode_origin absoluteRect] absoluteRect];

    int rectW = currentObjAbsRect.size.width;
    int rectH = currentObjAbsRect.size.height;

    NSString* w_origin = [NSString stringWithFormat:@"%d",rectW];
    NSString* h_origin = [NSString stringWithFormat:@"%d",rectH];

    [curnodeRectJsonInfo setValue:@"0" forKey:@"x"];
    [curnodeRectJsonInfo setValue:@"0" forKey:@"y"];
    [curnodeRectJsonInfo setValue:w_origin forKey:@"w"];
    [curnodeRectJsonInfo setValue:h_origin forKey:@"h"];
    [curnodeSketchJsonInfo setValue:curnodeRectJsonInfo forKey:@"Rect"];

    //make imgPath
    NSString* imgPath = [self.m_resFilePath stringByAppendingString:@"/___exportspecs___/images"];
    [SketchCommon exportLayerTofile:curnode_correspond filePath:imgPath fileName:objectID_origin];
    NSString* curimgPath = [[[imgPath stringByAppendingString:@"/"] stringByAppendingString:objectID_origin] stringByAppendingString:@".png"];
    [curnodeSketchJsonInfo setValue:curimgPath forKey:@"imgPath"];

    [curnodeJsonIndo setValue:curnodeSketchJsonInfo forKey:@"sketchInfo"];
}

-(NSString *) getMetaRemarksforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString * retobj = metaData[@"Remarks"];
    if (retobj == nil) {
        return @"";
    }

    return retobj;
}

-(void) makeJsonDestGradeInfo4Node: (id<MSLayer>)curArtboard_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo byMeta:(NSMutableDictionary *) metaData
{
    NSMutableDictionary* destGradeInfo = nil;
//    NSData *data = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
//    NSDictionary *tempDictQueryDiamond = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    NSString* tempdestGradeInfo = [SketchCommon readLayerInfo:@"ScreenAdoptionInfo" layer:curArtboard_origin keyWord:@"tmnaMM"];
    if(tempdestGradeInfo){
        NSData* data = [tempdestGradeInfo dataUsingEncoding:NSUTF8StringEncoding];
        destGradeInfo = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        //NSMutableDictionary* destGradeInfo = (NSMutableDictionary*)[SketchCommon readLayerInfo:@"ScreenAdoptionInfo" layer:curArtboard_origin keyWord:@"tmnaMM"];
    }

    NSMutableArray* dest_region_list = [NSMutableArray arrayWithObjects:@"Japan",@"Europe/Russia",@"China",@"Oceania",@"South Africa",@"HongKong / Macao",@"South East Asia",@"India",@"Taiwan",@"Middle East",@"South and Central (Brazil & Argentina)",@"South and Central",@"Korea", nil];
//    NSMutableArray * dest_region_list = @[@"Japan",@"Europe/Russia",@"China",@"Oceania",@"South Africa",@"HongKong / Macao",@"South East Asia",
//                                   @"India",@"Taiwan",@"Middle East",@"South and Central (Brazil & Argentina)",@"South and Central",@"Korea"];
    if(destGradeInfo && [destGradeInfo valueForKey:@"Region"] && [[destGradeInfo valueForKey:@"Region"] valueForKey:@"List"])
    {
        [dest_region_list removeAllObjects];
        NSMutableArray* temparray = [[destGradeInfo valueForKey:@"Region"] valueForKey:@"List"];
        [dest_region_list addObjectsFromArray:temparray];
    }
    for (int one_region_index = 0; one_region_index < [dest_region_list count]; one_region_index ++ ) {
        NSString* countryName = [dest_region_list objectAtIndex:one_region_index];
        NSMutableDictionary* oneRegionInfo = [NSMutableDictionary dictionary];
        [curnodeJsonIndo setValue:oneRegionInfo forKey:countryName];
        
        NSMutableDictionary* curdestGradeInfo = nil;
        if(destGradeInfo && [destGradeInfo valueForKey:countryName]){
            curdestGradeInfo = [destGradeInfo valueForKey:countryName];
        }
        NSMutableDictionary* LexusInfo = [NSMutableDictionary dictionary];
        [oneRegionInfo setValue:LexusInfo forKey: @"Lexus"];
        NSMutableDictionary* UnavailableInfo = [NSMutableDictionary dictionary];
        [LexusInfo setValue: UnavailableInfo forKey: @"Unavailable"];
        NSString* valueL1 = @"";
        NSString* valueL15 = @"";
        NSString* valueL2 = @"";
        if(curdestGradeInfo && [curdestGradeInfo valueForKey:@"Lexus"] && [[curdestGradeInfo valueForKey:@"Lexus"] valueForKey:@"Unavailable"]){
            NSMutableDictionary* UnavailableInfo = [[curdestGradeInfo valueForKey:@"Lexus"] valueForKey:@"Unavailable"];
            if(UnavailableInfo){
                if([UnavailableInfo valueForKey:@"L1"]){
                    valueL1 = [UnavailableInfo valueForKey:@"L1"];
                }
                if([UnavailableInfo valueForKey:@"L1.5"]){
                    valueL15 = [UnavailableInfo valueForKey:@"L1.5"];
                }
                if([UnavailableInfo valueForKey:@"L2"]){
                    valueL2 = [UnavailableInfo valueForKey:@"L2"];
                }
            }
        }
        [UnavailableInfo setValue: valueL1 forKey: @"L1"];
        [UnavailableInfo setValue: valueL15 forKey: @"L1.5"];
        [UnavailableInfo setValue: valueL2 forKey: @"L2"];

        NSMutableDictionary* AvailableInfo = [NSMutableDictionary dictionary];
        [LexusInfo setValue: AvailableInfo forKey: @"Available"];
        valueL1 = @"";
        valueL15 = @"";
        valueL2 = @"";
        if(curdestGradeInfo && [curdestGradeInfo valueForKey:@"Lexus"] && [[curdestGradeInfo valueForKey:@"Lexus"] valueForKey:@"Available"]){
            NSMutableDictionary* UnavailableInfo = [[curdestGradeInfo valueForKey:@"Lexus"] valueForKey:@"Available"];
            if(UnavailableInfo){
                if([UnavailableInfo valueForKey:@"L1"]){
                    valueL1 = [UnavailableInfo valueForKey:@"L1"];
                }
                if([UnavailableInfo valueForKey:@"L1.5"]){
                    valueL15 = [UnavailableInfo valueForKey:@"L1.5"];
                }
                if([UnavailableInfo valueForKey:@"L2"]){
                    valueL2 = [UnavailableInfo valueForKey:@"L2"];
                }
            }
        }
        [AvailableInfo setValue:valueL1 forKey: @"L1"];
        [AvailableInfo setValue:valueL15 forKey: @"L1.5"];
        [AvailableInfo setValue:valueL2 forKey: @"L2"];

        //toyota
        NSMutableDictionary* ToyotaInfo = [NSMutableDictionary dictionary];
        [oneRegionInfo setValue:ToyotaInfo forKey: @"Toyota"];

        NSMutableDictionary* toyotaUnavailableInfo = [NSMutableDictionary dictionary];
        [ToyotaInfo setValue: toyotaUnavailableInfo forKey: @"Unavailable"];
        NSString* valueEntryDA = @"";
        NSString* valueT1 = @"";
        NSString* valueTEMVN = @"";
        NSString* valueT2 = @"";
        if(curdestGradeInfo && [curdestGradeInfo valueForKey:@"Toyota"] && [[curdestGradeInfo valueForKey:@"Toyota"] valueForKey:@"Unavailable"]){
            NSMutableDictionary* UnavailableInfo = [[curdestGradeInfo valueForKey:@"Toyota"] valueForKey:@"Unavailable"];
            if(UnavailableInfo){
                if([UnavailableInfo valueForKey:@"Entry DA"]){
                    valueEntryDA = [UnavailableInfo valueForKey:@"Entry DA"];
                }
                if([UnavailableInfo valueForKey:@"T1"]){
                    valueT1 = [UnavailableInfo valueForKey:@"T1"];
                }
                if([UnavailableInfo valueForKey:@"T2"]){
                    valueT2 = [UnavailableInfo valueForKey:@"T2"];
                }
                if([UnavailableInfo valueForKey:@"T-EMVN"]){
                    valueTEMVN = [UnavailableInfo valueForKey:@"T-EMVN"];
                }
            }
        }
        [toyotaUnavailableInfo setValue: valueEntryDA forKey: @"Entry DA"];
        [toyotaUnavailableInfo setValue: valueT1 forKey: @"T1"];
        [toyotaUnavailableInfo setValue: valueT2 forKey: @"T2"];
        [toyotaUnavailableInfo setValue: valueTEMVN forKey: @"T-EMVN"];

        NSMutableDictionary* toyotaAvailableInfo = [NSMutableDictionary dictionary];
        [ToyotaInfo setValue: toyotaAvailableInfo forKey: @"Available"];
        valueEntryDA = @"";
        valueT1 = @"";
        valueTEMVN = @"";
        valueT2 = @"";
        if(curdestGradeInfo && [curdestGradeInfo valueForKey:@"Toyota"] && [[curdestGradeInfo valueForKey:@"Toyota"] valueForKey:@"Available"]){
            NSMutableDictionary* UnavailableInfo = [[curdestGradeInfo valueForKey:@"Toyota"] valueForKey:@"Available"];
            if(UnavailableInfo){
                if([UnavailableInfo valueForKey:@"Entry DA"]){
                    valueEntryDA = [UnavailableInfo valueForKey:@"Entry DA"];
                }
                if([UnavailableInfo valueForKey:@"T1"]){
                    valueT1 = [UnavailableInfo valueForKey:@"T1"];
                }
                if([UnavailableInfo valueForKey:@"T2"]){
                    valueT2 = [UnavailableInfo valueForKey:@"T2"];
                }
                if([UnavailableInfo valueForKey:@"T-EMVN"]){
                    valueTEMVN = [UnavailableInfo valueForKey:@"T-EMVN"];
                }
            }
        }
        [toyotaAvailableInfo setValue: valueEntryDA forKey: @"Entry DA"];
        [toyotaAvailableInfo setValue: valueT1 forKey: @"T1"];
        [toyotaAvailableInfo setValue: valueT2 forKey: @"T2"];
        [toyotaAvailableInfo setValue: valueTEMVN forKey: @"T-EMVN"];
    }
}

-(void) getChildrenMetaData:(NSArray*) meta originLayer: (id<MSLayer> )originLayer correspond:(id<MSLayer>)layer_correspond
{
    id<MSPluginCommand> command = [SketchCommon command];
    if([SketchCommon isInstance:originLayer]){

        id<MSSymbolMaster> symbolMaster_originLayer = nil;
        id<MSSymbolInstance> instance_originLayer = originLayer;
        symbolMaster_originLayer = [instance_originLayer symbolMaster];

        for(NSInteger i = 0; i < [meta count]; i++){
            NSDictionary* data = meta[i];
            NSString* key = [data objectForKey:@"type"];
            NSDictionary* value = [data objectForKey:@"content"];
            if([key isEqualToString:@"child"]){
                NSString * idInfo = [value  objectForKey:@"id"];
                NSArray * origin_children = [symbolMaster_originLayer children];
                for(NSInteger j = 0; j < [origin_children count]; j++){
                    id<MSLayer> child = [origin_children objectAtIndex:j];
                    NSString* originID = [child objectID];

                    if([originID isEqualToString:idInfo]){ //found  origin layer
                        //find copy layer
                        NSArray * groupChildren = [layer_correspond children];
                        for(NSInteger k = 0; k < [groupChildren count]; k++){
                            id<MSLayer> groupChild = groupChildren[k];
                            if([[originLayer objectID] isEqualToString: originID]){ //found  copy layer
                                NSArray * groupChildMeta = [value  objectForKey:@"metadata"]; //get metadata
                                [command setValue:groupChildMeta forKey:@"metadata" onLayer:groupChild forPluginIdentifier:@"tmnaMM"];
                            }
                        }
                    }
                }
            }
        }
    }
}

-(NSString*) getPartsTypeforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSDictionary* retobj = metaData[@"Parts Type"];

    if (retobj == nil) {
        return @"";
    }
    if ([[retobj objectForKey:@"part"] isEqualToString: @"Select Part Type"]) {
        return @"";
    }

    return [retobj objectForKey:@"part"];
}

-(NSString*) getTargetIDformMetaforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* retobj = metaData[@"Target"];
    if (retobj == nil) {
        return @"";
    }
    return retobj;
}



-(NSMutableDictionary *) getConditionDict:(NSString*)con_key{

//    if ([layerUUID isEqualToString:@"38B1FAF2-76F4-40D2-A2B9-A2C8AB081142_7636796A-0D92-4AF6-A3D0-1B53E7CB43CA_state_1"]) {
//        NSLog(@"%@", layerUUID);
//    }

//    NSString* con_key = [con_name stringByAppendingString:@"__"];
//    con_key = [con_key stringByAppendingString:layerUUID];
//    NSString* objectID = [layerInfo objectID];
//    BOOL res = [objectID isEqualToString:@"CEF4F7E9-87D9-462C-B49B-DBCA45BC4D60_B46D439C-034B-401F-BC4B-309C30BA7421"];
//
//    if (res) {
//        NSString* a = objectID;
//        NSLog(@"%@", a);
//        BOOL r = res;
//        NSLog(@"%@", r);
//    }
    // var conletters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    [retData setValue: @"" forKey: @"Formula"];
    [retData setValue: @"" forKey: @"else"];

    NSMutableDictionary* conditionData = [NSMutableDictionary dictionary];
    [retData setValue: conditionData forKey: @"Condition"];

    NSMutableDictionary* sameConditionData = [NSMutableDictionary dictionary];
    [retData setValue: sameConditionData forKey: @"Same Condition"];
    [sameConditionData setValue: @"" forKey: @"Parts ID"];
    [sameConditionData setValue: @"" forKey: @"Screen ID"];

    [retData setValue: @"" forKey: @"else"];

    if (self.m_allConditionData == nil) {
        return retData;
    }

    NSDictionary* con_obj = self.m_allConditionData[con_key];
    if (con_obj == nil) {
        return retData;
    }

    //else data
    NSArray* con_keyArr = [con_key componentsSeparatedByString:@"__"];
    NSString* metaDataKey = con_keyArr[1];
    NSMutableArray* curMetadata = [self.m_allMetadata valueForKey:metaDataKey];
    NSMutableDictionary* curmetaDic = [NSMutableDictionary dictionary];
    if (curMetadata) {
        curmetaDic = [self makeMetadata:curMetadata];
    }
    
    NSString* elseDataStr = [curmetaDic objectForKey:@"else"];

//    NSRange range = [elseDataStr rangeOfString:nullStr];
    if (![elseDataStr isKindOfClass:[NSNull class]] && ![elseDataStr containsString:@"null"]) {
        [retData setValue: elseDataStr forKey: @"else"];
    }
    //Formula data
    id formulaDataStr = [con_obj objectForKey:@"formula"];
//    range = [formulaDataStr rangeOfString:nullStr];
    if (![formulaDataStr isKindOfClass:[NSNull class]] && ![formulaDataStr containsString:@"null"]) {
        [retData setValue: formulaDataStr forKey: @"Formula"];
    }

//    conditionData = [con_obj objectForKey:@"conditions"];
//    if (conditionData) {
//        [retData setObject:conditionData forKey:@"Condition"];
//    }
    NSArray* conditionDataOrigin = [con_obj objectForKey:@"conditions"];
    NSArray* keyArr = [NSArray arrayWithObjects:@"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", nil];

//    NSInteger nullPos = 0;
    for (NSUInteger i = 0; i < [conditionDataOrigin count]; ++i) {
        if (![conditionDataOrigin[i] isKindOfClass:[NSNull class]] && ![conditionDataOrigin[i] containsString:@"null"]) {
            [conditionData setObject:conditionDataOrigin[i] forKey:keyArr[i]];
        }
        else {
            [conditionData setObject:@"-" forKey:keyArr[i]];
        }
    }

    NSDictionary* sameConditionOrig =[con_obj objectForKey:@"sameCondition"];
    NSString* partsIDDataStr = [sameConditionOrig objectForKey:@"partsID"];
    NSString* screenIDDataStr = [sameConditionOrig objectForKey:@"screenID"];
//    range = [partsIDDataStr rangeOfString:nullStr];
    if (![partsIDDataStr isKindOfClass:[NSNull class]] && ![partsIDDataStr containsString:@"null"]) {
        [sameConditionData setValue: partsIDDataStr forKey: @"Parts ID"];
    }
//    range = [screenIDDataStr rangeOfString:nullStr];
    if (![screenIDDataStr isKindOfClass:[NSNull class]] && ![screenIDDataStr containsString:@"null"]) {
        [sameConditionData setValue: screenIDDataStr forKey: @"Screen ID"];
    }
    return retData;
}

-(NSMutableDictionary *) getTextOrImageInformation: (NSMutableDictionary *) metaData curLayer: (NSString*)layerInfo {
    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    //japanese
    NSMutableDictionary* japanData = [NSMutableDictionary dictionary];
    [japanData setValue: [self getJapaneseJapanese:metaData] forKey: @"Japanese"];
    [japanData setValue: [self getJapaneseFixedwords:metaData] forKey: @"Fixed words"];
    [retData setValue: japanData forKey: @"Japanese"];
    //U.S.English
    NSMutableDictionary* usData = [NSMutableDictionary dictionary];
    [usData setValue: [self getUSEngUSEng:metaData] forKey: @"U.S.English"];
    [usData setValue: [self getUSEngFixedwords:metaData] forKey: @"Fixed words"];
    [retData setValue: usData forKey: @"U.S.English"];
    //U.K.English
    NSMutableDictionary* ukData = [NSMutableDictionary dictionary];
    [ukData setValue: [self getUKEngUKEng:metaData] forKey: @"U.K.English"];
    [ukData setValue: [self getUKEngFixedwords:metaData] forKey: @"Fixed words"];
    [retData setValue: ukData forKey: @"U.K.English"];
    //Fixed Image    getTextImgFixedImageforJson
    [retData setValue: [self getTextImgFixedImageforJson : metaData] forKey: @"Fixed Image"];

    [self getMultiStateConditionDict:retData dictKey:@"Delete condition in motion" msKey:layerInfo];
//    [retData setValue: [self getConditionDict:layerInfo] forKey: @"Delete condition in motion"];

    //Outside Input data
    NSMutableDictionary* outsideInputData = [NSMutableDictionary dictionary];
    [outsideInputData setValue: [self getOutsideInputDisplayContents:metaData] forKey: @"Display contents"];
    [outsideInputData setValue: [self getOutsideInputFormat:metaData] forKey: @"Format"];
    [outsideInputData setValue: [self getOutsideInputRange:metaData] forKey: @"Range"];
    [retData setValue: outsideInputData forKey: @"Outside Input"];

    //Validation
    [retData setValue: [self getTextImgValidationforJson : metaData] forKey: @"Validation"];

    return retData;
}

-(NSString*) getJapaneseJapanese:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"Japanese-Japanese"];

    return res;
}

-(NSString*) getJapaneseFixedwords:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"Japanese-Fixed words"];

    return res;
}

-(NSString*) getUSEngUSEng:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"U.S.English-U.S.English"];

    return res;
}

-(NSString*) getUSEngFixedwords:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"U.S.English-Fixed words"];

    return res;
}

-(NSString*) getUKEngUKEng:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"U.K.English-U.K.English"];

    return res;
}

-(NSString*) getUKEngFixedwords:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"U.K.English-Fixed words"];

    return res;
}

-(NSString*) getOutsideInputDisplayContents:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"text-image-outside-input-display-contents"];

    return res;
}

-(NSString*) getOutsideInputFormat:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"text-image-outside-input-format"];

    return res;
}

-(NSString*) getOutsideInputRange:(NSMutableDictionary*)metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString* res = [metaData objectForKey:@"text-image-outside-input-range"];

    return res;
}

-(NSString *) getTextImgValidationforJson: (NSMutableDictionary *) metaData  {
    if (metaData == nil) {
        return @"";
    }
    NSString* retobj = metaData[@"text-image-validation"];
    if (retobj == nil) {
        return @"";
    }
    return retobj;
}

-(NSString *) getTextImgFixedImageforJson: (NSMutableDictionary *) metaData  {
    if (metaData == nil) {
        return @"";
    }
    NSString* retobj = metaData[@"fixed-image"];
    if (retobj == nil) {
        return @"";
    }
    return retobj;
}

-(NSMutableDictionary *) getSWInformation: (NSMutableDictionary *) metaData curLayer: (NSString*)layerInfo {
    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    //in Motion
//    NSMutableDictionary* inMotionData = [NSMutableDictionary dictionary];
    NSString* sWTonedownMotionkey = [@"sWTonedownMotion__" stringByAppendingString:layerInfo];
    [self getMultiStateConditionDict:retData dictKey:@"Tonedown condition in motion" msKey:sWTonedownMotionkey];
//    inMotionData = [self getConditionDict:sWTonedownMotionkey];
//    [retData setValue: inMotionData forKey: @"Tonedown condition in motion"];

    //except in motion
//    NSMutableDictionary* exceptInMotionData = [NSMutableDictionary dictionary];
    NSString* sWTonedownExceptInMotionKey = [@"sWTonedownExceptInMotion__" stringByAppendingString:layerInfo];
    [self getMultiStateConditionDict:retData dictKey:@"Tonedown condition except in motion" msKey:sWTonedownExceptInMotionKey];
//    exceptInMotionData = [self getConditionDict:sWTonedownExceptInMotionKey];
//    [retData setValue: exceptInMotionData forKey: @"Tonedown condition except in motion"];

    //Selected condition
//    NSMutableDictionary* selectedConditionData = [NSMutableDictionary dictionary];
    NSString* sWSelectedKey = [@"sWSelected__" stringByAppendingString:layerInfo];
    [self getMultiStateConditionDict:retData dictKey:@"Selected condition" msKey:sWSelectedKey];
//    selectedConditionData = [self getConditionDict:sWSelectedKey];
//    [retData setValue: selectedConditionData forKey: @"Selected condition"];

    //SW operation Pattern
    NSString* SWOpePatternData = [self getSWOpePatternforJson: metaData];
    [retData setValue: SWOpePatternData forKey: @"SW operation Pattern"];

    //Selected condition
    NSMutableDictionary* opeRetData = [NSMutableDictionary dictionary];
    opeRetData = [self getOpeRetDict: metaData];
    [retData setValue: opeRetData forKey: @"Operation result"];

    //Selected condition
    NSString* beepData = [self getBeepInfoforJson: metaData];
    [retData setValue: beepData forKey: @"BEEP"];

    //Validation
    [retData setValue: [self getTextImgValidationforJson : metaData] forKey: @"Validation"];

    return retData;
}

-(void) makeJsonSketchInfo4Node:(CoreDataIterator*)treeNode toCurInfo:(NSMutableDictionary*)curnodeJsonIndo uuid:(NSString*)uuid
{
    id<MSLayer> curnode_correspond = [treeNode expandLayer];
    id<MSLayer> curnode_origin = [treeNode originLayer];

    NSString* objectID_origin = [curnode_origin objectID];
    NSString* objectID_corespond = [curnode_correspond objectID];
    NSMutableDictionary* curnodeSketchJsonInfo = [NSMutableDictionary dictionary];

    //make UUI
//    NSString* uuid = [treeNode absoluteObjectID];
    [curnodeSketchJsonInfo setValue:uuid forKey:@"uuid"];

    NSString* realFullID = [treeNode realFullID];
    [curnodeSketchJsonInfo setValue:realFullID forKey:@"realFullID"];

    //make Rect
    NSMutableDictionary* curnodeRectJsonInfo = [NSMutableDictionary dictionary];
    CGRect currentObjAbsRect = [[curnode_correspond absoluteRect] absoluteRect];
    id<MSArtboardGroup> parentRoot = [curnode_correspond parentRoot];
    CGRect currentArtboardAbsRect = [[parentRoot absoluteRect] absoluteRect];

    int rectX = currentObjAbsRect.origin.x - currentArtboardAbsRect.origin.x;
    int rectY = currentObjAbsRect.origin.y - currentArtboardAbsRect.origin.y;
    int rectW = currentObjAbsRect.size.width;
    int rectH = currentObjAbsRect.size.height;

    NSString* x_origin = [NSString stringWithFormat:@"%d",rectX];
    NSString* y_origin = [NSString stringWithFormat:@"%d",rectY];
    NSString* w_origin = [NSString stringWithFormat:@"%d",rectW];
    NSString* h_origin = [NSString stringWithFormat:@"%d",rectH];

    [curnodeRectJsonInfo setValue:x_origin forKey:@"x"];
    [curnodeRectJsonInfo setValue:y_origin forKey:@"y"];
    [curnodeRectJsonInfo setValue:w_origin forKey:@"w"];
    [curnodeRectJsonInfo setValue:h_origin forKey:@"h"];
    [curnodeSketchJsonInfo setValue:curnodeRectJsonInfo forKey:@"Rect"];

    //make imgPath
    NSString* imgPath = [self.m_resFilePath stringByAppendingString:@"/___exportspecs___/images"];
    [SketchCommon exportLayerTofile:curnode_correspond filePath:imgPath fileName:objectID_corespond];
    NSString* curimgPath = [[[imgPath stringByAppendingString:@"/"] stringByAppendingString:objectID_corespond] stringByAppendingString:@".png"];

    if ([SketchCommon checkIsTextInstance:curnode_correspond]) {
        //        if ([[curnode_correspond name] isEqualToString:@"text/18/Left/Regular/Gray 4"]) {
        //            BLOG(@"", @"");
        //        }
        NSString* textVal = [SketchCommon getTextInstanceValue:curnode_correspond];
        if (nil == textVal) {
            textVal = [NSString stringWithString:@"nil"];
        }
        [curnodeSketchJsonInfo setValue: textVal forKey:@"imgPath"];
    }
    else
    {
        [curnodeSketchJsonInfo setValue: curimgPath forKey:@"imgPath"];
    }

    [curnodeJsonIndo setValue:curnodeSketchJsonInfo forKey:@"sketchInfo"];
}

-(NSString *) getSWOpePatternforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSDictionary * retobj = metaData[@"sw-operation-pattern"];
    if (retobj == nil) {
        return @"";
    }
    NSString * dataStr = [retobj valueForKey:@"swOperationPattern"];
    return dataStr;
}

-(NSMutableDictionary *) getOpeRetDict: (NSMutableDictionary *) metaData {
    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    //Screen Transion
    NSString * screenTranData = [self getOpeResultScreenTransforJson: metaData];
    [retData setValue: screenTranData forKey: @"Screen Transion"];

    //Start Function
    NSString * screenFunData = [self getOpeResultStartFuncforJson: metaData];
    [retData setValue: screenFunData forKey: @"Start Function"];

    //Setting Value Change
    NSString * setValueChgData = [self getOpeResultSettingValueChangeforJson: metaData];
    [retData setValue: setValueChgData forKey: @"Setting Value Change"];

    //Setting Value Change
    NSString * otherData = [self getOpeResultOtherforJson: metaData];
    [retData setValue: otherData forKey: @"Other"];

    return retData;
}

-(NSString *) getBeepInfoforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSDictionary * retobj = metaData[@"beep"];
    if (retobj == nil) {
        return @"";
    }
    NSString * beepData = [retobj valueForKey:@"beep"];
    return beepData;
}

-(NSString *) getOpeResultScreenTransforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
//    NSString * retobj = @"";
//    if (retobj == nil) {
//        return @"";
//    }
//    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"] isEqualToString:@"screen-transition"])
//    {
//        retobj = metaData[@"sw-operation-result"];
//    }

    NSString* retobj = [metaData objectForKey:@"sw-operation-result-screen-transition"];
//    retobj = @"qwertyuiop";
    return retobj;
}

-(NSString *) getOpeResultStartFuncforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }

//    NSString * retobj = @"";
//    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"]  isEqualToString: @"start-function"])
//    {
//        retobj = metaData[@"sw-operation-result"];
//    }
//    if (retobj == nil) {
//        return @"";
//    }
//    NSDictionary* swOpeRes = [metaData objectForKey:@"sw-operation-result"];
//    if (swOpeRes) {
//        if ([[swOpeRes objectForKey:@"type"] isEqualToString:@"start-function"])
//        retobj = [swOpeRes objectForKey:@"value"];
//    }

    NSString* retobj = [metaData objectForKey:@"sw-operation-result-start-function"];
    return retobj;
}

-(NSString *) getOpeResultSettingValueChangeforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
//    NSString * retobj = @"";
//    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"] isEqualToString: @"setting-value-change"])
//    {
//        retobj = metaData[@"sw-operation-result"];
//    }

//    if (retobj == nil) {
//        return @"";
//    }

//    NSDictionary* swOpeRes = [metaData objectForKey:@"sw-operation-result"];
//    if (swOpeRes) {
//        if ([[swOpeRes objectForKey:@"type"] isEqualToString:@"setting-value-change"])
//            retobj = [swOpeRes objectForKey:@"value"];
//    }

    NSString* retobj = [metaData objectForKey:@"sw-operation-result-setting-value-change"];
    return retobj;
}

-(NSString *) getOpeResultOtherforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
//    NSString * retobj = @"";
//    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"] isEqualToString:@"other"] )
//    {
//        retobj = metaData[@"sw-operation-result"];
//    }

//    if (retobj == nil) {
//        return @"";
//    }

//    NSDictionary* swOpeRes = [metaData objectForKey:@"sw-operation-result"];
//    if (swOpeRes) {
//        if ([[swOpeRes objectForKey:@"type"] isEqualToString:@"other"])
//            retobj = [swOpeRes objectForKey:@"value"];
//    }

    NSString* retobj = [metaData objectForKey:@"sw-operation-result-other"];
    return retobj;
}

@end
