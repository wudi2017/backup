//
//  ExportHMISpec.m
//  TMNAFramework
//
//  Created by wuyuchi on 2018/12/27.
//

/*

 */
#import "ExportHMISpec.h"
#import "CStringUtils.h"
// const NSString* CorrespondType_DirectCorrespond = @"DirectCorrespond";
// const NSString* CorrespondType_DirectExpand = @"DirectExpand";
// const NSString* CorrespondType_DeepExpand = @"DeepExpand";
// const NSString* CorrespondType_Virtual = @"Virtual";

@implementation ExportHMISpec

-(instancetype)init {
    self = [super init];
    self.m_correspondingDic = [NSMutableDictionary dictionary];
    self.m_jsonContentInfo = [NSMutableDictionary dictionary];
    self.m_pageSelectConfig = [NSMutableDictionary dictionary];
    self.m_debugFlag = false;
    self.m_debugTag = @"ExportHMISpec";
    self.m_linkedObjectId = [[NSMutableArray alloc] init];
    return self;
}

-(BOOL) startExportHMISpec
{
    BLOG(self.m_debugTag, @"ExportHMISpec start");
    id<MSDocument> doc = SketchCommon.document;
    NSArray* pages = [doc pages];

    NSOpenPanel* openPanel = [NSOpenPanel openPanel];
    [openPanel setCanChooseDirectories:true];
    [openPanel setCanChooseFiles:true];
    //[openPanel setDirectoryURL:NSHomeDirectory()];
    [openPanel setPrompt:@"Export"];
    if([openPanel runModal] != NSModalResponseOK){
        return false;
    }
    NSString* result_full_path = [[openPanel URL] path];
    self.m_resFilePath = result_full_path;
    NSString* work_result_dir = [result_full_path stringByAppendingString:@"/___exportspecs___"];
    if([CFileUtils fileExists:work_result_dir]){
        [CFileUtils removeFile:work_result_dir];
    }
//    [CFileUtils createDirectory:work_result_dir];
//    [CFileUtils createDirectory:imagePath];

    NSMutableArray * copyArray = [NSMutableArray array];
    [copyArray addObjectsFromArray:pages];
    for(NSInteger pageNum=0;pageNum<[copyArray count];pageNum++){
        id<MSPage> curPage = [copyArray objectAtIndex:pageNum];
        // step 1: copy page
        NSString* curPageName = [curPage name];
        BLOG(self.m_debugTag, @"deal page: %@",curPageName);
        if([SketchCommon isPageIgnored:curPage]){
            continue;
        }
        if([self checkPageIsIgnore:curPageName]){
            continue;
        }
        NSString* newPageName = [curPageName stringByAppendingString:@"_copy"];
        id<MSPage> newPage = [SketchCommon duplicatePage:curPage NewName:newPageName];
        BLOG(self.m_debugTag, @"step 1: deatch for Node");
        // step 2: deatch curapge and make correspondInfo
        [self generate4Node:curPage newpage:newPage];

        BLOG(self.m_debugTag, @"step 2: generatePartID");
        [self generatePartID:newPage];

        //step 3: make json Info
        BLOG(self.m_debugTag, @"step 3: makeJsonInfo4Page");
        [self makeJsonInfo4Page:newPage name:[CStringUtils toSlug:curPageName]];

        //step4 : delete new page
        [doc removePage:newPage];
    }
    BLOG(self.m_debugTag, @"ExportHMISpec end");
    return true;
}


- (BOOL)generate4Node : (id<MSPage>)originPage newpage:(id<MSPage>)correspondPage
{
    // step1 :  loop page for artboard
    for(NSUInteger artboardNum=0;artboardNum<[[correspondPage layers] count];artboardNum++)
    {
        // step1_1 setInfo forArtboard
        id<MSLayer> curLayer_correspond = [correspondPage layers][artboardNum];
        id<MSLayer> curLayer_origin = [originPage layers][artboardNum];

        //step1_2 make correspond info
        for(NSInteger childNum=0;childNum<[[curLayer_correspond children] count];childNum++){
            id<MSLayer> childLayer_correspond = [[curLayer_correspond children] objectAtIndex:childNum];
            id<MSLayer> childLayer_origin = [[curLayer_origin children] objectAtIndex:childNum];

            NSMutableDictionary* childCorrespondInfo = [NSMutableDictionary dictionary];
            [childCorrespondInfo setValue:childLayer_origin forKey:@"originLayer"];
            NSString* objectID_childorigin = [childLayer_origin objectID];
            NSInteger level = [self getDeatchLevel:objectID_childorigin];
            NSString* objectID_childcorrespond = [childLayer_correspond objectID];
            [childCorrespondInfo setValue:[NSNumber numberWithInteger:level] forKey:@"level"];
            [childCorrespondInfo setValue:@"DirectCorrespond" forKey:@"type"];
            [self.m_correspondingDic setValue:childCorrespondInfo forKey:objectID_childcorrespond];
        }

        if([self isArtboardIgnored:curLayer_origin]){
            continue;
        }
        //step 1_3 loop
        [self detach4Node:curLayer_correspond];
    }
    return  true;
}

-(void) generatePartID:(id<MSPage>)page
{
//    BLOG(@"123", @"generatePartID start");
    for(NSInteger artboardNum=0;artboardNum<[[page layers] count];artboardNum++){
        id<MSLayer> artboard_correspond = [[page layers] objectAtIndex:artboardNum];
        if([self isArtboardIgnored:artboard_correspond]){
            continue;
        }
        if([artboard_correspond containsLayers]){
            NSMutableArray* startNum = [NSMutableArray array]; // index:num index:char
            [startNum addObject:[NSNumber numberWithInt:1]];
            [startNum addObject:[NSNumber numberWithInt:1]];
//            BLOG(@"123", [artboard_correspond name]);
            for(NSInteger num=0;num<[[artboard_correspond layers] count];num++){
                id<MSLayer> curLayer = [[artboard_correspond layers] objectAtIndex:num];
                [self generatePartID4Node:curLayer prex:@"" index:startNum];
            }
        }
    }
}

// page in
-(void) makeJsonInfo4Page:(id<MSPage>)page name:(NSString*)fileName
{
    for(NSInteger artboardNum=0;artboardNum<[[page layers] count];artboardNum++){
        id<MSLayer> artboard_correspond = [[page layers] objectAtIndex:artboardNum];
        if([self isArtboardIgnored:artboard_correspond]){
            continue;
        }
        NSString* objectID_correspond = [artboard_correspond objectID];
        NSMutableDictionary* correspondInfo = [self.m_correspondingDic objectForKey:objectID_correspond];
        id<MSLayer> artboard_origin = [correspondInfo valueForKey:@"originLayer"];
        NSString* objectID_origin = [artboard_origin objectID];
        NSMutableDictionary* curArtboatdJsonIndo = [NSMutableDictionary dictionary];

        //get mratdata
        id<MSPluginCommand> command = [SketchCommon command];
        NSMutableArray * metaData = [command valueForKey:@"metadata" onLayer:artboard_origin forPluginIdentifier:@"tmnaMM"];
        // int a = [metaData count];
        NSMutableDictionary * metaDic = [self makeMetadata: metaData];

        NSMutableDictionary* childJsonIndo = [NSMutableDictionary dictionary];
        [curArtboatdJsonIndo setValue:childJsonIndo forKey:@"PartsList"];

        //make screen info
        NSMutableDictionary* screenInfoJsonIndo = [NSMutableDictionary dictionary];
        [curArtboatdJsonIndo setValue:screenInfoJsonIndo forKey:@"ScreenInfo"];

        //make excel info for screen info
        [self makeJsonExcelInfo4Node: artboard_origin toCurInfo :screenInfoJsonIndo byMeta: metaDic];

        //make sketch info for screen info
        [self makeJsonSketchInfo4Artboard: artboard_correspond originLayer:artboard_origin toCurInfo:screenInfoJsonIndo];
        //[self makeJsonSketchInfo4Artboard:artboard_origin toCurInfo :screenInfoJsonIndo];

        NSMutableDictionary* destGradeInfoIndo = [NSMutableDictionary dictionary];
        [curArtboatdJsonIndo setValue:destGradeInfoIndo forKey:@"DestGradeInfo"];
        [self makeJsonDestGradeInfo4Node: artboard_origin toCurInfo :destGradeInfoIndo byMeta: metaDic];
        [self.m_jsonContentInfo setValue:curArtboatdJsonIndo forKey:objectID_origin];

        if([artboard_correspond containsLayers]){
            for(NSInteger num=0;num<[[artboard_correspond layers] count];num++){
                id<MSLayer> curLayer = [[artboard_correspond layers] objectAtIndex:num];
                [self makeJsonInfo4Node:curLayer infoContent:childJsonIndo inArtboard:artboard_origin partInfo:nil];
            }
        }
    }

//    [CFileUtils writeArrayToFile:@"/Users/wuyuchi/Documents/milestone/untitledfolder/" FileName:@"123.json" FileContent:self.m_jsonContentInfo];
    NSString* writhFilePth = [self.m_resFilePath stringByAppendingString:@"/___exportspecs___"];
    [CFileUtils writeArrayToFile:writhFilePth FileName:[fileName stringByAppendingString:@".json"] FileContent:self.m_jsonContentInfo];
    [self.m_jsonContentInfo removeAllObjects];
}

-(void)setPageSelectConfig:(NSMutableDictionary*) config{
    [self.m_pageSelectConfig setDictionary:config];
}

- (BOOL)detach4Node:(id<MSLayer>)correspondLayer
{
    NSString* correspondLayerName = [correspondLayer name];
    NSString* nodeObjectId = [correspondLayer objectID];
    NSMutableDictionary* correspondInfo  = [self.m_correspondingDic objectForKey:nodeObjectId];
    NSInteger curlevel = [[correspondInfo objectForKey:@"level"] integerValue];
    id<MSLayer> originNode = [correspondInfo objectForKey:@"originLayer"];
    if(originNode && [self checkIsContinue:curlevel correspondLayer:correspondLayer layer:originNode]) {
        [self dealNeedContinueNode:correspondLayer];
    }
    return true;
}

- (BOOL)dealNeedContinueNode:(id<MSLayer>)correspondLayer
{
    // step1 get some basal info
    NSString* nodeObjectId = [correspondLayer objectID];
    NSMutableDictionary* correspondInfo  = [self.m_correspondingDic objectForKey:nodeObjectId];
    id<MSLayer> originNode = [correspondInfo objectForKey:@"originLayer"];
    NSInteger curlevel = [[correspondInfo objectForKey:@"level"] integerValue];
    NSString* nodeType = [correspondInfo objectForKey:@"type"];

    // step2 deatch instance
    NSDictionary* curoverridesforiAutopage = [NSDictionary dictionary];
    NSMutableArray* layers_origin = [NSMutableArray array];
    NSMutableArray* layers_corresponds = [NSMutableArray array];
    NSMutableArray* allLayers_origin = [NSMutableArray array];
    NSMutableArray* allLayers_corresponds = [NSMutableArray array];

    //--------------------------------------
    //[self generatePartID: correspondLayer originLayer: originNode];

    if([SketchCommon isInstance:correspondLayer]){
        id<MSSymbolInstance> curInsatnce_correspond = correspondLayer;
        curoverridesforiAutopage = [NSDictionary dictionaryWithDictionary:[curInsatnce_correspond overrides]];
        id<MSSymbolMaster> symbolMaster_correspond = nil;
        NSString* curNodeName = [curInsatnce_correspond name];
        if([SketchCommon isInstance:originNode]){
            id<MSSymbolInstance> instance_origin = originNode;
            symbolMaster_correspond = [instance_origin symbolMaster];
        }
        else if([[originNode className] isEqualToString:@"MSSymbolMaster"]){
            symbolMaster_correspond = originNode;
        }

        layers_origin = [NSMutableArray arrayWithArray:[symbolMaster_correspond layers]];
        allLayers_origin = [NSMutableArray arrayWithArray:[symbolMaster_correspond children]];
        if([layers_origin count] > 0){
            id<MSLayerGroup> newgroup = [curInsatnce_correspond detachByReplacingWithGroup];
            if([[newgroup children] count] == [[symbolMaster_correspond children] count]){
                // has group for master
                [newgroup setName:curNodeName];
                NSString* temp_objectID = [newgroup objectID];
                NSMutableDictionary* tempinfo = [NSMutableDictionary dictionary];
                [tempinfo setValue:originNode forKey:@"originLayer"];
                [tempinfo setValue:[NSNumber numberWithInteger:curlevel] forKey:@"level"];
                [tempinfo setValue:nodeType forKey:@"type"];
                [self.m_correspondingDic setValue:tempinfo forKey:temp_objectID];
                layers_corresponds = [NSMutableArray arrayWithArray:[newgroup layers]];
                allLayers_corresponds = [NSMutableArray arrayWithArray:[newgroup children]];
            }
            else{
                id<MSLayerGroup> tempgroup = [MSLayerArray arrayWithLayer:newgroup];
                id<MSLayerGroup> newparentgroup = [MSLayerGroup groupWithLayers:tempgroup];
                [newparentgroup setName:curNodeName];
                NSString* temp_objectID = [newparentgroup objectID];
                NSMutableDictionary* tempinfo = [NSMutableDictionary dictionary];
                [tempinfo setValue:originNode forKey:@"originLayer"];
                [tempinfo setValue:[NSNumber numberWithInteger:curlevel] forKey:@"level"];
                [tempinfo setValue:nodeType forKey:@"type"];
                [self.m_correspondingDic setValue:tempinfo forKey:temp_objectID];
                layers_corresponds = [NSMutableArray arrayWithArray:[newparentgroup layers]];
                allLayers_corresponds = [NSMutableArray arrayWithArray:[newparentgroup children]];
            }
            curlevel -= 1;
            nodeType = @"Virtual";
        }
        else{
            //detele because its master no layer
        }
    }
    else if([[correspondLayer className] isEqualToString:@"MSLayerGroup"] || [[correspondLayer className] isEqualToString:@"MSArtboardGroup"]){
        layers_corresponds = [NSMutableArray arrayWithArray:[correspondLayer layers]];
        layers_origin = [NSMutableArray arrayWithArray:[originNode layers]];
    }
    else{

    }

    // step3 make childLayer correspond info
    for(NSUInteger childLayerNum=1;childLayerNum<[allLayers_corresponds count];childLayerNum++)
    {
        id<MSLayer> childLayer_correspond = [allLayers_corresponds objectAtIndex:childLayerNum];
        id<MSLayer> childLayer_origin = [allLayers_origin objectAtIndex:childLayerNum];
        NSString* name_childcorespond = [childLayer_correspond name];
        NSString* name_childorigin = [childLayer_origin  name];
        if(![name_childcorespond isEqualToString:name_childorigin]){
            return false;
        }
        NSString* objectID_childcorrespond = [childLayer_correspond objectID];
        NSString* objectID_origin = [childLayer_origin objectID];

        if([curoverridesforiAutopage valueForKey:objectID_origin]){
            NSDictionary* tempoverrides = [curoverridesforiAutopage valueForKey:objectID_origin];
            //                NSString* classname = [tempoverrides className];
            if([[tempoverrides className] isEqualToString:@"__NSDictionaryM"] &&[tempoverrides valueForKey:@"symbolID"] && ![[tempoverrides valueForKey:@"symbolID"] isEqualToString:@""]){
                NSString* symbolID = [tempoverrides valueForKey:@"symbolID"];
                if([SketchCommon getcurSymbolMasterBySymbolID:symbolID]){
                    childLayer_origin = [SketchCommon getcurSymbolMasterBySymbolID:symbolID];
                    [childLayer_correspond setName:[childLayer_origin name]];
                }
            }
        }
        NSMutableDictionary* childcorrespondInfo = [NSMutableDictionary dictionary];
        [childcorrespondInfo setValue:childLayer_origin forKey:@"originLayer"];
        [childcorrespondInfo setValue:[NSNumber numberWithInteger:curlevel] forKey:@"level"];
        [childcorrespondInfo setValue:nodeType forKey:@"type"];
        [self.m_correspondingDic setValue:childcorrespondInfo forKey:objectID_childcorrespond];
    }

    //step5 loop for next
    for(NSUInteger childLayerNum=0;childLayerNum<[layers_corresponds count];childLayerNum++)
    {
        id<MSLayer> childLayer_corespond = [layers_corresponds objectAtIndex:childLayerNum];
        [self detach4Node:childLayer_corespond];
    }
    return true;
}

-(NSMutableArray*) getAllArtboardGroup: (id<MSLayer>)layer_info
{
    NSMutableArray * grouplist = [NSMutableArray array];
    // if (layer_info class == MSLayerGroup) {
    //     grouplist.push(layer_info)
    // }
    //
    // if(layer_info.class() == MSArtboardGroup || layer_info.class() == MSLayerGroup)
    // {
    //     var subLayers = layer_info.layers()
    //     for(var idxSub=0; idxSub<subLayers.count(); idxSub++)
    //     {
    //         var sublayer = subLayers[idxSub];
    //         getAllArtboardGroup(sublayer, grouplist)
    //     }
    // }
    return nil;
}

-(void) generatePartID: (id<MSLayer>)correspondLayer originLayer: (id<MSLayer>)originNode {


    //   let group_list = []
    // getAllArtboardGroup(artboard_info, group_list)
    // generateGroupLayerPartID(context, artboard_info, "", artboard_info)
    //
    // int maxIndexForNode = getMaxIndexForGroup(context,artboard_info);
    // var partIDTextNum = maxIndexForNode+1
    // for (let igroup = 0; igroup < group_list.length; igroup++) {
    //   let curGroup = group_list[igroup];
    //   var curgroupobjectID = curGroup.objectID();
    //   let curPartIDMetadata = context.command.valueForKey_onLayer_forPluginIdentifier(
    //       'PartID',
    //       curGroup,
    //       'tmnaMM'
    //   );
    //   var curgrouppartID = "";
    //   if (curPartIDMetadata && curPartIDMetadata[curgroupobjectID]) {
    //       curgrouppartID = curPartIDMetadata[curgroupobjectID]
    //   }
    //   else{
    //       var curgroupobjectInfo = {}
    //       curgrouppartID = convertNumToStr(partIDTextNum)
    //       curgroupobjectInfo[curgroupobjectID] = curgrouppartID;
    //       context.command.setValue_forKey_onLayer_forPluginIdentifier(
    //           curgroupobjectInfo,
    //           "PartID",
    //           curGroup,
    //           "tmnaMM");
    //       partIDTextNum = partIDTextNum + 1;
    //   }
    //   //LogJS.error("importexport","generateGroupLayerPartID "+curGroup.name()+"")
    //   generateGroupLayerPartID(context, curGroup, curgrouppartID, artboard_info)
    // }
}

- (NSMutableArray*)convertObjectsIDtoArray:(NSArray*)layers dic:(NSMutableDictionary*)objectMap
{
    NSMutableArray* result = [NSMutableArray array];
    for(NSUInteger num=0;num<[layers count];num++)
    {
        id<MSLayer> curlayer = [layers objectAtIndex:num];
        NSString* curlayerObjectID = [curlayer objectID];
        [result addObject:curlayerObjectID];
        [objectMap setValue:curlayer forKey:curlayerObjectID];
    }
    return result;
}

-(void) makeJsonInfo4Node:(id<MSLayer>)layer_correspond infoContent:(NSMutableDictionary*)infoContent inArtboard:(id<MSLayer>)artboard partInfo:(NSMutableDictionary*)partInfo
{
//  id<MSLayer> curnode_correspond = [[layer_correspond layers] objectAtIndex:childNum];
    //get metadata
    id<MSPluginCommand> command = [SketchCommon command];
    NSMutableArray * metaData = [command valueForKey:@"metadata" onLayer:layer_correspond forPluginIdentifier:@"tmnaMM"];
    //get part IDs
    NSString * curLayerPartInfo = [command valueForKey:@"PartID" onLayer:layer_correspond forPluginIdentifier:@"tmnaMM"];

    NSMutableDictionary * metaDic = [self makeMetadata: metaData];
    NSString* objectID_correspond = [layer_correspond objectID];

    NSMutableDictionary* correspondInfo = [self.m_correspondingDic objectForKey:objectID_correspond];
    id<MSLayer> curnode_origin = [correspondInfo valueForKey:@"originLayer"];
    if(curnode_origin == nil){
      return;
    }
    NSInteger level = [[correspondInfo valueForKey:@"level"] integerValue];
    NSString* nodeType = [correspondInfo valueForKey:@"type"];
    NSString* name_origin = [curnode_origin name];
    if([nodeType isEqualToString:@"DirectCorrespond"]){
        partInfo = [[SketchCommon command] valueForKey:@"PartID" onLayer:curnode_origin forPluginIdentifier:@"tmnaMM"];

        [self getChildrenMetaData: metaData originLayer: curnode_origin correspond:layer_correspond];
    }else{
        //in lib :if layer is visible(overrides is  none), donot export it
        //in screen :if layer is visible, export it
        if(![layer_correspond isVisible]){
            return;
        }
    }
    NSString* curPartID = @"";
//    if(partInfo && [partInfo valueForKey:objectID_origin]){
//        curPartID = [partInfo valueForKey:objectID_origin];
//    }
    NSMutableDictionary* childInfoContent = infoContent;
    if([self checkIsNeedExport:curnode_origin correspondLayer:layer_correspond level:level]){
        curPartID = [SketchCommon readLayerInfo:@"partID" layer:layer_correspond keyWord:@"iautoExportConfig"];
        NSMutableDictionary* curnodeJsonIndo = [NSMutableDictionary dictionary];
        [curnodeJsonIndo setValue:name_origin forKey:@"Parts Name"];
        [curnodeJsonIndo setValue:name_origin forKey:@"Display image"];
        [curnodeJsonIndo setValue:curPartID forKey:@"Parts ID"];
        if([self checkIsCommonSymbol:curnode_origin]){
            [curnodeJsonIndo setValue:[NSNumber numberWithInteger:1] forKey:@"common symbol"];
        }
        else{
            [curnodeJsonIndo setValue:[NSNumber numberWithInteger:0] forKey:@"common symbol"];
        }
        BOOL flag = [[SketchCommon readLayerInfo:@"iautoTouchFlag" layer:layer_correspond keyWord:@"iautoExportConfig"] boolValue];
        if(flag == true){
            [curnodeJsonIndo setValue:[NSNumber numberWithInteger:1] forKey:@"touch symbol"];
        }
        else{
            [curnodeJsonIndo setValue:[NSNumber numberWithInteger:0] forKey:@"touch symbol"];
        }
        [curnodeJsonIndo setValue:[self getPartsTypeforJson: metaDic] forKey:@"Parts Type"];
        [curnodeJsonIndo setValue:[self getTargetIDformMetaforJson: metaDic] forKey:@"choose target"];
        [curnodeJsonIndo setValue:[self getConditionDict: metaDic curLayer: layer_correspond byKey:@"displayCondition"] forKey:@"Display Condition"];
        [curnodeJsonIndo setValue:[self getTextOrImageInformation: metaDic curLayer: layer_correspond byKey:@"textImageDeleteInMotion"] forKey:@"Text or Image information"];
        [curnodeJsonIndo setValue:[self getSWInformation: metaDic curLayer: layer_correspond ] forKey:@"SW Information"];
        NSMutableDictionary* childJsonIndo = [NSMutableDictionary dictionary];
        [curnodeJsonIndo setValue:childJsonIndo forKey:@"subsymbols"];
        [self makeJsonSketchInfo4Node:layer_correspond originLayer:curnode_origin toCurInfo:curnodeJsonIndo inArtboard:artboard];
        [infoContent setValue:curnodeJsonIndo forKey:objectID_correspond];
        childInfoContent = childJsonIndo;
    }

    if([self checkIsContinue:0 correspondLayer:layer_correspond layer:curnode_origin])
    {
        if([layer_correspond containsLayers]){
            [self.m_linkedObjectId addObject:[curnode_origin objectID]];
            for(NSInteger childNum=0;childNum<[[layer_correspond layers] count];childNum++){
                id<MSLayer> curLayer = [[layer_correspond layers] objectAtIndex:childNum];
                [self makeJsonInfo4Node:curLayer infoContent:infoContent inArtboard:artboard partInfo:partInfo];
            }
            [self.m_linkedObjectId removeLastObject];
        }
    }
}

-(void) generatePartID4Node:(id<MSLayer>)layer_correspond prex:(NSString*)prex index:(NSMutableArray*)startNum
{
    NSInteger index_num = [[startNum objectAtIndex:0] integerValue];
    NSInteger char_num = [[startNum objectAtIndex:1] integerValue];
    NSString* objectID_correspond = [layer_correspond objectID];
    NSMutableDictionary* correspondInfo = [self.m_correspondingDic objectForKey:objectID_correspond];
    id<MSLayer> curnode_origin = [correspondInfo valueForKey:@"originLayer"];
    if([self checkIsNeedExport:curnode_origin correspondLayer:layer_correspond level:0]){
        NSString* curpartID = nil;
        if([self checkIsTouchable:curnode_origin]){
            NSString* intNUm = [CStringUtils convertNumToStr:char_num];
            if([prex isEqualToString:@""]){
                curpartID = intNUm;
                char_num += 1;
            }
            else{
                curpartID = [[prex stringByAppendingString:@"_"] stringByAppendingString:intNUm];
                char_num += 1;
            }
            [SketchCommon writeLayerInfo:@"iautoTouchFlag" value:[NSNumber numberWithBool:true] layer:layer_correspond keyWord:@"iautoExportConfig"];
        }
        else{
            NSString* intNUm = [NSString stringWithFormat:@"%ld",(long)index_num];
            if([prex isEqualToString:@""]){
                curpartID = intNUm;
                index_num += 1;
            }
            else{
                curpartID = [[prex stringByAppendingString:@"_"] stringByAppendingString:intNUm];
                index_num += 1;
            }
            [SketchCommon writeLayerInfo:@"iautoTouchFlag" value:[NSNumber numberWithBool:false] layer:layer_correspond keyWord:@"iautoExportConfig"];
        }
        [startNum removeAllObjects];
        [startNum addObject:[NSNumber numberWithInteger:index_num]];
        [startNum addObject:[NSNumber numberWithInteger:char_num]];
        [SketchCommon writeLayerInfo:@"partID" value:curpartID layer:layer_correspond keyWord:@"iautoExportConfig"];
        if([self checkIsContinue:0 correspondLayer:layer_correspond layer:curnode_origin] && [layer_correspond containsLayers]){
            NSMutableArray* nextStartNum = [NSMutableArray array];
            [nextStartNum addObject:[NSNumber numberWithInteger:1]];
            [nextStartNum addObject:[NSNumber numberWithInteger:1]];
            for(NSInteger childNum=0;childNum<[[layer_correspond layers] count];childNum++){
                id<MSLayer> curLayer = [[layer_correspond layers] objectAtIndex:childNum];
                [self generatePartID4Node:curLayer prex:curpartID index:nextStartNum];
            }
        }
    }
    else if([self checkIsContinue:0 correspondLayer:layer_correspond layer:curnode_origin]){
        if([layer_correspond containsLayers]){
            for(NSInteger childNum=0;childNum<[[layer_correspond layers] count];childNum++){
                id<MSLayer> curLayer = [[layer_correspond layers] objectAtIndex:childNum];
                [self generatePartID4Node:curLayer prex:prex index:startNum];
            }
        }
    }
}

-(void) getChildrenMetaData:(NSArray*) meta originLayer: (id<MSLayer> )originLayer correspond:(id<MSLayer>)layer_correspond
{
    id<MSPluginCommand> command = [SketchCommon command];
    if([SketchCommon isInstance:originLayer]){

    id<MSSymbolMaster> symbolMaster_originLayer = nil;
    id<MSSymbolInstance> instance_originLayer = originLayer;
    symbolMaster_originLayer = [instance_originLayer symbolMaster];

    for(NSInteger i = 0; i < [meta count]; i++){
      NSDictionary* data = meta[i];
      NSString* key = [data objectForKey:@"type"];
      NSDictionary* value = [data objectForKey:@"content"];

      //get correspond child meta data
      if([key isEqualToString:@"child"]){
          NSString * idInfo = [value  objectForKey:@"id"];
          NSArray * origin_children = [symbolMaster_originLayer children];
          for(NSInteger j = 0; j < [origin_children count]; j++){
              id<MSLayer> child = [origin_children objectAtIndex:j];
              NSString* originID = [child objectID];

              if([originID isEqualToString:idInfo]){ //found  origin layer
                  //find copy layer
                  NSArray * groupChildren = [layer_correspond children];
                  for(NSInteger k = 0; k < [groupChildren count]; k++){
                      id<MSLayer> groupChild = groupChildren[k];
                      NSString* groupChildID = [groupChild objectID];
                      NSMutableDictionary* correspondInfo = [self.m_correspondingDic objectForKey:groupChildID];
                      id<MSLayer> curnode_origin = [correspondInfo valueForKey:@"originLayer"];
                      if([[curnode_origin objectID] isEqualToString: originID]){ //found  copy layer
                          NSArray * groupChildMeta = [value  objectForKey:@"metadata"]; //get metadata
                          [command setValue:groupChildMeta forKey:@"metadata" onLayer:groupChild forPluginIdentifier:@"tmnaMM"];
                      }
                  }
              }
          }
        }
    }
  }
}

-(BOOL)checkPageIsIgnore:(NSString*)pageName
{
    if(self.m_pageSelectConfig){
        if([self.m_pageSelectConfig valueForKey:pageName]){
            if(![[self.m_pageSelectConfig valueForKey:pageName] boolValue]){
                return true;
            }
        }
    }
    return false;
}

-(BOOL)checkIsNeedExport:(id<MSLayer>)targetLayer correspondLayer:(id<MSLayer>)correspondLayer level:(NSInteger)level
{
//    NSString* layerClass = [targetLayer className];
//    if([layerClass isEqualToString:@"MSSymbolInstance"]){
//        if(level == 2 || level == 1){
//            return true;
//        }
//        else{
//            return false;
//        }
//    }
//    else if([layerClass isEqualToString:@"MSLayerGroup"]){
//        return false;
//    }
//    else{
//        return false;
//    }

    if(!targetLayer || !correspondLayer){
        return false;
    }
    if(![correspondLayer isVisible]){
        return false;
    }
    NSString* targetLayerClassName = [targetLayer className];
    NSString* targetLayerName = [targetLayer name];

    if([targetLayerClassName isEqualToString:@"MSArtboardGroup"]){
        return true;
    }
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_export_flag" layer:targetLayer keyWord:@"iautoExportConfig"];
    BOOL export_flag = false;
    if(flag){
        if([flag integerValue] == 1){
            export_flag = true;
        }
    }
    else {
        NSString* masterflag = nil;
        if([targetLayerClassName isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = targetLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            masterflag = [SketchCommon readLayerInfo:@"iauto_export_flag" layer:master keyWord:@"iautoExportConfig"];
            if(masterflag){
                if([masterflag integerValue] == 1){
                    export_flag = true;
                }
            }
        }
        if(!masterflag){
            if([self isLayerIgnored:correspondLayer]){
                return false;
            }
            if([targetLayerClassName isEqualToString:@"MSSymbolInstance"] || [targetLayerClassName isEqualToString:@"MSSymbolMaster"]){
                if([targetLayerName containsString:@"Images/"] || [targetLayerName containsString:@"Icon/"]){
                    return true;
                }
                else if([self checkIsTextInstance:correspondLayer]){
                    NSString* text = [self getTextInstanceValue:correspondLayer];
                    if([text isEqualToString:@""] || [[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] == 0){
                        return false;
                    }
                    return true;
                }
            }
        }
    }
    return export_flag;
}

-(NSMutableDictionary *) getSWInformation: (NSMutableDictionary *) metaData curLayer: (id<MSLayer>)layerInfo {
    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    //in Motion
    NSMutableDictionary* inMotionData = [NSMutableDictionary dictionary];
    inMotionData = [self getConditionDict: metaData curLayer: layerInfo byKey:@"sWTonedownMotion"];
    [retData setValue: inMotionData forKey: @"Tonedown condition in motion"];
    //except in motion
    NSMutableDictionary* exceptInMotionData = [NSMutableDictionary dictionary];
    exceptInMotionData = [self getConditionDict: metaData curLayer: layerInfo byKey:@"sWTonedownExceptInMotion"];
    [retData setValue: exceptInMotionData forKey: @"Tonedown condition except in motion"];
    //Selected condition
    NSMutableDictionary* selectedConditionData = [NSMutableDictionary dictionary];
    selectedConditionData = [self getConditionDict: metaData curLayer: layerInfo byKey:@"sWSelected"];
    [retData setValue: selectedConditionData forKey: @"Selected condition"];
    //SW operation Pattern
    NSString* SWOpePatternData = [self getSWOpePatternforJson: metaData];
    [retData setValue: SWOpePatternData forKey: @"SW operation Pattern"];

    //Selected condition
    NSMutableDictionary* opeRetData = [NSMutableDictionary dictionary];
    opeRetData = [self getOpeRetDict: metaData];
    [retData setValue: opeRetData forKey: @"Operation result"];

    //Selected condition
    NSString* beepData = [self getBeepInfoforJson: metaData];
    [retData setValue: beepData forKey: @"BEEP"];

    //Validation
    [retData setValue: [self getTextImgValidationforJson : metaData] forKey: @"Validation"];

  return retData;
}

-(NSString *) getBeepInfoforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSDictionary * retobj = metaData[@"beep"];
    if (retobj == nil) {
        return @"";
    }

    NSString * beepData = [retobj valueForKey:@"beep"];


    return beepData;
}
-(NSMutableDictionary *) getOpeRetDict: (NSMutableDictionary *) metaData {
    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    //Screen Transion
    NSString * screenTranData = [self getOpeResultScreenTransforJson: metaData];
    [retData setValue: screenTranData forKey: @"Screen Transion"];

    //Start Function
    NSString * screenFunData = [self getOpeResultStartFuncforJson: metaData];
    [retData setValue: screenFunData forKey: @"Start Function"];

    //Setting Value Change
    NSString * setValueChgData = [self getOpeResultSettingValueChangeforJson: metaData];
    [retData setValue: setValueChgData forKey: @"Setting Value Change"];

    //Setting Value Change
    NSString * otherData = [self getOpeResultOtherforJson: metaData];
    [retData setValue: otherData forKey: @"Other"];

    return retData;
}

-(NSString *) getOpeResultOtherforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }

    NSString * retobj = nil;
    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"] isEqualToString:@"other"] )
    {
        retobj = metaData[@"sw-operation-result"];
    }

    if (retobj == nil) {
        return @"";
    }

    return retobj;
}

-(NSString *) getOpeResultSettingValueChangeforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }

    NSString * retobj = nil;
    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"] isEqualToString: @"setting-value-change"])
    {
        retobj = metaData[@"sw-operation-result"];
    }

    if (retobj == nil) {
        return @"";
    }

    return retobj;
}

-(NSString *) getOpeResultStartFuncforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }

    NSString * retobj = nil;
    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"]  isEqualToString: @"start-function"])
    {
        retobj = metaData[@"sw-operation-result"];
    }

    if (retobj == nil) {
        return @"";
    }

    return retobj;
}

-(NSString *) getOpeResultScreenTransforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }

    NSString * retobj = nil;

    if (retobj == nil) {
        return @"";
    }

    if(metaData[@"sw-operation-result"] && [metaData[@"text-image-outside-input"][@"type"] isEqualToString:@"screen-transition"])
    {
        retobj = metaData[@"sw-operation-result"];
    }

    return retobj;
}

-(NSString *) getSWOpePatternforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSDictionary * retobj = metaData[@"sw-operation-pattern"];
    if (retobj == nil) {
        return @"";
    }
    NSString * dataStr = [retobj valueForKey:@"swOperationPattern"];
    return dataStr;
}

-(NSMutableDictionary *) getTextOrImageInformation: (NSMutableDictionary *) metaData curLayer: (id<MSLayer>)layerInfo byKey: (NSString*)con_name {
    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    //japanese
    NSMutableDictionary* japanData = [NSMutableDictionary dictionary];
    [japanData setValue: @"" forKey: @"Japanese"];
    [japanData setValue: @"" forKey: @"Fixed words"];
    [retData setValue: japanData forKey: @"Japanese"];
    //U.S.English
    NSMutableDictionary* usData = [NSMutableDictionary dictionary];
    [usData setValue: @"" forKey: @"U.S.English"];
    [usData setValue: @"" forKey: @"Fixed words"];
    [retData setValue: usData forKey: @"U.S.English"];
    //U.K.English
    NSMutableDictionary* ukData = [NSMutableDictionary dictionary];
    [ukData setValue: @"" forKey: @"U.K.English"];
    [ukData setValue: @"" forKey: @"Fixed words"];
    [retData setValue: ukData forKey: @"U.K.English"];
    //Fixed Image
    [retData setValue: @"" forKey: @"Fixed Image"];

    [retData setValue: [self getConditionDict: metaData curLayer: layerInfo byKey:@"textImageDeleteInMotion"] forKey: @"Delete condition in motion"];

    //Outside Input data
    NSMutableDictionary* outsideInputData = [NSMutableDictionary dictionary];
    [outsideInputData setValue: @"" forKey: @"Display contents"];
    [outsideInputData setValue: @"" forKey: @"Format"];
    [outsideInputData setValue: @"" forKey: @"Range"];
    [retData setValue: outsideInputData forKey: @"Outside Input"];

    //Validation
    [retData setValue: [self getTextImgValidationforJson : metaData] forKey: @"Validation"];

  return retData;
}

-(NSString *) getTextImgValidationforJson: (NSMutableDictionary *) metaData  {
    if (metaData == nil) {
        return @"";
    }
    NSString* retobj = metaData[@"text-image-validation"];
    if (retobj == nil) {
        return @"";
    }

    return retobj;
}

-(NSMutableDictionary *) getConditionDict: (NSMutableDictionary *) metaData curLayer: (id<MSLayer>)layerInfo byKey: (NSString*)con_name {
    NSString* con_key =  [NSString stringWithFormat:@"%@__%@", con_name, [layerInfo objectID]];
    // var conletters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

    NSMutableDictionary* retData = [NSMutableDictionary dictionary];
    [retData setValue: @"" forKey: @"Formula"];

    NSMutableDictionary* conditionData = [NSMutableDictionary dictionary];
    [retData setValue: conditionData forKey: @"Condition"];

    NSMutableDictionary* sameConditionData = [NSMutableDictionary dictionary];
    [retData setValue: sameConditionData forKey: @"Same Condition"];
    [sameConditionData setValue: @"" forKey: @"Parts ID"];
    [sameConditionData setValue: @"" forKey: @"Screen ID"];

    [retData setValue: @"" forKey: @"else"];

    if (metaData == nil) {
        return retData;
    }

    NSDictionary* con_obj = metaData[con_key];
    if (con_obj == nil) {
        return retData;
    }

    NSString *nullStr = @"null";
    //else data
    NSString *elseDataStr = [con_obj objectForKey:@"else"];
    NSRange range = [elseDataStr rangeOfString:nullStr];
    if ( range.length != 0)
    {
        [retData setValue: @"" forKey: @"else"];
    }
    else{
        [retData setValue: elseDataStr forKey: @"else"];
    }
    //Formula data
    NSString *formulaDataStr = [con_obj objectForKey:@"Formula"];
    range = [formulaDataStr rangeOfString:nullStr];
    if ( range.length != 0)
    {
        [retData setValue: @"" forKey: @"Formula"];
    }
    else{
        [retData setValue: formulaDataStr forKey: @"Formula"];
    }

    NSDictionary* sameConditionOrig =[con_obj objectForKey:@"sameCondition"];
    NSString *partsIDDataStr = [sameConditionOrig objectForKey:@"partsID"];
    NSString *screenIDDataStr = [sameConditionOrig objectForKey:@"screenID"];
    range = [partsIDDataStr rangeOfString:nullStr];
    if ( range.length != 0)
    {
        [retData setValue: @"" forKey: @"Parts ID"];
    }
    else{
        [retData setValue: partsIDDataStr forKey: @"Parts ID"];
    }
    range = [screenIDDataStr rangeOfString:nullStr];
    if ( range.length != 0)
    {
        [retData setValue: @"" forKey: @"Screen ID"];
    }
    else{
        [retData setValue: screenIDDataStr forKey: @"Screen ID"];
    }

    // var iletter = 0;
    // con_obj.conditions.forEach(icon => {
    //     iletter = iletter % 26
    //     let nowLetter = conletters[iletter]
    //     ret_data_dict["Condition"][nowLetter] = ""+icon
    //     iletter = iletter+1
    //  })

    return retData;
}
-(NSString*) getPartsTypeforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSDictionary* retobj = metaData[@"Parts Type"];

    if (retobj == nil) {
        return @"";
    }
    if ([[retobj objectForKey:@"part"] isEqualToString: @"Select Part Type"]) {
        return @"";
    }

    return [retobj objectForKey:@"part"];
}

-(NSString*) getTargetIDformMetaforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";;
    }
    NSString* retobj = metaData[@"Target"];
    if (retobj == nil) {
        return @"";
    }
    return retobj;
}

//get sketch info
-(void) makeJsonSketchInfo4Artboard: (id<MSLayer>)curnode_correspond originLayer:(id<MSLayer>)curnode_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo
{
    NSString* objectID_origin = [curnode_origin objectID];

    NSMutableDictionary* curnodeSketchJsonInfo = [NSMutableDictionary dictionary];

    //make UUID
    [curnodeSketchJsonInfo setValue:objectID_origin forKey:@"uuid"];

    //make Rect
    NSMutableDictionary* curnodeRectJsonInfo = [NSMutableDictionary dictionary];
    CGRect currentObjAbsRect = [[curnode_origin absoluteRect] absoluteRect];

    int rectW = currentObjAbsRect.size.width;
    int rectH = currentObjAbsRect.size.height;

    NSString* w_origin = [NSString stringWithFormat:@"%d",rectW];
    NSString* h_origin = [NSString stringWithFormat:@"%d",rectH];

    [curnodeRectJsonInfo setValue:@"0" forKey:@"x"];
    [curnodeRectJsonInfo setValue:@"0" forKey:@"y"];
    [curnodeRectJsonInfo setValue:w_origin forKey:@"w"];
    [curnodeRectJsonInfo setValue:h_origin forKey:@"h"];
    [curnodeSketchJsonInfo setValue:curnodeRectJsonInfo forKey:@"Rect"];

    //make imgPath
    NSString* imgPath = [self.m_resFilePath stringByAppendingString:@"/___exportspecs___/images"];
    [SketchCommon exportLayerTofile:curnode_correspond filePath:imgPath fileName:objectID_origin];
    NSString* curimgPath = [[[imgPath stringByAppendingString:@"/"] stringByAppendingString:objectID_origin] stringByAppendingString:@".png"];
    [curnodeSketchJsonInfo setValue:curimgPath forKey:@"imgPath"];

    [curnodeJsonIndo setValue:curnodeSketchJsonInfo forKey:@"sketchInfo"];
}

-(bool) checkIsTextInstance:(id<MSLayer>)layer
{
    if ([[layer className] isEqualToString:@"MSTextLayer"]) {
        return true;
    }
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        id<MSSymbolInstance> instance = layer;
        NSMutableArray* overridesPoints = [instance overridePoints];
        if (nil != overridesPoints && 1 == [overridesPoints count]) {
            id<MSOverridePoint> overridePoint = [overridesPoints objectAtIndex:0];
            if (nil != overridePoint) {
                NSString* overridesVal = [overridePoint name];
                if (nil != overridesVal && [overridesVal rangeOfString:@"_stringValue"].location != NSNotFound) {
                    if (48 == [overridesVal length]) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}
-(NSString*) getTextInstanceValue:(id<MSLayer>)layer
{
    NSString* contentValue = @"";
    if ([[layer className] isEqualToString:@"MSTextLayer"]) {
        id<MSTextLayer> textLayer = layer;
        contentValue = [textLayer stringValue];
    }
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        id<MSSymbolInstance> instance = layer;
        NSMutableArray* symbolLayers = [[instance symbolMaster] layers];
        NSString* testSymbolID = nil;
        for (int i=0; i<[symbolLayers count]; i++) {
            id<MSLayer> symbolLayer = [symbolLayers objectAtIndex:i];
            if ([[symbolLayer className] isEqualToString:@"MSTextLayer"]) {
                testSymbolID = [symbolLayer objectID];
            }
        }
        if (nil != testSymbolID) {
            NSMutableDictionary* overrides = [instance overrides];
            if (nil != overrides && [overrides count] > 0) {
                contentValue = [overrides objectForKey:testSymbolID];
            }
        }
    }
    return contentValue;
}

//get sketch info
-(void) makeJsonSketchInfo4Node:(id<MSLayer>)curnode_correspond originLayer:(id<MSLayer>)curnode_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo  inArtboard:(id<MSLayer>)artboard
{
    NSString* objectID_origin = [curnode_origin objectID];
    NSString* objectID_corespond = [curnode_correspond objectID];
    NSMutableDictionary* curnodeSketchJsonInfo = [NSMutableDictionary dictionary];

    //make UUID
    if ([self.m_linkedObjectId count] > 0) {
        NSString* temp = [self.m_linkedObjectId componentsJoinedByString:@"_"];
        temp = [[temp stringByAppendingString:@"_"] stringByAppendingString:objectID_origin];
        [curnodeSketchJsonInfo setValue:temp forKey:@"uuid"];
    } else {
        [curnodeSketchJsonInfo setValue:objectID_origin forKey:@"uuid"];
    }


    //make Rect
    NSMutableDictionary* curnodeRectJsonInfo = [NSMutableDictionary dictionary];
    CGRect currentObjAbsRect = [[curnode_correspond absoluteRect] absoluteRect];
    CGRect currentArtboardAbsRect = [[artboard absoluteRect] absoluteRect];

    int rectX = currentObjAbsRect.origin.x - currentArtboardAbsRect.origin.x;
    int rectY = currentObjAbsRect.origin.y - currentArtboardAbsRect.origin.y;
    int rectW = currentObjAbsRect.size.width;
    int rectH = currentObjAbsRect.size.height;

    NSString* x_origin = [NSString stringWithFormat:@"%d",rectX];
    NSString* y_origin = [NSString stringWithFormat:@"%d",rectY];
    NSString* w_origin = [NSString stringWithFormat:@"%d",rectW];
    NSString* h_origin = [NSString stringWithFormat:@"%d",rectH];

    [curnodeRectJsonInfo setValue:x_origin forKey:@"x"];
    [curnodeRectJsonInfo setValue:y_origin forKey:@"y"];
    [curnodeRectJsonInfo setValue:w_origin forKey:@"w"];
    [curnodeRectJsonInfo setValue:h_origin forKey:@"h"];
    [curnodeSketchJsonInfo setValue:curnodeRectJsonInfo forKey:@"Rect"];

    //make imgPath
    NSString* imgPath = [self.m_resFilePath stringByAppendingString:@"/___exportspecs___/images"];
    [SketchCommon exportLayerTofile:curnode_correspond filePath:imgPath fileName:objectID_corespond];
    NSString* curimgPath = [[[imgPath stringByAppendingString:@"/"] stringByAppendingString:objectID_corespond] stringByAppendingString:@".png"];

    if ([self checkIsTextInstance:curnode_correspond]) {
//        if ([[curnode_correspond name] isEqualToString:@"text/18/Left/Regular/Gray 4"]) {
//            BLOG(@"", @"");
//        }
        NSString* textVal = [self getTextInstanceValue:curnode_correspond];
        if (nil == textVal) {
            textVal = [NSString stringWithString:@"nil"];
        }
        [curnodeSketchJsonInfo setValue: textVal forKey:@"imgPath"];
    }
    else
    {
        [curnodeSketchJsonInfo setValue: curimgPath forKey:@"imgPath"];
    }

    [curnodeJsonIndo setValue:curnodeSketchJsonInfo forKey:@"sketchInfo"];

}

-(void) makeJsonDestGradeInfo4Node: (id<MSLayer>)curArtboard_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo byMeta:(NSMutableDictionary *) metaData
{
    NSArray * dest_region_list = @[@"Japan",@"Europe/Russia",@"China",@"Oceania",@"South Africa",@"HongKong / Macao",@"South East Asia",
                                @"India",@"Taiwan",@"Middle East",@"South and Central (Brazil & Argentina)",@"South and Central",@"Korea",@"North America"];


    for (int one_region_index = 0; one_region_index < [dest_region_list count]; one_region_index ++ ) {
        NSString* one_region = dest_region_list[one_region_index];
        //japan
        NSMutableDictionary* oneRegionInfo = [NSMutableDictionary dictionary];
        [curnodeJsonIndo setValue:oneRegionInfo forKey: dest_region_list[one_region_index]];

        NSMutableDictionary* LexusInfo = [NSMutableDictionary dictionary];
        [oneRegionInfo setValue:LexusInfo forKey: @"Lexus"];

        NSMutableDictionary* UnavailableInfo = [NSMutableDictionary dictionary];
        [LexusInfo setValue: UnavailableInfo forKey: @"Unavailable"];

        [UnavailableInfo setValue: @"" forKey: @"L1"];
        [UnavailableInfo setValue: @"" forKey: @"L1.5"];
        [UnavailableInfo setValue: @"" forKey: @"L2"];

        NSMutableDictionary* AvailableInfo = [NSMutableDictionary dictionary];
        [LexusInfo setValue: AvailableInfo forKey: @"Available"];
        [AvailableInfo setValue: @"" forKey: @"L1"];
        [AvailableInfo setValue: @"" forKey: @"L1.5"];
        [AvailableInfo setValue: @"" forKey: @"L2"];

        //toyota
        NSMutableDictionary* ToyotaInfo = [NSMutableDictionary dictionary];
        [oneRegionInfo setValue:ToyotaInfo forKey: @"Toyota"];

        NSMutableDictionary* toyotaUnavailableInfo = [NSMutableDictionary dictionary];
        [ToyotaInfo setValue: toyotaUnavailableInfo forKey: @"Unavailable"];

        [toyotaUnavailableInfo setValue: @"" forKey: @"Entry DA"];
        [toyotaUnavailableInfo setValue: @"" forKey: @"L1"];
        [toyotaUnavailableInfo setValue: @"" forKey: @"L2"];
        [toyotaUnavailableInfo setValue: @"" forKey: @"T-EMVN"];

        NSMutableDictionary* toyotaAvailableInfo = [NSMutableDictionary dictionary];
        [ToyotaInfo setValue: toyotaAvailableInfo forKey: @"Available"];

        [toyotaAvailableInfo setValue: @"" forKey: @"Entry DA"];
        [toyotaAvailableInfo setValue: @"" forKey: @"L1"];
        [toyotaAvailableInfo setValue: @"" forKey: @"L2"];
        [toyotaAvailableInfo setValue: @"" forKey: @"T-EMVN"];
    }
}

//get sketch info
-(void) makeJsonExcelInfo4Node: (id<MSLayer>)curArtboard_origin toCurInfo :(NSMutableDictionary*)curnodeJsonIndo byMeta:(NSMutableDictionary *) metaData
{
    //make excel Info
    NSMutableDictionary* excelInfoJsonIndo = [NSMutableDictionary dictionary];
    [curnodeJsonIndo setValue:excelInfoJsonIndo forKey:@"excelInfo"];

    NSString* ScreenID = @"";
    NSString* ScreenName = [curArtboard_origin name];
    NSRange range =  [ScreenName rangeOfString: @"-"];
    if(range.length != 0){
        ScreenID = [ScreenName substringWithRange:NSMakeRange(0, range.location)];
        // NSCharacterSet * whitespace = [NSCharacterSet  whitespaceCharacterSet];
        ScreenID = [ScreenID stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        // [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]
    }

    [excelInfoJsonIndo setValue: ScreenID forKey:@"Screen ID"];
    [excelInfoJsonIndo setValue: [curArtboard_origin objectID] forKey:@"Basic Screen ID"];
    [excelInfoJsonIndo setValue:[ curArtboard_origin name] forKey:@"Screen Name"];
    [excelInfoJsonIndo setValue:[self getMetaRemarksforJson: metaData] forKey:@"Note"];

}


-(NSString *) getMetaRemarksforJson: (NSMutableDictionary *) metaData {
    if (metaData == nil) {
        return @"";
    }
    NSString * retobj = metaData[@"Remarks"];
    if (retobj == nil) {
        return @"";
    }

    return retobj;
}

//get sketch info
-(NSMutableDictionary*) makeMetadata:(NSMutableArray*)originData
{
  NSMutableDictionary * ret = [NSMutableDictionary dictionary];
  int a = [originData count];
    for(NSInteger i = 0; i < [originData count]; i++){
      NSDictionary* data = [originData objectAtIndex:i];
      NSString* key = [data objectForKey:@"type"];
      NSDictionary* value = [data objectForKey:@"content"];

      [ret setValue: value forKey:key];
    }
    return ret;
}

-(NSInteger) getDeatchLevel:(NSString*)objectID
{
    return 2;
}

-(BOOL) checkIsContinue:(NSInteger)level correspondLayer:(id<MSLayer>)correspondLayer layer:(id<MSLayer>)targetLayer
{
//    NSString* targetLayerClassName = [targetLayer className];
//    NSString* targetLayerName = [targetLayer name];
//    if([targetLayerClassName isEqualToString:@"MSSymbolInstance"]){
//        if([targetLayerName containsString:@"Images/"] || [targetLayerName containsString:@"Icon/"] || [targetLayerName containsString:@"text/"]){
//            return false;
//        }
//        else if ([targetLayerName isEqualToString:@"List/Alpha Jump"]){
//            return false;
//        }
//        else{
//
//        }
//    }
//    if(level > 0){
//        return true;
//    }
//    return false;
    if(!targetLayer || !correspondLayer){
        return false;
    }
    if(![correspondLayer isVisible]){
        return false;
    }
    NSString* targetLayerClassName = [targetLayer className];
    NSString* targetLayerName = [targetLayer name];
    if([targetLayerClassName isEqualToString:@"MSArtboardGroup"]){
        return true;
    }
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_expand_flag" layer:targetLayer keyWord:@"iautoExportConfig"];
    BOOL expand_flag = true;
    if(flag){
        if([flag integerValue] == 0){
            expand_flag = false;
        }
    }
    else{
        NSString* masterflag = nil;
        if([targetLayerClassName isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = targetLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            masterflag = [SketchCommon readLayerInfo:@"iauto_expand_flag" layer:master keyWord:@"iautoExportConfig"];
            if(masterflag){
                if([masterflag integerValue] == 0){
                    return false;
                }
            }
        }
        if(!masterflag){
            if([self isLayerIgnored:correspondLayer]){
                return false;
            }
            if([targetLayerClassName isEqualToString:@"MSSymbolInstance"] || [targetLayerClassName isEqualToString:@"MSSymbolMaster"]){
                if([targetLayerName containsString:@"Images/"] || [targetLayerName containsString:@"Icon/"] || [targetLayerName containsString:@"text/"]){
                    return false;
                }
            }
            if([self isLayerIgnored:targetLayer]){
                return false;
            }
        }
    }
    return expand_flag;
}

-(BOOL) checkIsTouchable:(id<MSLayer>)targetLayer
{
    BOOL touchFlag = false;
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_touchable_flag" layer:targetLayer keyWord:@"iautoExportConfig"];
    if(!flag){
        NSString* className = [targetLayer className];
        if([className isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = targetLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            if(master){
                flag = [SketchCommon readLayerInfo:@"iauto_touchable_flag" layer:master keyWord:@"iautoExportConfig"];
            }
        }
    }
    if(flag && [flag integerValue] == 1){
        return true;
    }
    return touchFlag;
    //
}

-(BOOL) checkIsCommonSymbol:(id<MSLayer>)targetLayer
{
    BOOL commonFlag = false;
    NSString* flag = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:targetLayer keyWord:@"iautoExportConfig"];
    if(!flag){
        NSString* className = [targetLayer className];
        if([className isEqualToString:@"MSSymbolInstance"]){
            id<MSSymbolInstance> instance = targetLayer;
            id<MSSymbolMaster> master = [instance symbolMaster];
            if(master){
                flag = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:master keyWord:@"iautoExportConfig"];
            }
        }
    }
    if(flag && [flag integerValue] == 1){
        return true;
    }
    return commonFlag;
    //NSString* commomFlag = [SketchCommon readLayerInfo:@"iauto_common_symbol_flag" layer:curnode_origin keyWord:@"iautoExportConfig"];
}

-(BOOL) isLayerIgnored:(id<MSLayer>)layer{

  NSString* layerName = [layer name];
  NSString* lowercaselayerName = [layerName lowercaseString];
  if( [lowercaselayerName isEqualToString:@"ignore redline"] || [lowercaselayerName isEqualToString:@"ignore redlines"])
  {
    return true;
  }

  if( [lowercaselayerName containsString:@"elevations"] || [lowercaselayerName containsString:@"elevation"]
    || [lowercaselayerName containsString:@"~shapes/"] || [lowercaselayerName containsString:@"Route Preview"]
    || [lowercaselayerName containsString:@"blank"] || [lowercaselayerName containsString:@"fade"]
    || [lowercaselayerName containsString:@"guide"] || [lowercaselayerName containsString:@"color"]
    || [lowercaselayerName containsString:@"shapes/rectangle"] || [lowercaselayerName containsString:@"bitmap"])
  {
    return true;
  }

  if ( [layerName containsString:@"🎨/Fill/"] || [layerName containsString:@"🎨/fill/"]
      || [layerName containsString:@"Spec/Tap Area"] || [layerName containsString:@"Map Gradient"])
  {
      return true;
  }
  if([self isTextLayerIgnored: layer]){
    return true;
  }
  if([self isPositionIgnore: layer]){
    return true;
  }

  return false;
}

-(BOOL) isPositionIgnore:(id<MSLayer>)layer
{
  id<MSLayer> artboard = [layer parentRoot];

  CGRect layerObjAbsRect = [[layer absoluteRect] absoluteRect];
  CGRect artboardAbsRect = [[artboard absoluteRect] absoluteRect];

  int layerX = layerObjAbsRect.origin.x;
  int layerY = layerObjAbsRect.origin.y;
  int layerW = layerObjAbsRect.size.width;
  int layerH = layerObjAbsRect.size.height;

  int artboardX = artboardAbsRect.origin.x;
  int artboardY = artboardAbsRect.origin.y;
  int artboardW = artboardAbsRect.size.width;
  int artboardH = artboardAbsRect.size.height;

  if ( layerX > artboardX +artboardW ) {
      return true;
  }
  if ( layerY > artboardY + artboardH) {
      return true;
  }

  if ( layerX + layerW < artboardX ) {
      return true;
  }
  if ( layerY + layerH < artboardY ) {
      return true;
  }

  return false;
}


-(BOOL) isArtboardIgnored:(id<MSLayer>)targetLayer
{
    NSString* targetLayerClass = [targetLayer className];
    if([targetLayerClass isEqualToString:@"MSArtboardGroup"]){
        NSString* targetLayerName = [targetLayer name];
        if([targetLayerName containsString:@"User Flows"] ){
            return  true;
        }
        CGFloat width = [targetLayer rect].size.width;
        CGFloat heigth = [targetLayer rect].size.height;
        if(width < 960.00 || heigth < 540.00){
            return true;
        }
        return false;
    }
    return true;
}

-(BOOL) isTextLayerIgnored:(id<MSLayer>)targetLayer
{
    NSString* textLayerID = nil;
    NSString* textOverridesContent = @"";
    NSString* targetLayerName = [targetLayer name];

    if(![targetLayerName containsString:@"text/"]){
        return false;
    }

    id<MSSymbolMaster> master = nil;

    NSString* targetLayerClass = [targetLayer className];

    if([targetLayerClass isEqualToString:@"MSSymbolInstance"] ){
        id<MSSymbolInstance> instance = targetLayer;
        master = [instance symbolMaster];
    }
    else if([targetLayerClass isEqualToString:@"MSSymbolMaster"]){
        master = targetLayer;
    }else{
        return false;
    }

    if(master != nil){
        NSArray* layerChildern = [master children];
        for(int i= 0; i<[layerChildern count]; i++){
            if([[layerChildern[i] className] isEqualToString:@"MSTextLayer"] ){
                textLayerID = [layerChildern[i] objectID];
                break;
            }
        }
    }

    if(textLayerID != nil && [targetLayerClass isEqualToString:@"MSSymbolInstance"]){
        NSDictionary* overrides = [targetLayer overrides];
        if(overrides && [overrides valueForKey: textLayerID]){
            textOverridesContent = [overrides valueForKey: textLayerID];
        }
        if([textOverridesContent isEqualToString:@""] || [textOverridesContent isEqualToString:@" "] || [textOverridesContent isEqualToString:@"  "] ){
            return true;
        }
        else {
            return false;
        }
    }
    return false;

}

void HMILOG(const NSString * fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    NSString * logContent = [[NSString alloc] initWithFormat:fmt arguments:args];
    va_end(args);

    BLOG(@"ExportHMISpec", @"%@",logContent);
}


@end
