//
//  SketchEventHandler.h
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#ifndef SketchEventHandler_h
#define SketchEventHandler_h

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "Sketch.h"
#import "CLog.h"
#import "pageSelectView.h"

@interface SketchEventHandler : NSObject

// base event handler
+ (void)onSetContextData:
            (id<MSPluginCommand>)command
              Document:(id<MSDocument>)document
            ScriptPath:(NSString*)scriptPath
             ScriptURL:(NSString*)scriptURL
             Selection:(NSMutableArray*)selection;

+ (void)onSetWorkspace: (NSString*) workspace;

+ (void)onInitSketchClass: (NSMutableDictionary*) objDict; // ClassName-Object
+ (void)onInitSketchClassWithObjects: (NSMutableArray*) objects; 

+ (void)onSelectChanged: (NSMutableArray*) selection;

// function
+ (void)showPageSelectedView;
+ (pageSelectView *)getpageSelectView;
+ (NSView *)getTestView;
+(void) startExportHMISpec:(NSString*)filePath;
+(void) startExportMarkConfig:(NSString*)filePath;
+(void) startImportMarkConfig:(NSString*)fileName;
+(void) resetExportMarkConfig;

+(void) test;

@end

#endif /* SketchEventHandler_h */
