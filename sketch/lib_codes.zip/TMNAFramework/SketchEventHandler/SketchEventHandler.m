//
//  SketchEventHandler.m
//  sketchPluginFramework
//
//  Created by nb on 2017/1/24.
//  Copyright © 2017年 iauto. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "public/SketchEventHandler.h"
#import "SketchCommon.h"
#import "Sketch.h"
#import "pageSelectView.h"
#import "ExportMarkConfig.h"
#import "ExportTMNASpec.h"
#import "TestCoreData.h"

@implementation SketchEventHandler

+ (void)onSetContextData:
(id<MSPluginCommand>)command
                Document:(id<MSDocument>)document
              ScriptPath:(NSString*)scriptPath
               ScriptURL:(NSString*)scriptURL
               Selection:(NSMutableArray*)selection
{
    [[Sketch instance] initialize:document];
    [SketchCommon setContextData:command Document:document ScriptPath:scriptPath ScriptURL:scriptURL Selection:selection];
}

+ (void)onSetWorkspace: (NSString*) workspace
{
    [SketchCommon setWorkSpace:workspace];
}

+ (void)onInitSketchClass: (NSMutableDictionary*) objDict
{
    [[Sketch instance] initSketchClass:objDict];
}
+ (void)onInitSketchClassWithObjects: (NSMutableArray*) objects
{
    [[Sketch instance] initSketchClassWithObjects:objects];
}

// base event handler
+ (void)onSelectChanged: (NSMutableArray*) selection
{
    
}

+(void) startExportHMISpec:(NSString*)filePath
{
//    ExportTMNASpec* exportTMNASpecObj = [[ExportTMNASpec alloc] init];
//    [exportTMNASpecObj startExportHMISpec];
    
}

//+ (void)showPageSelectedView
//{
//    pageSelectView* view = [pageSelectView shared];
//    [view startShowPageInfo];
//}
//
//+ (pageSelectView *)getpageSelectView
//{
//    pageSelectView* view = [pageSelectView shared];
//    return view;
//}

+(void) startExportMarkConfig:(NSString*)filePath
{
//    pageSelectView* pageSelectViewObj = [[pageSelectView alloc] init];
//    [pageSelectViewObj startShowPageInfo];
    ExportMarkConfig* exportMarkConfigObj = [[ExportMarkConfig alloc] init];
    [exportMarkConfigObj exportMarkConfig:filePath];
}

+(void) startImportMarkConfig:(NSString*)fileName
{
    ExportMarkConfig* exportMarkConfigObj = [[ExportMarkConfig alloc] init];
    [exportMarkConfigObj importMarkConfig:fileName];
}

+(void) resetExportMarkConfig
{
    ExportMarkConfig* exportMarkConfigObj = [[ExportMarkConfig alloc] init];
    [exportMarkConfigObj resetExportMarkConfig];
}

+(void) test
{
    TestCoreData* coreData = [[TestCoreData alloc] init];
    [coreData test];
}
@end
