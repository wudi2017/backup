//
//  UpdateMetadata.m
//  TMNAFramework
//
//  Created by nb on 2019/1/21.
//

#import <Foundation/Foundation.h>
#import "UpdateMetadata.h"
#import "CJSONXConvertor.h"

@implementation UpdateMetadata

+ (id) getDataByType:(NSMutableArray*)metadata TYPE:(NSString*)typeStr
{
    NSMutableDictionary* dataDict = nil;
    
    for (int iMeta=0; iMeta<[metadata count]; iMeta++) {
        NSMutableDictionary* item  = [metadata objectAtIndex:iMeta];
         NSString* type = [item objectForKey:@"type"];
        if ([type isEqualToString: typeStr]) {
            NSMutableDictionary* content = [item objectForKey:@"content"];
            dataDict = [CJSONXConvertor convertXObjectToValidJsonFormatObject:content];
        }
    }
    
    return dataDict;
}

+ (void) tryInitDefaultMetaDataWithMasterLayer:(NSMutableDictionary*)subPartsItem MetaData:(NSMutableArray*)metadata
{
    id<MSLayer> masterLayer = [subPartsItem objectForKey:@"layer"];
    NSString*  absoluteObjectID = [subPartsItem objectForKey:@"absoluteObjectID"];
    
    //NSString* masterLayerID = [masterLayer objectID];
    NSString* masterLayerName = [masterLayer name];
    NSMutableArray* masterLayerMetaData = [SketchCommon readLayerInfo:@"metadata" layer:masterLayer keyWord:@"tmnaMM"];
    if (nil == masterLayerMetaData) {
        return;
    }
    masterLayerMetaData = [CJSONXConvertor convertXObjectToValidJsonFormatObject:masterLayerMetaData];
    
    [self removeMetaDataWithType:@"child" DestMetaData:masterLayerMetaData];
    
    NSMutableDictionary* partsType = [self getDataByType:masterLayerMetaData TYPE:@"Parts Type"];
    NSString* partsTypeStr = [partsType objectForKey:@"part"];
    if ([partsTypeStr isEqualToString:@"Select Part Type"]) {
        // null metadata
        return;
    }
    
    // check exist
    bool bAlreadExist = false;
    for (int iMeta=0; iMeta<[metadata count]; iMeta++) {
        NSMutableDictionary* item  = [metadata objectAtIndex:iMeta];
        NSString* type = [item objectForKey:@"type"];
        
        if ([type isEqualToString:@"child"]) {
            
            NSMutableDictionary* content = [item objectForKey:@"content"];
            NSString* objectID = [content objectForKey:@"id"];
            if ([objectID isEqualToString:absoluteObjectID]) {
                NSString* subMetaData = [content objectForKey:@"metadata"];
                
                NSMutableDictionary* partsType = [self getDataByType:subMetaData TYPE:@"Parts Type"];
                NSString* partsTypeStr = [partsType objectForKey:@"part"];
                if (![partsTypeStr isEqualToString:@"Select Part Type"]) {
                    bAlreadExist = true;
                    break;
                }
                else
                {
                    [metadata removeObjectAtIndex:iMeta];
                    break;
                }
            }
        }
    }
    
    if (!bAlreadExist) {

        NSMutableDictionary* metadataContent = [NSMutableDictionary dictionary];
        [metadataContent setObject:absoluteObjectID forKey:@"id"];
        [metadataContent setObject:masterLayerMetaData forKey:@"metadata"];
        
        NSMutableDictionary* childMetaData = [NSMutableDictionary dictionary];
        [childMetaData setObject:@"child" forKey:@"type"];
        [childMetaData setObject:metadataContent forKey:@"content"];
        
        [metadata addObject:childMetaData];
        //BLOG(@"syncmetadata", @"    InitDefaultMetaDataWithMasterLayer %@ (%@)", masterLayerName, masterLayerID);
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:childMetaData options:NSJSONWritingPrettyPrinted error:nil];
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        //BLOG(@"syncmetadata", @"%@", jsonString);
        
    }
}

+ (void) removeMetaDataWithType:(NSString*)typeStr DestMetaData:(NSMutableArray*)metadata
{
    if (nil == metadata || nil == typeStr) {
        return;
    }
    NSMutableIndexSet *idxSet = [[NSMutableIndexSet alloc] init];
    NSMutableArray* rmIndexList = [NSMutableArray array];
    for (int iMeta=0; iMeta<[metadata count]; iMeta++) {
        NSMutableDictionary* item  = [metadata objectAtIndex:iMeta];
        NSString* type = [item objectForKey:@"type"];
        
        if ([type isEqualToString:typeStr]) {
            [idxSet addIndex:iMeta];
        }
    }
    
    //do remove
    [metadata removeObjectsAtIndexes:idxSet];
}

+ (void) updateMetaDataWithType:(NSString*)typeStr MetaDataItemContent:(id)metadataItemContent DestMetaData:(NSMutableArray*)metadata
{
    if (nil == metadata || nil == metadata || nil == typeStr) {
        return;
    }
    bool bupadte = false;
    for (int iMeta=0; iMeta<[metadata count]; iMeta++) {
        NSMutableDictionary* item  = [metadata objectAtIndex:iMeta];
        NSString* type = [item objectForKey:@"type"];
        
        if ([type isEqualToString:typeStr]) {
            
            [item setObject:metadataItemContent forKey:@"content"];
            bupadte = true;
        }
    }
    
    if (!bupadte) {
        NSMutableDictionary* item  = [NSMutableDictionary dictionary];
        [item setObject:typeStr forKey:@"type"];
        [item setObject:metadataItemContent forKey:@"content"];
        [metadata addObject:item];
    }
}
+ (bool) tryInitDefaultMetaDataWithMaster:(id<MSLayer>)layer MetaData:(NSMutableArray*)metadata
{
    if (![[layer className] isEqualToString:@"MSSymbolInstance"]) {
        return false;
    }
    id<MSSymbolInstance> instance = layer;
    id<MSLayer> master = [instance symbolMaster];
    
    NSString* masterID = [master objectID];
    NSString* masterName = [master name];
    NSMutableArray* masterMetaData = [SketchCommon readLayerInfo:@"metadata" layer:master keyWord:@"tmnaMM"];
    if (nil == masterMetaData) {
        return false;
    }
    masterMetaData = [CJSONXConvertor convertXObjectToValidJsonFormatObject:masterMetaData];
    
    NSMutableDictionary* partsType = [self getDataByType:masterMetaData TYPE:@"Parts Type"];
    NSString* partsTypeStr = [partsType objectForKey:@"part"];
    if ([partsTypeStr isEqualToString:@"Select Part Type"]) {
        // nil parts type
        return false;
    }
    
    // check exist
    bool bAlreadExist = false;
    for (int iMeta=0; iMeta<[metadata count]; iMeta++) {
        NSMutableDictionary* item  = [metadata objectAtIndex:iMeta];
        NSMutableDictionary* partsType = [item objectForKey:@"Parts Type"];
        if (nil != partsType) {
            NSString* partsTypeStr = [partsType objectForKey:@"part"];
            if (![partsTypeStr isEqualToString:@"Select Part Type"]) {
                bAlreadExist = true;
                break;
            }
        }
    }
    
    if (!bAlreadExist) {
        
        for (int iMeta=0; iMeta<[masterMetaData count]; iMeta++) {
            NSMutableDictionary* item  = [masterMetaData objectAtIndex:iMeta];
            NSString* type = [item objectForKey:@"type"];
            
            if (![type isEqualToString:@"child"]) {
                
                NSMutableDictionary* content = [item objectForKey:@"content"];
                
                [self updateMetaDataWithType:type MetaDataItemContent:content DestMetaData:metadata];
            }
        }
        
        
        //BLOG(@"syncmetadata", @"    InitDefaultMetaDataWithMasterLayer %@ (%@)", masterLayerName, masterLayerID);
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:masterMetaData options:NSJSONWritingPrettyPrinted error:nil];
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        //BLOG(@"syncmetadata", @"%@", jsonString);
        
        return true;
    }
    else
    {
        return false;
    }
}

+ (void) tryInitDefaultScreenSpecConditionsWithMaster:(id<MSLayer>)layer ScreenSpecConditions:(NSMutableArray*)screenSpecConditions
{
    if (![[layer className] isEqualToString:@"MSSymbolInstance"]) {
        return;
    }
    id<MSSymbolInstance> instance = layer;
    NSString* objectID = [instance objectID];
    
    id<MSLayer> master = [instance symbolMaster];
    NSString* masterID = [master objectID];
    NSString* masterName = [master name];
    
    NSMutableDictionary* masterScreenSpecConditions = [SketchCommon readLayerInfo:@"screenSpecConditions" layer:master keyWord:@"tmnaMM"];
    if (nil == masterScreenSpecConditions) {
        return;
    }
    //masterScreenSpecConditions = [CJSONXConvertor convertXObjectToValidJsonFormatObject:masterScreenSpecConditions];
    
    NSString* swCondKeyMaster = [@"sWSelected__" stringByAppendingString:masterID];
    NSMutableDictionary* swCondMaster = [masterScreenSpecConditions objectForKey:swCondKeyMaster];
    if (nil != swCondMaster) {
        NSString* swCondKey = [@"sWSelected__" stringByAppendingString:objectID];
        [screenSpecConditions setValue:swCondMaster forKey:swCondKey];
    }
    
    NSString* displayCondKeyMaster = [@"displayCondition__" stringByAppendingString:masterID];
    NSMutableDictionary* displayCondMaster = [masterScreenSpecConditions objectForKey:displayCondKeyMaster];
    if (nil != displayCondMaster) {
        NSString* displayCondKey = [@"displayCondition__" stringByAppendingString:objectID];
        [screenSpecConditions setValue:displayCondMaster forKey:displayCondKey];
    }
    
    NSString* sWTonedownExceptInMotionMaster = [@"sWTonedownExceptInMotion__" stringByAppendingString:masterID];
    NSMutableDictionary* sWTonedownExceptInMotionCondMaster = [masterScreenSpecConditions objectForKey:sWTonedownExceptInMotionMaster];
    if (nil != sWTonedownExceptInMotionCondMaster) {
        NSString* sWTonedownExceptInMotionKey = [@"sWTonedownExceptInMotion__" stringByAppendingString:objectID];
        [screenSpecConditions setValue:sWTonedownExceptInMotionCondMaster forKey:sWTonedownExceptInMotionKey];
    }
    
    NSString* sWTonedownMotionMaster = [@"sWTonedownMotion__" stringByAppendingString:masterID];
    NSMutableDictionary* sWTonedownMotionMasterCondMaster = [masterScreenSpecConditions objectForKey:sWTonedownMotionMaster];
    if (nil != sWTonedownMotionMasterCondMaster) {
        NSString* sWTonedownMotionKey = [@"sWTonedownMotion__" stringByAppendingString:objectID];
        [screenSpecConditions setValue:sWTonedownMotionMasterCondMaster forKey:sWTonedownMotionKey];
    }
    
    NSString* textImageDeleteInMotionMaster = [@"textImageDeleteInMotion__" stringByAppendingString:masterID];
    NSMutableDictionary* textImageDeleteInMotionCondMaster = [masterScreenSpecConditions objectForKey:textImageDeleteInMotionMaster];
    if (nil != textImageDeleteInMotionCondMaster) {
        NSString* textImageDeleteInMotionKey = [@"textImageDeleteInMotion__" stringByAppendingString:objectID];
        [screenSpecConditions setValue:textImageDeleteInMotionCondMaster forKey:textImageDeleteInMotionKey];
    }
    
}

+ (void) updateLayerMetaDatas:(id<MSLayer>)layer
{
    BLOG(@"syncmetadata", @"updateLayerMetaDatas %@", [layer name]);
    
    // get metadata
    NSMutableArray* metadata = [SketchCommon readLayerInfo:@"metadata" layer:layer keyWord:@"tmnaMM"];
    if (nil == metadata) {
        metadata = [NSMutableArray array];
    }
    metadata = [CJSONXConvertor convertXObjectToValidJsonFormatObject:metadata];
    bool bUpdated = [self tryInitDefaultMetaDataWithMaster:layer MetaData:metadata];
    
    // get condition
    NSMutableDictionary* screenSpecConditions = [SketchCommon readLayerInfo:@"screenSpecConditions" layer:layer keyWord:@"tmnaMM"];
    if (nil == screenSpecConditions) {
        screenSpecConditions = [NSMutableDictionary dictionary];
    }
    screenSpecConditions = [CJSONXConvertor convertXObjectToValidJsonFormatObject:screenSpecConditions];
    if (bUpdated) {
        [self tryInitDefaultScreenSpecConditionsWithMaster:layer ScreenSpecConditions:screenSpecConditions];
    }
    
    NSMutableArray* subPartsItemList = [MetadataUtils getSymbolInstanceSubPartsLayersHMISpec:layer];
    for (int iSubPartsItem=0; iSubPartsItem<[subPartsItemList count]; iSubPartsItem++) {
        NSMutableDictionary* subPartsItem = [subPartsItemList objectAtIndex:iSubPartsItem];
        NSString* absID = [subPartsItem objectForKey:@"absoluteObjectID"];
        if (![absID isEqualToString:[layer objectID]]) {
            [self tryInitDefaultMetaDataWithMasterLayer:subPartsItem MetaData:metadata];
        }
    }
    
    // set new metadata
    id<MSPluginCommand> command = [SketchCommon command];
    //    NSMutableArray* jsonObj = [CJSONXConvertor convertXObjectToValidJsonFormatObject:metadata];
    //    NSError* error = nil;
    //    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:jsonObj options:NSJSONWritingPrettyPrinted error:&error];
    //    NSString* jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    //[command setValue:metadata forKey:@"metadata" onLayer:layer forPluginIdentifier:@"tmnaMM"];
    
    [SketchCommon writeLayerInfo:@"metadata" value:metadata layer:layer keyWord:@"tmnaMM"];
    [SketchCommon writeLayerInfo:@"screenSpecConditions" value:screenSpecConditions layer:layer keyWord:@"tmnaMM"];
    
    //BLOG(@"syncmetadata", @"updateLayerMetaDatas %@ over", [layer name]);
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:metadata options:NSJSONWritingPrettyPrinted error:nil];
    NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    //BLOG(@"syncmetadata", @"%@", jsonString);
}

+ (void) update
{
    BLOG(@"syncmetadata", @"UpdateMetadata update");
    
    NSMutableArray* selections = [SketchCommon selection];
    for (int iSel=0; iSel<[selections count]; iSel++) {
        id<MSLayer> selLayer = [selections objectAtIndex:iSel];
        
        if ([[selLayer className] isEqualToString:@"MSSymbolInstance"]) {
            [self updateLayerMetaDatas:selLayer];
        }
    }
    
    BLOG(@"syncmetadata", @"UpdateMetadata update over");
}

@end
