 //
//  MetadataUtils.m
//  TMNAFramework
//
//  Created by nb on 2019/1/21.
//

#import <Foundation/Foundation.h>
#import "MetadataUtils.h"
#include "ExportHMISpec.h"

static ExportHMISpec* s_exportHMISpec = nil;

ExportHMISpec* getExportHMISpecInstance()
{
    if (nil == s_exportHMISpec) {
        s_exportHMISpec = [[ExportHMISpec alloc] init];
    }
    return s_exportHMISpec;
}

@implementation SketchTreeExpandPolicyHMISpec
- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer
{
    id layer = currentLayer;
    if ([[currentLayer symbolMaster] symbolID] != [[expandLayer symbolMaster] symbolID]) {
        layer = [expandLayer symbolMaster];
    }

    ExportHMISpec* exportHMISpec = getExportHMISpecInstance();
    bool isExpand =  [exportHMISpec checkIsContinue:0 correspondLayer:expandLayer layer:layer];
    if (isExpand) {
        return NSIntegerMax;
    }
    else{
        return -1;
    }
}
@end

@implementation MetadataUtils



+ (void) pushIfNotContains:(id<MSLayer>)layer List:(NSMutableArray*) list
{
    NSString* layerObjectID = [layer objectID];
    bool contains = false;
    
    for (int i=0; i<[list count]; i++) {
        id<MSLayer> oneLayer = [list objectAtIndex:i];
        NSString* oneLayerID = [oneLayer objectID];
        if ([oneLayerID isEqualToString:layerObjectID]) {
            contains = true;
        }
    }
    
    if (!contains) {
        [list addObject:layer];
    }
}

+ (void) addToResult:(id<MSLayer>)layer List:(NSMutableArray*) resultList
{
    ExportHMISpec* exportHMISpec = getExportHMISpecInstance();
    
    NSString* className = [layer className];
    if ([className isEqualToString:@"MSSymbolInstance"]) {
        bool isNeedExport =  [exportHMISpec checkIsNeedExport:layer correspondLayer:nil level:0];
        bool isExpand =  [exportHMISpec checkIsContinue:0 correspondLayer:nil layer:layer];
        bool isLayerIgnored =  [exportHMISpec isLayerIgnored:layer];
        if (isNeedExport) {
            if (!isLayerIgnored) {
                [self pushIfNotContains:layer List:resultList];
            };
        };
        if (isExpand) {
            id<MSSymbolInstance> instance = layer;
            NSArray* subLayers = [[instance symbolMaster] layers];
            if (nil != subLayers) {
                for (int iSubLayer=0; iSubLayer<[subLayers count]; iSubLayer++) {
                    id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
                    [self addToResult:subLayer List:resultList];
                }
            }
        };
    }
    else
    {
        NSArray* subLayers = [layer layers];
        if (nil != subLayers) {
            for (int iSubLayer=0; iSubLayer<[subLayers count]; iSubLayer++) {
                id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
                [self addToResult:subLayer List:resultList];
            }
        }
    }
}

+ (NSMutableArray*) getSymbolInstanceSubPartsLayers:(id<MSLayer>)layer
{
    NSMutableArray* resultList = [NSMutableArray array];
    
    [self addToResult:layer List:resultList];
    
    return resultList;
}


+ (void) addToResultJS:(id<MSLayer>)layer List:(NSMutableArray*) resultList Level:(int)level
{
    level = level + 1;

    if (level > 2) {
        return;
    }
    
    NSString* className = [layer className];
    if ([className isEqualToString:@"MSSymbolInstance"]) {
        
        if (0 != level) {
            [self pushIfNotContains:layer List:resultList];
        }
        
        id<MSSymbolInstance> instance = layer;
        if ([[instance symbolMaster] containsLayers]) {
            NSArray* subLayers = [[instance symbolMaster] layers];
            if (nil != subLayers) {
                for (int iSubLayer=0; iSubLayer<[subLayers count]; iSubLayer++) {
                    id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
                    [self addToResultJS:subLayer List:resultList Level:level];
                }
            }
        }
    }
    else
    {
        if ([layer containsLayers]) {
            NSArray* subLayers = [layer layers];
            if (nil != subLayers) {
                for (int iSubLayer=0; iSubLayer<[subLayers count]; iSubLayer++) {
                    id<MSLayer> subLayer = [subLayers objectAtIndex:iSubLayer];
                    [self addToResultJS:subLayer List:resultList Level:level];
                }
            }
        }
    }
}

+ (NSMutableArray*) getSymbolInstanceSubPartsLayersJS:(id<MSLayer>)layer
{
    NSMutableArray* resultList = [NSMutableArray array];
    
    [self addToResultJS:layer List:resultList Level:-1];
    
    return resultList;
}

+ (NSMutableArray*) getSymbolInstanceSubPartsLayersHMISpec:(id<MSLayer>)layer
{
    NSMutableArray* resultList = [NSMutableArray array];
    
    if ([[layer className] isEqualToString:@"MSSymbolInstance"]) {
        [[CoreDataEngine instance] reset];
        SketchTreeExpandPolicyHMISpec* expandPolicy = [[SketchTreeExpandPolicyHMISpec alloc] init];
        [[CoreDataEngine instance] setSketchTreeExpandPolicy:expandPolicy];
        
        CoreDataTree* coreDataTree = [[CoreDataEngine instance] coreDataLayerTree:layer];
        [coreDataTree load];
        
        CoreDataIterator* it = [coreDataTree rootIterator];
        [self getSymbolInstanceSubPartsLayersHMISpec_visit:it AbsolutePath: [it name] ResultList:resultList];
        
        [coreDataTree unload];
    }
    else
    {
        NSMutableDictionary* item = [NSMutableDictionary dictionary];
        [item setObject:layer forKey:@"layer"];
        [item setObject:[layer objectID]  forKey:@"absoluteObjectID"];
        [resultList addObject:item];
    }

    return resultList;
}

+ (void) getSymbolInstanceSubPartsLayersHMISpec_visit:(CoreDataIterator*)it AbsolutePath:(NSString*)absolutePath ResultList:(NSMutableArray*)resultList
{
    ExportHMISpec* exportHMISpec = getExportHMISpecInstance();
    
    NSString* absoluteObjectID = [it absoluteObjectID];
//    BLOG(@"Debug", @"absoluteObjectID:%@", absoluteObjectID);
//    if ([absoluteObjectID isEqualToString:@"1812F83F-1825-4587-85F1-5222D95EDBC5_2BDFC46D-9848-42A5-8443-14A5B44822E2_6E120D28-13FF-488A-A56C-941595B48B2D_74A8A119-1C59-4159-8849-D39C1DB39A56_E0E9E028-048A-4B52-A7AE-4F636BC853B5"]) {
//        BLOG(@"Debug", @"");
//    }
    NSString* objectID = [it objectID];
    NSString* name = [it name];
    NSString* className = [it className];
    NSString* type = [it type];
    id<MSLayer> currentLayer = [it originLayer];
    if ([[it type] isEqualToString:CoreDataIteratorType_Replaced]) {
        currentLayer = [it replacedLayerMaster];
    }
    id<MSLayer> expandLayer = [it expandLayer];
    bool bExport = [exportHMISpec checkIsNeedExport:currentLayer correspondLayer:expandLayer level:0];
    if (bExport) {
        NSMutableDictionary* item = [NSMutableDictionary dictionary];
        [item setObject:currentLayer forKey:@"layer"];
        [item setObject:absoluteObjectID forKey:@"absoluteObjectID"];
        [resultList addObject:item];
    }

    // visit childrens nodes
    NSArray<CoreDataIterator*>* childrens = [it childrens];
    for (int iChild=0; iChild<[childrens count]; iChild++) {
        CoreDataIterator* childIt = [childrens objectAtIndex:iChild];
        
        NSString* subPosition = [absolutePath stringByAppendingString:@"->"];
        subPosition = [subPosition stringByAppendingString:[childIt name]];
        [self getSymbolInstanceSubPartsLayersHMISpec_visit:childIt AbsolutePath:subPosition ResultList:resultList];
    }
}


@end
