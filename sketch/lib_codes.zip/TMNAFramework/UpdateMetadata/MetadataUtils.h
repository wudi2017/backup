//
//  MetadataUtils.h
//  TMNAFramework
//
//  Created by nb on 2019/1/21.
//

#ifndef MetadataUtils_h
#define MetadataUtils_h

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "Sketch.h"
#import "CLog.h"
#import "SketchCommon.h"
#import "CoreDataEngine.h"

@interface SketchTreeExpandPolicyHMISpec : SketchTreeExpandPolicy
- (NSInteger) instanceDetachLevel:(id<MSSymbolInstance>)currentLayer ExpandLayer:(id<MSSymbolInstance>)expandLayer;
@end

@interface MetadataUtils : NSObject

+ (NSMutableArray*) getSymbolInstanceSubPartsLayers:(id<MSLayer>)layer;

+ (NSMutableArray*) getSymbolInstanceSubPartsLayersJS:(id<MSLayer>)layer;

+ (NSMutableArray*) getSymbolInstanceSubPartsLayersHMISpec:(id<MSLayer>)layer;

@end

#endif /* MetadataUtils_h */
