//
//  UpdateMetadata.h
//  TMNAFramework
//
//  Created by nb on 2019/1/21.
//

#ifndef UpdateMetadata_h
#define UpdateMetadata_h

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "Sketch.h"
#import "CLog.h"
#import "SketchCommon.h"
#import "MetadataUtils.h"

@interface UpdateMetadata : NSObject

+ (void) update;

@end


#endif /* UpdateMetadata_h */
