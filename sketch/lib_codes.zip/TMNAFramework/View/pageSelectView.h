//
//  pageSelectView.h
//  TMNAFramework
//
//  Created by wuyuchi on 2018/12/24.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

// delegate
@interface pageSelectViewDelegate : NSObject

-(void)onUbindscreen:(NSDictionary*)param;
-(void)onOKBtn:(NSDictionary*)param;

@end

@interface pageSelectView : NSObject <NSTableViewDelegate>

//+ (instancetype)shared;
- (void) startShowPageInfo;
-(void)setDelegage:(pageSelectViewDelegate*)delegage;
-(IBAction)onOKBtn:(id)sender;
//- (NSPanel *) getPanel;

@property IBOutlet NSPanel* m_selectPanel;
@property IBOutlet NSButton* m_btnOk;
@property IBOutlet NSButton* m_btnSelectedAll;
@property IBOutlet NSButton* m_btnCancelSeledted;
@property IBOutlet NSView*   m_scrollView;
@property IBOutlet NSTextField*  m_selectedLabel;
@property NSMutableDictionary*   m_selectedPageNames;
@property NSMutableArray*        m_pageNames;
@property NSUInteger             m_maxArtboardNum;
@property NSUInteger             m_curArtboardNum;
@property NSMutableDictionary*   m_pagesInfoDic;  //{"page":obj,"artboardNum":x,"button":obj}
@property NSMutableDictionary*   m_pageArtboardNumDic;

@property pageSelectViewDelegate* m_delegate;

@end

NS_ASSUME_NONNULL_END
