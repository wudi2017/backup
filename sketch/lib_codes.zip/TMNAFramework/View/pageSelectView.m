//
//  pageSelectView.m
//  TMNAFramework
//
//  Created by wuyuchi on 2018/12/24.
//

#import "pageSelectView.h"
#import "Sketch.h"
#import "CLog.h"
#import "SketchCommon.h"
#import "ExportHMISpec.h"
#import "ExportTMNASpec.h"

@implementation pageSelectViewDelegate

-(void)onUbindscreen:(NSDictionary*)param{
    
}
-(void)onOKBtn:(NSDictionary*)param {
    
}

@end

@implementation pageSelectView

-(instancetype)init {
    self = [super init];
    if (![[NSBundle bundleForClass: [self class]] loadNibNamed:@"pageSelectView" owner:self topLevelObjects:nil])
    {
        NSLog(@"load error");
    }
    self.m_maxArtboardNum = 300;
    self.m_curArtboardNum = 0;
    self.m_pagesInfoDic = [NSMutableDictionary dictionary];
    self.m_selectedPageNames = [NSMutableDictionary dictionary];
    [self.m_selectPanel setLevel:NSModalPanelWindowLevel];
    [self.m_selectPanel makeKeyAndOrderFront:nil];
    [self.m_selectPanel center];
    self.m_pageNames =  [NSMutableArray array];
    NSString* selectedValue = [NSString stringWithFormat:@"0/%ld",self.m_maxArtboardNum];
    [self.m_selectedLabel setStringValue:selectedValue];
    //self.m_pageArtboardNumDic = [NSMutableDictionary dictionary];
    return self;
}

//+ (instancetype)shared {
//    static pageSelectView *manager = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        manager = [[pageSelectView alloc] init];
//    });
//    
//    return manager;
//}

-(IBAction)onOKBtn:(id)sender{
    NSLog(@"onOKBtn");
//    ExportHMISpec* exportHMISpecObj = [[ExportHMISpec alloc] init];
//    [exportHMISpecObj setPageSelectConfig:self.m_selectedPageNames];
//    [exportHMISpecObj startExportHMISpec];
//    NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:exportHMISpecObj.m_resFilePath,@"path", nil];
//    [self.m_delegate onOKBtn:self.m_selectedPageNames];
    ExportTMNASpec* exportTMNASpecObj = [[ExportTMNASpec alloc] init];
    [exportTMNASpecObj setPageSelectConfig:self.m_selectedPageNames];
    BOOL flag = [exportTMNASpecObj startExportHMISpec];
    if(flag == true){
        NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:exportTMNASpecObj.m_resFilePath,@"path", nil];
        [self.m_delegate onOKBtn:dic];
    }
    BLOG(BLOGTAG_PERFORMANCE, @"onOKBtn oc end!");
    [self.m_selectPanel close];
}


-(IBAction)onSelectedAllBtn:(id)sender{
    for(NSInteger pageNum=0;pageNum<[self.m_pageNames count];pageNum++){
        NSString* curpageName = [self.m_pageNames objectAtIndex:pageNum];
        NSDictionary* curPageInfo = [self.m_pagesInfoDic objectForKey:curpageName];
        if(curPageInfo){
            NSButton* curBtn = [curPageInfo objectForKey:@"button"];
            if(curBtn){
                if([curBtn state] == NSOffState){
                    NSInteger curpageArtboardNum = [[curPageInfo objectForKey:@"artboardNum"] intValue];
                    if(self.m_curArtboardNum + curpageArtboardNum > self.m_maxArtboardNum){
                        NSString* selectedValue = [NSString stringWithFormat:@"%ld/%ld",self.m_curArtboardNum,self.m_maxArtboardNum];
                        [self.m_selectedLabel setStringValue:selectedValue];
                        break;
                    }
                    else{
                        [curBtn setState:NSOnState];
                        self.m_curArtboardNum += curpageArtboardNum;
                        [self.m_selectedPageNames setValue:[NSNumber numberWithBool:true]  forKey:curpageName];
                    }
                }
            }
            
        }
    }
    [self updateSelecteStatus];
}

-(IBAction)onCacelSelectedBtn:(id)sender {
    for(NSInteger pageNum=0;pageNum<[self.m_pageNames count];pageNum++){
        NSString* curpageName = [self.m_pageNames objectAtIndex:pageNum];
        NSDictionary* curPageInfo = [self.m_pagesInfoDic objectForKey:curpageName];
        if(curPageInfo){
            NSButton* curBtn = [curPageInfo objectForKey:@"button"];
            [self.m_selectedPageNames setValue:[NSNumber numberWithBool:false]  forKey:curpageName];
            if(curBtn){
                [curBtn setState:NSOffState];
                [curBtn setEnabled:true];
            }
        }
    }
    NSString* selectedValue = [NSString stringWithFormat:@"0/%ld",self.m_maxArtboardNum];
    [self.m_selectedLabel setStringValue:selectedValue];
}

-(IBAction)onPageSelected:(id)sender
{
    NSLog(@"onPageSelected");
    NSButton* curbtn = (NSButton*)sender;
    NSString* pageName = [curbtn title];
    BOOL flag = false;
    NSLog(@" %@",[self.m_selectedPageNames valueForKey:pageName]);
    if([[self.m_selectedPageNames valueForKey:pageName] boolValue]){
        flag = true;
    }
    if([curbtn state] == NSOnState){
        [self.m_selectedPageNames setValue:[NSNumber numberWithBool:true]  forKey:pageName];
        NSLog(@"change on %@",pageName);
        if(!flag && [self.m_pagesInfoDic objectForKey:pageName]){
            NSMutableDictionary* curPageInfo = [self.m_pagesInfoDic objectForKey:pageName];
            long int curPageArtNum = [[curPageInfo objectForKey:@"artboardNum"] intValue];
            self.m_curArtboardNum += curPageArtNum;
        }
    }
    else{
        [self.m_selectedPageNames setValue:[NSNumber numberWithBool:false]  forKey:pageName];
        NSLog(@"change off %@",pageName);
        if(flag && [self.m_pagesInfoDic objectForKey:pageName]){
            NSMutableDictionary* curPageInfo = [self.m_pagesInfoDic objectForKey:pageName];
            NSUInteger curPageArtNum = [[curPageInfo objectForKey:@"artboardNum"] intValue];
            self.m_curArtboardNum -= curPageArtNum;
        }
    }
    NSString* selectedValue = [NSString stringWithFormat:@"%ld/%ld",self.m_curArtboardNum,self.m_maxArtboardNum];
    [self.m_selectedLabel setStringValue:selectedValue];
    [self updateSelecteStatus];
}

-(void)setDelegage:(pageSelectViewDelegate*)delegage
{
    BLOG(BLOGTAG_PERFORMANCE, @"setDelegage oc!");
    self.m_delegate = delegage;
}

- (void) startShowPageInfo
{
    [self makePageNames];
    double heigth = self.m_scrollView.frame.size.height;
    if([self.m_pageNames count]*25.0 > heigth){
        heigth = [self.m_pageNames count]*25+15;
        double width = self.m_scrollView.frame.size.width;
        [self.m_scrollView setFrame:NSMakeRect(0, 0, width, heigth)];
    }
    for(NSInteger pagesNum=0;pagesNum<[self.m_pageNames count];pagesNum++)
    {
        NSString* curPageName = [self.m_pageNames objectAtIndex:pagesNum];
        NSButton* button = [[NSButton alloc] initWithFrame:NSMakeRect(15, heigth - 40 - 25*pagesNum, 300, 20)];
        [button setImagePosition:NSNoImage];
        [button setButtonType:NSButtonTypeSwitch];
        [button setTitle:curPageName];
        [button setState:NSOffState];
        [button setTarget:self];
        [button setAction:@selector(onPageSelected:)];
        [self.m_scrollView addSubview:button];
        NSMutableDictionary* curPageInfo = [self.m_pagesInfoDic objectForKey:curPageName];
        if(curPageInfo){
            [curPageInfo setObject:button forKey:@"button"];
        }
    }
}

- (void) makePageNames
{
    id<MSDocument> doc = SketchCommon.document;
    NSArray* pages = [doc pages];
    for(NSInteger pageNum=0;pageNum<[pages count];pageNum++){
        id<MSPage> curpage = [pages objectAtIndex:pageNum];
        NSString* curPageName = [curpage name];
        if([SketchCommon isPageIgnored:curpage]){
            continue;
        }
        NSInteger curartboardNum = [[curpage artboards] count];
        NSMutableDictionary* curPageInfo = [NSMutableDictionary dictionary];
        [curPageInfo setObject:curpage forKey:@"page"];
        [curPageInfo setObject:[NSNumber numberWithInteger:curartboardNum] forKey:@"artboardNum"];
        [self.m_pagesInfoDic setValue:curPageInfo forKey:curPageName];
        [self.m_pageNames addObject:curPageName];
        [self.m_selectedPageNames setValue:[NSNumber numberWithBool:false]  forKey:curPageName];
    }
//    NSArray* test = [[NSArray alloc] initWithObjects:@"NormalLabel",@"MultilineText",@"MultipleImage",@"NormalImage", nil];
//    for(NSInteger testNum=0;testNum<[test count];testNum++)
//    {
//        NSString* curpagenName = [test objectAtIndex:testNum];
//        [self.m_pageNames addObject:curpagenName];
//        [self.m_selectedPageNames setValue:[NSNumber numberWithBool:false]  forKey:curpagenName];
//        NSMutableDictionary* curPageInfo = [NSMutableDictionary dictionary];
//        [curPageInfo setValue:nil forKey:@"page"];
//        [curPageInfo setObject:[NSNumber numberWithInteger:20+5*testNum] forKey:@"artboardNum"];
//        [self.m_pagesInfoDic setValue:curPageInfo forKey:curpagenName];
//    }
}

-(void) updateSelecteStatus
{
    for(NSInteger pageNum=0;pageNum<[self.m_pageNames count];pageNum++){
        NSString* curpageName = [self.m_pageNames objectAtIndex:pageNum];
        NSDictionary* curPageInfo = [self.m_pagesInfoDic objectForKey:curpageName];
        if(curPageInfo){
            NSButton* curBtn = [curPageInfo objectForKey:@"button"];
            if(curBtn){
                if([curBtn state] == NSOffState){
                    NSInteger curpageArtboardNum = [[curPageInfo objectForKey:@"artboardNum"] intValue];
                    if(self.m_curArtboardNum == 0){
                        [curBtn setEnabled:true];
                    }
                    else {
                        if(self.m_curArtboardNum + curpageArtboardNum > self.m_maxArtboardNum){
                            [curBtn setEnabled:false];
                        }
                        else{
                            [curBtn setEnabled:true];
                        }
                    }
                }
            }
            
        }
    }
}

@end
